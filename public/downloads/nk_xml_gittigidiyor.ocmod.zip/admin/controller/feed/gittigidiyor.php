<?php
namespace Opencart\Admin\Controller\Extension\NkXmlGittigidiyor\Feed;

class Gittigidiyor extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/nk_xml_gittigidiyor/feed/gittigidiyor');
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
        $this->load->model('setting/setting');
        $setting_info = $this->model_setting_setting->getSetting('feed_gittigidiyor', $store_id);

        $defaults = [
            'feed_gittigidiyor_status' => '0',
            'feed_gittigidiyor_language_id' => (string)$this->config->get('config_language_id'),
            'feed_gittigidiyor_currency_code' => (string)$this->config->get('config_currency'),
            'feed_gittigidiyor_cache_hours' => '6',
            'feed_gittigidiyor_token' => $this->createToken(),
            'feed_gittigidiyor_excluded_categories' => []
        ];

        $data = [];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($setting_info[$key]) && $setting_info[$key] !== '') {
                $data[$key] = $setting_info[$key];
            } else {
                $data[$key] = $default;
            }
        }

        if (!is_array($data['feed_gittigidiyor_excluded_categories'])) {
            $data['feed_gittigidiyor_excluded_categories'] = $data['feed_gittigidiyor_excluded_categories'] !== '' ? explode(',', (string)$data['feed_gittigidiyor_excluded_categories']) : [];
        }

        $data['feed_gittigidiyor_excluded_categories'] = array_map('intval', $data['feed_gittigidiyor_excluded_categories']);

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_feed'] = $this->language->get('text_feed');
        $data['text_last_generated'] = $this->language->get('text_last_generated');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_language_id'] = $this->language->get('entry_language_id');
        $data['entry_currency_code'] = $this->language->get('entry_currency_code');
        $data['entry_cache_hours'] = $this->language->get('entry_cache_hours');
        $data['entry_token'] = $this->language->get('entry_token');
        $data['entry_excluded_categories'] = $this->language->get('entry_excluded_categories');
        $data['help_feed_url'] = $this->language->get('help_feed_url');
        $data['help_token'] = $this->language->get('help_token');
        $data['button_copy'] = $this->language->get('button_copy');
        $data['button_clear_cache'] = $this->language->get('button_clear_cache');
        $data['button_regenerate'] = $this->language->get('button_regenerate');

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $this->load->model('localisation/currency');
        $data['currencies'] = array_values($this->model_localisation_currency->getCurrencies());

        $this->load->model('catalog/category');
        $data['categories'] = $this->model_catalog_category->getCategories();

        $cache_file = $this->cacheFile($store_id);
        $data['last_generated'] = is_file($cache_file) ? date('Y-m-d H:i:s', filemtime($cache_file)) : $this->language->get('text_not_generated');

        $data['feed_url'] = html_entity_decode($this->config->get('config_url') . 'index.php?route=extension/nk_xml_gittigidiyor/feed/gittigidiyor&token=' . rawurlencode((string)$data['feed_gittigidiyor_token']), ENT_QUOTES, 'UTF-8');
        $data['save'] = $this->url->link('extension/nk_xml_gittigidiyor/feed/gittigidiyor.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['clear_cache'] = $this->url->link('extension/nk_xml_gittigidiyor/feed/gittigidiyor.clearCache', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed');

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_xml_gittigidiyor/feed/gittigidiyor', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_xml_gittigidiyor/feed/gittigidiyor', $data));
    }

    public function save(): void {
        $this->load->language('extension/nk_xml_gittigidiyor/feed/gittigidiyor');
        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_xml_gittigidiyor/feed/gittigidiyor')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            $post = $this->request->post;

            // Only the known keys are stored, so nothing else can be written
            // into the feed_gittigidiyor setting group.
            $save = [];

            $save['feed_gittigidiyor_status'] = !empty($post['feed_gittigidiyor_status']) ? '1' : '0';

            $this->load->model('localisation/language');
            $language_id = isset($post['feed_gittigidiyor_language_id']) ? (int)$post['feed_gittigidiyor_language_id'] : 0;

            if (!$language_id || !$this->model_localisation_language->getLanguage($language_id)) {
                $language_id = (int)$this->config->get('config_language_id');
            }

            $save['feed_gittigidiyor_language_id'] = (string)$language_id;

            $this->load->model('localisation/currency');
            $currency_code = isset($post['feed_gittigidiyor_currency_code']) ? (string)$post['feed_gittigidiyor_currency_code'] : '';

            if ($currency_code === '' || !$this->model_localisation_currency->getCurrencyByCode($currency_code)) {
                $currency_code = (string)$this->config->get('config_currency');
            }

            $save['feed_gittigidiyor_currency_code'] = $currency_code;

            $save['feed_gittigidiyor_cache_hours'] = in_array((string)($post['feed_gittigidiyor_cache_hours'] ?? '6'), ['1', '6', '12', '24'], true) ? (string)$post['feed_gittigidiyor_cache_hours'] : '6';

            $token = isset($post['feed_gittigidiyor_token']) ? trim((string)$post['feed_gittigidiyor_token']) : '';

            if (!preg_match('/^[A-Za-z0-9_-]{16,64}$/', $token)) {
                $token = $this->createToken();
            }

            $save['feed_gittigidiyor_token'] = $token;

            $save['feed_gittigidiyor_excluded_categories'] = [];

            if (isset($post['feed_gittigidiyor_excluded_categories']) && is_array($post['feed_gittigidiyor_excluded_categories'])) {
                foreach ($post['feed_gittigidiyor_excluded_categories'] as $category_id) {
                    $category_id = (int)$category_id;

                    if ($category_id > 0 && !in_array($category_id, $save['feed_gittigidiyor_excluded_categories'], true)) {
                        $save['feed_gittigidiyor_excluded_categories'][] = $category_id;
                    }
                }
            }

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('feed_gittigidiyor', $save, $store_id);

            // Settings changed, so the cached feed is stale.
            $this->deleteCache($store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function clearCache(): void {
        $this->load->language('extension/nk_xml_gittigidiyor/feed/gittigidiyor');
        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_xml_gittigidiyor/feed/gittigidiyor')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            $this->deleteCache($store_id);

            $json['success'] = $this->language->get('text_cache_cleared');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $setting_info = $this->model_setting_setting->getSetting('feed_gittigidiyor');

        $defaults = [
            'feed_gittigidiyor_status' => '0',
            'feed_gittigidiyor_language_id' => (string)$this->config->get('config_language_id'),
            'feed_gittigidiyor_currency_code' => (string)$this->config->get('config_currency'),
            'feed_gittigidiyor_cache_hours' => '6',
            'feed_gittigidiyor_token' => $this->createToken(),
            'feed_gittigidiyor_excluded_categories' => []
        ];

        // A re-install keeps whatever was configured before.
        foreach ($defaults as $key => $value) {
            if (isset($setting_info[$key]) && $setting_info[$key] !== '') {
                $defaults[$key] = $setting_info[$key];
            }
        }

        $this->model_setting_setting->editSetting('feed_gittigidiyor', $defaults);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('feed_gittigidiyor');

        foreach ((array)glob(DIR_CACHE . 'nk_feed_gittigidiyor_*.xml') as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
    }

    protected function cacheFile(int $store_id): string {
        return DIR_CACHE . 'nk_feed_gittigidiyor_' . $store_id . '.xml';
    }

    protected function deleteCache(int $store_id): void {
        $cache_file = $this->cacheFile($store_id);

        if (is_file($cache_file)) {
            unlink($cache_file);
        }
    }

    protected function createToken(): string {
        return bin2hex(random_bytes(16));
    }
}
