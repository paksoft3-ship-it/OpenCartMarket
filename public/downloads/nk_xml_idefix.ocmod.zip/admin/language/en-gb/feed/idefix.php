<?php
$_['heading_title']                  = 'NovaKur İdefix Feed';

$_['text_extension']                 = 'Extensions';
$_['text_success']                   = 'Success: You have modified İdefix feed settings!';
$_['text_edit']                      = 'Edit İdefix Feed';
$_['text_enabled']                   = 'Enabled';
$_['text_disabled']                  = 'Disabled';
$_['text_default_store']             = 'Default Store';
$_['text_cache_cleared']             = 'Feed cache has been cleared.';
$_['text_feed_url']                  = 'Feed URL';
$_['text_feed_status']               = 'Feed Status';
$_['text_last_generated']            = 'Last Generated';
$_['text_not_generated']             = 'Not generated yet';
$_['text_book_fields']               = 'Book Fields';

$_['entry_status']                   = 'Status';
$_['entry_store']                    = 'Store';
$_['entry_currency']                 = 'Currency';
$_['entry_language']                 = 'Language';
$_['entry_include_out_of_stock']     = 'Include Out Of Stock';
$_['entry_include_tax']              = 'Prices Include KDV';
$_['entry_author_attribute']         = 'Author Attribute';
$_['entry_publisher_attribute']      = 'Publisher Attribute';
$_['entry_page_count_attribute']     = 'Page Count Attribute';
$_['entry_max_products']             = 'Maximum Products';
$_['entry_cache_hours']              = 'Cache Duration (Hours)';
$_['entry_excluded_categories']      = 'Excluded Categories';
$_['entry_token']                    = 'Feed Token';

$_['help_feed_url']                  = 'Hand this URL to your İdefix integration contact. It contains the feed token, so treat it as a secret.';
$_['help_excluded_categories']       = 'Products in the selected categories will be excluded from the feed.';
$_['help_include_tax']               = 'Turkish marketplaces expect KDV inclusive prices. The exported VatRate is derived from each product\'s OpenCart tax class, so a 0% class exports as 0.';
$_['help_max_products']              = 'Hard cap on the number of products written to the feed. 0 means no limit. Products are read from the database in batches of 250 either way.';
$_['help_token']                     = 'Required. The feed URL only answers when this token is supplied, otherwise the route returns 404.';
$_['help_book_fields']               = 'Optional. Map the OpenCart attributes that hold book metadata. ISBN is taken automatically from the product identifiers (product code or legacy ISBN column). Every other product attribute is exported inside the generic Attributes block.';

$_['button_copy']                    = 'Copy';
$_['button_clear_cache']             = 'Clear Cache';
$_['button_regenerate_token']        = 'Regenerate Token';

$_['error_permission']               = 'Warning: You do not have permission to modify İdefix feed!';
$_['error_currency']                 = 'Select a currency that exists in your store!';
$_['error_token']                    = 'The feed token must be 16 to 64 letters or digits!';
