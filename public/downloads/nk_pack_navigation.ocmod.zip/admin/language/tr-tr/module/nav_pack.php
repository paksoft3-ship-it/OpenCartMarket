<?php
// Heading
$_['heading_title']           = 'NovaKur Mega Menü + Mobil Navigasyon Paketi';

// Text
$_['text_extension']          = 'Eklentiler';
$_['text_success']            = 'Başarılı: NovaKur Navigasyon Paketi ayarlarını güncellediniz!';
$_['text_edit']               = 'NovaKur Mega Menü + Mobil Navigasyon Paketini Düzenle';
$_['text_enabled']            = 'Etkin';
$_['text_disabled']           = 'Devre dışı';
$_['text_features']           = 'Özellikler';
$_['text_layout']             = 'Yerleşim';
$_['text_promo']              = 'Tanıtım Kutuları';
$_['text_no_promo']           = 'Henüz tanıtım kutusu yok. Mega menü panelinin içine afiş yerleştirmek için bir satır ekleyin.';
$_['text_coexist']            = 'Bu paket kendi mega menüsüyle gelir. Bağımsız NovaKur Mega Menü modülünü de kullanıyorsanız iki masaüstü menüsünden birini kapatın — ayarları ayrıdır, aksi hâlde ikisi birden görüntülenir.';

// Entry
$_['entry_status']            = 'Durum';
$_['entry_mega_status']       = 'Masaüstü mega menü';
$_['entry_mobile_status']     = 'Mobil çekmece menü';
$_['entry_sticky_status']     = 'Yapışkan başlık';
$_['entry_breadcrumb_status'] = 'Breadcrumb JSON-LD';
$_['entry_show_images']       = 'Kategori görselleri';
$_['entry_hide_theme_menu']   = 'Tema menüsünü gizle';
$_['entry_max_depth']         = 'Azami derinlik';
$_['entry_columns']           = 'Panel başına sütun';
$_['entry_breakpoint']        = 'Mobil kırılma noktası (px)';
$_['entry_promo_category']    = 'Panel';
$_['entry_promo_image']       = 'Görsel';
$_['entry_promo_link']        = 'Bağlantı';
$_['entry_promo_text']        = 'Başlık';

// Help
$_['help_mega_status']        = 'Kategori ağacınızdan oluşturulan tam genişlikte açılır paneller; mobil kırılma noktasının üzerinde görüntülenir.';
$_['help_mobile_status']      = 'Akordeon alt kategoriler, kaydırarak kapatma ve sayfa kaydırma kilidi içeren yandan açılır menü; mobil kırılma noktasının altında görüntülenir.';
$_['help_sticky_status']      = 'Müşteri aşağı kaydırdığında navigasyon çubuğu gizlenir, yukarı kaydırdığı anda geri gelir. Tema başlığınızın da birlikte hareket etmesi için başlığa data-nk-nav-sticky-host özniteliğini ekleyin.';
$_['help_breadcrumb_status']  = 'Kategori ve ürün sayfalarına schema.org BreadcrumbList JSON-LD bloğu ekler. Sayfada zaten bir tane varsa otomatik olarak atlanır.';
$_['help_show_images']        = 'Mega menü ve çekmece menüdeki her girdinin yanında kategori görselini gösterir.';
$_['help_hide_theme_menu']    = 'Temanın kendi #menu öğesini gizler; böylece sayfadaki tek navigasyon bu paket olur.';
$_['help_max_depth']          = 'Kaç kategori seviyesinin çizileceği: 1 (yalnızca üst seviye), 2 veya 3. Daha derin ağaçlar sayfa başına daha çok sorgu demektir.';
$_['help_columns']            = 'Mega menü panelindeki alt kategori sütunu sayısı (2-6).';
$_['help_breakpoint']         = 'Masaüstü mega menünün mobil çekmecenin yerini aldığı ekran genişliği. 992 değeri Bootstrap lg kırılma noktasına denk gelir.';
$_['help_promo']              = 'Her satır, seçilen üst seviye kategorinin paneline bir tanıtım kutusu yerleştirir. Satırlar tek bir JSON ayarı olarak saklanır. Görsel, başlık veya her ikisi gereklidir; bağlantı isteğe bağlıdır.';
$_['help_mount']              = 'Yerleşim: tema başlığınızın istediğiniz yerine <div data-nk-nav-mount></div> ekleyin, paket açılışta navigasyonu oraya taşır. Bu kanca yoksa navigasyon temanın kapanan </header> etiketinin hemen ardına eklenir.';

// Button
$_['button_save']             = 'Kaydet';
$_['button_back']             = 'Geri';
$_['button_edit']             = 'Düzenle';
$_['button_clear']            = 'Temizle';
$_['button_promo_add']        = 'Tanıtım kutusu ekle';
$_['button_remove']           = 'Kaldır';

// Error
$_['error_permission']        = 'Uyarı: NovaKur Navigasyon Paketini değiştirme yetkiniz yok!';
$_['error_max_depth']         = 'Azami derinlik 1, 2 veya 3 olmalıdır!';
$_['error_columns']           = 'Panel başına sütun sayısı 2 ile 6 arasında olmalıdır!';
$_['error_breakpoint']        = 'Mobil kırılma noktası 576 ile 1600 piksel arasında olmalıdır!';
