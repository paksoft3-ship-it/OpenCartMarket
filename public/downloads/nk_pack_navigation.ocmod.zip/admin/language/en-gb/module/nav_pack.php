<?php
// Heading
$_['heading_title']           = 'NovaKur Mega Menu + Mobile Nav Pack';

// Text
$_['text_extension']          = 'Extensions';
$_['text_success']            = 'Success: You have modified the NovaKur Navigation Pack settings!';
$_['text_edit']               = 'Edit NovaKur Mega Menu + Mobile Nav Pack';
$_['text_enabled']            = 'Enabled';
$_['text_disabled']           = 'Disabled';
$_['text_features']           = 'Features';
$_['text_layout']             = 'Layout';
$_['text_promo']              = 'Promo Tiles';
$_['text_no_promo']           = 'No promo tiles yet. Add one to place a banner inside a mega menu panel.';
$_['text_coexist']            = 'This pack ships its own mega menu. If you already run the standalone NovaKur Mega Menu module, turn one of the two desktop menus off — they use separate settings and will otherwise both render.';

// Entry
$_['entry_status']            = 'Status';
$_['entry_mega_status']       = 'Desktop mega menu';
$_['entry_mobile_status']     = 'Mobile drawer';
$_['entry_sticky_status']     = 'Sticky header';
$_['entry_breadcrumb_status'] = 'Breadcrumb JSON-LD';
$_['entry_show_images']       = 'Category images';
$_['entry_hide_theme_menu']   = 'Hide the theme menu';
$_['entry_max_depth']         = 'Maximum depth';
$_['entry_columns']           = 'Columns per panel';
$_['entry_breakpoint']        = 'Mobile breakpoint (px)';
$_['entry_promo_category']    = 'Panel';
$_['entry_promo_image']       = 'Image';
$_['entry_promo_link']        = 'Link';
$_['entry_promo_text']        = 'Caption';

// Help
$_['help_mega_status']        = 'Full-width dropdown panels built from your category tree, shown above the mobile breakpoint.';
$_['help_mobile_status']      = 'Off-canvas drawer with accordion subcategories, swipe-to-close and body scroll lock, shown below the mobile breakpoint.';
$_['help_sticky_status']      = 'The navigation bar hides when the shopper scrolls down and reappears the moment they scroll up. Add data-nk-nav-sticky-host to your theme header to make it move with the bar.';
$_['help_breadcrumb_status']  = 'Adds a schema.org BreadcrumbList JSON-LD block to category and product pages. Skipped automatically if the page already contains one.';
$_['help_show_images']        = 'Show the category image next to each entry in the mega menu and the drawer.';
$_['help_hide_theme_menu']    = 'Hides the theme\'s own #menu element so the pack menu is the only navigation on the page.';
$_['help_max_depth']          = 'How many category levels to render: 1 (top level only), 2 or 3. Deeper trees mean more queries per page.';
$_['help_columns']            = 'Number of subcategory columns inside a mega menu panel (2-6).';
$_['help_breakpoint']         = 'Viewport width at which the desktop mega menu replaces the mobile drawer. 992 matches Bootstrap\'s lg breakpoint.';
$_['help_promo']              = 'Each row places a promotional tile in the panel of the chosen top-level category. The rows are stored as a single JSON setting. An image, a caption, or both are required; the link is optional.';
$_['help_mount']              = 'Placement: add a <div data-nk-nav-mount></div> anywhere in your theme header and the pack moves the navigation into it on load. Without that hook the navigation is injected straight after the theme\'s closing </header> tag.';

// Button
$_['button_save']             = 'Save';
$_['button_back']             = 'Back';
$_['button_edit']             = 'Edit';
$_['button_clear']            = 'Clear';
$_['button_promo_add']        = 'Add promo tile';
$_['button_remove']           = 'Remove';

// Error
$_['error_permission']        = 'Warning: You do not have permission to modify the NovaKur Navigation Pack!';
$_['error_max_depth']         = 'Maximum depth must be 1, 2 or 3!';
$_['error_columns']           = 'Columns per panel must be between 2 and 6!';
$_['error_breakpoint']        = 'Mobile breakpoint must be between 576 and 1600 pixels!';
