<?php
namespace Opencart\Admin\Controller\Extension\NkPackNavigation\Module;

/**
 * NovaKur Mega Menu + Mobile Nav Pack
 *
 * Settings namespace: module_nav_pack_*
 * Route:              extension/nk_pack_navigation/module/nav_pack
 * Event codes:        nk_nav_pack_assets / nk_nav_pack_header / nk_nav_pack_breadcrumb
 *
 * Deliberately kept clear of the standalone `nk-mega-menu` module: different
 * setting code, different route, different event codes, different file names.
 */
class NavPack extends \Opencart\System\Engine\Controller {
	private string $route = 'extension/nk_pack_navigation/module/nav_pack';
	private string $prefix = 'module_nav_pack';

	private const MAX_PROMO_ROWS = 50;

	/**
	 * Default setting values. Every key must start with $prefix or
	 * ModelSettingSetting::editSetting() will silently drop it.
	 *
	 * @return array<string, mixed>
	 */
	private function defaults(): array {
		return [
			'module_nav_pack_status'            => '0',
			'module_nav_pack_mega_status'       => '1',
			'module_nav_pack_mobile_status'     => '1',
			'module_nav_pack_sticky_status'     => '1',
			'module_nav_pack_breadcrumb_status' => '1',
			'module_nav_pack_show_images'       => '1',
			'module_nav_pack_hide_theme_menu'   => '0',
			'module_nav_pack_max_depth'         => '3',
			'module_nav_pack_columns'           => '4',
			'module_nav_pack_breakpoint'        => '992',
			'module_nav_pack_promo'             => []
		];
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private function events(): array {
		return [
			[
				'code'        => 'nk_nav_pack_assets',
				'description' => 'NovaKur Navigation Pack: stylesheet + script injection',
				'trigger'     => 'catalog/controller/common/header/before',
				'action'      => 'extension/nk_pack_navigation/event/nav_pack.assets',
				'status'      => 1,
				'sort_order'  => 1
			],
			[
				'code'        => 'nk_nav_pack_header',
				'description' => 'NovaKur Navigation Pack: mega menu + mobile drawer markup',
				'trigger'     => 'catalog/controller/common/header/after',
				'action'      => 'extension/nk_pack_navigation/event/nav_pack.header',
				'status'      => 1,
				'sort_order'  => 2
			],
			[
				'code'        => 'nk_nav_pack_breadcrumb',
				'description' => 'NovaKur Navigation Pack: BreadcrumbList JSON-LD',
				'trigger'     => 'catalog/view/product/*/after',
				'action'      => 'extension/nk_pack_navigation/event/nav_pack.breadcrumb',
				'status'      => 1,
				'sort_order'  => 3
			]
		];
	}

	public function index(): void {
		$this->load->language($this->route);
		$this->document->setTitle($this->language->get('heading_title'));
		$this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
	}

	public function save(): void {
		$this->load->language($this->route);

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;
		$save = [];

		// --- Boolean toggles -------------------------------------------------
		foreach ([
			'status',
			'mega_status',
			'mobile_status',
			'sticky_status',
			'breadcrumb_status',
			'show_images',
			'hide_theme_menu'
		] as $key) {
			$save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
		}

		// --- Numeric ranges --------------------------------------------------
		$max_depth = trim((string)($post[$this->prefix . '_max_depth'] ?? '3'));

		if (!$this->inRange($max_depth, 1, 3)) {
			$json['error'][$this->prefix . '_max_depth'] = $this->language->get('error_max_depth');
		} else {
			$save[$this->prefix . '_max_depth'] = (string)(int)$max_depth;
		}

		$columns = trim((string)($post[$this->prefix . '_columns'] ?? '4'));

		if (!$this->inRange($columns, 2, 6)) {
			$json['error'][$this->prefix . '_columns'] = $this->language->get('error_columns');
		} else {
			$save[$this->prefix . '_columns'] = (string)(int)$columns;
		}

		$breakpoint = trim((string)($post[$this->prefix . '_breakpoint'] ?? '992'));

		if (!$this->inRange($breakpoint, 576, 1600)) {
			$json['error'][$this->prefix . '_breakpoint'] = $this->language->get('error_breakpoint');
		} else {
			$save[$this->prefix . '_breakpoint'] = (string)(int)$breakpoint;
		}

		// --- Promo tile rows (stored as a serialized JSON setting) -----------
		$promo = [];
		$rows  = $post[$this->prefix . '_promo'] ?? [];

		if (is_array($rows)) {
			foreach ($rows as $row) {
				if (!is_array($row) || count($promo) >= self::MAX_PROMO_ROWS) {
					continue;
				}

				$category_id = (int)($row['category_id'] ?? 0);
				$image       = $this->sanitizeImage((string)($row['image'] ?? ''));
				$link        = $this->sanitizeLink((string)($row['link'] ?? ''));
				$text        = $this->sanitizeText((string)($row['text'] ?? ''));

				// A row without a target panel, or with nothing to show, is noise.
				if ($category_id <= 0 || ($image === '' && $text === '')) {
					continue;
				}

				$promo[] = [
					'category_id' => $category_id,
					'image'       => $image,
					'link'        => $link,
					'text'        => $text
				];
			}
		}

		$save[$this->prefix . '_promo'] = $promo;

		if (!isset($json['error'])) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function install(): void {
		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
			$this->model_setting_event->addEvent($event);
		}

		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->prefix, $this->defaults());

		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
	}

	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting($this->prefix);
	}

	/**
	 * @return array<string, mixed>
	 */
	private function buildFormData(): array {
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

		$data = [];

		foreach ([
			'heading_title',
			'text_home',
			'text_extension',
			'text_edit',
			'text_enabled',
			'text_disabled',
			'text_features',
			'text_layout',
			'text_promo',
			'text_no_promo',
			'text_coexist',
			'entry_status',
			'entry_mega_status',
			'entry_mobile_status',
			'entry_sticky_status',
			'entry_breadcrumb_status',
			'entry_show_images',
			'entry_hide_theme_menu',
			'entry_max_depth',
			'entry_columns',
			'entry_breakpoint',
			'entry_promo_category',
			'entry_promo_image',
			'entry_promo_link',
			'entry_promo_text',
			'help_mega_status',
			'help_mobile_status',
			'help_sticky_status',
			'help_breadcrumb_status',
			'help_show_images',
			'help_hide_theme_menu',
			'help_max_depth',
			'help_columns',
			'help_breakpoint',
			'help_promo',
			'help_mount',
			'button_save',
			'button_back',
			'button_edit',
			'button_clear',
			'button_promo_add',
			'button_remove',
			'error_permission',
			'error_max_depth',
			'error_columns',
			'error_breakpoint'
		] as $key) {
			$data[$key] = $this->language->get($key);
		}

		foreach ($this->defaults() as $key => $default) {
			if ($key === $this->prefix . '_promo') {
				continue;
			}

			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} else {
				$data[$key] = $settings[$key] ?? $default;
			}
		}

		$this->load->model('tool/image');

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		// Top-level categories are the only valid promo panel targets.
		$this->load->model('catalog/category');

		$data['categories'] = [];

		foreach ($this->model_catalog_category->getCategories(['filter_parent_id' => 0]) as $category) {
			$data['categories'][] = [
				'category_id' => (int)$category['category_id'],
				'name'        => (string)$category['name']
			];
		}

		// Promo rows: prefer unsaved POST data so a validation error keeps input.
		$rows = $this->request->post[$this->prefix . '_promo'] ?? ($settings[$this->prefix . '_promo'] ?? []);

		if (!is_array($rows)) {
			$rows = [];
		}

		$data['promo_rows'] = [];

		foreach ($rows as $row) {
			if (!is_array($row)) {
				continue;
			}

			$image = $this->sanitizeImage((string)($row['image'] ?? ''));

			$data['promo_rows'][] = [
				'category_id' => (int)($row['category_id'] ?? 0),
				'image'       => $image,
				'thumb'       => $image !== '' ? $this->model_tool_image->resize($image, 100, 100) : $data['placeholder'],
				'link'        => (string)($row['link'] ?? ''),
				'text'        => (string)($row['text'] ?? '')
			];
		}

		// Everything the inline row builder needs, encoded once so the template
		// never has to interpolate DB strings into JavaScript by hand.
		$data['nk_config_json'] = (string)json_encode([
			'categories'  => $data['categories'],
			'placeholder' => $data['placeholder'],
			'label'       => [
				'edit'   => $data['button_edit'],
				'clear'  => $data['button_clear'],
				'remove' => $data['button_remove'],
				'link'   => $data['entry_promo_link'],
				'text'   => $data['entry_promo_text']
			]
		], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);

		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
			],
			[
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
			]
		];

		$data['save']        = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back']        = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		return $data;
	}

	private function inRange(string $value, int $min, int $max): bool {
		if (!preg_match('/^\d{1,5}$/', $value)) {
			return false;
		}

		$number = (int)$value;

		return $number >= $min && $number <= $max;
	}

	/**
	 * Accept only a relative path inside the store's image directory.
	 */
	private function sanitizeImage(string $image): string {
		$image = trim(str_replace('\\', '/', $image));

		if ($image === '') {
			return '';
		}

		if (str_contains($image, '..') || str_starts_with($image, '/')) {
			return '';
		}

		if (!preg_match('/^[a-zA-Z0-9 _\-\/.]+\.(jpg|jpeg|png|gif|webp|svg)$/i', $image)) {
			return '';
		}

		return $image;
	}

	/**
	 * Accept an empty value, a relative path, or an http(s) URL. Anything that
	 * could execute (javascript:, data:, vbscript:) is discarded.
	 */
	private function sanitizeLink(string $link): string {
		$link = trim(strip_tags($link));

		if ($link === '') {
			return '';
		}

		if (preg_match('/^\s*(javascript|data|vbscript|file)\s*:/i', $link)) {
			return '';
		}

		if (preg_match('/[\r\n\t<>"\']/', $link)) {
			return '';
		}

		return mb_substr($link, 0, 500);
	}

	private function sanitizeText(string $text): string {
		$text = trim(strip_tags($text));
		$text = preg_replace('/\s+/u', ' ', $text) ?? '';

		return mb_substr($text, 0, 120);
	}
}
