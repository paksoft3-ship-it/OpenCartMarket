<?php
$_['text_menu']     = 'Menü';
$_['text_close']    = 'Menüyü kapat';
$_['text_open']     = 'Menüyü aç';
$_['text_back']     = 'Geri';
$_['text_home']     = 'Anasayfa';
$_['text_expand']   = 'Alt kategorileri göster';
$_['text_view_all'] = 'Tümünü gör: %s';
