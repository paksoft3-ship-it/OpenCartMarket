<?php
$_['text_menu']     = 'Menu';
$_['text_close']    = 'Close menu';
$_['text_open']     = 'Open menu';
$_['text_back']     = 'Back';
$_['text_home']     = 'Home';
$_['text_expand']   = 'Show subcategories';
$_['text_view_all'] = 'View all %s';
