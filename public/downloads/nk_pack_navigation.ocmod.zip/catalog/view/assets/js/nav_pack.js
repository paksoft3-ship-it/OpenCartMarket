/*!
 * NovaKur Mega Menu + Mobile Nav Pack
 * Dependency-free. Progressive enhancement: the desktop panels already work on
 * hover with CSS alone, this file adds keyboard/touch support, the off-canvas
 * drawer, the sticky header behaviour and the [data-nk-nav-mount] relocation.
 */
(function () {
    'use strict';

    var SWIPE_START = 12;   // px of horizontal travel before a drag is a drag
    var SWIPE_CLOSE = 70;   // px of travel that commits to closing
    var SCROLL_STEP = 6;    // px of scroll before the sticky bar reacts
    var SCROLL_TOP = 80;    // px from the top where the bar is always shown

    var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

    function each(list, fn) {
        Array.prototype.forEach.call(list || [], fn);
    }

    function isRtl() {
        var dir = document.documentElement.getAttribute('dir') || document.body.getAttribute('dir') || '';

        return dir.toLowerCase() === 'rtl';
    }

    /* ------------------------------------------------------------- mounting */

    /**
     * If the theme exposes [data-nk-nav-mount], move the nav into it so the
     * store owner controls placement. Otherwise the server-side injection
     * (after </header>) already put it in a sensible spot.
     */
    function mount(roots) {
        var target = document.querySelector('[data-nk-nav-mount]');

        if (!target) {
            return;
        }

        each(roots, function (root) {
            if (!target.contains(root)) {
                target.appendChild(root);
            }
        });
    }

    /* -------------------------------------------------------- desktop menu  */

    function initDesktop(root) {
        var items = root.querySelectorAll('[data-nk-nav-item]');
        var coarse = window.matchMedia ? window.matchMedia('(hover: none)').matches : false;

        function closeAll(except) {
            each(items, function (item) {
                if (item === except) {
                    return;
                }

                item.classList.remove('nk-nav-open');

                var link = item.querySelector('.nk-nav-link');

                if (link && link.hasAttribute('aria-expanded')) {
                    link.setAttribute('aria-expanded', 'false');
                }
            });
        }

        function open(item) {
            closeAll(item);
            item.classList.add('nk-nav-open');

            var link = item.querySelector('.nk-nav-link');

            if (link && link.hasAttribute('aria-expanded')) {
                link.setAttribute('aria-expanded', 'true');
            }
        }

        each(items, function (item) {
            var panel = item.querySelector('[data-nk-nav-panel]');

            if (!panel) {
                return;
            }

            var link = item.querySelector('.nk-nav-link');

            // Keyboard users: opening on focus, closing when focus leaves.
            item.addEventListener('focusin', function () {
                open(item);
            });

            item.addEventListener('focusout', function () {
                window.setTimeout(function () {
                    if (!item.contains(document.activeElement)) {
                        item.classList.remove('nk-nav-open');

                        if (link && link.hasAttribute('aria-expanded')) {
                            link.setAttribute('aria-expanded', 'false');
                        }
                    }
                }, 0);
            });

            // Touch tablets at desktop width: first tap opens, second follows.
            if (coarse && link) {
                link.addEventListener('click', function (event) {
                    if (!item.classList.contains('nk-nav-open')) {
                        event.preventDefault();
                        open(item);
                    }
                });
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' || event.key === 'Esc') {
                closeAll(null);
            }
        });

        document.addEventListener('click', function (event) {
            if (!root.contains(event.target)) {
                closeAll(null);
            }
        });
    }

    /* --------------------------------------------------------- scroll lock  */

    var lockCount = 0;
    var lockedAt = 0;

    function lockScroll() {
        if (lockCount++ > 0) {
            return;
        }

        lockedAt = window.pageYOffset || document.documentElement.scrollTop || 0;

        document.documentElement.classList.add('nk-nav-locked');
        document.body.classList.add('nk-nav-locked');
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        document.body.style.top = (-lockedAt) + 'px';
    }

    function unlockScroll() {
        if (lockCount === 0 || --lockCount > 0) {
            return;
        }

        document.documentElement.classList.remove('nk-nav-locked');
        document.body.classList.remove('nk-nav-locked');
        document.body.style.position = '';
        document.body.style.width = '';
        document.body.style.top = '';

        window.scrollTo(0, lockedAt);
    }

    /* ---------------------------------------------------------- mobile nav  */

    function initMobile(root) {
        var drawer = root.querySelector('[data-nk-nav-drawer]');
        var overlay = root.querySelector('[data-nk-nav-overlay]');
        var burger = root.querySelector('[data-nk-nav-open]');

        if (!drawer || !burger) {
            return;
        }

        var lastFocus = null;
        var isOpen = false;

        function openDrawer() {
            if (isOpen) {
                return;
            }

            isOpen = true;
            lastFocus = document.activeElement;

            root.classList.add('nk-nav-drawer-open');
            drawer.setAttribute('aria-hidden', 'false');
            burger.setAttribute('aria-expanded', 'true');
            lockScroll();

            var first = drawer.querySelector(FOCUSABLE);

            (first || drawer).focus();
        }

        function closeDrawer() {
            if (!isOpen) {
                return;
            }

            isOpen = false;

            root.classList.remove('nk-nav-drawer-open');
            drawer.setAttribute('aria-hidden', 'true');
            burger.setAttribute('aria-expanded', 'false');
            drawer.style.transform = '';
            drawer.classList.remove('nk-nav-dragging');
            unlockScroll();

            if (lastFocus && typeof lastFocus.focus === 'function') {
                lastFocus.focus();
            }
        }

        burger.addEventListener('click', openDrawer);

        each(root.querySelectorAll('[data-nk-nav-close]'), function (button) {
            button.addEventListener('click', closeDrawer);
        });

        if (overlay) {
            overlay.addEventListener('click', closeDrawer);
        }

        drawer.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' || event.key === 'Esc') {
                event.preventDefault();
                closeDrawer();

                return;
            }

            if (event.key !== 'Tab') {
                return;
            }

            var focusable = drawer.querySelectorAll(FOCUSABLE);

            if (!focusable.length) {
                return;
            }

            var first = focusable[0];
            var last = focusable[focusable.length - 1];

            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });

        // ---- accordion -----------------------------------------------------
        each(drawer.querySelectorAll('[data-nk-nav-acc]'), function (toggle) {
            toggle.addEventListener('click', function () {
                var row = toggle.parentNode;
                var panel = row ? row.nextElementSibling : null;

                if (!panel || !panel.hasAttribute('data-nk-nav-acc-panel')) {
                    return;
                }

                var expanded = toggle.getAttribute('aria-expanded') === 'true';

                toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                panel.classList.toggle('nk-nav-acc-expanded', !expanded);
            });
        });

        // ---- swipe to close ------------------------------------------------
        var startX = 0;
        var startY = 0;
        var deltaX = 0;
        var dragging = false;
        var tracking = false;

        drawer.addEventListener('touchstart', function (event) {
            if (!isOpen || event.touches.length !== 1) {
                return;
            }

            startX = event.touches[0].clientX;
            startY = event.touches[0].clientY;
            deltaX = 0;
            tracking = true;
            dragging = false;
        }, { passive: true });

        drawer.addEventListener('touchmove', function (event) {
            if (!tracking || event.touches.length !== 1) {
                return;
            }

            var dx = event.touches[0].clientX - startX;
            var dy = event.touches[0].clientY - startY;

            // Let vertical scrolling win.
            if (!dragging && Math.abs(dy) > Math.abs(dx)) {
                tracking = false;

                return;
            }

            if (!dragging && Math.abs(dx) < SWIPE_START) {
                return;
            }

            // Only travel towards the edge the drawer came from.
            var closing = isRtl() ? dx > 0 : dx < 0;

            if (!closing) {
                deltaX = 0;
                drawer.style.transform = '';

                return;
            }

            dragging = true;
            deltaX = dx;

            drawer.classList.add('nk-nav-dragging');
            drawer.style.transform = 'translateX(' + dx + 'px)';
        }, { passive: true });

        function endSwipe() {
            if (!tracking) {
                return;
            }

            tracking = false;

            drawer.classList.remove('nk-nav-dragging');

            if (dragging && Math.abs(deltaX) > SWIPE_CLOSE) {
                drawer.style.transform = '';
                closeDrawer();
            } else {
                drawer.style.transform = '';
            }

            dragging = false;
            deltaX = 0;
        }

        drawer.addEventListener('touchend', endSwipe);
        drawer.addEventListener('touchcancel', endSwipe);

        // Crossing back to the desktop breakpoint hides this root via CSS, which
        // would otherwise leave the body locked with no visible close button.
        window.addEventListener('resize', function () {
            if (isOpen && root.offsetParent === null) {
                closeDrawer();
            }
        });

        // A link inside the drawer navigates away; drop the lock first so a
        // back-button restore does not land on a frozen page.
        each(drawer.querySelectorAll('a[href]'), function (link) {
            link.addEventListener('click', function () {
                closeDrawer();
            });
        });

        window.addEventListener('pagehide', function () {
            if (isOpen) {
                closeDrawer();
            }
        });
    }

    /* ------------------------------------------------------- sticky header  */

    function initSticky(targets) {
        if (!targets.length) {
            return;
        }

        var lastY = window.pageYOffset || 0;
        var ticking = false;

        function update() {
            ticking = false;

            var y = window.pageYOffset || document.documentElement.scrollTop || 0;

            if (y <= SCROLL_TOP) {
                each(targets, function (el) {
                    el.classList.remove('nk-nav-hidden');
                    el.classList.remove('nk-nav-pinned');
                });

                lastY = y;

                return;
            }

            if (y > lastY + SCROLL_STEP) {
                each(targets, function (el) {
                    el.classList.add('nk-nav-hidden');
                });

                lastY = y;
            } else if (y < lastY - SCROLL_STEP) {
                each(targets, function (el) {
                    el.classList.remove('nk-nav-hidden');
                    el.classList.add('nk-nav-pinned');
                });

                lastY = y;
            }
        }

        window.addEventListener('scroll', function () {
            // Never hide the bar while the drawer holds the body in place.
            if (document.body.classList.contains('nk-nav-locked')) {
                return;
            }

            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });
    }

    /* ------------------------------------------------------------- bootstrap */

    function init() {
        var roots = document.querySelectorAll('.nk-nav-root');
        var hosts = document.querySelectorAll('[data-nk-nav-sticky-host]');

        // With every panel feature switched off there is still work to do if the
        // theme opted its own header into the sticky behaviour.
        if (!roots.length && !hosts.length) {
            return;
        }

        mount(roots);

        each(document.querySelectorAll('[data-nk-nav-desktop]'), initDesktop);
        each(document.querySelectorAll('[data-nk-nav-mobile]'), initMobile);

        var sticky = [];

        each(document.querySelectorAll('[data-nk-nav-sticky]'), function (el) {
            sticky.push(el);
        });

        // Optional theme opt-in: mark the real header and it rides along.
        each(hosts, function (el) {
            el.classList.add('nk-nav-sticky-host');
            sticky.push(el);
        });

        initSticky(sticky);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
}());
