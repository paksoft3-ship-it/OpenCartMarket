<?php
$_['heading_title'] = 'NovaKur Luxury Brand Theme';
$_['text_edit'] = 'Luxury brand theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Luxury theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_cinematic_hero'] = 'Show Cinematic Hero';
$_['entry_show_story'] = 'Show Maison Story Block';
$_['entry_show_collections'] = 'Show Collection Showcases';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
