<?php
// Heading
$_['heading_title']         = 'NovaKur Countdown Timer';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified NovaKur Countdown Timer settings!';
$_['text_edit']             = 'Edit NovaKur Countdown Timer';
$_['text_enabled']          = 'Enabled';
$_['text_disabled']         = 'Disabled';
$_['text_general']          = 'General';
$_['text_product']          = 'Product Special Timer';
$_['text_bar']              = 'Sitewide Campaign Bar';

// Entry
$_['entry_status']          = 'Status';
$_['entry_product_status']  = 'Special offer timer';
$_['entry_product_color']   = 'Timer accent colour';
$_['entry_bar_status']      = 'Campaign bar';
$_['entry_bar_date']        = 'Campaign ends';
$_['entry_bar_message']     = 'Campaign message';
$_['entry_bar_bg_color']    = 'Bar background colour';
$_['entry_bar_text_color']  = 'Bar text colour';

// Help
$_['help_product_status']   = 'Shows a countdown on the product page when the product has an active special with an end date. Products whose special never expires show nothing.';
$_['help_product_color']    = 'Accent colour for the product page timer digits.';
$_['help_bar_status']       = 'Shows a countdown bar under the header on every storefront page.';
$_['help_bar_date']         = 'End of the campaign, in the store server\'s own timezone. Leave empty to hide the bar.';
$_['help_bar_message']      = 'Text shown beside the campaign countdown. Maximum 120 characters.';

// Button
$_['button_save']           = 'Save';
$_['button_back']           = 'Back';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify this module!';
$_['error_color']           = 'Colour must be a 6 digit hex value, e.g. #DC2626!';
$_['error_bar_date']        = 'Campaign end must be a real date and time, e.g. 2026-12-24 23:59!';
$_['error_bar_message']     = 'Campaign message must be 120 characters or fewer!';
