<?php
namespace Opencart\Admin\Controller\Extension\NkCountdown\Module;

/**
 * NovaKur Countdown Timer
 *
 * Settings namespace: module_countdown_*
 * Route:              extension/nk_countdown/module/countdown
 * Event codes:        nk_countdown_assets / nk_countdown_product / nk_countdown_bar
 */
class Countdown extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_countdown/module/countdown';
    private string $prefix = 'module_countdown';

    private const MESSAGE_MAX = 120;

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_countdown_status'         => '0',
            'module_countdown_product_status' => '1',
            'module_countdown_product_color'  => '#DC2626',
            'module_countdown_bar_status'     => '0',
            'module_countdown_bar_date'       => '',
            'module_countdown_bar_message'    => '',
            'module_countdown_bar_bg_color'   => '#111827',
            'module_countdown_bar_text_color' => '#FFFFFF'
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_countdown_assets',
                'description' => 'NovaKur Countdown Timer: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_countdown/event/countdown.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_countdown_product',
                'description' => 'NovaKur Countdown Timer: special-offer timer on the product page',
                'trigger'     => 'catalog/view/product/product/after',
                'action'      => 'extension/nk_countdown/event/countdown.product',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_countdown_bar',
                'description' => 'NovaKur Countdown Timer: sitewide campaign bar',
                'trigger'     => 'catalog/view/common/header/after',
                'action'      => 'extension/nk_countdown/event/countdown.bar',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_product',
            'text_bar',
            'entry_status',
            'entry_product_status',
            'entry_product_color',
            'entry_bar_status',
            'entry_bar_date',
            'entry_bar_message',
            'entry_bar_bg_color',
            'entry_bar_text_color',
            'help_product_status',
            'help_product_color',
            'help_bar_status',
            'help_bar_date',
            'help_bar_message',
            'button_save',
            'button_back',
            'error_permission',
            'error_color',
            'error_bar_date',
            'error_bar_message'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        foreach (['status', 'product_status', 'bar_status'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // --- Colours ---------------------------------------------------------
        foreach (['product_color', 'bar_bg_color', 'bar_text_color'] as $key) {
            $color = strtoupper(trim((string)($post[$this->prefix . '_' . $key] ?? '')));

            if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_color');
            } else {
                $save[$this->prefix . '_' . $key] = $color;
            }
        }

        // --- Campaign end datetime -------------------------------------------
        // Stored as `Y-m-d H:i` in the store's own timezone. Empty is legal, and
        // simply means the bar has nothing to count down to.
        $date = trim((string)($post[$this->prefix . '_bar_date'] ?? ''));

        if ($date === '') {
            $save[$this->prefix . '_bar_date'] = '';
        } else {
            $normalised = $this->normaliseDate($date);

            if ($normalised === null) {
                $json['error'][$this->prefix . '_bar_date'] = $this->language->get('error_bar_date');
            } else {
                $save[$this->prefix . '_bar_date'] = $normalised;
            }
        }

        // --- Campaign message -------------------------------------------------
        $message = is_scalar($post[$this->prefix . '_bar_message'] ?? null) ? (string)$post[$this->prefix . '_bar_message'] : '';
        $message = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $message) ?? '');

        if (function_exists('mb_strlen') ? mb_strlen($message, 'UTF-8') > self::MESSAGE_MAX : strlen($message) > self::MESSAGE_MAX) {
            $json['error'][$this->prefix . '_bar_message'] = $this->language->get('error_bar_message');
        } else {
            $save[$this->prefix . '_bar_message'] = $message;
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Accepts both the HTML `datetime-local` shape (`Y-m-d\TH:i`, optionally
     * with seconds) and a plain `Y-m-d H:i`. Returns the canonical
     * `Y-m-d H:i` form, or null when the value is not a real calendar instant
     * (checkdate() rejects 2026-02-30 and friends).
     */
    private function normaliseDate(string $value): ?string {
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::\d{2})?$/', $value, $match)) {
            return null;
        }

        [, $year, $month, $day, $hour, $minute] = $match;

        if (!checkdate((int)$month, (int)$day, (int)$year)) {
            return null;
        }

        if ((int)$hour > 23 || (int)$minute > 59) {
            return null;
        }

        return $year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute;
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }
}
