<?php
$_['text_special_ends']  = 'Special offer ends in';
$_['text_bar_default']   = 'Sale ends soon';
$_['text_days']          = 'Days';
$_['text_hours']         = 'Hours';
$_['text_minutes']       = 'Mins';
$_['text_seconds']       = 'Secs';
$_['text_ends_on']       = 'Ends on %s';
$_['text_ends_in_day']   = 'Ends in %d day';
$_['text_ends_in_days']  = 'Ends in %d days';
$_['text_ends_in_hour']  = 'Ends in %d hour';
$_['text_ends_in_hours'] = 'Ends in %d hours';
$_['text_ends_soon']     = 'Ends within the hour';
