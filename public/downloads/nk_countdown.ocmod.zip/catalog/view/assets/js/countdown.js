(function () {
  'use strict';

  function pad(value) {
    return value < 10 ? '0' + value : String(value);
  }

  function reduceMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  function expire(el, timer) {
    if (timer) {
      window.clearInterval(timer);
    }

    el.classList.add('is-expired');
    el.setAttribute('aria-hidden', 'true');
  }

  function start(el) {
    // The server hands us seconds remaining rather than a wall-clock deadline,
    // so a shopper with a wrong system clock still sees the right numbers.
    var remaining = parseInt(el.getAttribute('data-nk-countdown'), 10);

    if (isNaN(remaining) || remaining <= 0) {
      expire(el, null);

      return;
    }

    var deadline = Date.now() + remaining * 1000;

    // Reduced motion: keep the static server-rendered wording, never tick.
    // The block still disappears on its own once the offer lapses.
    if (reduceMotion()) {
      window.setTimeout(function () {
        expire(el, null);
      }, remaining * 1000);

      return;
    }

    var days = el.querySelector('[data-nk-days]');
    var hours = el.querySelector('[data-nk-hours]');
    var minutes = el.querySelector('[data-nk-minutes]');
    var seconds = el.querySelector('[data-nk-seconds]');

    if (!days || !hours || !minutes || !seconds) {
      return;
    }

    el.classList.add('is-live');

    var timer = null;

    function tick() {
      var left = Math.floor((deadline - Date.now()) / 1000);

      if (left <= 0) {
        expire(el, timer);

        return;
      }

      days.textContent = String(Math.floor(left / 86400));
      hours.textContent = pad(Math.floor(left / 3600) % 24);
      minutes.textContent = pad(Math.floor(left / 60) % 60);
      seconds.textContent = pad(left % 60);
    }

    tick();

    timer = window.setInterval(tick, 1000);
  }

  function init() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-nk-countdown]'), start);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
