<?php
namespace Opencart\Catalog\Controller\Extension\NkCountdown\Event;

/**
 * NovaKur Countdown Timer — storefront hooks.
 *
 * assets()  catalog/controller/common/header/before → register CSS/JS
 * bar()     catalog/view/common/header/after        → sitewide campaign bar
 * product() catalog/view/product/product/after      → special-offer timer
 *
 * Every hook fails open: when the data is missing or the theme does not expose
 * the anchors this module expects, the storefront output is returned untouched.
 */
class Countdown extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_countdown/catalog/view/assets/css/countdown.css';
    private const JS  = 'extension/nk_countdown/catalog/view/assets/js/countdown.js';

    private const DEFAULT_ACCENT   = '#DC2626';
    private const DEFAULT_BAR_BG   = '#111827';
    private const DEFAULT_BAR_TEXT = '#FFFFFF';

    private const MESSAGE_MAX = 120;

    /**
     * Cached across the two view hooks on a product page.
     */
    private ?int $bar_remaining = null;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        // Only pay for the assets on pages that can actually show a timer.
        if (!$this->barVisible() && !($this->productEnabled() && $this->isProductPage())) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * catalog/view/common/header/after
     *
     * @param string               $route
     * @param array<string, mixed> $args
     * @param mixed                $output
     *
     * @return void
     */
    public function bar(string &$route, array &$args, mixed &$output): void {
        if (!$this->enabled() || !$this->barVisible() || !is_string($output) || $output === '') {
            return;
        }

        // A theme may render the header twice (print views); one bar only.
        if (str_contains($output, 'id="nk-countdown-bar"')) {
            return;
        }

        $remaining = $this->barRemaining();

        if ($remaining <= 0) {
            return;
        }

        $this->load->language('extension/nk_countdown/module/countdown');

        $html = $this->load->view('extension/nk_countdown/module/countdown_bar', [
            'message'    => $this->barMessage(),
            'remaining'  => $remaining,
            'static'     => $this->staticText($remaining),
            'bg_color'   => $this->color('module_countdown_bar_bg_color', self::DEFAULT_BAR_BG),
            'text_color' => $this->color('module_countdown_bar_text_color', self::DEFAULT_BAR_TEXT)
        ] + $this->labels());

        if (!is_string($html) || $html === '') {
            return;
        }

        if (str_contains($output, '<header')) {
            // preg_replace() would read $1/\1 inside the rendered bar as
            // backreferences, so the replacement is built in a callback.
            $output = preg_replace_callback('/<header[^>]*>/', static function (array $match) use ($html): string {
                return $html . $match[0];
            }, $output, 1) ?? $output;
        } else {
            $output = $html . $output;
        }
    }

    /**
     * catalog/view/product/product/after
     *
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function product(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || !$this->productEnabled() || !is_string($output) || $output === '') {
            return;
        }

        if (str_contains($output, 'id="nk-countdown-product"')) {
            return;
        }

        $product_id = (int)($data['product_id'] ?? 0);

        if ($product_id <= 0) {
            return;
        }

        $special = $this->special($product_id);

        if (!$special) {
            return;
        }

        $this->load->language('extension/nk_countdown/module/countdown');

        $html = $this->load->view('extension/nk_countdown/module/countdown_product', [
            'remaining'  => $special['remaining'],
            'static'     => $this->staticText($special['remaining'], $special['date_end']),
            'accent'     => $this->color('module_countdown_product_color', self::DEFAULT_ACCENT)
        ] + $this->labels());

        if (!is_string($html) || $html === '') {
            return;
        }

        if ($this->insertBefore($output, $html, 'id="form-product"', '<form')) {
            return;
        }

        $this->insertBefore($output, $html, 'id="button-cart"', '<button');
    }

    /**
     * Insert $html immediately before the tag that carries $anchor.
     */
    private function insertBefore(string &$output, string $html, string $anchor, string $tag): bool {
        $pos = strpos($output, $anchor);

        if ($pos === false) {
            return false;
        }

        $open = strrpos(substr($output, 0, $pos), $tag);

        if ($open === false) {
            return false;
        }

        $output = substr($output, 0, $open) . $html . substr($output, $open);

        return true;
    }

    /**
     * The active special for this product, or null when there is none, when it
     * never expires, or when it has already lapsed.
     *
     * There is no `product_special` table in OpenCart 4 — a special is a
     * `product_discount` row with `special` = 1. The WHERE clause and the
     * ORDER BY mirror catalog/model/catalog/product.php's `special` sub-select
     * exactly, so the row read here is the same row the displayed price came
     * from. `TIMESTAMPDIFF` is evaluated by the same clock as the `NOW()`
     * filter, which keeps the timer honest even if PHP and MySQL disagree about
     * the current time.
     *
     * Note `date_end` is a DATE column, so MySQL compares it as midnight at the
     * START of that day — which is exactly when the core stops applying the
     * special. The timer therefore hits zero at the same instant the price
     * reverts.
     *
     * @return array{date_end: string, remaining: int}|null
     */
    private function special(int $product_id): ?array {
        $query = $this->db->query("SELECT `date_end`, TIMESTAMPDIFF(SECOND, NOW(), `date_end`) AS `remaining` FROM `" . DB_PREFIX . "product_discount` WHERE `product_id` = '" . (int)$product_id . "' AND `customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `quantity` = '1' AND `special` = '1' AND ((`date_start` = '0000-00-00' OR `date_start` < NOW()) AND (`date_end` = '0000-00-00' OR `date_end` > NOW())) ORDER BY `priority` ASC, `price` ASC LIMIT 1");

        if (!$query->num_rows) {
            return null;
        }

        $date_end = (string)$query->row['date_end'];

        // An open-ended special has nothing to count down to.
        if ($date_end === '' || $date_end === '0000-00-00') {
            return null;
        }

        $remaining = (int)$query->row['remaining'];

        if ($remaining <= 0) {
            return null;
        }

        return ['date_end' => $date_end, 'remaining' => $remaining];
    }

    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_countdown_status');
    }

    private function productEnabled(): bool {
        return (bool)(int)$this->config->get('module_countdown_product_status');
    }

    private function barVisible(): bool {
        return (bool)(int)$this->config->get('module_countdown_bar_status') && $this->barRemaining() > 0;
    }

    private function isProductPage(): bool {
        $route = (string)($this->request->get['route'] ?? '');

        return $route === 'product/product' || str_starts_with($route, 'product/product.');
    }

    /**
     * Seconds left on the merchant-set campaign deadline. 0 when unset or past.
     */
    private function barRemaining(): int {
        if ($this->bar_remaining !== null) {
            return $this->bar_remaining;
        }

        $this->bar_remaining = 0;

        $raw = $this->config->get('module_countdown_bar_date');

        if (!is_scalar($raw)) {
            return 0;
        }

        $value = trim((string)$raw);

        // Re-validate: save() writes `Y-m-d H:i`, but a hand-edited `oc_setting`
        // row must not reach strtotime() as a free-form string.
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})$/', $value, $match)) {
            return 0;
        }

        [, $year, $month, $day, $hour, $minute] = $match;

        if (!checkdate((int)$month, (int)$day, (int)$year) || (int)$hour > 23 || (int)$minute > 59) {
            return 0;
        }

        $target = mktime((int)$hour, (int)$minute, 0, (int)$month, (int)$day, (int)$year);

        if ($target === false) {
            return 0;
        }

        $this->bar_remaining = max(0, $target - time());

        return $this->bar_remaining;
    }

    private function barMessage(): string {
        $message = $this->config->get('module_countdown_bar_message');
        $message = is_scalar($message) ? (string)$message : '';
        $message = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $message) ?? '');

        if ($message === '') {
            return (string)$this->language->get('text_bar_default');
        }

        if (function_exists('mb_substr')) {
            return mb_substr($message, 0, self::MESSAGE_MAX, 'UTF-8');
        }

        return substr($message, 0, self::MESSAGE_MAX);
    }

    /**
     * Static, non-ticking wording for `prefers-reduced-motion` users and for the
     * no-JS case. Coarse on purpose — nothing here needs a per-second update.
     *
     * @return string
     */
    private function staticText(int $remaining, string $date_end = ''): string {
        if ($date_end !== '') {
            $timestamp = strtotime($date_end);

            if ($timestamp !== false) {
                // Language::get() echoes the key back when it is missing, so a
                // store without the core date format still gets a real date.
                $format = (string)$this->language->get('date_format_short');

                if ($format === '' || $format === 'date_format_short') {
                    $format = 'd/m/Y';
                }

                return sprintf($this->language->get('text_ends_on'), date($format, $timestamp));
            }
        }

        $days = (int)floor($remaining / 86400);

        if ($days >= 1) {
            return sprintf($this->language->get($days === 1 ? 'text_ends_in_day' : 'text_ends_in_days'), $days);
        }

        $hours = (int)floor($remaining / 3600);

        if ($hours >= 1) {
            return sprintf($this->language->get($hours === 1 ? 'text_ends_in_hour' : 'text_ends_in_hours'), $hours);
        }

        return (string)$this->language->get('text_ends_soon');
    }

    /**
     * @return array<string, string>
     */
    private function labels(): array {
        $labels = [];

        foreach (['text_special_ends', 'text_days', 'text_hours', 'text_minutes', 'text_seconds'] as $key) {
            $labels[$key] = (string)$this->language->get($key);
        }

        return $labels;
    }

    /**
     * Settings are written by a validating save(), but a hand-edited
     * `oc_setting` row must never be able to break out of a style attribute.
     */
    private function color(string $key, string $fallback): string {
        $value = $this->config->get($key);

        if (!is_scalar($value)) {
            return $fallback;
        }

        $color = strtoupper(trim((string)$value));

        return preg_match('/^#[0-9A-F]{6}$/', $color) ? $color : $fallback;
    }
}
