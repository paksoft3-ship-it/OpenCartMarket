/**
 * NovaKur Advanced Layered Filters
 *
 * Progressive enhancement only. With JavaScript disabled the sidebar stays a plain GET form
 * that reloads the category page, so nothing below is required for the module to work.
 */
(function () {
    'use strict';

    var SUPPORTED = !!(window.fetch && window.history && window.history.pushState);

    var form = null;
    var slider = null;
    var token = 0;
    var timer = null;

    function ready(fn) {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    function grid() {
        var list = document.getElementById('product-list');

        if (!list) {
            return null;
        }

        var row = list.nextElementSibling;

        return {
            list: list,
            pagination: row ? row.querySelector('.text-start') : null,
            results: row ? row.querySelector('.text-end') : null
        };
    }

    /* ------------------------------------------------------------------ price slider */

    function initSlider() {
        var box = form.querySelector('.nk-lf-slider');

        if (!box) {
            return;
        }

        slider = {
            box: box,
            fill: box.querySelector('.nk-lf-fill'),
            low: box.querySelector('.nk-lf-range-min'),
            high: box.querySelector('.nk-lf-range-max'),
            min: parseFloat(box.getAttribute('data-nk-min')),
            max: parseFloat(box.getAttribute('data-nk-max')),
            numberLow: form.querySelector('.nk-lf-price-min'),
            numberHigh: form.querySelector('.nk-lf-price-max')
        };

        if (!slider.low || !slider.high) {
            slider = null;
            return;
        }

        // Only reveal the dual handle track once it can actually be driven.
        form.classList.add('nk-lf-has-slider');

        slider.low.addEventListener('input', function () {
            fromRange();
        });

        slider.high.addEventListener('input', function () {
            fromRange();
        });

        if (slider.numberLow) {
            slider.numberLow.addEventListener('change', fromNumber);
        }

        if (slider.numberHigh) {
            slider.numberHigh.addEventListener('change', fromNumber);
        }

        paint();
    }

    function clamp(value, min, max) {
        if (isNaN(value)) {
            return min;
        }

        return Math.min(Math.max(value, min), max);
    }

    function fromRange() {
        var low = parseFloat(slider.low.value);
        var high = parseFloat(slider.high.value);

        if (low > high) {
            var swap = low;
            low = high;
            high = swap;
            slider.low.value = low;
            slider.high.value = high;
        }

        if (slider.numberLow) {
            slider.numberLow.value = low;
        }

        if (slider.numberHigh) {
            slider.numberHigh.value = high;
        }

        paint();
        schedule();
    }

    function fromNumber() {
        var low = clamp(parseFloat(slider.numberLow ? slider.numberLow.value : slider.min), slider.min, slider.max);
        var high = clamp(parseFloat(slider.numberHigh ? slider.numberHigh.value : slider.max), slider.min, slider.max);

        if (low > high) {
            var swap = low;
            low = high;
            high = swap;
        }

        slider.low.value = low;
        slider.high.value = high;

        if (slider.numberLow) {
            slider.numberLow.value = low;
        }

        if (slider.numberHigh) {
            slider.numberHigh.value = high;
        }

        paint();
        schedule();
    }

    function paint() {
        if (!slider || !slider.fill) {
            return;
        }

        var span = slider.max - slider.min;

        if (span <= 0) {
            return;
        }

        var low = ((parseFloat(slider.low.value) - slider.min) / span) * 100;
        var high = ((parseFloat(slider.high.value) - slider.min) / span) * 100;

        slider.fill.style.left = low + '%';
        slider.fill.style.width = Math.max(high - low, 0) + '%';
    }

    /* ------------------------------------------------------------------ query building */

    function component(value) {
        return encodeURIComponent(value).replace(/%3A/g, ':');
    }

    function query() {
        var map = {};
        var parts = [];

        Array.prototype.forEach.call(form.querySelectorAll('input.nk-lf-check:checked'), function (input) {
            var name = input.name.replace(/\[\]$/, '');

            if (!map[name]) {
                map[name] = [];
            }

            map[name].push(input.value);
        });

        Object.keys(map).forEach(function (name) {
            // Both stock boxes ticked is the same as none ticked.
            if (name === 'filter_stock' && map[name].length !== 1) {
                return;
            }

            parts.push(name + '=' + map[name].map(component).join(','));
        });

        if (slider) {
            var low = parseFloat(slider.low.value);
            var high = parseFloat(slider.high.value);

            if (low > slider.min || high < slider.max) {
                parts.push('filter_price=' + low + '-' + high);
            }
        }

        Array.prototype.forEach.call(form.querySelectorAll('input[type="hidden"]'), function (input) {
            if (input.name === 'sort' || input.name === 'order' || input.name === 'limit') {
                parts.push(input.name + '=' + component(input.value));
            }
        });

        return parts.length ? '&' + parts.join('&') : '';
    }

    function endpoint(page) {
        var url = form.getAttribute('data-nk-results');
        var path = form.getAttribute('data-nk-path');

        if (path) {
            url += '&path=' + component(path);
        } else {
            url += '&category_id=' + component(form.getAttribute('data-nk-category'));
        }

        url += query();

        if (page > 1) {
            url += '&page=' + page;
        }

        return url;
    }

    /* ------------------------------------------------------------------ applying */

    function busy(state) {
        var loading = form.querySelector('.nk-lf-loading');

        if (loading) {
            loading.hidden = !state;
        }

        form.classList.toggle('nk-lf-busy', !!state);
    }

    function schedule() {
        window.clearTimeout(timer);

        timer = window.setTimeout(function () {
            apply(1, true);
        }, 450);
    }

    function apply(page, push) {
        var target = grid();

        if (!target) {
            return;
        }

        var current = ++token;

        busy(true);

        fetch(endpoint(page), {
            headers: {'X-Requested-With': 'XMLHttpRequest'},
            credentials: 'same-origin'
        }).then(function (response) {
            return response.json();
        }).then(function (json) {
            if (current !== token) {
                return;
            }

            busy(false);

            if (!json || json.error) {
                return;
            }

            target.list.innerHTML = json.total ? json.list : '<div class="col"><p>' + json.text_empty + '</p></div>';

            if (target.pagination) {
                target.pagination.innerHTML = json.pagination || '';
            }

            if (target.results) {
                target.results.innerHTML = json.results || '';
            }

            counts(json.counts);
            toolbar('input-sort', json.sorts);
            toolbar('input-limit', json.limits);

            if (push && json.url) {
                window.history.pushState({novakur: true}, '', json.url);
            }

            document.dispatchEvent(new CustomEvent('novakur.filters.updated', {detail: json}));
        }).catch(function () {
            if (current === token) {
                busy(false);
            }
        });
    }

    /**
     * The theme's sort and limit dropdowns carry a full URL per option. Refresh those URLs so
     * that picking a sort order after filtering does not throw the filters away. The server
     * builds the option list in the same order the theme rendered it.
     */
    function toolbar(id, hrefs) {
        if (!hrefs || !hrefs.length) {
            return;
        }

        var select = document.getElementById(id);

        if (!select || select.options.length !== hrefs.length) {
            return;
        }

        for (var i = 0; i < hrefs.length; i++) {
            select.options[i].value = hrefs[i];
        }
    }

    function counts(map) {
        if (!map) {
            return;
        }

        Array.prototype.forEach.call(form.querySelectorAll('input.nk-lf-check'), function (input) {
            var key = input.name.replace(/\[\]$/, '') + '|' + input.value;
            var total = Object.prototype.hasOwnProperty.call(map, key) ? map[key] : 0;
            var item = input.closest('.nk-lf-item');

            if (!item) {
                return;
            }

            var badge = item.querySelector('.nk-lf-count');

            if (badge) {
                badge.textContent = total;
            }

            item.classList.toggle('nk-lf-empty', total === 0 && !input.checked);
        });
    }

    /* ------------------------------------------------------------------ history */

    function restore() {
        if (!grid()) {
            window.location.reload();
            return;
        }

        var search = new URLSearchParams(window.location.search);
        var wanted = {};

        ['filter_manufacturer', 'filter_filter', 'filter_attribute', 'filter_option', 'filter_stock'].forEach(function (name) {
            var raw = search.get(name);

            wanted[name] = raw ? raw.split(',') : [];
        });

        Array.prototype.forEach.call(form.querySelectorAll('input.nk-lf-check'), function (input) {
            var name = input.name.replace(/\[\]$/, '');

            input.checked = (wanted[name] || []).indexOf(input.value) !== -1;
        });

        if (slider) {
            var price = search.get('filter_price');
            var low = slider.min;
            var high = slider.max;

            if (price && price.indexOf('-') !== -1) {
                var pair = price.split('-');

                low = pair[0] === '' ? slider.min : clamp(parseFloat(pair[0]), slider.min, slider.max);
                high = pair[1] === '' ? slider.max : clamp(parseFloat(pair[1]), slider.min, slider.max);
            }

            slider.low.value = low;
            slider.high.value = high;

            if (slider.numberLow) {
                slider.numberLow.value = low;
            }

            if (slider.numberHigh) {
                slider.numberHigh.value = high;
            }

            paint();
        }

        apply(parseInt(search.get('page'), 10) || 1, false);
    }

    /* ------------------------------------------------------------------ boot */

    ready(function () {
        form = document.getElementById('novakur-lf');

        if (!form) {
            return;
        }

        initSlider();

        if (form.getAttribute('data-nk-ajax') !== '1' || !SUPPORTED) {
            return;
        }

        form.classList.add('nk-lf-js');

        form.addEventListener('submit', function (event) {
            // No grid on the page (a filter combination matched nothing) - let the browser
            // do a normal GET so the shopper can always get back out again.
            if (!grid()) {
                return;
            }

            event.preventDefault();
            window.clearTimeout(timer);
            apply(1, true);
        });

        form.addEventListener('change', function (event) {
            if (!event.target || !event.target.classList.contains('nk-lf-check')) {
                return;
            }

            window.clearTimeout(timer);

            if (!grid()) {
                form.submit();
                return;
            }

            apply(1, true);
        });

        var clear = form.querySelector('.nk-lf-clear');

        if (clear) {
            clear.addEventListener('click', function (event) {
                if (!grid()) {
                    return;
                }

                event.preventDefault();

                Array.prototype.forEach.call(form.querySelectorAll('input.nk-lf-check'), function (input) {
                    input.checked = false;
                });

                if (slider) {
                    slider.low.value = slider.min;
                    slider.high.value = slider.max;

                    if (slider.numberLow) {
                        slider.numberLow.value = slider.min;
                    }

                    if (slider.numberHigh) {
                        slider.numberHigh.value = slider.max;
                    }

                    paint();
                }

                window.clearTimeout(timer);
                apply(1, true);
            });
        }

        // Keep pagination inside the AJAX flow.
        document.addEventListener('click', function (event) {
            var link = event.target.closest ? event.target.closest('a') : null;

            if (!link || !link.href) {
                return;
            }

            var list = document.getElementById('product-list');

            if (!list || !list.nextElementSibling || !list.nextElementSibling.contains(link)) {
                return;
            }

            var page = new URLSearchParams(link.search).get('page');

            event.preventDefault();
            window.clearTimeout(timer);
            apply(parseInt(page, 10) || 1, true);

            list.scrollIntoView({behavior: 'smooth', block: 'start'});
        });

        window.addEventListener('popstate', function () {
            restore();
        });
    });
})();
