<?php
// Heading
$_['heading_title']     = 'Filter';

// Text
$_['text_price']        = 'Price';
$_['text_manufacturer'] = 'Brand';
$_['text_availability'] = 'Availability';
$_['text_in_stock']     = 'In Stock';
$_['text_out_of_stock'] = 'Out Of Stock';
$_['text_apply']        = 'Apply Filters';
$_['text_clear']        = 'Clear All';
$_['text_loading']      = 'Updating results...';
$_['text_min']          = 'Minimum price';
$_['text_max']          = 'Maximum price';
$_['text_empty']        = 'No products match the selected filters. Try removing one of them.';

// Error
$_['error_disabled']    = 'Warning: Layered filters are not enabled!';
$_['error_category']    = 'Warning: A category is required to filter products!';
