<?php
// Heading
$_['heading_title']       = 'NovaKur Advanced Layered Filters';

// Text
$_['text_extension']      = 'Extensions';
$_['text_home']           = 'Dashboard';
$_['text_success']        = 'Success: You have modified NovaKur Advanced Layered Filters settings!';
$_['text_edit']           = 'Edit NovaKur Advanced Layered Filters';
$_['text_enabled']        = 'Enabled';
$_['text_disabled']       = 'Disabled';
$_['text_general']        = 'General';
$_['text_types']          = 'Filter Types';
$_['text_usage']          = 'How It Works';

// Entry
$_['entry_status']        = 'Status';
$_['entry_price']         = 'Price Range';
$_['entry_filter']        = 'OpenCart Filters';
$_['entry_attribute']     = 'Attributes';
$_['entry_option']        = 'Options';
$_['entry_manufacturer']  = 'Manufacturers';
$_['entry_stock']         = 'Stock Availability';
$_['entry_price_step']    = 'Price Slider Step';
$_['entry_show_counts']   = 'Show Result Counts';
$_['entry_ajax']          = 'Update Without Reload';

// Help
$_['help_price']          = 'Dual handle price slider built from the lowest and highest effective price in the category (specials and discounts included).';
$_['help_filter']         = 'The built in OpenCart filter groups assigned to your products under Catalog &gt; Filters.';
$_['help_attribute']      = 'Distinct product attribute values. Values longer than 64 characters are skipped because those are descriptions rather than facets.';
$_['help_option']         = 'Product option values such as colour and size. Options with a value image are shown as swatches.';
$_['help_manufacturer']   = 'Brands of the products in the category, limited to manufacturers assigned to this store.';
$_['help_stock']          = 'Splits the products into In Stock and Out Of Stock.';
$_['help_price_step']     = 'Increment of the price slider in your default currency. Use 1 for whole units, 0.5 or 10 for coarser steps. Must be greater than 0.';
$_['help_show_counts']    = 'Display the number of matching products next to every filter value.';
$_['help_ajax']           = 'Refresh the product grid in place and rewrite the address bar. Turn this off to force a full page reload on every filter change. The sidebar always works as a plain form when a shopper has JavaScript disabled.';
$_['help_usage']          = 'Enable the module and the filter sidebar is injected into the left column of every category page automatically - no layout change and no theme edit needed. Filtered pages carry their state in the URL (for example ?filter_price=10-50&amp;filter_manufacturer=1,3) so they can be shared, bookmarked and crawled. You can also place the module in a layout position from Design &gt; Layouts if you prefer to control where it appears.';

// Button
$_['button_save']         = 'Save';
$_['button_back']         = 'Back';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify this module!';
$_['error_form']          = 'Warning: Please check the form carefully for errors!';
$_['error_price_step']    = 'The price slider step must be a number greater than 0 and no more than 10000!';
