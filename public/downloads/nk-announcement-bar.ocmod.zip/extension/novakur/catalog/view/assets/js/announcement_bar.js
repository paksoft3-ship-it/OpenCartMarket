(function () {
  var cookieKey = 'nk_ann_dismissed';

  function isDismissed() {
    return document.cookie.split(';').some(function (part) {
      return part.trim().indexOf(cookieKey + '=') === 0;
    });
  }

  function init() {
    var bar = document.getElementById('nk-announcement-bar');
    if (!bar) return;

    var cfg = window.nkAnnouncementBar || { rotate: false, rotateInterval: 4, cookieHours: 24, dismissible: true };

    if (isDismissed()) {
      bar.style.display = 'none';
      return;
    }

    var timers = [];

    var closeBtn = bar.querySelector('.nk-ann-bar__close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        timers.forEach(function (id) { clearInterval(id); });
        timers.length = 0;

        // Collapse first, then take the element out of the flow. transitionend
        // never fires when motion is reduced or the bundle loads without CSS,
        // so a timer closes the gap.
        var hidden = false;

        function hide() {
          if (hidden) return;
          hidden = true;
          bar.style.display = 'none';
        }

        bar.classList.add('is-dismissed');
        bar.addEventListener('transitionend', hide);
        window.setTimeout(hide, 300);

        var d = new Date();
        d.setHours(d.getHours() + Number(cfg.cookieHours || 24));
        document.cookie = cookieKey + '=1; expires=' + d.toUTCString() + '; path=/; SameSite=Lax';
      });
    }

    var items = Array.prototype.slice.call(bar.querySelectorAll('.nk-ann-bar__item'));

    if (cfg.rotate && items.length > 1) {
      var idx = 0;
      items.forEach(function (item, i) { if (i !== 0) item.style.display = 'none'; });

      timers.push(setInterval(function () {
        items[idx].style.display = 'none';
        idx = (idx + 1) % items.length;
        items[idx].style.display = 'block';
      }, Math.max(2, Number(cfg.rotateInterval || 4)) * 1000));
    }

    bar.querySelectorAll('.nk-ann-bar__countdown').forEach(function (el) {
      var end = new Date(el.getAttribute('data-end') || '').getTime();
      if (!end) return;

      var id;

      function tick() {
        var diff = Math.max(0, end - Date.now());
        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        el.textContent = d + 'd ' + h + 'h ' + m + 'm ' + s + 's';

        if (!diff && id) {
          clearInterval(id);
        }
      }

      tick();
      id = setInterval(tick, 1000);
      timers.push(id);
    });
  }

  // The bundle is queued in <head>, so the bar does not exist yet on first run.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
