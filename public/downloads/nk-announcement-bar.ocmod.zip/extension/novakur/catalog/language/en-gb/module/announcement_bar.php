<?php
$_['text_link'] = 'Details';
$_['text_close'] = 'Close';
