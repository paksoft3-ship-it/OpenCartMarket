<?php
namespace Opencart\Catalog\Controller\Extension\NkInvoicePdf\Document;

class InvoicePdf extends \Opencart\System\Engine\Controller {
    /**
     * Printable invoice for the logged in customer's own order.
     *
     * @return void
     */
    public function invoice(): void {
        $this->load->language('extension/nk_invoice_pdf/document/invoice_pdf', '', 'en-gb');
        $this->load->language('extension/nk_invoice_pdf/document/invoice_pdf');

        $data = $this->text();

        $data['packing_slip'] = false;
        $data['title'] = $this->language->get('text_invoice');
        $data['direction'] = $this->language->get('direction');
        $data['lang'] = $this->language->get('code');
        $data['auto_print'] = !isset($this->request->get['preview']);
        $data['documents'] = [];
        $data['logo'] = '';
        $data['company'] = '';
        $data['footer_note'] = '';

        if (!$this->config->get('module_invoice_pdf_status')) {
            $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));

            return;
        }

        // The customer must be logged in and own the order (enforced again by the model query).
        if (!$this->load->controller('account/login.validate')) {
            $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));

            return;
        }

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;

        $this->load->model('account/order');

        $order_info = $this->model_account_order->getOrder($order_id);

        if (!$order_info) {
            $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));

            return;
        }

        $data['logo'] = $this->logo();
        $data['company'] = (string)$this->config->get('module_invoice_pdf_company');
        $data['footer_note'] = (string)$this->config->get('module_invoice_pdf_footer');

        $this->load->model('tool/upload');
        $this->load->model('extension/nk_invoice_pdf/invoice/invoice_pdf');

        $invoice_info = $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->addInvoice($order_id, (string)$this->config->get('module_invoice_pdf_prefix'), (int)$this->config->get('module_invoice_pdf_next_number'));

        $currency_code = $order_info['currency_code'];
        $currency_value = $order_info['currency_value'];

        $products = [];

        $tax_rates = [];

        $net_total = 0.0;
        $tax_total = 0.0;

        foreach ($this->model_account_order->getProducts($order_id) as $product) {
            $options = [];

            foreach ($this->model_account_order->getOptions($order_id, (int)$product['order_product_id']) as $option) {
                if ($option['type'] != 'file') {
                    $value = $option['value'];
                } else {
                    $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

                    $value = $upload_info ? $upload_info['name'] : '';
                }

                $options[] = [
                    'name'  => $option['name'],
                    'value' => (oc_strlen($value) > 40) ? oc_substr($value, 0, 40) . '..' : $value
                ];
            }

            $quantity = (int)$product['quantity'];
            $unit_net = (float)$product['price'];
            $unit_tax = (float)$product['tax'];
            $line_net = (float)$product['total'];
            $line_tax = $unit_tax * $quantity;

            $rate = ($unit_net > 0) ? round(($unit_tax / $unit_net) * 100, 2) : 0.0;

            $net_total += $line_net;
            $tax_total += $line_tax;

            $key = 'r' . number_format($rate, 2, '.', '');

            if (!isset($tax_rates[$key])) {
                $tax_rates[$key] = ['rate' => $rate, 'net' => 0.0, 'tax' => 0.0];
            }

            $tax_rates[$key]['net'] += $line_net;
            $tax_rates[$key]['tax'] += $line_tax;

            $products[] = [
                'name'       => $product['name'],
                'model'      => $product['model'],
                'option'     => $options,
                'quantity'   => $quantity,
                'unit_net'   => $this->currency->format($unit_net, $currency_code, $currency_value),
                'tax_rate'   => $this->rate($rate),
                'line_tax'   => $this->currency->format($line_tax, $currency_code, $currency_value),
                'line_net'   => $this->currency->format($line_net, $currency_code, $currency_value),
                'line_gross' => $this->currency->format($line_net + $line_tax, $currency_code, $currency_value)
            ];
        }

        usort($tax_rates, function (array $a, array $b): int {
            return $b['rate'] <=> $a['rate'];
        });

        $tax_breakdown = [];

        foreach ($tax_rates as $row) {
            $tax_breakdown[] = [
                'rate' => $this->rate($row['rate']),
                'net'  => $this->currency->format($row['net'], $currency_code, $currency_value),
                'tax'  => $this->currency->format($row['tax'], $currency_code, $currency_value)
            ];
        }

        $totals = [];

        foreach ($this->model_account_order->getTotals($order_id) as $total) {
            $totals[] = [
                'title' => $total['title'],
                'text'  => $this->currency->format((float)$total['value'], $currency_code, $currency_value)
            ];
        }

        $store = [
            'name'      => $order_info['store_name'],
            'url'       => $order_info['store_url'],
            'address'   => (string)$this->config->get('config_address'),
            'email'     => (string)$this->config->get('config_email'),
            'telephone' => (string)$this->config->get('config_telephone')
        ];

        $data['documents'][] = [
            'order_id'         => (int)$order_info['order_id'],
            'invoice_no'       => $invoice_info ? $invoice_info['invoice_prefix'] . $invoice_info['invoice_number'] : '',
            'invoice_date'     => $invoice_info ? date($this->language->get('date_format_short'), strtotime($invoice_info['date_added'])) : '',
            'date_added'       => date($this->language->get('date_format_short'), strtotime($order_info['date_added'])),
            'order_status'     => $this->orderStatus((int)$order_info['order_status_id']),
            'store'            => $store,
            'customer'         => trim($order_info['firstname'] . ' ' . $order_info['lastname']),
            'email'            => $order_info['email'],
            'telephone'        => $order_info['telephone'],
            'payment_address'  => $this->address($order_info, 'payment'),
            'shipping_address' => $this->address($order_info, 'shipping'),
            'payment_method'   => $order_info['payment_method']['name'] ?? '',
            'shipping_method'  => $order_info['shipping_method']['name'] ?? '',
            'comment'          => $order_info['comment'],
            'products'         => $products,
            'tax_breakdown'    => $tax_breakdown,
            'totals'           => $totals,
            'net_total'        => $this->currency->format($net_total, $currency_code, $currency_value),
            'tax_total'        => $this->currency->format($tax_total, $currency_code, $currency_value),
            'gross_total'      => $this->currency->format($net_total + $tax_total, $currency_code, $currency_value)
        ];

        $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));
    }

    /**
     * @param int $order_status_id
     *
     * @return string
     */
    protected function orderStatus(int $order_status_id): string {
        $this->load->model('localisation/order_status');

        $order_status_info = $this->model_localisation_order_status->getOrderStatus($order_status_id);

        return $order_status_info ? $order_status_info['name'] : '';
    }

    /**
     * @return string
     */
    protected function logo(): string {
        $logo = (string)$this->config->get('module_invoice_pdf_logo');

        if (!$logo) {
            $logo = (string)$this->config->get('config_logo');
        }

        if (!$logo) {
            return '';
        }

        $file = html_entity_decode($logo, ENT_QUOTES, 'UTF-8');

        $real = realpath(DIR_IMAGE . $file);

        if (!$real || !is_file($real) || substr(str_replace('\\', '/', $real), 0, strlen(DIR_IMAGE)) != DIR_IMAGE) {
            return '';
        }

        return $this->config->get('config_url') . 'image/' . str_replace('%2F', '/', rawurlencode($file));
    }

    /**
     * @param float $rate
     *
     * @return string
     */
    protected function rate(float $rate): string {
        return rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.') . '%';
    }

    /**
     * @param array<string, mixed> $order_info
     * @param string               $type
     *
     * @return string
     */
    protected function address(array $order_info, string $type): string {
        if (!empty($order_info[$type . '_address_format'])) {
            $format = $order_info[$type . '_address_format'];
        } else {
            $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
        }

        $find = [
            '{firstname}',
            '{lastname}',
            '{company}',
            '{address_1}',
            '{address_2}',
            '{city}',
            '{postcode}',
            '{zone}',
            '{zone_code}',
            '{country}'
        ];

        $replace = [
            (string)($order_info[$type . '_firstname'] ?? ''),
            (string)($order_info[$type . '_lastname'] ?? ''),
            (string)($order_info[$type . '_company'] ?? ''),
            (string)($order_info[$type . '_address_1'] ?? ''),
            (string)($order_info[$type . '_address_2'] ?? ''),
            (string)($order_info[$type . '_city'] ?? ''),
            (string)($order_info[$type . '_postcode'] ?? ''),
            (string)($order_info[$type . '_zone'] ?? ''),
            (string)($order_info[$type . '_zone_code'] ?? ''),
            (string)($order_info[$type . '_country'] ?? '')
        ];

        $lines = [];

        foreach (explode("\n", str_replace($find, $replace, $format)) as $line) {
            $line = trim(preg_replace('/[ \t]+/', ' ', $line));

            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return implode("\n", $lines);
    }

    /**
     * @return array<string, string>
     */
    protected function text(): array {
        $keys = [
            'text_invoice',
            'text_packing_slip',
            'text_invoice_no',
            'text_invoice_date',
            'text_order_id',
            'text_order_date',
            'text_order_status',
            'text_bill_to',
            'text_ship_to',
            'text_payment_method',
            'text_shipping_method',
            'text_email',
            'text_telephone',
            'text_comment',
            'text_tax_breakdown',
            'text_net_total',
            'text_tax_total',
            'text_gross_total',
            'text_total',
            'text_print',
            'text_no_orders',
            'column_product',
            'column_model',
            'column_quantity',
            'column_unit_net',
            'column_tax_rate',
            'column_tax_amount',
            'column_line_net',
            'column_line_gross',
            'column_taxable_net',
            'column_tax'
        ];

        $data = [];

        foreach ($keys as $key) {
            $data[$key] = $this->language->get($key);
        }

        return $data;
    }
}
