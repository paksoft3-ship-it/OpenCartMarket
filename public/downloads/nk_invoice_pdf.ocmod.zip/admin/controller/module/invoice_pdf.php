<?php
namespace Opencart\Admin\Controller\Extension\NkInvoicePdf\Module;

class InvoicePdf extends \Opencart\System\Engine\Controller {
    /**
     * Settings form.
     *
     * @return void
     */
    public function index(): void {
        $this->load->language('extension/nk_invoice_pdf/module/invoice_pdf');

        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');

        $settings = $this->model_setting_setting->getSetting('module_invoice_pdf', $store_id);

        $defaults = $this->defaults();

        foreach ($defaults as $key => $value) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $value;
            }
        }

        // Logo preview
        $this->load->model('tool/image');

        $data['placeholder'] = $this->model_tool_image->resize('no_image.png', 200, 100);

        $logo = html_entity_decode((string)$data['module_invoice_pdf_logo'], ENT_QUOTES, 'UTF-8');

        if ($logo && is_file(DIR_IMAGE . $logo)) {
            $data['thumb'] = $this->model_tool_image->resize((string)$data['module_invoice_pdf_logo'], 200, 100);
        } else {
            $data['thumb'] = $data['placeholder'];
        }

        // Live sequence state
        $this->load->model('extension/nk_invoice_pdf/invoice/invoice_pdf');

        $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->createTable();

        $prefix = (string)$data['module_invoice_pdf_prefix'];

        $data['next_number_live'] = $prefix . $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->getNextNumber($prefix, (int)$data['module_invoice_pdf_next_number']);

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_invoice_pdf/module/invoice_pdf', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/nk_invoice_pdf/module/invoice_pdf.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['user_token'] = $this->session->data['user_token'];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/module/invoice_pdf', $data));
    }

    /**
     * AJAX save.
     *
     * @return void
     */
    public function save(): void {
        $this->load->language('extension/nk_invoice_pdf/module/invoice_pdf');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_invoice_pdf/module/invoice_pdf')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;

        $prefix = isset($post['module_invoice_pdf_prefix']) ? trim((string)$post['module_invoice_pdf_prefix']) : '';

        if (oc_strlen($prefix) > 32 || preg_match('/[^A-Za-z0-9_\/\-\.]/', $prefix)) {
            $json['error']['prefix'] = $this->language->get('error_prefix');
        }

        $next_number = isset($post['module_invoice_pdf_next_number']) ? (int)$post['module_invoice_pdf_next_number'] : 1;

        if ($next_number < 1 || $next_number > 999999999) {
            $json['error']['next_number'] = $this->language->get('error_next_number');
        }

        $logo = isset($post['module_invoice_pdf_logo']) ? trim((string)$post['module_invoice_pdf_logo']) : '';

        if ($logo) {
            $file = html_entity_decode($logo, ENT_QUOTES, 'UTF-8');

            $real = realpath(DIR_IMAGE . $file);

            if (!$real || !is_file($real) || substr(str_replace('\\', '/', $real), 0, strlen(DIR_IMAGE)) != DIR_IMAGE) {
                $json['error']['logo'] = $this->language->get('error_logo');
            }
        }

        if (!$json) {
            $save = [];

            $save['module_invoice_pdf_status'] = isset($post['module_invoice_pdf_status']) ? (string)(int)$post['module_invoice_pdf_status'] : '0';
            $save['module_invoice_pdf_show_packing_slip'] = isset($post['module_invoice_pdf_show_packing_slip']) ? (string)(int)$post['module_invoice_pdf_show_packing_slip'] : '0';
            $save['module_invoice_pdf_logo'] = $logo;
            $save['module_invoice_pdf_company'] = isset($post['module_invoice_pdf_company']) ? oc_substr((string)$post['module_invoice_pdf_company'], 0, 2000) : '';
            $save['module_invoice_pdf_prefix'] = $prefix;
            $save['module_invoice_pdf_next_number'] = (string)$next_number;
            $save['module_invoice_pdf_footer'] = isset($post['module_invoice_pdf_footer']) ? oc_substr((string)$post['module_invoice_pdf_footer'], 0, 2000) : '';

            $this->load->model('setting/setting');

            $this->model_setting_setting->editSetting('module_invoice_pdf', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Printable invoice document (admin).
     *
     * @return void
     */
    public function invoice(): void {
        $this->document($this->orderIds(), false);
    }

    /**
     * Printable packing slip — same document with all prices removed.
     *
     * @return void
     */
    public function packingSlip(): void {
        $this->document($this->orderIds(), true);
    }

    /**
     * @return array<int, int>
     */
    protected function orderIds(): array {
        $order_ids = [];

        if (isset($this->request->post['selected'])) {
            foreach ((array)$this->request->post['selected'] as $order_id) {
                $order_ids[] = (int)$order_id;
            }
        }

        if (isset($this->request->get['order_id'])) {
            $order_ids[] = (int)$this->request->get['order_id'];
        }

        return array_values(array_unique(array_filter($order_ids)));
    }

    /**
     * Build and output the printable document.
     *
     * @param array<int, int> $order_ids
     * @param bool            $packing_slip
     *
     * @return void
     */
    protected function document(array $order_ids, bool $packing_slip): void {
        $this->load->language('extension/nk_invoice_pdf/module/invoice_pdf', '', 'en-gb');
        $this->load->language('extension/nk_invoice_pdf/module/invoice_pdf');

        $data = $this->text();

        $data['packing_slip'] = $packing_slip;
        $data['title'] = $packing_slip ? $this->language->get('text_packing_slip') : $this->language->get('text_invoice');
        $data['direction'] = $this->language->get('direction');
        $data['lang'] = $this->language->get('code');
        $data['auto_print'] = !isset($this->request->get['preview']);

        $data['logo'] = $this->logo();
        $data['company'] = (string)$this->config->get('module_invoice_pdf_company');
        $data['footer_note'] = (string)$this->config->get('module_invoice_pdf_footer');

        if ($packing_slip && !$this->config->get('module_invoice_pdf_show_packing_slip')) {
            $data['documents'] = [];

            $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));

            return;
        }

        $this->load->model('sale/order');
        $this->load->model('setting/setting');
        $this->load->model('tool/upload');
        $this->load->model('extension/nk_invoice_pdf/invoice/invoice_pdf');

        $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->createTable();

        $invoice_prefix = (string)$this->config->get('module_invoice_pdf_prefix');
        $invoice_start = (int)$this->config->get('module_invoice_pdf_next_number');

        $data['documents'] = [];

        foreach ($order_ids as $order_id) {
            $order_info = $this->model_sale_order->getOrder($order_id);

            if (!$order_info) {
                continue;
            }

            $currency_code = $order_info['currency_code'];
            $currency_value = $order_info['currency_value'];

            // Invoice number — only issued for real invoices, never for packing slips.
            if (!$packing_slip) {
                $invoice_info = $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->addInvoice($order_id, $invoice_prefix, $invoice_start);

                $invoice_no = $invoice_info ? $invoice_info['invoice_prefix'] . $invoice_info['invoice_number'] : '';
                $invoice_date = $invoice_info ? date($this->language->get('date_format_short'), strtotime($invoice_info['date_added'])) : '';
            } else {
                $invoice_no = '';
                $invoice_date = '';
            }

            // Store block
            $store_info = $this->model_setting_setting->getSetting('config', (int)$order_info['store_id']);

            $store = [
                'name'      => $order_info['store_name'],
                'url'       => $order_info['store_url'],
                'address'   => $store_info['config_address'] ?? (string)$this->config->get('config_address'),
                'email'     => $store_info['config_email'] ?? (string)$this->config->get('config_email'),
                'telephone' => $store_info['config_telephone'] ?? (string)$this->config->get('config_telephone')
            ];

            // Line items
            $products = [];

            $tax_rates = [];

            $net_total = 0.0;
            $tax_total = 0.0;

            foreach ($this->model_sale_order->getProducts($order_id) as $product) {
                $options = [];

                foreach ($this->model_sale_order->getOptions($order_id, (int)$product['order_product_id']) as $option) {
                    if ($option['type'] != 'file') {
                        $value = $option['value'];
                    } else {
                        $upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

                        $value = $upload_info ? $upload_info['name'] : '';
                    }

                    $options[] = [
                        'name'  => $option['name'],
                        'value' => (oc_strlen($value) > 40) ? oc_substr($value, 0, 40) . '..' : $value
                    ];
                }

                $quantity = (int)$product['quantity'];
                $unit_net = (float)$product['price'];
                $unit_tax = (float)$product['tax'];
                $line_net = (float)$product['total'];
                $line_tax = $unit_tax * $quantity;

                $rate = ($unit_net > 0) ? round(($unit_tax / $unit_net) * 100, 2) : 0.0;

                $net_total += $line_net;
                $tax_total += $line_tax;

                $key = 'r' . number_format($rate, 2, '.', '');

                if (!isset($tax_rates[$key])) {
                    $tax_rates[$key] = ['rate' => $rate, 'net' => 0.0, 'tax' => 0.0];
                }

                $tax_rates[$key]['net'] += $line_net;
                $tax_rates[$key]['tax'] += $line_tax;

                $products[] = [
                    'name'          => $product['name'],
                    'model'         => $product['model'],
                    'option'        => $options,
                    'quantity'      => $quantity,
                    'unit_net'      => $this->currency->format($unit_net, $currency_code, $currency_value),
                    'tax_rate'      => $this->rate($rate),
                    'line_tax'      => $this->currency->format($line_tax, $currency_code, $currency_value),
                    'line_net'      => $this->currency->format($line_net, $currency_code, $currency_value),
                    'line_gross'    => $this->currency->format($line_net + $line_tax, $currency_code, $currency_value)
                ];
            }

            // VAT / tax breakdown, highest rate first
            usort($tax_rates, function (array $a, array $b): int {
                return $b['rate'] <=> $a['rate'];
            });

            $tax_breakdown = [];

            foreach ($tax_rates as $row) {
                $tax_breakdown[] = [
                    'rate' => $this->rate($row['rate']),
                    'net'  => $this->currency->format($row['net'], $currency_code, $currency_value),
                    'tax'  => $this->currency->format($row['tax'], $currency_code, $currency_value)
                ];
            }

            // Order totals
            $totals = [];

            foreach ($this->model_sale_order->getTotals($order_id) as $total) {
                $totals[] = [
                    'title' => $total['title'],
                    'text'  => $this->currency->format((float)$total['value'], $currency_code, $currency_value)
                ];
            }

            $data['documents'][] = [
                'order_id'         => (int)$order_info['order_id'],
                'invoice_no'       => $invoice_no,
                'invoice_date'     => $invoice_date,
                'date_added'       => date($this->language->get('date_format_short'), strtotime($order_info['date_added'])),
                'order_status'     => $order_info['order_status'],
                'store'            => $store,
                'customer'         => trim($order_info['firstname'] . ' ' . $order_info['lastname']),
                'email'            => $order_info['email'],
                'telephone'        => $order_info['telephone'],
                'payment_address'  => $this->address($order_info, 'payment'),
                'shipping_address' => $this->address($order_info, 'shipping'),
                'payment_method'   => $order_info['payment_method']['name'] ?? '',
                'shipping_method'  => $order_info['shipping_method']['name'] ?? '',
                'comment'          => $order_info['comment'],
                'products'         => $products,
                'tax_breakdown'    => $tax_breakdown,
                'totals'           => $totals,
                'net_total'        => $this->currency->format($net_total, $currency_code, $currency_value),
                'tax_total'        => $this->currency->format($tax_total, $currency_code, $currency_value),
                'gross_total'      => $this->currency->format($net_total + $tax_total, $currency_code, $currency_value)
            ];
        }

        $this->response->setOutput($this->load->view('extension/nk_invoice_pdf/document/invoice_pdf', $data));
    }

    /**
     * Absolute URL of the configured logo (falls back to the store logo).
     *
     * @return string
     */
    protected function logo(): string {
        $logo = (string)$this->config->get('module_invoice_pdf_logo');

        if (!$logo) {
            $logo = (string)$this->config->get('config_logo');
        }

        if (!$logo) {
            return '';
        }

        $file = html_entity_decode($logo, ENT_QUOTES, 'UTF-8');

        $real = realpath(DIR_IMAGE . $file);

        if (!$real || !is_file($real) || substr(str_replace('\\', '/', $real), 0, strlen(DIR_IMAGE)) != DIR_IMAGE) {
            return '';
        }

        return HTTP_CATALOG . 'image/' . str_replace('%2F', '/', rawurlencode($file));
    }

    /**
     * Format a tax rate for display.
     *
     * @param float $rate
     *
     * @return string
     */
    protected function rate(float $rate): string {
        return rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.') . '%';
    }

    /**
     * Render an OpenCart address block as HTML.
     *
     * @param array<string, mixed> $order_info
     * @param string               $type       payment|shipping
     *
     * @return string
     */
    protected function address(array $order_info, string $type): string {
        if (!empty($order_info[$type . '_address_format'])) {
            $format = $order_info[$type . '_address_format'];
        } else {
            $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
        }

        $find = [
            '{firstname}',
            '{lastname}',
            '{company}',
            '{address_1}',
            '{address_2}',
            '{city}',
            '{postcode}',
            '{zone}',
            '{zone_code}',
            '{country}'
        ];

        $replace = [
            (string)($order_info[$type . '_firstname'] ?? ''),
            (string)($order_info[$type . '_lastname'] ?? ''),
            (string)($order_info[$type . '_company'] ?? ''),
            (string)($order_info[$type . '_address_1'] ?? ''),
            (string)($order_info[$type . '_address_2'] ?? ''),
            (string)($order_info[$type . '_city'] ?? ''),
            (string)($order_info[$type . '_postcode'] ?? ''),
            (string)($order_info[$type . '_zone'] ?? ''),
            (string)($order_info[$type . '_zone_code'] ?? ''),
            (string)($order_info[$type . '_country'] ?? '')
        ];

        $lines = [];

        foreach (explode("\n", str_replace($find, $replace, $format)) as $line) {
            $line = trim(preg_replace('/[ \t]+/', ' ', $line));

            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return implode("\n", $lines);
    }

    /**
     * Language strings used by the printable document.
     *
     * @return array<string, string>
     */
    protected function text(): array {
        $keys = [
            'text_invoice',
            'text_packing_slip',
            'text_invoice_no',
            'text_invoice_date',
            'text_order_id',
            'text_order_date',
            'text_order_status',
            'text_bill_to',
            'text_ship_to',
            'text_payment_method',
            'text_shipping_method',
            'text_email',
            'text_telephone',
            'text_comment',
            'text_tax_breakdown',
            'text_net_total',
            'text_tax_total',
            'text_gross_total',
            'text_total',
            'text_print',
            'text_no_orders',
            'column_product',
            'column_model',
            'column_quantity',
            'column_unit_net',
            'column_tax_rate',
            'column_tax_amount',
            'column_line_net',
            'column_line_gross',
            'column_taxable_net',
            'column_tax'
        ];

        $data = [];

        foreach ($keys as $key) {
            $data[$key] = $this->language->get($key);
        }

        return $data;
    }

    /**
     * @return array<string, string>
     */
    protected function defaults(): array {
        return [
            'module_invoice_pdf_status'            => '0',
            'module_invoice_pdf_logo'              => '',
            'module_invoice_pdf_company'           => '',
            'module_invoice_pdf_prefix'            => 'INV-',
            'module_invoice_pdf_next_number'       => '1',
            'module_invoice_pdf_footer'            => '',
            'module_invoice_pdf_show_packing_slip' => '1'
        ];
    }

    /**
     * @return void
     */
    public function install(): void {
        $this->load->model('setting/setting');

        $this->model_setting_setting->editSetting('module_invoice_pdf', $this->defaults());

        $this->load->model('extension/nk_invoice_pdf/invoice/invoice_pdf');

        $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->createTable();

        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('novakur_invoice_pdf_admin');
        $this->model_setting_event->deleteEventByCode('novakur_invoice_pdf_catalog');

        $this->model_setting_event->addEvent([
            'code'        => 'novakur_invoice_pdf_admin',
            'description' => 'NovaKur Invoice + Packing Slip — adds print buttons to the admin order view.',
            'trigger'     => 'admin/view/sale/order_info/after',
            'action'      => 'extension/nk_invoice_pdf/event/invoice_pdf.orderInfo',
            'status'      => 1,
            'sort_order'  => 1
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'novakur_invoice_pdf_catalog',
            'description' => 'NovaKur Invoice + Packing Slip — adds a print invoice button to the customer order page.',
            'trigger'     => 'catalog/view/account/order_info/after',
            'action'      => 'extension/nk_invoice_pdf/event/invoice_pdf.orderInfo',
            'status'      => 1,
            'sort_order'  => 1
        ]);
    }

    /**
     * @return void
     */
    public function uninstall(): void {
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('novakur_invoice_pdf_admin');
        $this->model_setting_event->deleteEventByCode('novakur_invoice_pdf_catalog');

        $this->load->model('extension/nk_invoice_pdf/invoice/invoice_pdf');

        $this->model_extension_nk_invoice_pdf_invoice_invoice_pdf->dropTable();

        $this->load->model('setting/setting');

        $this->model_setting_setting->deleteSetting('module_invoice_pdf');
    }
}
