<?php
namespace Opencart\Admin\Model\Extension\NkVariantImages\Module;

/**
 * NovaKur Variant Images - admin model.
 *
 * Owns `<prefix>nk_variant_image`: (product, option value) -> product images.
 *
 * `product_image_id` = 0 is a deliberate sentinel for "the product's own main
 * image" (`product`.`image`), which OpenCart keeps on the product row rather
 * than in `product_image`. Without it a merchant could map every extra photo
 * but never map back to the default one.
 */
class VariantImages extends \Opencart\System\Engine\Model {
	/**
	 * @return void
	 */
	public function createTable(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_variant_image` (
			`nk_variant_image_id` int(11) NOT NULL AUTO_INCREMENT,
			`product_id` int(11) NOT NULL DEFAULT '0',
			`option_value_id` int(11) NOT NULL DEFAULT '0',
			`product_image_id` int(11) NOT NULL DEFAULT '0',
			`sort_order` int(3) NOT NULL DEFAULT '0',
			PRIMARY KEY (`nk_variant_image_id`),
			UNIQUE KEY `variant_image` (`product_id`,`option_value_id`,`product_image_id`),
			KEY `product_id` (`product_id`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * Autocomplete source for the product picker.
	 *
	 * @param string $filter_name
	 * @param int    $limit
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getProducts(string $filter_name, int $limit = 10): array {
		if ($limit < 1 || $limit > 50) {
			$limit = 10;
		}

		$sql = "SELECT `p`.`product_id`, `pd`.`name`, `p`.`model` FROM `" . DB_PREFIX . "product` `p` LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id`) WHERE `pd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "'";

		$filter_name = trim($filter_name);

		if ($filter_name !== '') {
			$sql .= " AND `pd`.`name` LIKE '" . $this->db->escape($filter_name . '%') . "'";
		}

		$sql .= " ORDER BY `pd`.`name` ASC LIMIT " . $limit;

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * @param int $product_id
	 *
	 * @return array<string, mixed>
	 */
	public function getProduct(int $product_id): array {
		$query = $this->db->query("SELECT `p`.`product_id`, `p`.`image`, `p`.`model`, `pd`.`name` FROM `" . DB_PREFIX . "product` `p` LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id` AND `pd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "') WHERE `p`.`product_id` = '" . (int)$product_id . "'");

		return $query->row;
	}

	/**
	 * Distinct option values this product actually offers, with the option they
	 * belong to, so the mapping screen can group them.
	 *
	 * @param int $product_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getOptionValues(int $product_id): array {
		$language_id = (int)$this->config->get('config_language_id');

		$query = $this->db->query("SELECT DISTINCT `pov`.`option_value_id`, `ovd`.`name` AS `value_name`, `od`.`name` AS `option_name`, `o`.`sort_order` AS `option_sort`, `ov`.`sort_order` AS `value_sort` FROM `" . DB_PREFIX . "product_option_value` `pov` LEFT JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `pov`.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value_description` `ovd` ON (`ovd`.`option_value_id` = `pov`.`option_value_id` AND `ovd`.`language_id` = '" . $language_id . "') LEFT JOIN `" . DB_PREFIX . "option` `o` ON (`o`.`option_id` = `pov`.`option_id`) LEFT JOIN `" . DB_PREFIX . "option_description` `od` ON (`od`.`option_id` = `pov`.`option_id` AND `od`.`language_id` = '" . $language_id . "') WHERE `pov`.`product_id` = '" . (int)$product_id . "' ORDER BY `o`.`sort_order` ASC, `od`.`name` ASC, `ov`.`sort_order` ASC, `ovd`.`name` ASC");

		return $query->rows;
	}

	/**
	 * The product's images: its main image as id 0, then `product_image` rows.
	 *
	 * @param int $product_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getImages(int $product_id): array {
		$images = [];

		$product = $this->getProduct($product_id);

		if ($product && (string)$product['image'] !== '') {
			$images[] = [
				'product_image_id' => 0,
				'image'            => (string)$product['image'],
				'main'             => true
			];
		}

		$query = $this->db->query("SELECT `product_image_id`, `image` FROM `" . DB_PREFIX . "product_image` WHERE `product_id` = '" . (int)$product_id . "' ORDER BY `sort_order` ASC, `product_image_id` ASC");

		foreach ($query->rows as $row) {
			$images[] = [
				'product_image_id' => (int)$row['product_image_id'],
				'image'            => (string)$row['image'],
				'main'             => false
			];
		}

		return $images;
	}

	/**
	 * @param int $product_id
	 *
	 * @return array<int, array<int, int>> option_value_id => [product_image_id]
	 */
	public function getMap(int $product_id): array {
		$query = $this->db->query("SELECT `option_value_id`, `product_image_id` FROM `" . DB_PREFIX . "nk_variant_image` WHERE `product_id` = '" . (int)$product_id . "' ORDER BY `sort_order` ASC, `nk_variant_image_id` ASC");

		$map = [];

		foreach ($query->rows as $row) {
			$map[(int)$row['option_value_id']][] = (int)$row['product_image_id'];
		}

		return $map;
	}

	/**
	 * Replace the whole map for one product.
	 *
	 * A wholesale delete + insert inside one product is simpler and safer than
	 * diffing: the screen always posts the complete state for that product, and
	 * no other product's rows are touched.
	 *
	 * @param int                         $product_id
	 * @param array<int, array<int, int>> $map option_value_id => [product_image_id]
	 *
	 * @return void
	 */
	public function editMap(int $product_id, array $map): void {
		$this->deleteMap($product_id);

		foreach ($map as $option_value_id => $product_image_ids) {
			$sort_order = 0;

			foreach ($product_image_ids as $product_image_id) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_variant_image` SET `product_id` = '" . (int)$product_id . "', `option_value_id` = '" . (int)$option_value_id . "', `product_image_id` = '" . (int)$product_image_id . "', `sort_order` = '" . (int)$sort_order . "'");

				$sort_order++;
			}
		}
	}

	/**
	 * @param int $product_id
	 *
	 * @return void
	 */
	public function deleteMap(int $product_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_variant_image` WHERE `product_id` = '" . (int)$product_id . "'");
	}

	/**
	 * Products that currently have at least one mapping, for the admin summary.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getMappedProducts(): array {
		$query = $this->db->query("SELECT `vi`.`product_id`, COUNT(*) AS `total`, `pd`.`name` FROM `" . DB_PREFIX . "nk_variant_image` `vi` LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `vi`.`product_id` AND `pd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "') GROUP BY `vi`.`product_id`, `pd`.`name` ORDER BY `pd`.`name` ASC LIMIT 200");

		return $query->rows;
	}

	/**
	 * Drop rows whose product, option value or image has since been deleted.
	 *
	 * @return void
	 */
	public function purgeOrphans(): void {
		$this->db->query("DELETE `vi` FROM `" . DB_PREFIX . "nk_variant_image` `vi` LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `vi`.`product_id`) WHERE `p`.`product_id` IS NULL");

		$this->db->query("DELETE `vi` FROM `" . DB_PREFIX . "nk_variant_image` `vi` LEFT JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `vi`.`option_value_id`) WHERE `ov`.`option_value_id` IS NULL");

		// product_image_id 0 is the sentinel for the product's own image and has
		// no `product_image` row to match, so it is exempt from this sweep.
		$this->db->query("DELETE `vi` FROM `" . DB_PREFIX . "nk_variant_image` `vi` LEFT JOIN `" . DB_PREFIX . "product_image` `pi` ON (`pi`.`product_image_id` = `vi`.`product_image_id`) WHERE `vi`.`product_image_id` > '0' AND `pi`.`product_image_id` IS NULL");
	}
}
