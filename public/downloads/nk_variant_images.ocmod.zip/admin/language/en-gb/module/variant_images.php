<?php
// Heading
$_['heading_title']         = 'NovaKur Variant Images';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified NovaKur Variant Images settings!';
$_['text_map_success']      = 'Success: You have modified the image map for this product!';
$_['text_edit']             = 'Edit NovaKur Variant Images';
$_['text_mapping']          = 'Image Map';
$_['text_mapped_products']  = 'Products with a map';
$_['text_no_mapped']        = 'No product has an image map yet.';
$_['text_no_product']       = 'Search for a product above to map its option values to its images.';
$_['text_not_found']        = 'That product no longer exists.';
$_['text_no_values']        = 'This product has no option values. Add options to it under Catalog &raquo; Products &raquo; Option first.';
$_['text_no_images']        = 'This product has no images. Add images to it under Catalog &raquo; Products &raquo; Image first.';
$_['text_main_image']       = 'Main image';
$_['text_default']          = 'Default:';
$_['text_images_count']     = '%s image(s)';

// Entry
$_['entry_status']          = 'Status';
$_['entry_main_selector']   = 'Main Image Selector';
$_['entry_thumb_selector']  = 'Thumbnail Strip Selector';
$_['entry_swap_thumbs']     = 'Swap Thumbnails';
$_['entry_restore']         = 'Restore On Deselect';
$_['entry_product']         = 'Product';

// Column
$_['column_value']          = 'Option Value';
$_['column_images']         = 'Images';
$_['column_product']        = 'Product';
$_['column_total']          = 'Mapped Images';
$_['column_action']         = 'Action';

// Help
$_['help_status']           = 'Switches the product gallery when the shopper picks an option value that has images mapped to it.';
$_['help_main_selector']    = 'CSS selector for the link wrapping the large product image. Leave the default unless your theme changed the gallery markup; the script also tries a short list of common fallbacks on its own.';
$_['help_thumb_selector']   = 'CSS selector for the container holding the small thumbnail links. Leave empty to only ever swap the main image.';
$_['help_swap_thumbs']      = 'Rebuilds the thumbnail strip from the mapped images as well as swapping the large one.';
$_['help_restore']          = 'Puts the original gallery back when the shopper clears the option. With this off the last mapped set stays on screen.';
$_['help_mapping']          = 'Choose which of this product&rsquo;s existing images belong to each of its option values. The first ticked image becomes the large one. Option values with nothing ticked leave the gallery alone.';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify NovaKur Variant Images!';
$_['error_selector']        = 'Enter a valid CSS selector (up to 255 characters).';
$_['error_product']         = 'Warning: That product does not exist!';
