<?php
namespace Opencart\Admin\Controller\Extension\NkVariantImages\Module;

/**
 * NovaKur Variant Images - admin settings and the per product image map.
 *
 * Routes
 *   extension/nk_variant_images/module/variant_images               settings + mapper
 *   extension/nk_variant_images/module/variant_images.save          settings
 *   extension/nk_variant_images/module/variant_images.autocomplete  product picker
 *   extension/nk_variant_images/module/variant_images.map           mapping panel (AJAX)
 *   extension/nk_variant_images/module/variant_images.map_save      the map for one product
 *
 * The mapper is a standalone screen rather than an injected tab on the core
 * product form. Injecting a tab means hooking admin/view/catalog/product_form,
 * smuggling fields into a form whose save() ignores unknown keys, and then
 * hooking the product model's save as well - three brittle joints for no gain.
 * One screen with a product search does the same job and keeps working when
 * OpenCart rearranges its product form.
 */
class VariantImages extends \Opencart\System\Engine\Controller {
	private const ROUTE = 'extension/nk_variant_images/module/variant_images';

	private const PREFIX = 'module_variant_images';

	/**
	 * Stock OpenCart 4.1 product template markup:
	 *
	 *   <div class="image magnific-popup">
	 *     <a href="{{ popup }}"><img src="{{ thumb }}" class="img-thumbnail mb-3"/></a>
	 *     <div>
	 *       <a href="{{ image.popup }}"><img src="{{ image.thumb }}" class="img-thumbnail"/></a>
	 *     </div>
	 *   </div>
	 *
	 * verified against upload/catalog/view/template/product/product.twig.
	 */
	private const DEFAULT_MAIN_SELECTOR  = '#product-info .image.magnific-popup > a';
	private const DEFAULT_THUMB_SELECTOR = '#product-info .image.magnific-popup > div';

	/**
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'nk_variant_images_assets',
			'description' => 'NovaKur Variant Images: queue the gallery script in the page head.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/nk_variant_images/event/variant_images.assets'
		],
		[
			'code'        => 'nk_variant_images_product',
			'description' => 'NovaKur Variant Images: attach the option value to image map to the product page.',
			'trigger'     => 'catalog/view/product/product/after',
			'action'      => 'extension/nk_variant_images/event/variant_images.product'
		]
	];

	/**
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			self::PREFIX . '_status'         => '0',
			self::PREFIX . '_main_selector'  => self::DEFAULT_MAIN_SELECTOR,
			self::PREFIX . '_thumb_selector' => self::DEFAULT_THUMB_SELECTOR,
			self::PREFIX . '_swap_thumbs'    => '1',
			self::PREFIX . '_restore'        => '1'
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language(self::ROUTE);

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting(self::PREFIX, $store_id);

		$data = [];

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		$data['default_main_selector'] = self::DEFAULT_MAIN_SELECTOR;
		$data['default_thumb_selector'] = self::DEFAULT_THUMB_SELECTOR;

		$this->load->model('extension/nk_variant_images/module/variant_images');

		$data['mapped'] = [];

		foreach ($this->model_extension_nk_variant_images_module_variant_images->getMappedProducts() as $row) {
			$data['mapped'][] = [
				'product_id' => (int)$row['product_id'],
				'name'       => (string)($row['name'] ?? ''),
				'total'      => (int)$row['total'],
				'edit'       => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id . '&product_id=' . (int)$row['product_id'])
			];
		}

		$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

		$data['product_id'] = $product_id;
		$data['map'] = $product_id ? $this->getMap($product_id) : '';

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save'] = $this->url->link(self::ROUTE . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['autocomplete'] = $this->url->link(self::ROUTE . '.autocomplete', 'user_token=' . $this->session->data['user_token']);
		$data['map_url'] = $this->url->link(self::ROUTE . '.map', 'user_token=' . $this->session->data['user_token']);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$main_selector = isset($post[self::PREFIX . '_main_selector']) ? trim((string)$post[self::PREFIX . '_main_selector']) : '';

		if (!self::validSelector($main_selector)) {
			$json['error']['main_selector'] = $this->language->get('error_selector');
		}

		$thumb_selector = isset($post[self::PREFIX . '_thumb_selector']) ? trim((string)$post[self::PREFIX . '_thumb_selector']) : '';

		// The thumbnail strip is optional: a theme may only have a main image.
		if ($thumb_selector !== '' && !self::validSelector($thumb_selector)) {
			$json['error']['thumb_selector'] = $this->language->get('error_selector');
		}

		if (!isset($json['error'])) {
			$save = [
				self::PREFIX . '_status'         => !empty($post[self::PREFIX . '_status']) ? '1' : '0',
				self::PREFIX . '_main_selector'  => $main_selector,
				self::PREFIX . '_thumb_selector' => $thumb_selector,
				self::PREFIX . '_swap_thumbs'    => !empty($post[self::PREFIX . '_swap_thumbs']) ? '1' : '0',
				self::PREFIX . '_restore'        => !empty($post[self::PREFIX . '_restore']) ? '1' : '0'
			];

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting(self::PREFIX, $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Product picker source. Deliberately its own endpoint rather than core's
	 * catalog/product.autocomplete, so using this screen does not require the
	 * user group to hold the catalog/product permission.
	 *
	 * @return void
	 */
	public function autocomplete(): void {
		$json = [];

		if ($this->user->hasPermission('access', self::ROUTE)) {
			$filter_name = isset($this->request->get['filter_name']) ? (string)$this->request->get['filter_name'] : '';

			$limit = (int)$this->config->get('config_autocomplete_limit');

			$this->load->model('extension/nk_variant_images/module/variant_images');

			foreach ($this->model_extension_nk_variant_images_module_variant_images->getProducts($filter_name, $limit > 0 ? $limit : 10) as $row) {
				$json[] = [
					'product_id' => (int)$row['product_id'],
					'name'       => html_entity_decode((string)($row['name'] ?? ''), ENT_QUOTES, 'UTF-8'),
					'model'      => (string)($row['model'] ?? '')
				];
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function map(): void {
		$this->load->language(self::ROUTE);

		$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

		$this->response->setOutput($this->getMap($product_id));
	}

	/**
	 * @param int $product_id
	 *
	 * @return string
	 */
	private function getMap(int $product_id): string {
		$this->load->model('extension/nk_variant_images/module/variant_images');
		$this->load->model('tool/image');

		$model = $this->model_extension_nk_variant_images_module_variant_images;

		$data = [];

		$data['product_id'] = $product_id;

		$product = $model->getProduct($product_id);

		$data['product_name'] = (string)($product['name'] ?? '');
		$data['found'] = (bool)$product;

		$placeholder = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['images'] = [];

		foreach ($model->getImages($product_id) as $image) {
			$path = (string)$image['image'];

			if ($path !== '' && is_file(DIR_IMAGE . html_entity_decode($path, ENT_QUOTES, 'UTF-8'))) {
				$thumb = $this->model_tool_image->resize($path, 100, 100);
			} else {
				$thumb = $placeholder;
			}

			$data['images'][] = [
				'product_image_id' => (int)$image['product_image_id'],
				'thumb'            => $thumb,
				'main'             => (bool)$image['main']
			];
		}

		$map = $model->getMap($product_id);

		$data['values'] = [];

		foreach ($model->getOptionValues($product_id) as $row) {
			$option_value_id = (int)$row['option_value_id'];

			$data['values'][] = [
				'option_value_id' => $option_value_id,
				'option_name'     => (string)($row['option_name'] ?? ''),
				'value_name'      => (string)($row['value_name'] ?? ''),
				'selected'        => $map[$option_value_id] ?? []
			];
		}

		$data['save'] = $this->url->link(self::ROUTE . '.map_save', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $product_id);

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_variant_images/module/variant_images_map', $data);
	}

	/**
	 * Persist the map for one product.
	 *
	 * Both halves of every posted pair are checked against reality before they
	 * are stored: the option value must be one the product actually offers and
	 * the image must be one the product actually owns. That makes the storefront
	 * read a straight lookup with nothing left to validate.
	 *
	 * @return void
	 */
	public function map_save(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

		if ($product_id < 1) {
			$json['error']['warning'] = $this->language->get('error_product');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_variant_images/module/variant_images');

			$model = $this->model_extension_nk_variant_images_module_variant_images;

			if (!$model->getProduct($product_id)) {
				$json['error']['warning'] = $this->language->get('error_product');
			} else {
				$allowed_values = [];

				foreach ($model->getOptionValues($product_id) as $row) {
					$allowed_values[(int)$row['option_value_id']] = true;
				}

				$allowed_images = [];

				foreach ($model->getImages($product_id) as $image) {
					$allowed_images[(int)$image['product_image_id']] = true;
				}

				$posted = (isset($this->request->post['image']) && is_array($this->request->post['image'])) ? $this->request->post['image'] : [];

				$map = [];

				foreach ($posted as $option_value_id => $product_image_ids) {
					$option_value_id = (int)$option_value_id;

					if (!isset($allowed_values[$option_value_id]) || !is_array($product_image_ids)) {
						continue;
					}

					$clean = [];

					foreach ($product_image_ids as $product_image_id) {
						$product_image_id = (int)$product_image_id;

						// isset() on the key, not in_array on the value: 0 is a
						// legitimate id here and must not be confused with "no".
						if (isset($allowed_images[$product_image_id]) && !isset($clean[$product_image_id])) {
							$clean[$product_image_id] = $product_image_id;
						}
					}

					if ($clean) {
						$map[$option_value_id] = array_values($clean);
					}
				}

				$model->editMap($product_id, $map);
				$model->purgeOrphans();

				$json['success'] = $this->language->get('text_map_success');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * A gallery selector is handed straight to querySelector() in the browser.
	 * It travels there inside JSON, so it cannot break out of the page; this
	 * check is about keeping obvious nonsense out of the setting.
	 *
	 * @param string $selector
	 *
	 * @return bool
	 */
	public static function validSelector(string $selector): bool {
		$selector = trim($selector);

		if ($selector === '' || oc_strlen($selector) > 255) {
			return false;
		}

		// Letters, digits and the punctuation CSS selectors are actually made
		// of. '>' is a child combinator and stays; '<' has no meaning in CSS and
		// is the one character that would matter if this ever reached markup.
		return (bool)preg_match('/^[A-Za-z0-9_\-#.,:()\[\]="\'>+~*\s]+$/', $selector);
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/nk_variant_images/module/variant_images');

		$this->model_extension_nk_variant_images_module_variant_images->createTable();

		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting(self::PREFIX, $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}

		$this->load->model('user/user_group');

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', self::ROUTE);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', self::ROUTE);
	}

	/**
	 * The map is merchant data, so `nk_variant_image` outlives an uninstall.
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting(self::PREFIX);
	}
}
