<?php
namespace Opencart\Catalog\Model\Extension\NkVariantImages\Module;

/**
 * NovaKur Variant Images - storefront read of the image map.
 */
class VariantImages extends \Opencart\System\Engine\Model {
	/**
	 * Hard ceiling so one product cannot pull an unbounded result set.
	 */
	private const MAX_ROWS = 400;

	/**
	 * Mapped images for a product, keyed by the value the *form field* carries.
	 *
	 * The product page submits `option[product_option_id] = product_option_value_id`,
	 * while the map is stored against `option_value_id` (which is what makes one
	 * mapping reusable across every option row of the product). The join between
	 * the two happens here, once, so the browser only ever sees the id it can
	 * actually read off the form.
	 *
	 * `product_image_id` 0 means the product's own `product`.`image`.
	 *
	 * @param int             $product_id
	 * @param array<int, int> $product_option_ids
	 *
	 * @return array<int, array<int, string>> product_option_value_id => [image path]
	 */
	public function getMap(int $product_id, array $product_option_ids): array {
		$ids = [];

		foreach ($product_option_ids as $product_option_id) {
			$product_option_id = (int)$product_option_id;

			if ($product_option_id > 0) {
				$ids[$product_option_id] = $product_option_id;
			}
		}

		if ($product_id < 1 || !$ids) {
			return [];
		}

		$query = $this->db->query("SELECT `pov`.`product_option_value_id`, (CASE WHEN `vi`.`product_image_id` = '0' THEN `p`.`image` ELSE `pi`.`image` END) AS `image` FROM `" . DB_PREFIX . "nk_variant_image` `vi` INNER JOIN `" . DB_PREFIX . "product_option_value` `pov` ON (`pov`.`option_value_id` = `vi`.`option_value_id` AND `pov`.`product_option_id` IN (" . implode(',', $ids) . ")) LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `vi`.`product_id`) LEFT JOIN `" . DB_PREFIX . "product_image` `pi` ON (`pi`.`product_image_id` = `vi`.`product_image_id` AND `pi`.`product_id` = `vi`.`product_id`) WHERE `vi`.`product_id` = '" . (int)$product_id . "' ORDER BY `vi`.`option_value_id` ASC, `vi`.`sort_order` ASC, `vi`.`nk_variant_image_id` ASC LIMIT " . self::MAX_ROWS);

		$map = [];

		foreach ($query->rows as $row) {
			$image = (string)($row['image'] ?? '');

			// A deleted product_image leaves a NULL here rather than silently
			// falling back to the main photo.
			if ($image === '') {
				continue;
			}

			$product_option_value_id = (int)$row['product_option_value_id'];

			if (!isset($map[$product_option_value_id])) {
				$map[$product_option_value_id] = [];
			}

			if (!in_array($image, $map[$product_option_value_id], true)) {
				$map[$product_option_value_id][] = $image;
			}
		}

		return $map;
	}
}
