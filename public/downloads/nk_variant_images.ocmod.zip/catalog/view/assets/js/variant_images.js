/**
 * NovaKur Variant Images - storefront.
 *
 * Listens for a change on any option field inside #form-product, looks the
 * chosen product_option_value_id up in the map the PHP event attached to the
 * page, and repoints the gallery at the mapped images.
 *
 * Three rules the whole file exists to keep:
 *
 *   1. If the shopper's selection has no mapping, the gallery is left exactly
 *      as OpenCart rendered it. Nothing is emptied "ready" for a swap.
 *   2. The original gallery is captured once, before anything is touched, so it
 *      can always be put back.
 *   3. Anchors are rewritten, never replaced wholesale on the container, so the
 *      theme's Magnific Popup binding - which delegates from `.magnific-popup`
 *      down to `a` - keeps working on the new images.
 *
 * It hears swatch clicks from NovaKur Color Swatches for free: that module
 * drives the same native field and fires the same native `change` event.
 */
(function (root, factory) {
  var api = factory();

  if (root) {
    root.NkVariantImages = api;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        api.boot(document);
      });
    } else {
      api.boot(document);
    }
  }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  var MAIN_FALLBACKS = [
    '#product-info .image.magnific-popup > a',
    '.magnific-popup > a',
    '#content .image a',
    '#product-info .image a'
  ];

  var THUMB_FALLBACKS = [
    '#product-info .image.magnific-popup > div',
    '.magnific-popup > div',
    '#content .image > div'
  ];

  /**
   * @param {string} text
   * @returns {object|null}
   */
  function readPayload(text) {
    var raw;

    try {
      raw = JSON.parse(text);
    } catch (e) {
      return null;
    }

    if (!raw || typeof raw !== 'object' || !raw.map || typeof raw.map !== 'object') {
      return null;
    }

    var map = {};
    var found = false;

    Object.keys(raw.map).forEach(function (key) {
      var set = raw.map[key];

      if (!Array.isArray(set)) {
        return;
      }

      var clean = set.filter(function (image) {
        return image && typeof image.t === 'string' && typeof image.p === 'string' && image.t !== '' && image.p !== '';
      });

      if (clean.length) {
        map[String(key)] = clean;
        found = true;
      }
    });

    if (!found) {
      return null;
    }

    return {
      main: typeof raw.main === 'string' ? raw.main : '',
      thumbs: typeof raw.thumbs === 'string' ? raw.thumbs : '',
      swap: raw.swap === 1 || raw.swap === '1' || raw.swap === true,
      restore: raw.restore === 1 || raw.restore === '1' || raw.restore === true,
      map: map
    };
  }

  /**
   * The first selected value that has a mapping wins. Order matters: it is the
   * order the option controls appear in the form, so on a product with both
   * "Colour" and "Size" the colour - listed first - drives the gallery.
   *
   * @param {string[]} values selected product_option_value_ids, in form order
   * @param {object} map
   * @returns {Array|null}
   */
  function pickSet(values, map) {
    for (var i = 0; i < values.length; i++) {
      var set = map[String(values[i])];

      if (set && set.length) {
        return set;
      }
    }

    return null;
  }

  /**
   * @param {string} value
   * @returns {string}
   */
  function escapeAttr(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /**
   * Rebuild the thumbnail strip, matching the markup product.twig emits.
   *
   * @param {Array} set
   * @param {string} alt
   * @returns {string}
   */
  function thumbsHtml(set, alt) {
    var title = escapeAttr(alt || '');

    return set.map(function (image) {
      return '<a href="' + escapeAttr(image.p) + '" title="' + title + '">'
        + '<img src="' + escapeAttr(image.a || image.t) + '" title="' + title + '" alt="' + title + '" class="img-thumbnail"/>'
        + '</a>&nbsp;';
    }).join('');
  }

  /**
   * Point the gallery at one image set.
   *
   * `gallery` is a plain description of the DOM nodes involved, so this can be
   * exercised without a browser.
   *
   * @param {object} gallery {link, img, thumbs, alt}
   * @param {Array} set
   * @param {boolean} swap
   * @returns {boolean}
   */
  function applySet(gallery, set, swap) {
    if (!gallery || !set || !set.length) {
      return false;
    }

    var first = set[0];

    if (gallery.link) {
      gallery.link.href = first.p;
    }

    if (gallery.img) {
      gallery.img.src = first.t;
    }

    if (swap && gallery.thumbs) {
      gallery.thumbs.innerHTML = thumbsHtml(set, gallery.alt);
    }

    return true;
  }

  /**
   * @param {object} gallery
   * @param {object} original
   */
  function restore(gallery, original) {
    if (!gallery || !original) {
      return;
    }

    if (gallery.link && typeof original.href === 'string') {
      gallery.link.href = original.href;
    }

    if (gallery.img && typeof original.src === 'string') {
      gallery.img.src = original.src;
    }

    if (gallery.thumbs && typeof original.thumbs === 'string') {
      gallery.thumbs.innerHTML = original.thumbs;
    }
  }

  // ---------------------------------------------------------------- DOM ----

  function firstMatch(doc, selectors) {
    for (var i = 0; i < selectors.length; i++) {
      if (!selectors[i]) {
        continue;
      }

      var found;

      // A merchant-typed selector can be invalid; that must not take the page
      // down, it just means "try the next one".
      try {
        found = doc.querySelector(selectors[i]);
      } catch (e) {
        found = null;
      }

      if (found) {
        return found;
      }
    }

    return null;
  }

  function findGallery(doc, config) {
    var link = firstMatch(doc, [config.main].concat(MAIN_FALLBACKS));

    if (!link) {
      return null;
    }

    var thumbs = config.swap ? firstMatch(doc, [config.thumbs].concat(THUMB_FALLBACKS)) : null;

    // The strip must not be the element holding the main image, or swapping it
    // would delete the main image along with the thumbnails.
    if (thumbs && (thumbs === link || thumbs.contains(link))) {
      thumbs = null;
    }

    var img = link.querySelector ? link.querySelector('img') : null;

    return {
      link: link,
      img: img,
      thumbs: thumbs,
      alt: img ? (img.getAttribute('alt') || '') : ''
    };
  }

  function selectedValues(form) {
    var values = [];
    var fields = form.querySelectorAll('select[name^="option["], input[type="radio"][name^="option["], input[type="checkbox"][name^="option["]');

    Array.prototype.forEach.call(fields, function (field) {
      if (field.tagName === 'SELECT') {
        if (field.value !== '') {
          values.push(String(field.value));
        }

        return;
      }

      if (field.checked && field.value !== '') {
        values.push(String(field.value));
      }
    });

    return values;
  }

  /**
   * @param {Document} doc
   */
  function boot(doc) {
    var holder = doc.getElementById('nk-variant-image-data');

    if (!holder) {
      return;
    }

    var config = readPayload(holder.textContent || holder.innerHTML || '');

    if (!config) {
      return;
    }

    var form = doc.getElementById('form-product');

    if (!form) {
      return;
    }

    var gallery = findGallery(doc, config);

    if (!gallery || !gallery.img) {
      return;
    }

    // Captured before anything is touched.
    var original = {
      href: gallery.link.getAttribute('href') || '',
      src: gallery.img.getAttribute('src') || '',
      thumbs: gallery.thumbs ? gallery.thumbs.innerHTML : null
    };

    // Dim the wrapper while the new file is on the wire, clear it once the
    // browser has the pixels. Purely cosmetic - if any of it is unavailable the
    // swap still happens, just without the fade.
    function flash(swapper) {
      var host = gallery.link.parentNode;
      var classed = !!(host && host.classList);

      if (classed) {
        host.classList.add('nk-variant-swapping');
      }

      swapper();

      if (!classed) {
        return;
      }

      var done = function () {
        host.classList.remove('nk-variant-swapping');
      };

      if (!gallery.img || gallery.img.complete || typeof gallery.img.addEventListener !== 'function') {
        done();

        return;
      }

      gallery.img.addEventListener('load', done, { once: true });
      gallery.img.addEventListener('error', done, { once: true });
    }

    function update() {
      var set = pickSet(selectedValues(form), config.map);

      if (set) {
        flash(function () {
          applySet(gallery, set, config.swap);
        });

        return;
      }

      if (config.restore) {
        flash(function () {
          restore(gallery, original);
        });
      }
    }

    form.addEventListener('change', function (e) {
      var name = e.target && e.target.name ? String(e.target.name) : '';

      if (name.indexOf('option[') === 0) {
        update();
      }
    });

    // A theme, a saved form state or a swatch module may already have something
    // chosen by the time this runs.
    update();
  }

  return {
    boot: boot,
    readPayload: readPayload,
    pickSet: pickSet,
    thumbsHtml: thumbsHtml,
    applySet: applySet,
    restore: restore,
    escapeAttr: escapeAttr
  };
});
