<?php
namespace Opencart\Catalog\Controller\Extension\NkVariantImages\Event;

/**
 * NovaKur Variant Images - storefront hooks.
 *
 * assets()  catalog/controller/common/header/before  queue CSS + JS
 * product() catalog/view/product/product/after       attach the image map
 *
 * The map is resolved to finished image URLs here rather than in the browser,
 * because only PHP can run OpenCart's image cache (Tool\Image::resize writes
 * image/cache/... on demand) and only PHP knows the store's configured
 * thumb / additional / popup dimensions. The browser receives nothing but URLs.
 *
 * Verified against upload/catalog/view/template/product/product.twig (4.1.0.3):
 * the gallery is
 *
 *   <div class="image magnific-popup">
 *     <a href="{{ popup }}"><img src="{{ thumb }}" class="img-thumbnail mb-3"/></a>
 *     <div><a href="{{ image.popup }}"><img src="{{ image.thumb }}" class="img-thumbnail"/></a>&nbsp;</div>
 *   </div>
 *
 * so the main image is the first child <a> and the strip is the sibling <div>.
 * Both selectors are settings, and the script keeps its own fallback chain for
 * themes that moved things.
 */
class VariantImages extends \Opencart\System\Engine\Controller {
	private const CSS = 'extension/nk_variant_images/catalog/view/assets/css/variant_images.css';
	private const JS  = 'extension/nk_variant_images/catalog/view/assets/js/variant_images.js';

	private const MARKER = 'id="nk-variant-image-data"';

	private const DEFAULT_MAIN_SELECTOR  = '#product-info .image.magnific-popup > a';
	private const DEFAULT_THUMB_SELECTOR = '#product-info .image.magnific-popup > div';

	/**
	 * @param string               $route
	 * @param array<string, mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!$this->enabled()) {
			return;
		}

		$this->document->addStyle(self::CSS);
		$this->document->addScript(self::JS);
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function product(string &$route, array &$data, mixed &$output): void {
		if (!$this->enabled() || !is_string($output) || $output === '') {
			return;
		}

		if (str_contains($output, self::MARKER)) {
			return;
		}

		$product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

		if ($product_id < 1 || !isset($data['options']) || !is_array($data['options'])) {
			return;
		}

		$product_option_ids = [];

		foreach ($data['options'] as $option) {
			if (is_array($option) && isset($option['product_option_id'])) {
				$product_option_ids[] = (int)$option['product_option_id'];
			}
		}

		if (!$product_option_ids) {
			return;
		}

		$this->load->model('extension/nk_variant_images/module/variant_images');

		$rows = $this->model_extension_nk_variant_images_module_variant_images->getMap($product_id, $product_option_ids);

		if (!$rows) {
			return;
		}

		$this->load->model('tool/image');

		$map = [];

		foreach ($rows as $product_option_value_id => $images) {
			$set = [];

			foreach ($images as $image) {
				$entry = $this->resolve($image);

				if ($entry) {
					$set[] = $entry;
				}
			}

			if ($set) {
				$map[(string)$product_option_value_id] = $set;
			}
		}

		if (!$map) {
			return;
		}

		$payload = [
			'main'    => $this->selector('main_selector', self::DEFAULT_MAIN_SELECTOR, false),
			'thumbs'  => $this->selector('thumb_selector', self::DEFAULT_THUMB_SELECTOR, true),
			'swap'    => (int)(bool)(int)$this->config->get('module_variant_images_swap_thumbs'),
			'restore' => (int)(bool)(int)$this->config->get('module_variant_images_restore'),
			'map'     => $map
		];

		$json = json_encode($payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);

		if (!is_string($json)) {
			return;
		}

		$output .= '<script type="application/json" ' . self::MARKER . '>' . $json . '</script>';
	}

	/**
	 * One image path -> the three sizes the gallery needs.
	 *
	 * @param string $image
	 *
	 * @return array<string, string> empty when the file is missing or unusable
	 */
	private function resolve(string $image): array {
		$image = trim($image);

		if ($image === '' || str_contains($image, '..') || str_contains($image, "\0") || $image[0] === '/') {
			return [];
		}

		if (!is_file(DIR_IMAGE . html_entity_decode($image, ENT_QUOTES, 'UTF-8'))) {
			return [];
		}

		$entry = [
			// main slot, strip thumbnail, lightbox
			't' => (string)$this->model_tool_image->resize($image, (int)$this->config->get('config_image_thumb_width'), (int)$this->config->get('config_image_thumb_height')),
			'a' => (string)$this->model_tool_image->resize($image, (int)$this->config->get('config_image_additional_width'), (int)$this->config->get('config_image_additional_height')),
			'p' => (string)$this->model_tool_image->resize($image, (int)$this->config->get('config_image_popup_width'), (int)$this->config->get('config_image_popup_height'))
		];

		foreach ($entry as $url) {
			// These end up in an href and a src built by string concatenation in
			// the browser. A URL carrying a quote or a bracket is dropped rather
			// than escaped, which keeps the JS side free of escaping rules.
			if ($url === '' || preg_match('/[\'"<>\s]/', $url)) {
				return [];
			}
		}

		return $entry;
	}

	/**
	 * @param string $key
	 * @param string $default
	 * @param bool   $optional true when an empty setting means "do not do this"
	 *                         rather than "use the default"
	 *
	 * @return string
	 */
	private function selector(string $key, string $default, bool $optional): string {
		$selector = trim((string)$this->config->get('module_variant_images_' . $key));

		if ($selector === '') {
			return $optional ? '' : $default;
		}

		return oc_strlen($selector) > 255 ? $default : $selector;
	}

	/**
	 * @return bool
	 */
	private function enabled(): bool {
		return (bool)(int)$this->config->get('module_variant_images_status');
	}
}
