/**
 * NovaKur Speed Optimization Pack - lightweight infinite scroll.
 *
 * Appends the next category page's product grid when a sentinel element scrolls
 * into view. The real pagination markup is never removed, so crawlers and
 * visitors without JavaScript keep the full paginated navigation.
 *
 * Configuration arrives on this script's own src query string as a single
 * "nk=<selector>|<maxPages>" parameter, which avoids an inline <script> (CSP
 * friendly) and keeps a raw "&" out of the emitted markup.
 */
(function () {
  'use strict';

  var script = document.currentScript;

  if (!script || !('IntersectionObserver' in window) || typeof window.fetch !== 'function') {
    return;
  }

  var config = readConfig(script.src);
  var selector = config[0] || '#product-list';
  var maxPages = parseInt(config[1], 10);

  if (isNaN(maxPages) || maxPages < 0) {
    maxPages = 0;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }

  /**
   * "...speed_pack.js?nk=%23product-list%7C0" -> ['#product-list', '0']
   */
  function readConfig(src) {
    try {
      var query = String(src).split('?')[1];

      if (!query || query.indexOf('nk=') !== 0) {
        return [];
      }

      return decodeURIComponent(query.slice(3)).split('|');
    } catch (e) {
      return [];
    }
  }

  function findGrid() {
    try {
      return document.querySelector(selector);
    } catch (e) {
      return null;
    }
  }

  /**
   * Resolves the next page URL from rel="next" first (OpenCart emits it on
   * category pages), then from the pagination widget as a fallback.
   */
  function findNext(root) {
    var link = root.querySelector('link[rel="next"]');

    if (link && link.href) {
      return link.href;
    }

    var active = root.querySelector('.pagination .page-item.active');

    if (!active) {
      return '';
    }

    var current = parseInt((active.textContent || '').trim(), 10);

    if (isNaN(current)) {
      return '';
    }

    var anchors = root.querySelectorAll('.pagination .page-item a[href]');

    for (var i = 0; i < anchors.length; i++) {
      if (parseInt((anchors[i].textContent || '').trim(), 10) === current + 1) {
        return anchors[i].href;
      }
    }

    return '';
  }

  function sameOrigin(url) {
    try {
      return new URL(url, window.location.href).origin === window.location.origin;
    } catch (e) {
      return false;
    }
  }

  function start() {
    var grid = findGrid();

    if (!grid || !grid.parentNode) {
      return;
    }

    var next = findNext(document);

    if (!next || !sameOrigin(next)) {
      return;
    }

    var loaded = 0;
    var busy = false;
    var done = false;

    var sentinel = document.createElement('div');
    sentinel.className = 'nk-speed-sentinel';
    sentinel.setAttribute('aria-hidden', 'true');
    sentinel.innerHTML = '<span class="nk-speed-spinner"></span>';
    grid.parentNode.insertBefore(sentinel, grid.nextSibling);

    var observer = new IntersectionObserver(function (entries) {
      for (var i = 0; i < entries.length; i++) {
        if (entries[i].isIntersecting) {
          load();
        }
      }
    }, { rootMargin: '400px 0px' });

    observer.observe(sentinel);

    function stop() {
      done = true;

      try {
        observer.disconnect();
      } catch (e) {
        /* no-op */
      }

      if (sentinel.parentNode) {
        sentinel.parentNode.removeChild(sentinel);
      }
    }

    function load() {
      if (busy || done || !next) {
        return;
      }

      if (maxPages > 0 && loaded >= maxPages) {
        stop();

        return;
      }

      busy = true;
      sentinel.classList.add('nk-speed-loading');

      var url = next;

      window.fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'NovaKurSpeedPack' } })
        .then(function (response) {
          if (!response.ok) {
            throw new Error('HTTP ' + response.status);
          }

          return response.text();
        })
        .then(function (html) {
          var doc = new DOMParser().parseFromString(html, 'text/html');
          var incoming = null;

          try {
            incoming = doc.querySelector(selector);
          } catch (e) {
            incoming = null;
          }

          if (!incoming || !incoming.children.length) {
            stop();

            return;
          }

          var fragment = document.createDocumentFragment();

          while (incoming.firstElementChild) {
            fragment.appendChild(document.adoptNode(incoming.firstElementChild));
          }

          grid.appendChild(fragment);
          loaded++;

          // Resolve the following page BEFORE the pagination node is adopted
          // out of the parsed document by syncPagination().
          next = findNext(doc);

          // Keep the visible pagination in step with what has been loaded.
          syncPagination(doc);

          try {
            window.history.replaceState(window.history.state, '', url);
          } catch (e) {
            /* no-op */
          }

          if (!next || !sameOrigin(next)) {
            stop();
          }
        })
        .catch(function () {
          // Fail open: leave the untouched pagination as the way forward.
          stop();
        })
        .then(function () {
          busy = false;
          sentinel.classList.remove('nk-speed-loading');
        });
    }

    /**
     * Replaces the pagination block with the freshly loaded page's one. The
     * links stay real anchors, so SEO and no-JS navigation are preserved.
     */
    function syncPagination(doc) {
      try {
        var current = document.querySelector('.pagination');
        var incoming = doc.querySelector('.pagination');

        if (current && incoming && current.parentNode) {
          current.parentNode.replaceChild(document.adoptNode(incoming), current);
        }
      } catch (e) {
        /* no-op */
      }
    }
  }
})();
