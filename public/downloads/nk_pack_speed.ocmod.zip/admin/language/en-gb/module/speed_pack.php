<?php
// Heading
$_['heading_title']             = 'NovaKur Speed Optimization Pack';

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: You have modified NovaKur Speed Optimization Pack settings! The asset cache was rebuilt.';
$_['text_edit']                 = 'Edit NovaKur Speed Optimization Pack';
$_['text_enabled']              = 'Enabled';
$_['text_disabled']             = 'Disabled';
$_['text_general']              = 'General';
$_['text_lazy']                 = 'Image Lazy Loading';
$_['text_bundles']              = 'Asset Bundles';
$_['text_infinite']             = 'Infinite Scroll';
$_['text_headers']              = 'Server Headers';
$_['text_vitals']               = 'Core Web Vitals';
$_['text_cache']                = 'Asset cache';
$_['text_cache_empty']          = 'The asset cache is empty. Bundles are generated on the next storefront page view.';
$_['text_cache_cleared']        = 'Asset cache cleared: %s bundle file(s) removed.';
$_['text_lcp']                  = 'Largest Contentful Paint';
$_['text_cls']                  = 'Cumulative Layout Shift';
$_['text_inp']                  = 'Interaction to Next Paint';
$_['text_checklist']            = 'Tuning checklist';
$_['text_snippet']              = 'Measurement snippet';
$_['text_limitations']          = 'Honest limitations';
$_['text_auto']                 = 'Handled by this extension';
$_['text_manual']               = 'Manual / theme-side';

// Columns
$_['column_metric']             = 'Metric';
$_['column_good']               = 'Good';
$_['column_poor']               = 'Poor';
$_['column_meaning']            = 'What it measures';

// Entry
$_['entry_status']              = 'Status';
$_['entry_lazy_status']         = 'Lazy-load images';
$_['entry_lazy_skip']           = 'Eager images per page';
$_['entry_bundle_css']          = 'Bundle CSS';
$_['entry_bundle_js']           = 'Bundle JavaScript';
$_['entry_infinite_status']     = 'Infinite scroll';
$_['entry_infinite_selector']   = 'Product grid selector';
$_['entry_infinite_max_pages']  = 'Max pages to append';

// Help
$_['help_status']               = 'Master switch. When disabled, no event does any work at all and the storefront renders exactly as it would without this extension.';
$_['help_lazy_status']          = 'Rewrites storefront output to add loading="lazy" and decoding="async" to product and category images. Images that already carry a loading attribute are never touched. Add class="nk-no-lazy" or a data-nk-eager attribute in your theme to opt a specific image out.';
$_['help_lazy_skip']            = 'How many images at the top of the page stay eagerly loaded (0-50). Your LCP image must be in this group, so keep it at least as large as the first visible row of product cards. 4 suits a 4-column grid; use 0 to lazy-load everything.';
$_['help_bundle_css']           = 'Concatenates every local stylesheet in the &lt;head&gt; into one cached bundle. External CDN sheets, print/media-specific sheets and sheets with a query string are left exactly where they are.';
$_['help_bundle_js']            = 'Concatenates every local &lt;script src&gt; in the &lt;head&gt; into one cached bundle. Scripts marked async/defer/nomodule, inline blocks and external URLs are left alone. Test your theme after enabling this one.';
$_['help_bundle_min']           = 'Minification is conservative: comments and redundant whitespace only, using a scanner that never touches string, template or regular-expression literals. Files already named *.min.css or *.min.js are bundled verbatim and never re-minified. If anything about a file looks ambiguous, the original source is used unchanged. Bundling is also skipped entirely when a page has fewer than two bundleable files of that type, or when a script or stylesheet that cannot be bundled sits between two that can - reordering assets is never worth the risk.';
$_['help_infinite_status']      = 'Appends the next category page into the grid when the shopper reaches the bottom. The real pagination links stay in the DOM for crawlers and for visitors without JavaScript.';
$_['help_infinite_selector']    = 'CSS selector of the product grid container. The OpenCart default theme uses #product-list; change it if your theme renders a different container.';
$_['help_infinite_max_pages']   = 'Stop appending after this many extra pages (0 = unlimited). A small number keeps very long category lists from growing the DOM without bound.';
$_['help_headers']             = 'This extension never modifies your .htaccess. Copy the snippet below, review it against your host, and paste it into the .htaccess in your OpenCart root above the OpenCart rules. On nginx, use the gzip / brotli directives and an "expires 1y" location block for the same file types.';
$_['help_cache']                = 'Bundles are stored in the OpenCart storage cache directory and served through a lightweight route with immutable far-future cache headers and ETag/304 revalidation. Filenames carry a content hash, so a rebuild is picked up instantly by every browser. Clearing the cache forces a rebuild on the next storefront page view.';
$_['help_snippet']              = 'Paste this into your browser devtools console on a storefront page (or save it as a bookmarklet). It reports LCP, CLS and INP after four seconds using native PerformanceObserver APIs - nothing is sent anywhere. Scroll and click around before running it again to get a realistic INP.';
$_['help_limitations']          = 'Minification is conservative comment and whitespace stripping, not a full JavaScript or CSS parser: it will not rename variables or drop dead code, so expect smaller savings than a build-time tool such as terser or cssnano. Bundles are streamed through PHP because the OpenCart storage directory usually sits outside the web root; the far-future cache headers mean each browser pays that cost once. Infinite scroll needs IntersectionObserver, fetch and a theme whose product grid matches the selector above - if any of that is missing it quietly does nothing and normal pagination remains. Real-world impact should always be confirmed on the live store with Lighthouse or field data.';

$_['help_lcp']                  = 'How long the largest image or text block in the viewport takes to render. Usually your category hero or first product image.';
$_['help_cls']                  = 'How much visible content jumps around while the page loads. Images without width/height attributes are the usual cause.';
$_['help_inp']                  = 'How quickly the page responds to taps, clicks and key presses across the whole visit. Heavy JavaScript on the main thread is the usual cause.';

// Checklist
$_['check_lazy']                = 'Below-the-fold images carry loading="lazy" and decoding="async".';
$_['check_skip']                = 'The first row of images stays eager so the LCP element is not delayed.';
$_['check_css']                 = 'Local stylesheets are concatenated and minified into one cached bundle.';
$_['check_js']                  = 'Local header scripts are concatenated and minified into one cached bundle.';
$_['check_headers']             = 'Compression and far-future Cache-Control headers are applied on the server (see the Server Headers tab).';
$_['check_dimensions']          = 'Every product image tag has explicit width and height so nothing shifts as images arrive (theme-side).';
$_['check_fonts']               = 'Web fonts are self-hosted, preloaded and use font-display: swap (theme-side).';
$_['check_thirdparty']          = 'Third-party tags (chat, analytics, pixels) are loaded async or deferred (theme-side).';

// Button
$_['button_save']               = 'Save';
$_['button_back']               = 'Back';
$_['button_clear_cache']        = 'Clear asset cache';
$_['button_copy']               = 'Copy';

// Error
$_['error_permission']          = 'Warning: You do not have permission to modify this module!';
$_['error_selector']            = 'Selector must be a simple CSS selector of up to 120 characters!';
$_['error_lazy_skip']           = 'Eager image count must be between 0 and 50!';
$_['error_infinite_max_pages']  = 'Max pages must be between 0 and 100!';
