<?php
namespace Opencart\Admin\Controller\Extension\NkPackSpeed\Module;

class SpeedPack extends \Opencart\System\Engine\Controller {
	/**
	 * Cache sub-directory (inside DIR_CACHE) holding the generated bundles.
	 */
	private const CACHE_SUBDIR = 'nk_speed';

	/**
	 * Setting key => default value. Also drives validation in save().
	 *
	 * @var array<string, string>
	 */
	private array $defaults = [
		'module_speed_pack_status'              => '0',
		'module_speed_pack_lazy_status'         => '1',
		'module_speed_pack_lazy_skip'           => '4',
		'module_speed_pack_bundle_css'          => '1',
		'module_speed_pack_bundle_js'           => '0',
		'module_speed_pack_infinite_status'     => '0',
		'module_speed_pack_infinite_selector'   => '#product-list',
		'module_speed_pack_infinite_max_pages'  => '0',
		'module_speed_pack_cache_version'       => '1'
	];

	/**
	 * Events registered on install, removed on uninstall.
	 *
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'novakur_speed_pack_assets',
			'description' => 'NovaKur Speed Pack: registers infinite scroll assets.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.assets'
		],
		[
			'code'        => 'novakur_speed_pack_bundle',
			'description' => 'NovaKur Speed Pack: concatenates and minifies theme CSS/JS.',
			'trigger'     => 'catalog/view/common/header/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.bundle'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_home',
			'description' => 'NovaKur Speed Pack: lazy-loads home page images.',
			'trigger'     => 'catalog/view/common/home/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_category',
			'description' => 'NovaKur Speed Pack: lazy-loads category page images.',
			'trigger'     => 'catalog/view/product/category/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_search',
			'description' => 'NovaKur Speed Pack: lazy-loads search result images.',
			'trigger'     => 'catalog/view/product/search/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_special',
			'description' => 'NovaKur Speed Pack: lazy-loads specials page images.',
			'trigger'     => 'catalog/view/product/special/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_manufacturer',
			'description' => 'NovaKur Speed Pack: lazy-loads brand page images.',
			'trigger'     => 'catalog/view/product/manufacturer_info/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		],
		[
			'code'        => 'novakur_speed_pack_lazy_product',
			'description' => 'NovaKur Speed Pack: lazy-loads product page images.',
			'trigger'     => 'catalog/view/product/product/after',
			'action'      => 'extension/nk_pack_speed/event/speed_pack.lazy'
		]
	];

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/nk_pack_speed/module/speed_pack');
		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');
		$settings = $this->model_setting_setting->getSetting('module_speed_pack', $store_id);

		$data = [];

		foreach ($this->defaults as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ([
			'heading_title',
			'text_edit',
			'text_enabled',
			'text_disabled',
			'text_general',
			'text_lazy',
			'text_bundles',
			'text_infinite',
			'text_headers',
			'text_vitals',
			'text_cache',
			'text_cache_empty',
			'text_lcp',
			'text_cls',
			'text_inp',
			'text_checklist',
			'text_snippet',
			'text_limitations',
			'text_auto',
			'text_manual',
			'entry_status',
			'entry_lazy_status',
			'entry_lazy_skip',
			'entry_bundle_css',
			'entry_bundle_js',
			'entry_infinite_status',
			'entry_infinite_selector',
			'entry_infinite_max_pages',
			'help_status',
			'help_lazy_status',
			'help_lazy_skip',
			'help_bundle_css',
			'help_bundle_js',
			'help_bundle_min',
			'help_infinite_status',
			'help_infinite_selector',
			'help_infinite_max_pages',
			'help_headers',
			'help_cache',
			'help_snippet',
			'help_limitations',
			'button_save',
			'button_back',
			'button_clear_cache',
			'button_copy',
			'column_metric',
			'column_good',
			'column_poor',
			'column_meaning'
		] as $key) {
			$data[$key] = $this->language->get($key);
		}

		$data['checklist'] = $this->buildChecklist($data);
		$data['vitals']    = $this->buildVitals();
		$data['htaccess']  = $this->htaccessSnippet();
		$data['snippet']   = $this->measurementSnippet();

		$cache = $this->cacheStats();

		$data['cache_files'] = $cache['files'];
		$data['cache_size']  = $this->humanBytes($cache['bytes']);

		$data['breadcrumbs'] = [];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];
		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/nk_pack_speed/module/speed_pack', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save']        = $this->url->link('extension/nk_pack_speed/module/speed_pack.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		// true = do not HTML-escape "&", the link is used inside an inline script.
		$data['clear_cache'] = $this->url->link('extension/nk_pack_speed/module/speed_pack.clearCache', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id, true);
		$data['back']        = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/nk_pack_speed/module/speed_pack', $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/nk_pack_speed/module/speed_pack');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/nk_pack_speed/module/speed_pack')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$selector = isset($post['module_speed_pack_infinite_selector']) ? trim((string)$post['module_speed_pack_infinite_selector']) : '';

		if ($selector === '') {
			$selector = $this->defaults['module_speed_pack_infinite_selector'];
		}

		// Keep the selector to a simple, injection-free CSS selector.
		if (!preg_match('/^[A-Za-z0-9 _\-.#\[\]="\':>()]{1,120}$/', $selector)) {
			$json['error']['selector'] = $this->language->get('error_selector');
		}

		$skip = isset($post['module_speed_pack_lazy_skip']) ? (int)$post['module_speed_pack_lazy_skip'] : 0;

		if ($skip < 0 || $skip > 50) {
			$json['error']['lazy-skip'] = $this->language->get('error_lazy_skip');
		}

		$max_pages = isset($post['module_speed_pack_infinite_max_pages']) ? (int)$post['module_speed_pack_infinite_max_pages'] : 0;

		if ($max_pages < 0 || $max_pages > 100) {
			$json['error']['infinite-max-pages'] = $this->language->get('error_infinite_max_pages');
		}

		if (!isset($json['error'])) {
			$this->load->model('setting/setting');

			$current = $this->model_setting_setting->getSetting('module_speed_pack', $store_id);

			$version = isset($current['module_speed_pack_cache_version']) ? (int)$current['module_speed_pack_cache_version'] : 1;

			// Any settings change invalidates every generated bundle.
			$version++;

			if ($version > 999999) {
				$version = 1;
			}

			$save = [
				'module_speed_pack_status'             => isset($post['module_speed_pack_status']) ? (string)(int)(bool)$post['module_speed_pack_status'] : '0',
				'module_speed_pack_lazy_status'        => isset($post['module_speed_pack_lazy_status']) ? (string)(int)(bool)$post['module_speed_pack_lazy_status'] : '0',
				'module_speed_pack_lazy_skip'          => (string)$skip,
				'module_speed_pack_bundle_css'         => isset($post['module_speed_pack_bundle_css']) ? (string)(int)(bool)$post['module_speed_pack_bundle_css'] : '0',
				'module_speed_pack_bundle_js'          => isset($post['module_speed_pack_bundle_js']) ? (string)(int)(bool)$post['module_speed_pack_bundle_js'] : '0',
				'module_speed_pack_infinite_status'    => isset($post['module_speed_pack_infinite_status']) ? (string)(int)(bool)$post['module_speed_pack_infinite_status'] : '0',
				'module_speed_pack_infinite_selector'  => $selector,
				'module_speed_pack_infinite_max_pages' => (string)$max_pages,
				'module_speed_pack_cache_version'      => (string)$version
			];

			$this->model_setting_setting->editSetting('module_speed_pack', $save, $store_id);

			$this->purgeCache();

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Deletes every generated bundle and bumps the cache-busting version.
	 *
	 * @return void
	 */
	public function clearCache(): void {
		$this->load->language('extension/nk_pack_speed/module/speed_pack');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/nk_pack_speed/module/speed_pack')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!isset($json['error'])) {
			$removed = $this->purgeCache();

			$this->load->model('setting/setting');

			$current = $this->model_setting_setting->getSetting('module_speed_pack', $store_id);

			if ($current) {
				$version = isset($current['module_speed_pack_cache_version']) ? (int)$current['module_speed_pack_cache_version'] + 1 : 1;

				if ($version > 999999) {
					$version = 1;
				}

				$current['module_speed_pack_cache_version'] = (string)$version;

				$this->model_setting_setting->editSetting('module_speed_pack', $current, $store_id);
			}

			$json['success'] = sprintf($this->language->get('text_cache_cleared'), $removed);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('module_speed_pack', $this->defaults);

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting('module_speed_pack');

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->purgeCache();
	}

	/* ------------------------------------------------------------------ */
	/* Helpers                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * @return string|null
	 */
	private function cacheDir(): ?string {
		if (!defined('DIR_CACHE')) {
			return null;
		}

		$dir = rtrim((string)DIR_CACHE, '/\\') . '/' . self::CACHE_SUBDIR . '/';

		return is_dir($dir) ? $dir : null;
	}

	/**
	 * @return array<string, int>
	 */
	private function cacheStats(): array {
		$stats = ['files' => 0, 'bytes' => 0];

		$dir = $this->cacheDir();

		if ($dir === null) {
			return $stats;
		}

		$files = glob($dir . 'nk-speed.*');

		if (!is_array($files)) {
			return $stats;
		}

		foreach ($files as $file) {
			if (!is_file($file)) {
				continue;
			}

			$size = filesize($file);

			$stats['files']++;
			$stats['bytes'] += ($size === false) ? 0 : (int)$size;
		}

		return $stats;
	}

	/**
	 * @return int number of files removed
	 */
	private function purgeCache(): int {
		$dir = $this->cacheDir();

		if ($dir === null) {
			return 0;
		}

		$files = glob($dir . 'nk-speed.*');

		if (!is_array($files)) {
			return 0;
		}

		$removed = 0;

		foreach ($files as $file) {
			// Only ever touch our own generated bundles.
			if (!is_file($file) || !preg_match('/^nk\-speed\.[a-f0-9]{32}\.(?:css|js)$/', basename($file))) {
				continue;
			}

			if (@unlink($file)) {
				$removed++;
			}
		}

		return $removed;
	}

	/**
	 * @param int $bytes
	 *
	 * @return string
	 */
	private function humanBytes(int $bytes): string {
		if ($bytes < 1024) {
			return $bytes . ' B';
		}

		if ($bytes < 1048576) {
			return round($bytes / 1024, 1) . ' KB';
		}

		return round($bytes / 1048576, 2) . ' MB';
	}

	/**
	 * Core Web Vitals thresholds, straight from web.dev.
	 *
	 * @return array<int, array<string, string>>
	 */
	private function buildVitals(): array {
		return [
			[
				'metric'  => 'LCP',
				'name'    => $this->language->get('text_lcp'),
				'good'    => '<= 2.5 s',
				'poor'    => '> 4.0 s',
				'meaning' => $this->language->get('help_lcp')
			],
			[
				'metric'  => 'CLS',
				'name'    => $this->language->get('text_cls'),
				'good'    => '<= 0.1',
				'poor'    => '> 0.25',
				'meaning' => $this->language->get('help_cls')
			],
			[
				'metric'  => 'INP',
				'name'    => $this->language->get('text_inp'),
				'good'    => '<= 200 ms',
				'poor'    => '> 500 ms',
				'meaning' => $this->language->get('help_inp')
			]
		];
	}

	/**
	 * Checklist rows whose state reflects the settings currently loaded in the
	 * form, so the tab is a live report rather than static copy.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function buildChecklist(array $data): array {
		$rows = [
			['key' => 'check_lazy', 'done' => (bool)(int)$data['module_speed_pack_lazy_status']],
			['key' => 'check_skip', 'done' => (int)$data['module_speed_pack_lazy_skip'] > 0],
			['key' => 'check_css', 'done' => (bool)(int)$data['module_speed_pack_bundle_css']],
			['key' => 'check_js', 'done' => (bool)(int)$data['module_speed_pack_bundle_js']],
			['key' => 'check_headers', 'done' => false],
			['key' => 'check_dimensions', 'done' => false],
			['key' => 'check_fonts', 'done' => false],
			['key' => 'check_thirdparty', 'done' => false]
		];

		$out = [];

		foreach ($rows as $row) {
			$out[] = [
				'text'   => $this->language->get($row['key']),
				'done'   => $row['done'],
				'manual' => in_array($row['key'], ['check_headers', 'check_dimensions', 'check_fonts', 'check_thirdparty'], true)
			];
		}

		return $out;
	}

	/**
	 * Copy-paste server config. This extension NEVER writes to .htaccess.
	 *
	 * @return string
	 */
	private function htaccessSnippet(): string {
		return <<<'SNIPPET'
# --- NovaKur Speed Optimization Pack -------------------------------------
# Paste into the .htaccess in your OpenCart root, ABOVE the OpenCart rules.
# This extension never edits .htaccess for you - review and apply manually.

# 1. Compression (Apache mod_deflate)
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css
  AddOutputFilterByType DEFLATE application/javascript application/x-javascript
  AddOutputFilterByType DEFLATE application/json application/xml
  AddOutputFilterByType DEFLATE image/svg+xml application/rss+xml
  AddOutputFilterByType DEFLATE font/ttf font/otf application/vnd.ms-fontobject
</IfModule>

# 2. Brotli, when the module is available (preferred over gzip)
<IfModule mod_brotli.c>
  AddOutputFilterByType BROTLI_COMPRESS text/html text/css
  AddOutputFilterByType BROTLI_COMPRESS application/javascript application/json
  AddOutputFilterByType BROTLI_COMPRESS image/svg+xml
</IfModule>

# 3. Far-future caching for fingerprinted and static assets
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css                "access plus 1 year"
  ExpiresByType application/javascript  "access plus 1 year"
  ExpiresByType image/webp              "access plus 1 year"
  ExpiresByType image/avif              "access plus 1 year"
  ExpiresByType image/jpeg              "access plus 1 year"
  ExpiresByType image/png               "access plus 1 year"
  ExpiresByType image/svg+xml           "access plus 1 year"
  ExpiresByType font/woff2              "access plus 1 year"
  ExpiresDefault                        "access plus 2 days"
</IfModule>

<IfModule mod_headers.c>
  <FilesMatch "\.(css|js|jpe?g|png|gif|webp|avif|svg|woff2?|ttf|otf|eot)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
    Header unset ETag
  </FilesMatch>
  # HTML must always revalidate - prices and stock change.
  <FilesMatch "\.(html?|php)$">
    Header set Cache-Control "no-cache, must-revalidate"
  </FilesMatch>
</IfModule>
# --- end NovaKur Speed Optimization Pack ---------------------------------
SNIPPET;
	}

	/**
	 * Console/bookmarklet snippet that reports LCP, CLS and INP for the page it
	 * is run on. Uses only native PerformanceObserver - no library, no network.
	 *
	 * @return string
	 */
	private function measurementSnippet(): string {
		return <<<'SNIPPET'
javascript:(function(){var r={LCP:0,CLS:0,INP:0};
try{new PerformanceObserver(function(l){var e=l.getEntries();r.LCP=Math.round(e[e.length-1].startTime)}).observe({type:'largest-contentful-paint',buffered:true})}catch(e){}
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(x){if(!x.hadRecentInput){r.CLS+=x.value}})}).observe({type:'layout-shift',buffered:true})}catch(e){}
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(x){var d=Math.round(x.duration);if(d>r.INP){r.INP=d}})}).observe({type:'event',durationThreshold:16,buffered:true})}catch(e){}
setTimeout(function(){console.table([{metric:'LCP (ms)',value:r.LCP,good:'<=2500'},{metric:'CLS',value:r.CLS.toFixed(3),good:'<=0.1'},{metric:'INP (ms)',value:r.INP,good:'<=200'}]);alert('LCP '+r.LCP+' ms | CLS '+r.CLS.toFixed(3)+' | INP '+r.INP+' ms\n\nScroll and click around first, then run again for a realistic INP.')},4000);})();
SNIPPET;
	}
}
