<?php
namespace Opencart\Catalog\Model\Extension\NkFbt\Module;

/**
 * NovaKur Frequently Bought Together - storefront model.
 *
 * Reads `<prefix>nk_fbt` and, when asked, rebuilds the automatic half of it from
 * the order history. Every value that reaches SQL is int cast or escaped.
 */
class Fbt extends \Opencart\System\Engine\Model {
	/**
	 * @return bool
	 */
	public function tableExists(): bool {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_fbt') . "'")->num_rows;
	}

	/**
	 * Cached companion ids for one product, best first.
	 *
	 * The related_id 0 sentinel (written when a computation found nothing) never
	 * leaves this method.
	 *
	 * @param int    $product_id
	 * @param int    $store_id
	 * @param string $source     manual|auto
	 * @param int    $limit
	 *
	 * @return array<int, int>
	 */
	public function getCompanionIds(int $product_id, int $store_id, string $source, int $limit): array {
		$source = ($source === 'auto') ? 'auto' : 'manual';
		$limit = max(1, min(20, $limit));

		$query = $this->db->query("SELECT `related_id` FROM `" . DB_PREFIX . "nk_fbt` WHERE `product_id` = '" . (int)$product_id . "' AND `store_id` = '" . (int)$store_id . "' AND `source` = '" . $this->db->escape($source) . "' AND `related_id` > 0 ORDER BY `sort_order` ASC, `score` DESC, `fbt_id` ASC LIMIT " . $limit);

		$ids = [];

		foreach ($query->rows as $row) {
			$ids[] = (int)$row['related_id'];
		}

		return $ids;
	}

	/**
	 * Has this product already been through the co-occurrence pass? The sentinel
	 * row counts, otherwise a product with no companions would be recomputed on
	 * every single page view.
	 *
	 * @param int $product_id
	 * @param int $store_id
	 *
	 * @return bool
	 */
	public function hasAuto(int $product_id, int $store_id): bool {
		return (bool)$this->db->query("SELECT `fbt_id` FROM `" . DB_PREFIX . "nk_fbt` WHERE `product_id` = '" . (int)$product_id . "' AND `store_id` = '" . (int)$store_id . "' AND `source` = 'auto' LIMIT 1")->num_rows;
	}

	/**
	 * Products customers bought in the same order as this one.
	 *
	 * Only orders that actually exist as orders count: order_status_id 0 is the
	 * abandoned "missing orders" state OpenCart writes before payment confirms.
	 *
	 * @param int $product_id
	 * @param int $store_id
	 * @param int $min_orders how many distinct orders must contain the pair
	 * @param int $days       0 = every order
	 * @param int $limit
	 *
	 * @return array<int, int> related_id => order count
	 */
	public function computeAuto(int $product_id, int $store_id, int $min_orders, int $days, int $limit): array {
		$min_orders = max(1, min(1000, $min_orders));
		$days = max(0, min(3650, $days));
		$limit = max(1, min(20, $limit));

		$sql = "SELECT `op2`.`product_id` AS `related_id`, COUNT(DISTINCT `op1`.`order_id`) AS `orders`";
		$sql .= " FROM `" . DB_PREFIX . "order_product` `op1`";
		$sql .= " INNER JOIN `" . DB_PREFIX . "order_product` `op2` ON (`op2`.`order_id` = `op1`.`order_id` AND `op2`.`product_id` <> `op1`.`product_id`)";
		$sql .= " INNER JOIN `" . DB_PREFIX . "order` `o` ON (`o`.`order_id` = `op1`.`order_id`)";
		$sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `op2`.`product_id` AND `p2s`.`store_id` = '" . (int)$store_id . "')";
		$sql .= " INNER JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `op2`.`product_id`)";
		$sql .= " WHERE `op1`.`product_id` = '" . (int)$product_id . "' AND `o`.`order_status_id` > '0' AND `o`.`store_id` = '" . (int)$store_id . "'";
		$sql .= " AND `p`.`status` = '1' AND `p`.`date_available` <= NOW()";

		if ($days > 0) {
			$sql .= " AND `o`.`date_added` >= DATE_SUB(NOW(), INTERVAL " . $days . " DAY)";
		}

		$sql .= " GROUP BY `op2`.`product_id` HAVING `orders` >= " . $min_orders;
		$sql .= " ORDER BY `orders` DESC, `related_id` ASC LIMIT " . $limit;

		$result = [];

		foreach ($this->db->query($sql)->rows as $row) {
			$result[(int)$row['related_id']] = (int)$row['orders'];
		}

		return $result;
	}

	/**
	 * Replace the cached suggestions of one product. An empty result writes the
	 * related_id 0 sentinel so the pass is not repeated on every page view.
	 *
	 * @param int             $product_id
	 * @param int             $store_id
	 * @param array<int, int> $companions related_id => score
	 *
	 * @return void
	 */
	public function setAuto(int $product_id, int $store_id, array $companions): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_fbt` WHERE `product_id` = '" . (int)$product_id . "' AND `store_id` = '" . (int)$store_id . "' AND `source` = 'auto'");

		if (!$companions) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_fbt` SET `product_id` = '" . (int)$product_id . "', `related_id` = '0', `store_id` = '" . (int)$store_id . "', `source` = 'auto', `score` = '0', `sort_order` = '0', `date_added` = NOW() ON DUPLICATE KEY UPDATE `date_added` = NOW()");

			return;
		}

		$sort_order = 0;

		foreach ($companions as $related_id => $score) {
			$related_id = (int)$related_id;

			if ($related_id < 1 || $related_id === $product_id) {
				continue;
			}

			$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_fbt` SET `product_id` = '" . (int)$product_id . "', `related_id` = '" . $related_id . "', `store_id` = '" . (int)$store_id . "', `source` = 'auto', `score` = '" . (int)$score . "', `sort_order` = '" . (int)$sort_order . "', `date_added` = NOW() ON DUPLICATE KEY UPDATE `score` = '" . (int)$score . "', `sort_order` = '" . (int)$sort_order . "', `date_added` = NOW()");

			$sort_order++;
		}
	}

	/**
	 * One batch of product ids that have ever been ordered - the only products
	 * worth running the co-occurrence pass for.
	 *
	 * @param int $store_id
	 * @param int $days
	 * @param int $start
	 * @param int $limit
	 *
	 * @return array<int, int>
	 */
	public function getOrderedProductIds(int $store_id, int $days, int $start, int $limit): array {
		$days = max(0, min(3650, $days));
		$start = max(0, $start);
		$limit = max(1, min(1000, $limit));

		$sql = "SELECT DISTINCT `op`.`product_id` FROM `" . DB_PREFIX . "order_product` `op`";
		$sql .= " INNER JOIN `" . DB_PREFIX . "order` `o` ON (`o`.`order_id` = `op`.`order_id`)";
		$sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `op`.`product_id` AND `p2s`.`store_id` = '" . (int)$store_id . "')";
		$sql .= " WHERE `o`.`order_status_id` > '0' AND `o`.`store_id` = '" . (int)$store_id . "'";

		if ($days > 0) {
			$sql .= " AND `o`.`date_added` >= DATE_SUB(NOW(), INTERVAL " . $days . " DAY)";
		}

		$sql .= " ORDER BY `op`.`product_id` ASC LIMIT " . $start . "," . $limit;

		$ids = [];

		foreach ($this->db->query($sql)->rows as $row) {
			$ids[] = (int)$row['product_id'];
		}

		return $ids;
	}

	/**
	 * Drop cached suggestions for products that are no longer ordered at all.
	 *
	 * @param int $store_id
	 *
	 * @return int
	 */
	public function clearAuto(int $store_id): int {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_fbt` WHERE `store_id` = '" . (int)$store_id . "' AND `source` = 'auto'");

		return (int)$this->db->countAffected();
	}
}
