/* NovaKur Frequently Bought Together */
(function () {
  function numberFormat(number, decimals, decimalPoint, thousandPoint) {
    var negative = number < 0;
    var fixed = Math.abs(Number(number) || 0).toFixed(decimals);
    var parts = fixed.split('.');
    var whole = parts[0];
    var fraction = parts.length > 1 ? parts[1] : '';
    var out = '';
    var count = 0;
    var i;

    for (i = whole.length - 1; i >= 0; i--) {
      out = whole.charAt(i) + out;
      count++;

      if (count % 3 === 0 && i > 0) {
        out = thousandPoint + out;
      }
    }

    if (decimals > 0) {
      out += decimalPoint + fraction;
    }

    return (negative ? '-' : '') + out;
  }

  function alertMessage(message, type) {
    var box = document.getElementById('alert');

    if (!box) {
      return;
    }

    var el = document.createElement('div');
    el.className = 'alert alert-' + (type || 'success') + ' alert-dismissible';
    el.textContent = message;

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'btn-close';
    close.setAttribute('data-bs-dismiss', 'alert');
    el.appendChild(close);

    box.prepend(el);
  }

  function init() {
    var root = document.getElementById('nk-fbt');

    if (!root) {
      return;
    }

    var addUrl = root.getAttribute('data-cart-add-url') || '';
    var infoUrl = root.getAttribute('data-cart-info-url') || '';

    var currency = {
      symbolLeft: root.getAttribute('data-symbol-left') || '',
      symbolRight: root.getAttribute('data-symbol-right') || '',
      decimalPlace: parseInt(root.getAttribute('data-decimal-place'), 10),
      decimalPoint: root.getAttribute('data-decimal-point') || '.',
      thousandPoint: root.getAttribute('data-thousand-point') || ','
    };

    if (isNaN(currency.decimalPlace) || currency.decimalPlace < 0 || currency.decimalPlace > 8) {
      currency.decimalPlace = 2;
    }

    var text = {
      add: root.getAttribute('data-text-add') || 'Add selected to cart',
      adding: root.getAttribute('data-text-adding') || 'Adding...',
      none: root.getAttribute('data-text-none') || 'Tick at least one product first.',
      success: root.getAttribute('data-text-success') || '',
      error: root.getAttribute('data-text-error') || 'Some products could not be added to your cart.'
    };

    var totalEl = document.getElementById('nk-fbt-total');
    var button = document.getElementById('nk-fbt-add');
    var boxes = Array.prototype.slice.call(root.querySelectorAll('.nk-fbt__box'));

    function selected() {
      return boxes.filter(function (box) {
        return box.checked && !box.disabled;
      });
    }

    function refreshTotal() {
      if (!totalEl) {
        return;
      }

      var total = 0;

      selected().forEach(function (box) {
        total += parseFloat(box.getAttribute('data-value')) || 0;
      });

      totalEl.textContent = currency.symbolLeft +
        numberFormat(total, currency.decimalPlace, currency.decimalPoint, currency.thousandPoint) +
        currency.symbolRight;
    }

    boxes.forEach(function (box) {
      box.addEventListener('change', refreshTotal);
    });

    refreshTotal();

    function addOne(productId, quantity) {
      var body = 'product_id=' + encodeURIComponent(productId) + '&quantity=' + encodeURIComponent(quantity);

      return fetch(addUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: body,
        credentials: 'same-origin'
      }).then(function (response) {
        return response.json();
      }).then(function (json) {
        return json && typeof json === 'object' ? json : {};
      }).catch(function () {
        return {error: true};
      });
    }

    function refreshCart() {
      if (!infoUrl) {
        return;
      }

      var target = document.getElementById('cart');

      if (!target) {
        return;
      }

      fetch(infoUrl, {
        headers: {'X-Requested-With': 'XMLHttpRequest'},
        credentials: 'same-origin'
      }).then(function (response) {
        return response.text();
      }).then(function (html) {
        target.innerHTML = html;
      }).catch(function () {
        /* the header cart just stays stale */
      });
    }

    if (button) {
      button.addEventListener('click', function () {
        var chosen = selected();

        if (!chosen.length) {
          alertMessage(text.none, 'danger');

          return;
        }

        button.disabled = true;
        button.textContent = text.adding;

        var failures = 0;
        var lastSuccess = '';

        // Sequential on purpose: the cart is session state, and firing the
        // adds in parallel makes OpenCart race itself over the same rows.
        var run = chosen.reduce(function (promise, box) {
          return promise.then(function () {
            var quantity = parseInt(box.getAttribute('data-minimum'), 10);

            if (!quantity || quantity < 1) {
              quantity = 1;
            }

            return addOne(box.value, quantity).then(function (json) {
              if (json.success) {
                lastSuccess = json.success;
              } else {
                failures++;
              }
            });
          });
        }, Promise.resolve());

        run.then(function () {
          button.disabled = false;
          button.textContent = text.add;

          if (failures) {
            alertMessage(text.error, 'danger');
          }

          if (failures < chosen.length) {
            alertMessage(text.success || lastSuccess, 'success');

            refreshCart();
          }
        });
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
