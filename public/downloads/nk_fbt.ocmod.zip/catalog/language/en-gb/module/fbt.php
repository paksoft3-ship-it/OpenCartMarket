<?php
$_['text_fbt_heading'] = 'Frequently bought together';
$_['text_fbt_this_item'] = 'This item:';
$_['text_fbt_total'] = 'Total price:';
$_['text_fbt_add'] = 'Add selected to cart';
$_['text_fbt_adding'] = 'Adding...';
$_['text_fbt_none'] = 'Tick at least one product first.';
$_['text_fbt_unavailable'] = 'Choose the options on this page to add this item.';
$_['text_fbt_quantity'] = '&times; %d';
$_['text_fbt_success'] = 'Success: The selected products have been added to your shopping cart!';
$_['text_fbt_error'] = 'Some products could not be added to your cart.';
