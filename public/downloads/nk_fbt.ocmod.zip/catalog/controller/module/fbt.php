<?php
namespace Opencart\Catalog\Controller\Extension\NkFbt\Module;

/**
 * NovaKur Frequently Bought Together - storefront endpoints.
 *
 *   extension/nk_fbt/module/fbt.render  bundle markup (used by the product page event)
 *   extension/nk_fbt/module/fbt.cron    token guarded rebuild of the cached suggestions
 *
 * Nothing here adds to the cart: the browser posts each ticked product to the
 * stock checkout/cart.add endpoint so every core stock, option, discount and
 * subscription rule still applies.
 */
class Fbt extends \Opencart\System\Engine\Controller {
	private const CRON_BATCH = 100;

	/**
	 * Layout placeholder. The bundle is injected by the product page event.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * @param int $product_id
	 *
	 * @return string
	 */
	public function render(int $product_id = 0): string {
		if (!(int)$this->config->get('module_fbt_status')) {
			return '';
		}

		if ($product_id < 1) {
			$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
		}

		if ($product_id < 1) {
			return '';
		}

		$this->load->model('extension/nk_fbt/module/fbt');

		if (!$this->model_extension_nk_fbt_module_fbt->tableExists()) {
			return '';
		}

		$this->load->model('catalog/product');

		$product_info = $this->model_catalog_product->getProduct($product_id);

		if (!$product_info) {
			return '';
		}

		$store_id = (int)$this->config->get('config_store_id');
		$limit = $this->limit();

		$companion_ids = $this->model_extension_nk_fbt_module_fbt->getCompanionIds($product_id, $store_id, 'manual', $limit);

		if (!$companion_ids && (int)$this->config->get('module_fbt_auto_status')) {
			$companion_ids = $this->autoCompanionIds($product_id, $store_id, $limit);
		}

		if (!$companion_ids) {
			return '';
		}

		$this->load->language('extension/nk_fbt/module/fbt');
		$this->load->model('tool/image');

		$show_price = $this->customer->isLogged() || !$this->config->get('config_customer_price');
		$hide_out_of_stock = (bool)(int)$this->config->get('module_fbt_hide_out_of_stock');

		$items = [];

		$main = $this->item($product_info, $show_price, true);

		if (!$main) {
			return '';
		}

		$items[] = $main;

		foreach ($companion_ids as $companion_id) {
			if (count($items) > $limit) {
				break;
			}

			$companion_info = $this->model_catalog_product->getProduct($companion_id);

			if (!$companion_info) {
				continue;
			}

			if ($hide_out_of_stock && (int)$companion_info['quantity'] <= 0) {
				continue;
			}

			// A companion with required options cannot be added blind, so it is
			// never offered inside the bundle.
			if ($this->hasRequiredOptions($companion_id)) {
				continue;
			}

			$item = $this->item($companion_info, $show_price, false);

			if ($item) {
				$items[] = $item;
			}
		}

		// Nothing to bundle with: one row is just the product page again.
		if (count($items) < 2) {
			return '';
		}

		$currency_code = (string)($this->session->data['currency'] ?? $this->config->get('config_currency'));

		$total = 0.0;

		foreach ($items as $item) {
			if ($item['selected']) {
				$total += (float)$item['value'];
			}
		}

		$language = (string)$this->config->get('config_language');

		$data = [
			'items'          => $items,
			'show_price'     => $show_price,
			'total'          => $this->currency->format($total, $currency_code, 1.0),
			'currency'       => [
				'symbol_left'    => $this->currency->getSymbolLeft($currency_code),
				'symbol_right'   => $this->currency->getSymbolRight($currency_code),
				'decimal_place'  => $this->currency->getDecimalPlace($currency_code),
				'decimal_point'  => (string)$this->language->get('decimal_point'),
				'thousand_point' => (string)$this->language->get('thousand_point')
			],
			'cart_add_url'   => $this->url->link('checkout/cart.add', 'language=' . $language, true),
			'cart_info_url'  => $this->url->link('common/cart.info', 'language=' . $language, true)
		];

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_fbt/module/fbt', $data);
	}

	/**
	 * Token guarded rebuild of every cached suggestion for this store.
	 *
	 * @return void
	 */
	public function cron(): void {
		$this->response->addHeader('Content-Type: text/plain; charset=utf-8');

		$configured = (string)$this->config->get('module_fbt_cron_token');
		$supplied = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

		if ($configured === '' || strlen($supplied) !== strlen($configured) || !hash_equals($configured, $supplied)) {
			$this->response->addHeader(((string)($this->request->server['SERVER_PROTOCOL'] ?? 'HTTP/1.1')) . ' 403 Forbidden');
			$this->response->setOutput("Forbidden\n");

			return;
		}

		if (!(int)$this->config->get('module_fbt_auto_status')) {
			$this->response->setOutput("Automatic suggestions are disabled.\n");

			return;
		}

		$this->load->model('extension/nk_fbt/module/fbt');

		if (!$this->model_extension_nk_fbt_module_fbt->tableExists()) {
			$this->response->setOutput("The nk_fbt table is not installed.\n");

			return;
		}

		$store_id = (int)$this->config->get('config_store_id');
		$limit = $this->limit();
		$min_orders = max(1, min(1000, (int)$this->config->get('module_fbt_min_orders')));
		$days = max(0, min(3650, (int)$this->config->get('module_fbt_order_days')));

		$start = 0;
		$products = 0;
		$pairs = 0;

		// Chunked: a busy catalogue must not be pulled into memory in one go.
		while (true) {
			$product_ids = $this->model_extension_nk_fbt_module_fbt->getOrderedProductIds($store_id, $days, $start, self::CRON_BATCH);

			if (!$product_ids) {
				break;
			}

			foreach ($product_ids as $product_id) {
				$companions = $this->model_extension_nk_fbt_module_fbt->computeAuto($product_id, $store_id, $min_orders, $days, $limit);

				$this->model_extension_nk_fbt_module_fbt->setAuto($product_id, $store_id, $companions);

				$products++;
				$pairs += count($companions);
			}

			if (count($product_ids) < self::CRON_BATCH) {
				break;
			}

			$start += self::CRON_BATCH;
		}

		$this->response->setOutput('Products processed: ' . $products . "\n" . 'Suggestions written: ' . $pairs . "\n");
	}

	/**
	 * Cached suggestions, computing them once on demand when the merchant allows it.
	 *
	 * @param int $product_id
	 * @param int $store_id
	 * @param int $limit
	 *
	 * @return array<int, int>
	 */
	private function autoCompanionIds(int $product_id, int $store_id, int $limit): array {
		$ids = $this->model_extension_nk_fbt_module_fbt->getCompanionIds($product_id, $store_id, 'auto', $limit);

		if ($ids) {
			return $ids;
		}

		if (!(int)$this->config->get('module_fbt_auto_live')) {
			return [];
		}

		// The sentinel row means "already computed, nothing qualified" - without
		// this check every view of an unpopular product would rerun the pass.
		if ($this->model_extension_nk_fbt_module_fbt->hasAuto($product_id, $store_id)) {
			return [];
		}

		$min_orders = max(1, min(1000, (int)$this->config->get('module_fbt_min_orders')));
		$days = max(0, min(3650, (int)$this->config->get('module_fbt_order_days')));

		$companions = $this->model_extension_nk_fbt_module_fbt->computeAuto($product_id, $store_id, $min_orders, $days, $limit);

		$this->model_extension_nk_fbt_module_fbt->setAuto($product_id, $store_id, $companions);

		return array_keys($companions);
	}

	/**
	 * One bundle row.
	 *
	 * @param array<string, mixed> $product_info
	 * @param bool                 $show_price
	 * @param bool                 $main
	 *
	 * @return array<string, mixed>
	 */
	private function item(array $product_info, bool $show_price, bool $main): array {
		$product_id = (int)$product_info['product_id'];

		if ($product_id < 1) {
			return [];
		}

		if (!empty($product_info['image'])) {
			$thumb = $this->model_tool_image->resize((string)$product_info['image'], 100, 100);
		} else {
			$thumb = $this->model_tool_image->resize('no_image.png', 100, 100);
		}

		$currency_code = (string)($this->session->data['currency'] ?? $this->config->get('config_currency'));

		$unit = (float)$product_info['price'];

		if ((float)$product_info['special']) {
			$unit = (float)$product_info['special'];
		}

		$minimum = max(1, (int)$product_info['minimum']);

		// The bundle adds the product's minimum order quantity, so the line - and
		// the running total - has to price that many units.
		$taxed = (float)$this->tax->calculate($unit, (int)$product_info['tax_class_id'], $this->config->get('config_tax')) * $minimum;

		// format(..., false) hands back the converted, rounded number the shopper
		// is charged in - the same figure the formatted string shows.
		$value = $show_price ? (float)$this->currency->format($taxed, $currency_code, 0, false) : 0.0;

		// The main product may be unavailable or need options; it is then shown
		// but cannot take part in the one click add.
		$addable = !$main || (!$this->hasRequiredOptions($product_id) && (int)$product_info['quantity'] > 0);

		return [
			'product_id' => $product_id,
			'name'       => html_entity_decode((string)$product_info['name'], ENT_QUOTES, 'UTF-8'),
			'thumb'      => $thumb,
			'href'       => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id),
			'price'      => $show_price ? $this->currency->format($taxed, $currency_code) : '',
			'value'      => $value,
			'main'       => $main,
			'addable'    => $addable,
			'selected'   => $addable,
			'minimum'    => $minimum
		];
	}

	/**
	 * @param int $product_id
	 *
	 * @return bool
	 */
	private function hasRequiredOptions(int $product_id): bool {
		foreach ($this->model_catalog_product->getOptions($product_id) as $option) {
			if (!empty($option['required'])) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @return int
	 */
	private function limit(): int {
		$limit = (int)$this->config->get('module_fbt_limit');

		if ($limit < 1 || $limit > 4) {
			$limit = 3;
		}

		return $limit;
	}
}
