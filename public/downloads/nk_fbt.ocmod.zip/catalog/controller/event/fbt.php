<?php
namespace Opencart\Catalog\Controller\Extension\NkFbt\Event;

/**
 * NovaKur Frequently Bought Together - storefront event handlers.
 *
 *   assets   catalog/controller/product/product/before
 *   product  catalog/view/product/product/after
 */
class Fbt extends \Opencart\System\Engine\Controller {
	/**
	 * Queue the assets before the product controller renders its header, so the
	 * tags land in the normal <head> style/script lists.
	 *
	 * @param string            $route
	 * @param array<int, mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_fbt_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_fbt/catalog/view/assets/css/fbt.css');
		$this->document->addScript('extension/nk_fbt/catalog/view/assets/js/fbt.js');
	}

	/**
	 * Inject the bundle box between the product summary and the description tabs.
	 * Falls back to the end of the product form, and does nothing at all when
	 * neither anchor is present, so an unusual theme can never be corrupted.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function product(string &$route, array &$data, mixed &$output): void {
		if (!(int)$this->config->get('module_fbt_status') || !is_string($output) || $output === '') {
			return;
		}

		// The module can also sit in a layout position; never emit a second copy.
		if (str_contains($output, 'id="nk-fbt"')) {
			return;
		}

		$product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

		if ($product_id < 1) {
			return;
		}

		$html = $this->load->controller('extension/nk_fbt/module/fbt.render', $product_id);

		if (!is_string($html) || $html === '') {
			return;
		}

		$anchor = '<ul class="nav nav-tabs">';

		$position = strpos($output, $anchor);

		if ($position !== false) {
			$output = substr($output, 0, $position) . $html . substr($output, $position);

			return;
		}

		$position = strpos($output, 'id="form-product"');

		if ($position !== false) {
			$close = strpos($output, '</form>', $position);

			if ($close !== false) {
				$at = $close + strlen('</form>');

				$output = substr($output, 0, $at) . $html . substr($output, $at);
			}
		}
	}
}
