<?php
namespace Opencart\Admin\Controller\Extension\NkFbt\Module;

/**
 * NovaKur Frequently Bought Together - admin settings, companion picker.
 *
 * Settings namespace: module_fbt_*
 * Route:              extension/nk_fbt/module/fbt
 * Table:              <prefix>nk_fbt (kept on uninstall - merchant data)
 */
class Fbt extends \Opencart\System\Engine\Controller {
	private string $route = 'extension/nk_fbt/module/fbt';
	private string $prefix = 'module_fbt';

	/**
	 * Every key must start with $prefix or editSetting() silently drops it.
	 *
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			'module_fbt_status'            => '0',
			'module_fbt_limit'             => '3',
			'module_fbt_hide_out_of_stock' => '1',
			'module_fbt_auto_status'       => '1',
			'module_fbt_auto_live'         => '1',
			'module_fbt_min_orders'        => '2',
			'module_fbt_order_days'        => '365',
			'module_fbt_cron_token'        => oc_token(32)
		];
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private function events(): array {
		return [
			[
				'code'        => 'nk_fbt_assets',
				'description' => 'NovaKur Frequently Bought Together: queue the bundle stylesheet and script on the product page.',
				'trigger'     => 'catalog/controller/product/product/before',
				'action'      => 'extension/nk_fbt/event/fbt.assets',
				'status'      => 1,
				'sort_order'  => 1
			],
			[
				'code'        => 'nk_fbt_product',
				'description' => 'NovaKur Frequently Bought Together: inject the bundle box into the product page.',
				'trigger'     => 'catalog/view/product/product/after',
				'action'      => 'extension/nk_fbt/event/fbt.product',
				'status'      => 1,
				'sort_order'  => 1
			]
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

		$data = [];

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		// A cron route without a token would let anyone burn CPU on the whole catalogue.
		if (trim((string)$data['module_fbt_cron_token']) === '' && $this->user->hasPermission('modify', $this->route)) {
			$data['module_fbt_cron_token'] = oc_token(32);

			$settings['module_fbt_cron_token'] = $data['module_fbt_cron_token'];

			$this->model_setting_setting->editSetting($this->prefix, $settings, $store_id);
		}

		$token = 'user_token=' . $this->session->data['user_token'];

		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', $token)
			],
			[
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('marketplace/extension', $token . '&type=module')
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link($this->route, $token . '&store_id=' . $store_id)
			]
		];

		$data['store_id'] = $store_id;
		$data['user_token'] = $this->session->data['user_token'];

		$data['save'] = $this->url->link($this->route . '.save', $token . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', $token . '&type=module');
		$data['form'] = $this->url->link($this->route . '.form', $token . '&store_id=' . $store_id);
		$data['save_product'] = $this->url->link($this->route . '.saveProduct', $token . '&store_id=' . $store_id);
		$data['delete_product'] = $this->url->link($this->route . '.deleteProduct', $token . '&store_id=' . $store_id);
		$data['clear_auto'] = $this->url->link($this->route . '.clearAuto', $token . '&store_id=' . $store_id);
		$data['cron_url'] = $this->cronUrl($store_id, (string)$data['module_fbt_cron_token']);

		$this->load->model('extension/nk_fbt/module/fbt');

		if ($this->model_extension_nk_fbt_module_fbt->tableExists()) {
			$data['stats'] = $this->model_extension_nk_fbt_module_fbt->getStats($store_id);
		} else {
			$data['stats'] = ['manual' => 0, 'auto' => 0, 'date_added' => ''];
		}

		if ($data['stats']['date_added'] === '') {
			$data['stats']['date_added'] = $this->language->get('text_never');
		}

		$data['list'] = $this->getList();

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/nk_fbt/module/fbt', $data));
	}

	/**
	 * Ajax refreshable table of every product that has hand picked companions.
	 *
	 * @return void
	 */
	public function list(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$this->response->setOutput($this->getList());
	}

	/**
	 * @return string
	 */
	private function getList(): string {
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
		$page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;
		$filter_name = isset($this->request->get['filter_name']) ? trim((string)$this->request->get['filter_name']) : '';

		$limit = (int)$this->config->get('config_pagination_admin');

		if ($limit < 1) {
			$limit = 10;
		}

		$data = [];

		$data['products'] = [];
		$total = 0;

		$this->load->model('extension/nk_fbt/module/fbt');

		if ($this->model_extension_nk_fbt_module_fbt->tableExists()) {
			$filter_data = [
				'store_id'    => $store_id,
				'language_id' => (int)$this->config->get('config_language_id'),
				'filter_name' => $filter_name,
				'start'       => ($page - 1) * $limit,
				'limit'       => $limit
			];

			$total = $this->model_extension_nk_fbt_module_fbt->getTotalBaseProducts($filter_data);

			foreach ($this->model_extension_nk_fbt_module_fbt->getBaseProducts($filter_data) as $row) {
				$name = (string)$row['name'];

				$data['products'][] = [
					'product_id' => (int)$row['product_id'],
					'name'       => $name !== '' ? $name : sprintf($this->language->get('text_missing_product'), (int)$row['product_id']),
					'model'      => (string)$row['model'],
					'total'      => (int)$row['total']
				];
			}
		}

		$url = '&store_id=' . $store_id;

		if ($filter_name !== '') {
			$url .= '&filter_name=' . urlencode($filter_name);
		}

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->url->link($this->route . '.list', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), $total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($total - $limit)) ? $total : ((($page - 1) * $limit) + $limit), $total, (int)ceil($total / $limit));

		$data['filter_name'] = $filter_name;
		$data['total'] = $total;

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_fbt/module/fbt_list', $data);
	}

	/**
	 * Companion editor for one base product (ajax).
	 *
	 * @return void
	 */
	public function form(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
		$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

		$data = [];

		$data['product_id'] = $product_id;
		$data['store_id'] = $store_id;
		$data['product_name'] = '';
		$data['companions'] = [];
		$data['suggestions'] = [];
		$data['error'] = '';

		$this->load->model('catalog/product');

		$product_info = $product_id ? $this->model_catalog_product->getProduct($product_id) : [];

		if (!$product_info) {
			$data['error'] = $this->language->get('error_product');
		} else {
			$data['product_name'] = (string)$product_info['name'];

			$this->load->model('extension/nk_fbt/module/fbt');

			if ($this->model_extension_nk_fbt_module_fbt->tableExists()) {
				$language_id = (int)$this->config->get('config_language_id');

				foreach ($this->model_extension_nk_fbt_module_fbt->getCompanions($product_id, $store_id, $language_id, 'manual') as $row) {
					$name = (string)$row['name'];

					$data['companions'][] = [
						'product_id' => (int)$row['related_id'],
						'name'       => $name !== '' ? $name : sprintf($this->language->get('text_missing_product'), (int)$row['related_id'])
					];
				}

				foreach ($this->model_extension_nk_fbt_module_fbt->getCompanions($product_id, $store_id, $language_id, 'auto') as $row) {
					$name = (string)$row['name'];

					$data['suggestions'][] = [
						'product_id' => (int)$row['related_id'],
						'name'       => $name !== '' ? $name : sprintf($this->language->get('text_missing_product'), (int)$row['related_id']),
						'score'      => (int)$row['score']
					];
				}
			}
		}

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		$this->response->setOutput($this->load->view('extension/nk_fbt/module/fbt_form', $data));
	}

	/**
	 * Replace the companion set of one product.
	 *
	 * @return void
	 */
	public function saveProduct(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

		$this->load->model('catalog/product');

		if (!isset($json['error']) && (!$product_id || !$this->model_catalog_product->getProduct($product_id))) {
			$json['error'] = $this->language->get('error_product');
		}

		$related = [];

		if (isset($this->request->post['companion']) && is_array($this->request->post['companion'])) {
			foreach ($this->request->post['companion'] as $value) {
				$related_id = (int)$value;

				// Never trust the posted ids: a stale or forged one would leave a
				// row pointing at a product that does not exist.
				if ($related_id < 1 || $related_id === $product_id || in_array($related_id, $related, true)) {
					continue;
				}

				if ($this->model_catalog_product->getProduct($related_id)) {
					$related[] = $related_id;
				}
			}
		}

		if (!isset($json['error']) && count($related) > 20) {
			$json['error'] = $this->language->get('error_companion_limit');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_fbt/module/fbt');

			$this->model_extension_nk_fbt_module_fbt->createTable();
			$this->model_extension_nk_fbt_module_fbt->setCompanions($product_id, $store_id, $related);

			$json['success'] = $this->language->get('text_product_success');
			$json['total'] = count($related);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Drop every hand picked companion of one product.
	 *
	 * @return void
	 */
	public function deleteProduct(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

		if (!isset($json['error']) && !$product_id) {
			$json['error'] = $this->language->get('error_product');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_fbt/module/fbt');

			if ($this->model_extension_nk_fbt_module_fbt->tableExists()) {
				$this->model_extension_nk_fbt_module_fbt->deleteCompanions($product_id, $store_id);
			}

			$json['success'] = $this->language->get('text_delete_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Throw away the cached automatic suggestions.
	 *
	 * @return void
	 */
	public function clearAuto(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_fbt/module/fbt');

			$removed = $this->model_extension_nk_fbt_module_fbt->tableExists() ? $this->model_extension_nk_fbt_module_fbt->clearAuto($store_id) : 0;

			$json['success'] = sprintf($this->language->get('text_cleared'), $removed);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/nk_fbt/module/fbt');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$limit = isset($post['module_fbt_limit']) ? (int)$post['module_fbt_limit'] : 3;

		if ($limit < 1 || $limit > 4) {
			$json['error']['limit'] = $this->language->get('error_limit');
		}

		$min_orders = isset($post['module_fbt_min_orders']) ? (int)$post['module_fbt_min_orders'] : 2;

		if ($min_orders < 1 || $min_orders > 1000) {
			$json['error']['min_orders'] = $this->language->get('error_min_orders');
		}

		$order_days = isset($post['module_fbt_order_days']) ? (int)$post['module_fbt_order_days'] : 365;

		if ($order_days < 0 || $order_days > 3650) {
			$json['error']['order_days'] = $this->language->get('error_order_days');
		}

		$cron_token = isset($post['module_fbt_cron_token']) ? trim((string)$post['module_fbt_cron_token']) : '';

		if (!preg_match('/^[A-Za-z0-9]{16,64}$/', $cron_token)) {
			$json['error']['cron_token'] = $this->language->get('error_cron_token');
		}

		if (!isset($json['error'])) {
			$save = [
				'module_fbt_status'            => !empty($post['module_fbt_status']) ? '1' : '0',
				'module_fbt_limit'             => (string)$limit,
				'module_fbt_hide_out_of_stock' => !empty($post['module_fbt_hide_out_of_stock']) ? '1' : '0',
				'module_fbt_auto_status'       => !empty($post['module_fbt_auto_status']) ? '1' : '0',
				'module_fbt_auto_live'         => !empty($post['module_fbt_auto_live']) ? '1' : '0',
				'module_fbt_min_orders'        => (string)$min_orders,
				'module_fbt_order_days'        => (string)$order_days,
				'module_fbt_cron_token'        => $cron_token
			];

			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/nk_fbt/module/fbt');
		$this->model_extension_nk_fbt_module_fbt->createTable();

		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->prefix, $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
			$this->model_setting_event->addEvent($event);
		}

		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
	}

	/**
	 * The pair table is deliberately left in place: the hand picked companions are
	 * merchant data, and rebuilding them by hand after a reinstall is painful.
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting($this->prefix);
	}

	/**
	 * Public cron URL for the configured store.
	 *
	 * @param int    $store_id
	 * @param string $cron_token
	 *
	 * @return string
	 */
	private function cronUrl(int $store_id, string $cron_token): string {
		$store_url = (string)$this->config->get('config_url');

		if ($store_id) {
			$this->load->model('setting/store');

			$store_info = $this->model_setting_store->getStore($store_id);

			if ($store_info && !empty($store_info['url'])) {
				$store_url = (string)$store_info['url'];
			}
		}

		$store_url = rtrim(html_entity_decode($store_url, ENT_QUOTES, 'UTF-8'), '/') . '/';

		return $store_url . 'index.php?route=extension/nk_fbt/module/fbt.cron&token=' . rawurlencode($cron_token);
	}
}
