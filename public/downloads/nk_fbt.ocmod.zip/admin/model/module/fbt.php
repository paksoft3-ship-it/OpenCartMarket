<?php
namespace Opencart\Admin\Model\Extension\NkFbt\Module;

/**
 * NovaKur Frequently Bought Together - admin model.
 *
 * Owns `<prefix>nk_fbt`, one row per (product, companion, store) pair.
 *
 *   source = 'manual'  merchant picked this companion by hand
 *   source = 'auto'    written by the co-occurrence pass; related_id 0 is the
 *                      "computed, nothing passed the threshold" sentinel
 */
class Fbt extends \Opencart\System\Engine\Model {
	/**
	 * @return void
	 */
	public function createTable(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_fbt` (
			`fbt_id` int(11) NOT NULL AUTO_INCREMENT,
			`product_id` int(11) NOT NULL DEFAULT '0',
			`related_id` int(11) NOT NULL DEFAULT '0',
			`store_id` int(11) NOT NULL DEFAULT '0',
			`source` varchar(6) NOT NULL DEFAULT 'manual',
			`score` int(11) NOT NULL DEFAULT '0',
			`sort_order` int(3) NOT NULL DEFAULT '0',
			`date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`fbt_id`),
			UNIQUE KEY `pair` (`product_id`,`related_id`,`store_id`,`source`),
			KEY `lookup` (`product_id`,`store_id`,`source`,`sort_order`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * @return bool
	 */
	public function tableExists(): bool {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_fbt') . "'")->num_rows;
	}

	/**
	 * Base products that carry at least one hand picked companion.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getBaseProducts(array $data = []): array {
		$sql = "SELECT `f`.`product_id`, COALESCE(`pd`.`name`, '') AS `name`, COALESCE(`p`.`model`, '') AS `model`, COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_fbt` `f`";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `f`.`product_id`)";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `f`.`product_id` AND `pd`.`language_id` = '" . (int)($data['language_id'] ?? 0) . "')";
		$sql .= " WHERE `f`.`store_id` = '" . (int)($data['store_id'] ?? 0) . "' AND `f`.`source` = 'manual' AND `f`.`related_id` > 0";

		if (!empty($data['filter_name'])) {
			$sql .= " AND `pd`.`name` LIKE '" . $this->db->escape((string)$data['filter_name'] . '%') . "'";
		}

		$sql .= " GROUP BY `f`.`product_id`, `pd`.`name`, `p`.`model` ORDER BY `name` ASC, `f`.`product_id` ASC";

		$start = max(0, (int)($data['start'] ?? 0));
		$limit = (int)($data['limit'] ?? 10);

		if ($limit < 1) {
			$limit = 10;
		}

		$sql .= " LIMIT " . $start . "," . $limit;

		return $this->db->query($sql)->rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function getTotalBaseProducts(array $data = []): int {
		$sql = "SELECT COUNT(DISTINCT `f`.`product_id`) AS `total` FROM `" . DB_PREFIX . "nk_fbt` `f`";

		if (!empty($data['filter_name'])) {
			$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `f`.`product_id` AND `pd`.`language_id` = '" . (int)($data['language_id'] ?? 0) . "')";
		}

		$sql .= " WHERE `f`.`store_id` = '" . (int)($data['store_id'] ?? 0) . "' AND `f`.`source` = 'manual' AND `f`.`related_id` > 0";

		if (!empty($data['filter_name'])) {
			$sql .= " AND `pd`.`name` LIKE '" . $this->db->escape((string)$data['filter_name'] . '%') . "'";
		}

		return (int)($this->db->query($sql)->row['total'] ?? 0);
	}

	/**
	 * Companions of one base product, newest sort order first, with names.
	 *
	 * @param int    $product_id
	 * @param int    $store_id
	 * @param int    $language_id
	 * @param string $source
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getCompanions(int $product_id, int $store_id, int $language_id, string $source = 'manual'): array {
		$source = ($source === 'auto') ? 'auto' : 'manual';

		$sql = "SELECT `f`.`related_id`, `f`.`score`, `f`.`sort_order`, COALESCE(`pd`.`name`, '') AS `name`, COALESCE(`p`.`model`, '') AS `model`, COALESCE(`p`.`status`, 0) AS `status` FROM `" . DB_PREFIX . "nk_fbt` `f`";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `f`.`related_id`)";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `f`.`related_id` AND `pd`.`language_id` = '" . (int)$language_id . "')";
		$sql .= " WHERE `f`.`product_id` = '" . (int)$product_id . "' AND `f`.`store_id` = '" . (int)$store_id . "' AND `f`.`source` = '" . $this->db->escape($source) . "' AND `f`.`related_id` > 0";
		$sql .= " ORDER BY `f`.`sort_order` ASC, `f`.`fbt_id` ASC";

		return $this->db->query($sql)->rows;
	}

	/**
	 * Replace the hand picked companions of one product.
	 *
	 * @param int             $product_id
	 * @param int             $store_id
	 * @param array<int, int> $related_ids
	 *
	 * @return void
	 */
	public function setCompanions(int $product_id, int $store_id, array $related_ids): void {
		$this->deleteCompanions($product_id, $store_id);

		$sort_order = 0;

		foreach ($related_ids as $related_id) {
			$related_id = (int)$related_id;

			if ($related_id < 1 || $related_id === $product_id) {
				continue;
			}

			$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_fbt` SET `product_id` = '" . (int)$product_id . "', `related_id` = '" . $related_id . "', `store_id` = '" . (int)$store_id . "', `source` = 'manual', `score` = '0', `sort_order` = '" . (int)$sort_order . "', `date_added` = NOW() ON DUPLICATE KEY UPDATE `sort_order` = '" . (int)$sort_order . "'");

			$sort_order++;
		}
	}

	/**
	 * @param int $product_id
	 * @param int $store_id
	 *
	 * @return void
	 */
	public function deleteCompanions(int $product_id, int $store_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_fbt` WHERE `product_id` = '" . (int)$product_id . "' AND `store_id` = '" . (int)$store_id . "' AND `source` = 'manual'");
	}

	/**
	 * Throw the cached automatic suggestions away so the next cron run (or the
	 * next product view) recomputes them.
	 *
	 * @param int $store_id
	 *
	 * @return int
	 */
	public function clearAuto(int $store_id): int {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_fbt` WHERE `store_id` = '" . (int)$store_id . "' AND `source` = 'auto'");

		return (int)$this->db->countAffected();
	}

	/**
	 * Row counts for the dashboard panel.
	 *
	 * @param int $store_id
	 *
	 * @return array<string, mixed>
	 */
	public function getStats(int $store_id): array {
		$manual = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_fbt` WHERE `store_id` = '" . (int)$store_id . "' AND `source` = 'manual' AND `related_id` > 0");
		$auto = $this->db->query("SELECT COUNT(*) AS `total`, MAX(`date_added`) AS `date_added` FROM `" . DB_PREFIX . "nk_fbt` WHERE `store_id` = '" . (int)$store_id . "' AND `source` = 'auto' AND `related_id` > 0");

		return [
			'manual'     => (int)($manual->row['total'] ?? 0),
			'auto'       => (int)($auto->row['total'] ?? 0),
			'date_added' => (string)($auto->row['date_added'] ?? '')
		];
	}
}
