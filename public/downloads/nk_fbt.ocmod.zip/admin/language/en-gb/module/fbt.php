<?php
// Heading
$_['heading_title'] = 'NovaKur Frequently Bought Together';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified NovaKur Frequently Bought Together settings!';
$_['text_edit'] = 'Edit NovaKur Frequently Bought Together';
$_['text_product_success'] = 'Success: The companion products have been saved!';
$_['text_delete_success'] = 'Success: The companion products have been removed!';
$_['text_cleared'] = 'Success: %d cached suggestion(s) removed. They rebuild on the next cron run.';
$_['text_companions'] = 'Companion Products';
$_['text_configured'] = 'Products With Hand Picked Companions';
$_['text_cron'] = 'Suggestion Rebuild Cron';
$_['text_stats'] = 'Cache';
$_['text_stats_manual'] = 'Hand picked pairs';
$_['text_stats_auto'] = 'Cached suggestions';
$_['text_stats_date'] = 'Suggestions last written';
$_['text_never'] = 'Never';
$_['text_choose_product'] = 'Start typing a product name to load its companion list.';
$_['text_no_companions'] = 'No companion products yet.';
$_['text_no_suggestions'] = 'No cached suggestions for this product yet.';
$_['text_suggestions'] = 'Automatic suggestions (read only)';
$_['text_suggestion_orders'] = '%d order(s)';
$_['text_missing_product'] = '(deleted product #%d)';
$_['text_no_results'] = 'No products have hand picked companions yet.';
$_['text_all_time'] = 'Leave 0 to look at every order ever placed.';

// Column
$_['column_product'] = 'Product';
$_['column_model'] = 'Model';
$_['column_companions'] = 'Companions';
$_['column_action'] = 'Action';

// Entry
$_['entry_status'] = 'Status';
$_['entry_limit'] = 'Companions Shown';
$_['entry_hide_out_of_stock'] = 'Hide Out Of Stock';
$_['entry_auto_status'] = 'Automatic Suggestions';
$_['entry_auto_live'] = 'Warm Cache On View';
$_['entry_min_orders'] = 'Minimum Orders';
$_['entry_order_days'] = 'Order History Window';
$_['entry_cron_token'] = 'Cron Token';
$_['entry_product'] = 'Product';
$_['entry_companion'] = 'Add Companion';
$_['entry_filter_name'] = 'Product Name';

// Help
$_['help_status'] = 'Shows the bundle box on product pages.';
$_['help_limit'] = 'How many companion products to offer beside the product being viewed (1-4).';
$_['help_hide_out_of_stock'] = 'Skip companions that are out of stock so the bundle can always be added.';
$_['help_auto_status'] = 'When a product has no hand picked companions, fall back to suggestions mined from your order history.';
$_['help_auto_live'] = 'Let the first product view compute and cache the suggestions for that product. Turn this off to rely on the cron URL only.';
$_['help_min_orders'] = 'How many separate orders must contain both products before the pair is suggested. Higher is stricter.';
$_['help_order_days'] = 'Only look at orders placed in the last N days. 0 = every order.';
$_['help_cron_token'] = '16-64 letters and digits. The rebuild URL below is refused without it.';
$_['help_cron'] = 'Call this URL from cron (for example nightly) to rebuild every cached suggestion. It answers 403 without the token.';
$_['help_companion'] = 'Type a product name and pick it from the list. Products with required options are skipped on the storefront because they cannot be added blind.';
$_['help_product'] = 'Pick the product whose bundle you want to edit.';

// Button
$_['button_save_product'] = 'Save Companions';
$_['button_delete_product'] = 'Remove All';
$_['button_clear_auto'] = 'Clear Cached Suggestions';
$_['button_filter'] = 'Filter';
$_['button_edit'] = 'Edit';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify NovaKur Frequently Bought Together!';
$_['error_limit'] = 'Choose between 1 and 4 companions!';
$_['error_min_orders'] = 'The minimum order count must be between 1 and 1000!';
$_['error_order_days'] = 'The order history window must be between 0 and 3650 days!';
$_['error_cron_token'] = 'The cron token must be 16 to 64 letters and digits!';
$_['error_product'] = 'Warning: That product could not be found!';
$_['error_companion_limit'] = 'Warning: A product cannot carry more than 20 companions!';
