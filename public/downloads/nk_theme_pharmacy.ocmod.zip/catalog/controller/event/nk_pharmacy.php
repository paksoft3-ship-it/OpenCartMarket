<?php
namespace Opencart\Catalog\Controller\Extension\NkThemePharmacy\Event;

class NkPharmacy extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isPharmacyThemeActive()) {
            return;
        }

        // ---- Signature feature toggles (available to every overridden template) ----
        $data['nk_show_prescription_upload'] = (bool)$this->config->get('theme_nk_pharmacy_show_prescription_upload');
        $data['nk_show_medicine_info']       = (bool)$this->config->get('theme_nk_pharmacy_show_medicine_info');
        $data['nk_show_trust_strip']         = (bool)$this->config->get('theme_nk_pharmacy_show_trust_strip');

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/common/header_pharmacy.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_pharmacy/catalog/view/assets/dist/css/nk-pharmacy.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_pharmacy/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_pharmacy_primary_color') ?: '#0e7d6d';
                $data['novakur_secondary_color'] = '#1c4e80';
                $data['novakur_container_width'] = 1240;
                $data['novakur_base_font']       = 'Source Sans 3';
                $data['novakur_heading_font']    = 'Lora';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/nk_theme_pharmacy/common/header_pharmacy';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/common/footer_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/common/footer_pharmacy';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/common/home_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/common/home_pharmacy';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);
            $cat_w = (int)($this->config->get('config_image_category_width')  ?: 320);
            $cat_h = (int)($this->config->get('config_image_category_height') ?: 320);

            // Category tiles from real OC categories
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => ($cat['image'] ?? '')
                        ? $this->model_tool_image->resize($cat['image'], $cat_w, $cat_h)
                        : '',
                ];
            }

            // Latest products
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            // Bestsellers by rating
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 4,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/product/category_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/product/category_pharmacy';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/product/special_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/product/special_pharmacy';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/product/product_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/product/product_pharmacy';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/checkout/cart_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/checkout/cart_pharmacy';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/checkout/checkout_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/checkout/checkout_pharmacy';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/product/search_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/product/search_pharmacy';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/account/login_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/account/login_pharmacy';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/account/register_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/account/register_pharmacy';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/account/account_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/account/account_pharmacy';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/account/order_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/account/order_pharmacy';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/account/wishlist_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/account/wishlist_pharmacy';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_pharmacy/catalog/view/template/error/not_found_pharmacy.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_pharmacy/error/not_found_pharmacy';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
                'quantity'     => (int)($p['quantity'] ?? 0),
            ];
        }
        return $products;
    }

    private function isPharmacyThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_pharmacy', 'novakur_pharmacy'], true)
            && (bool)$this->config->get('theme_nk_pharmacy_status');
    }
}
