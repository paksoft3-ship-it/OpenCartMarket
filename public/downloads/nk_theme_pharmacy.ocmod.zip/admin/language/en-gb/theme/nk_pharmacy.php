<?php
$_['heading_title'] = 'NovaKur Pharmacy Theme';
$_['text_edit'] = 'Pharmacy theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Pharmacy theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_prescription_upload'] = 'Show Prescription Upload';
$_['entry_show_medicine_info'] = 'Show Medicine Info Accordion';
$_['entry_show_trust_strip'] = 'Show Trust Strip';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
