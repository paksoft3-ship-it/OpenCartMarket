<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkSeasonalPack extends \Opencart\System\Engine\Controller {

    private const SEASONS = ['winter', 'ramadan', 'spring', 'summer', 'black_friday', 'new_year'];

    public function view(string &$route, array &$data, string &$code): void {
        // The pack decorates the homepage only and never replaces the route.
        if ($route !== 'common/home') {
            return;
        }

        // Always define the keys so host templates can print them unguarded.
        $data['nk_season']             = '';
        $data['nk_season_css']         = '';
        $data['nk_seasonal_hero']      = '';
        $data['nk_seasonal_strip']     = '';
        $data['nk_seasonal_countdown'] = '';

        if (!$this->isPackActive()) {
            return;
        }

        $season = $this->resolveSeason();

        if ($season === '') {
            return;
        }

        $css_url = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-seasonal.css';
        $js_url  = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/nk-seasonal.js';

        $data['nk_season']     = $season;
        $data['nk_season_css'] = $css_url;

        $shared = [
            'season'       => $season,
            'season_label' => $this->seasonLabel($season),
            'css_url'      => $css_url,
            'js_url'       => $js_url,
            'home_href'    => $this->url->link('common/home'),
            'shop_href'    => $this->url->link('product/category'),
            'special_href' => $this->url->link('product/special'),
        ];

        // ---- Hero banner ----
        if ($this->config->get('theme_nk_seasonal_pack_show_hero_banner')) {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/component/seasonal/hero_' . $season . '.twig';
            if (is_file($template)) {
                $data['nk_seasonal_hero'] = $this->load->view('extension/novakur/component/seasonal/hero_' . $season, $shared);
            }
        }

        // ---- Promo strip ----
        if ($this->config->get('theme_nk_seasonal_pack_show_promo_strip')) {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/component/seasonal/promo_strip.twig';
            if (is_file($template)) {
                $strip = $shared;
                $strip['strip_items'] = $this->stripItems($season);
                $data['nk_seasonal_strip'] = $this->load->view('extension/novakur/component/seasonal/promo_strip', $strip);
            }
        }

        // ---- Countdown band ----
        if ($this->config->get('theme_nk_seasonal_pack_show_countdown')) {
            $until = $this->countdownDate();
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/component/seasonal/countdown_band.twig';
            if ($until !== '' && is_file($template)) {
                $countdown = $shared;
                $countdown['countdown_until'] = $until;
                $countdown['countdown_label'] = $this->countdownLabel($season);
                $data['nk_seasonal_countdown'] = $this->load->view('extension/novakur/component/seasonal/countdown_band', $countdown);
            }
        }
    }

    private function isPackActive(): bool {
        if (!(bool)$this->config->get('theme_nk_seasonal_pack_status')) {
            return false;
        }

        // Safe on top of any NovaKur theme; stay inactive elsewhere.
        $current_theme = (string)$this->config->get('config_theme');

        return str_starts_with($current_theme, 'nk_') || str_starts_with($current_theme, 'novakur');
    }

    private function resolveSeason(): string {
        $setting = trim((string)($this->config->get('theme_nk_seasonal_pack_active_season') ?? 'auto'));

        if ($setting === 'none') {
            return '';
        }

        if (in_array($setting, self::SEASONS, true)) {
            return $setting;
        }

        // 'auto' (and any unknown value): derive from the server month.
        // Ramadan shifts yearly, so it is never chosen automatically.
        $month = (int)date('n');

        switch ($month) {
            case 11:
                return 'black_friday';
            case 12:
                return 'new_year';
            case 1:
            case 2:
                return 'winter';
            case 3:
            case 4:
            case 5:
                return 'spring';
            case 6:
            case 7:
            case 8:
                return 'summer';
            default:
                // September / October: no campaign running.
                return '';
        }
    }

    private function countdownDate(): string {
        $date = trim((string)($this->config->get('theme_nk_seasonal_pack_countdown_date') ?? ''));

        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m)) {
            return '';
        }

        if (!checkdate((int)$m[2], (int)$m[3], (int)$m[1])) {
            return '';
        }

        return $date;
    }

    private function seasonLabel(string $season): string {
        $labels = [
            'winter'       => 'Winter',
            'ramadan'      => 'Ramadan',
            'spring'       => 'Spring',
            'summer'       => 'Summer',
            'black_friday' => 'Black Friday',
            'new_year'     => 'New Year',
        ];

        return $labels[$season] ?? ucfirst($season);
    }

    private function countdownLabel(string $season): string {
        $labels = [
            'winter'       => 'Winter sale ends in',
            'ramadan'      => 'Ramadan offers end in',
            'spring'       => 'Spring event ends in',
            'summer'       => 'Summer deals end in',
            'black_friday' => 'Black Friday ends in',
            'new_year'     => 'New Year offers end in',
        ];

        return $labels[$season] ?? 'Offer ends in';
    }

    private function stripItems(string $season): array {
        $items = [
            'winter' => [
                'Winter warm-up: extra cosy picks in store',
                'Free shipping on winter orders over $75',
                'Layer up — new cold-season arrivals weekly',
                'Gift wrapping on the house all season',
            ],
            'ramadan' => [
                'Ramadan Kareem — blessed offers all month',
                'Iftar-ready bundles, curated for sharing',
                'Free shipping on Ramadan orders over $75',
                'Eid gifts wrapped with care, on us',
            ],
            'spring' => [
                'Spring refresh: fresh arrivals in bloom',
                'Free shipping on spring orders over $75',
                'New season, new picks — updated weekly',
                'Easy 30-day returns, rain or shine',
            ],
            'summer' => [
                'Summer heat, cool prices — shop the edit',
                'Free shipping on summer orders over $75',
                'Sun-ready essentials restocked daily',
                'Holiday mode on: easy 30-day returns',
            ],
            'black_friday' => [
                'Black Friday: our biggest prices of the year',
                'Doorbusters drop while stocks last',
                'Free shipping on every Black Friday order',
                'No code needed — prices already cut',
            ],
            'new_year' => [
                'New Year, new arrivals — start fresh',
                'Countdown deals refreshed every day',
                'Free shipping on orders over $75',
                'Gift cards delivered instantly by email',
            ],
        ];

        return $items[$season] ?? [];
    }
}
