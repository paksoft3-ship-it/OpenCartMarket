(function () {
  var config = window.nk_ajax_cart || {};

  function url(key, fallback) {
    return config[key] || fallback;
  }

  function drawer() {
    return document.getElementById('nk-cart-drawer');
  }

  function openDrawer() {
    var el = drawer();
    if (!el) return;
    el.classList.remove('nk-cart--hidden');
    el.setAttribute('aria-hidden', 'false');
  }

  function closeDrawer() {
    var el = drawer();
    if (!el) return;
    el.classList.add('nk-cart--hidden');
    el.setAttribute('aria-hidden', 'true');
  }

  function post(target, body) {
    return fetch(target, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body
    });
  }

  // Keep the theme's own header cart in sync - the drawer is an addition, not a replacement.
  function refreshHeaderCart() {
    var target = document.getElementById('cart');
    if (!target) return;

    fetch(url('cart_info', 'index.php?route=common/cart.info'), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (r) { return r.text(); })
      .then(function (html) { target.innerHTML = html; })
      .catch(function () { /* the drawer still shows the right figures */ });
  }

  function refreshDrawer(show) {
    return fetch(url('drawer', 'index.php?route=extension/nk_ajax_cart/module/ajax_cart.getDrawer'), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (r) { return r.json(); })
      .then(function (json) {
        var old = drawer();
        if (!old || !json || !json.html) return;

        old.outerHTML = json.html;

        if (show) openDrawer();
      })
      .catch(function () { /* leave the current markup in place */ });
  }

  function isCartAdd(form, submitter) {
    var action = (submitter && submitter.getAttribute('formaction')) || form.getAttribute('action') || '';

    if (action.indexOf('checkout/cart.add') !== -1) return true;

    // Default OC4 theme product page: the form has no action, the handler posts to cart.add.
    return form.id === 'form-product' && !!submitter && submitter.id === 'button-cart';
  }

  function showErrors(form, errors) {
    form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
    form.querySelectorAll('.invalid-feedback').forEach(function (el) { el.classList.remove('d-block'); });

    for (var key in errors) {
      if (!Object.prototype.hasOwnProperty.call(errors, key)) continue;

      var input = form.querySelector('#input-' + key.replace(/_/g, '-'));
      var feedback = form.querySelector('#error-' + key.replace(/_/g, '-'));

      if (input) input.classList.add('is-invalid');

      if (feedback) {
        feedback.innerHTML = errors[key];
        feedback.classList.add('d-block');
      }
    }
  }

  // Take over add-to-cart before the theme's own jQuery handler sees the event.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;

    var submitter = e.submitter || document.activeElement;

    if (!isCartAdd(form, submitter)) return;

    e.preventDefault();
    e.stopPropagation();

    var body = new URLSearchParams(new FormData(form));

    // The submit button may itself carry the product_id on some themes.
    if (!body.get('product_id') && submitter && submitter.getAttribute('data-product-id')) {
      body.set('product_id', submitter.getAttribute('data-product-id'));
    }

    if (!body.get('quantity')) {
      body.set('quantity', '1');
    }

    post(url('add', 'index.php?route=checkout/cart.add'), body.toString())
      .then(function (r) { return r.json(); })
      .then(function (json) {
        if (json && json.error) {
          // Required options, out of stock, ... - surface them exactly where the theme would.
          if (typeof json.error === 'object') {
            showErrors(form, json.error);
          } else {
            alert(json.error);
          }

          return;
        }

        refreshHeaderCart();
        refreshDrawer(config.open !== false);
      })
      .catch(function (e) {
        // Never silently swallow it, and never re-submit: the item may already be in the cart.
        if (window.console) console.log('nk_ajax_cart: ' + e);
      });
  }, true);

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-nk-cart-close="1"]')) {
      e.preventDefault();
      closeDrawer();
      return;
    }

    var item = e.target.closest('[data-nk-cart-key]');
    if (!item) return;

    var key = item.getAttribute('data-nk-cart-key');

    var step = e.target.closest('[data-nk-cart-qty]');

    if (step) {
      e.preventDefault();

      var input = item.querySelector('[data-nk-cart-input]');
      var quantity = Math.max(0, (parseInt(input && input.value, 10) || 1) + parseInt(step.getAttribute('data-nk-cart-qty'), 10));

      post(url('edit', 'index.php?route=extension/nk_ajax_cart/module/ajax_cart.edit'), 'key=' + encodeURIComponent(key) + '&quantity=' + encodeURIComponent(quantity))
        .then(function () {
          refreshHeaderCart();
          refreshDrawer(true);
        });

      return;
    }

    if (e.target.closest('[data-nk-cart-remove="1"]')) {
      e.preventDefault();

      post(url('remove', 'index.php?route=extension/nk_ajax_cart/module/ajax_cart.remove'), 'key=' + encodeURIComponent(key))
        .then(function () {
          refreshHeaderCart();
          refreshDrawer(true);
        });
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeDrawer();
  });
})();
