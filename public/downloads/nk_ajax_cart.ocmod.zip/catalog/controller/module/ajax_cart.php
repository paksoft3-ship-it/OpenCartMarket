<?php
namespace Opencart\Catalog\Controller\Extension\NkAjaxCart\Module;

/**
 * NovaKur AJAX Cart - storefront endpoints.
 *
 *   extension/nk_ajax_cart/module/ajax_cart.render     drawer markup (used by the footer event)
 *   extension/nk_ajax_cart/module/ajax_cart.getDrawer  JSON: refreshed markup + count + total
 *   extension/nk_ajax_cart/module/ajax_cart.edit       POST key/quantity - change one cart line
 *   extension/nk_ajax_cart/module/ajax_cart.remove     POST key          - drop one cart line
 *
 * The drawer is injected into every page by extension/nk_ajax_cart/event/ajax_cart.footer,
 * which the admin controller registers on install.
 */
class AjaxCart extends \Opencart\System\Engine\Controller {
	/**
	 * Layout placeholder.
	 *
	 * The drawer is injected sitewide by the footer event, so a layout position has
	 * nothing to render. Kept so a layout that still references the module resolves
	 * instead of throwing.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * Drawer markup.
	 *
	 * @return string
	 */
	public function render(): string {
		if (!(int)$this->config->get('module_ajax_cart_status')) {
			return '';
		}

		return $this->load->view('extension/nk_ajax_cart/module/ajax_cart_drawer', $this->getData());
	}

	/**
	 * Refreshed drawer markup plus the header figures.
	 *
	 * @return void
	 */
	public function getDrawer(): void {
		$json = [];

		if (!(int)$this->config->get('module_ajax_cart_status')) {
			$json['error'] = 'disabled';
		} else {
			$data = $this->getData();

			$json['html'] = $this->load->view('extension/nk_ajax_cart/module/ajax_cart_drawer', $data);
			$json['count'] = $data['count'];
			$json['total'] = $data['total'];
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Change the quantity of a single cart line from inside the drawer.
	 *
	 * @return void
	 */
	public function edit(): void {
		$this->load->language('extension/nk_ajax_cart/module/ajax_cart');

		$json = [];

		if (!(int)$this->config->get('module_ajax_cart_status')) {
			$json['error'] = 'disabled';
		}

		$key = isset($this->request->post['key']) ? (int)$this->request->post['key'] : 0;
		$quantity = isset($this->request->post['quantity']) ? (int)$this->request->post['quantity'] : 0;

		// Never let a hand crafted request push a silly quantity into the cart.
		if ($quantity < 0) {
			$quantity = 0;
		}

		if ($quantity > 9999) {
			$quantity = 9999;
		}

		if (!isset($json['error']) && !$this->cart->has($key)) {
			$json['error'] = $this->language->get('error_product');
		}

		if (!isset($json['error'])) {
			$this->cart->update($key, $quantity);

			$this->clearCheckoutState();

			$json['success'] = 1;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Drop a single cart line from inside the drawer.
	 *
	 * @return void
	 */
	public function remove(): void {
		$this->load->language('extension/nk_ajax_cart/module/ajax_cart');

		$json = [];

		if (!(int)$this->config->get('module_ajax_cart_status')) {
			$json['error'] = 'disabled';
		}

		$key = isset($this->request->post['key']) ? (int)$this->request->post['key'] : 0;

		if (!isset($json['error']) && !$this->cart->has($key)) {
			$json['error'] = $this->language->get('error_product');
		}

		if (!isset($json['error'])) {
			$this->cart->remove($key);

			$this->clearCheckoutState();

			$json['success'] = 1;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Everything the drawer template needs.
	 *
	 * @return array<string, mixed>
	 */
	private function getData(): array {
		$this->load->language('extension/nk_ajax_cart/module/ajax_cart');

		$this->load->model('checkout/cart');
		$this->load->model('tool/image');

		$data = $this->language->all();

		$width = (int)$this->config->get('config_image_cart_width');
		$height = (int)$this->config->get('config_image_cart_height');

		// The cart image dimensions are optional in the settings; fall back to a sane square.
		if (!$width || !$height) {
			$width = 72;
			$height = 72;
		}

		// Guests may be blocked from seeing prices.
		$price_status = $this->customer->isLogged() || !$this->config->get('config_customer_price');

		$data['price_status'] = $price_status;

		$data['products'] = [];

		$sub_total = 0.0;

		foreach ($this->model_checkout_cart->getProducts() as $product) {
			$option_text = [];

			foreach ((array)$product['option'] as $option) {
				$option_text[] = $option['name'] . ': ' . $option['value'];
			}

			$data['products'][] = [
				'cart_id'     => (int)$product['cart_id'],
				'product_id'  => (int)$product['product_id'],
				'name'        => (string)$product['name'],
				'model'       => (string)$product['model'],
				'option_text' => implode(', ', $option_text),
				'thumb'       => $this->model_tool_image->resize((string)$product['image'], $width, $height),
				'href'        => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$product['product_id']),
				'price'       => $price_status ? (string)$product['price_text'] : '',
				'total'       => $price_status ? (string)$product['total_text'] : '',
				'quantity'    => (int)$product['quantity'],
				'minimum'     => max(1, (int)$product['minimum'])
			];

			$sub_total += (float)$this->tax->calculate((float)$product['total'], (int)$product['tax_class_id'], (bool)$this->config->get('config_tax'));
		}

		$data['count'] = $this->cart->countProducts();
		$data['total'] = $price_status ? $this->currency->format($sub_total, $this->session->data['currency']) : '';

		// Free shipping progress bar
		$threshold = (float)$this->config->get('module_ajax_cart_free_shipping_threshold');

		$data['show_free_shipping_bar'] = (bool)$this->config->get('module_ajax_cart_show_free_shipping_bar') && $threshold > 0 && $price_status;
		$data['free_shipping_reached'] = $sub_total >= $threshold;
		$data['free_shipping_percent'] = $threshold > 0 ? (int)min(100, round(($sub_total / $threshold) * 100)) : 0;
		$data['free_shipping_remaining'] = $this->currency->format(max(0, $threshold - $sub_total), $this->session->data['currency']);

		$data['open_on_add'] = (bool)$this->config->get('module_ajax_cart_open_on_add');

		$data['url_drawer'] = $this->url->link('extension/nk_ajax_cart/module/ajax_cart.getDrawer', 'language=' . $this->config->get('config_language'));
		$data['url_edit'] = $this->url->link('extension/nk_ajax_cart/module/ajax_cart.edit', 'language=' . $this->config->get('config_language'));
		$data['url_remove'] = $this->url->link('extension/nk_ajax_cart/module/ajax_cart.remove', 'language=' . $this->config->get('config_language'));
		$data['url_cart_add'] = $this->url->link('checkout/cart.add', 'language=' . $this->config->get('config_language'));
		$data['url_cart_info'] = $this->url->link('common/cart.info', 'language=' . $this->config->get('config_language'));
		$data['url_cart'] = $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'));
		$data['url_checkout'] = $this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language'));

		return $data;
	}

	/**
	 * Cart contents changed, so anything quoted against the old cart is stale.
	 *
	 * Mirrors what checkout/cart.edit and checkout/cart.remove do in core.
	 *
	 * @return void
	 */
	private function clearCheckoutState(): void {
		unset($this->session->data['shipping_method']);
		unset($this->session->data['shipping_methods']);
		unset($this->session->data['payment_method']);
		unset($this->session->data['payment_methods']);
		unset($this->session->data['reward']);
	}
}
