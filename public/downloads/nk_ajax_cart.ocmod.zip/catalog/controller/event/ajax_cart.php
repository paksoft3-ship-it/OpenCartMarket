<?php
namespace Opencart\Catalog\Controller\Extension\NkAjaxCart\Event;

/**
 * NovaKur AJAX Cart - storefront event hooks.
 *
 * Registered by the admin controller's install():
 *   catalog/controller/common/header/before -> header()  queue the drawer CSS/JS in <head>
 *   catalog/view/common/footer/after        -> footer()  inject the drawer markup + config
 */
class AjaxCart extends \Opencart\System\Engine\Controller {
	/**
	 * Queue the assets while the header controller is still able to render them.
	 *
	 * @param string            $route
	 * @param array<int, mixed> $args
	 *
	 * @return void
	 */
	public function header(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_ajax_cart_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_ajax_cart/catalog/view/assets/css/ajax_cart.css');
		$this->document->addScript('extension/nk_ajax_cart/catalog/view/assets/js/ajax_cart.js');
	}

	/**
	 * Drop the drawer and its runtime config at the end of every page.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function footer(string &$route, array &$data, &$output): void {
		if (!(int)$this->config->get('module_ajax_cart_status') || !is_string($output)) {
			return;
		}

		// Guard against a double injection if the merchant also placed the module in a layout.
		if (str_contains($output, 'id="nk-cart-drawer"')) {
			return;
		}

		$drawer = $this->load->controller('extension/nk_ajax_cart/module/ajax_cart.render');

		if (!is_string($drawer) || $drawer === '') {
			return;
		}

		$config = [
			'drawer'    => $this->url->link('extension/nk_ajax_cart/module/ajax_cart.getDrawer', 'language=' . $this->config->get('config_language')),
			'edit'      => $this->url->link('extension/nk_ajax_cart/module/ajax_cart.edit', 'language=' . $this->config->get('config_language')),
			'remove'    => $this->url->link('extension/nk_ajax_cart/module/ajax_cart.remove', 'language=' . $this->config->get('config_language')),
			'add'       => $this->url->link('checkout/cart.add', 'language=' . $this->config->get('config_language')),
			'cart_info' => $this->url->link('common/cart.info', 'language=' . $this->config->get('config_language')),
			'open'      => (bool)$this->config->get('module_ajax_cart_open_on_add')
		];

		$html = '<script type="text/javascript">var nk_ajax_cart = ' . json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>' . "\n" . $drawer;

		if (str_contains($output, '</body>')) {
			$output = str_replace('</body>', $html . '</body>', $output);
		} else {
			$output .= $html;
		}
	}
}
