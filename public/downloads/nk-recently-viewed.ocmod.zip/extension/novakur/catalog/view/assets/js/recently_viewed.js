(function () {
  var KEY = 'nk_recently_viewed';
  var HARD_CAP = 24;

  /**
   * localStorage is attacker-writable (any XSS elsewhere on the origin, or the
   * user's own console), so the stored list is re-validated to positive
   * integers on every read. Nothing else is ever put on the wire.
   */
  function read() {
    var raw;

    try {
      raw = JSON.parse(window.localStorage.getItem(KEY) || '[]');
    } catch (e) {
      return [];
    }

    if (!Array.isArray(raw)) return [];

    var out = [];

    for (var i = 0; i < raw.length && out.length < HARD_CAP; i++) {
      var id = parseInt(raw[i], 10);

      if (id > 0 && out.indexOf(id) === -1) out.push(id);
    }

    return out;
  }

  function write(list) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(list));
    } catch (e) {
      /* private mode / quota — the strip simply stays empty */
    }
  }

  function init() {
    var root = document.querySelector('[data-nk-rv]');
    if (!root) return;

    var list = root.querySelector('[data-nk-rv-list]');
    var url = root.getAttribute('data-nk-rv-url');
    var limit = parseInt(root.getAttribute('data-nk-rv-limit'), 10);
    var current = parseInt(root.getAttribute('data-nk-rv-product'), 10);

    if (!list || !url) return;
    if (isNaN(limit) || limit < 1) limit = 6;
    if (isNaN(current) || current < 1) current = 0;

    var history = read();

    // Record the product currently being viewed, most recent first.
    if (current) {
      history = [current].concat(history.filter(function (id) { return id !== current; })).slice(0, HARD_CAP);
      write(history);
    }

    var wanted = history.filter(function (id) { return id !== current; }).slice(0, limit);

    if (!wanted.length) return;

    var query = url + (url.indexOf('?') === -1 ? '?' : '&') + 'ids=' + encodeURIComponent(wanted.join(',')) + (current ? '&exclude=' + encodeURIComponent(current) : '');

    fetch(query, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (response) { return response.ok ? response.text() : ''; })
      .then(function (html) {
        // Every value in this fragment is escaped server side by Twig.
        if (!html || !html.trim()) return;

        list.innerHTML = html;
        root.hidden = false;
      })
      .catch(function () { /* the strip is optional — stay hidden on failure */ });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
