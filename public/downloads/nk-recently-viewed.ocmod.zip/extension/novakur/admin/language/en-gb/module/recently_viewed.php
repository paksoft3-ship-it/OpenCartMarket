<?php
// Heading
$_['heading_title']    = 'NovaKur Recently Viewed';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified NovaKur Recently Viewed settings!';
$_['text_edit']        = 'Edit NovaKur Recently Viewed';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';

// Entry
$_['entry_status']     = 'Status';
$_['entry_title']      = 'Heading';
$_['entry_limit']      = 'Products shown';
$_['entry_show_price'] = 'Show prices';

// Help
$_['help_layout']      = 'This is a layout module. After enabling it, add "NovaKur Recently Viewed" to a layout position under Design > Layouts (Content Bottom on the Product and Home layouts is the usual choice).';
$_['help_title']       = 'Leave empty to use the storefront language default.';
$_['help_limit']       = 'How many of the most recently viewed products the strip shows.';
$_['help_show_price']  = 'Prices still follow the "Login Display Prices" store setting.';

// Button
$_['button_save']      = 'Save';
$_['button_back']      = 'Back';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';
$_['error_title']      = 'Heading must be 64 characters or fewer!';
$_['error_limit']      = 'Products shown must be 4, 6, 8 or 12!';
