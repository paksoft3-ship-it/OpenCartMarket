<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Feed;

/**
 * NovaKur Hepsiburada XML feed.
 *
 * index.php?route=extension/novakur/feed/hepsiburada&token=xxxx
 *
 * Emits the Hepsiburada listing XML shape (merchantSku / barcode / brand /
 * listPrice / price / tax / stock / images). Prices are VAT inclusive and
 * always written with a dot decimal separator, which is what the Hepsiburada
 * importer expects regardless of the store's display locale.
 */
class Hepsiburada extends \Opencart\System\Engine\Controller {
    /**
     * Products fetched and rendered per query, so a 50k product catalogue
     * never has to fit in memory in one go.
     */
    protected int $batch_size = 250;

    /**
     * tax_class_id => VAT percentage
     *
     * @var array<int, float>
     */
    protected array $vat_rates = [];

    public function index(): void {
        $protocol = isset($this->request->server['SERVER_PROTOCOL']) ? (string)$this->request->server['SERVER_PROTOCOL'] : 'HTTP/1.1';

        if (!(int)$this->config->get('feed_hepsiburada_status')) {
            $this->response->addHeader($protocol . ' 404 Not Found');
            $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
            $this->response->setOutput('Feed disabled');

            return;
        }

        // The feed exposes the whole catalogue, so it is token guarded. An
        // unset token locks the feed rather than opening it.
        $token = trim((string)$this->config->get('feed_hepsiburada_token'));
        $supplied = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied)) {
            $this->response->addHeader($protocol . ' 403 Forbidden');
            $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
            $this->response->setOutput('');

            return;
        }

        $cache_hours = (int)$this->config->get('feed_hepsiburada_cache_hours');

        if (!in_array($cache_hours, [1, 6, 12, 24], true)) {
            $cache_hours = 6;
        }

        $cache_file = DIR_CACHE . 'nk_feed_hepsiburada_' . (int)$this->config->get('config_store_id') . '.xml';

        if (is_file($cache_file) && (time() - filemtime($cache_file)) < ($cache_hours * 3600)) {
            $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
            $this->response->setOutput((string)file_get_contents($cache_file));

            return;
        }

        $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
        $this->response->setOutput($this->build($cache_file));
    }

    /**
     * Builds the feed in batches, writing straight into the cache file and
     * only then swapping it in, so a half generated feed is never served.
     */
    protected function build(string $cache_file): string {
        $language_id = (int)$this->config->get('feed_hepsiburada_language_id');

        if (!$language_id) {
            $language_id = (int)$this->config->get('config_language_id');
        }

        $currency_code = (string)$this->config->get('feed_hepsiburada_currency_code');

        if ($currency_code === '' || !$this->currency->has($currency_code)) {
            $currency_code = (string)$this->config->get('config_currency');
        }

        $excluded_categories = $this->config->get('feed_hepsiburada_excluded_categories');

        if (!is_array($excluded_categories)) {
            $excluded_categories = $excluded_categories !== '' && $excluded_categories !== null ? explode(',', (string)$excluded_categories) : [];
        }

        $excluded_categories = array_filter(array_map('intval', $excluded_categories));

        $this->load->model('tool/image');

        $category_paths = $this->categoryPaths($language_id);

        $sql = "SELECT `p`.`product_id`, `p`.`model`, `p`.`sku`, `p`.`upc`, `p`.`ean`, `p`.`jan`, `p`.`isbn`, `p`.`mpn`, `p`.`price`, `p`.`quantity`, `p`.`image`, `p`.`tax_class_id`,
                `pd`.`name`, `pd`.`description`,
                (SELECT `m`.`name` FROM `" . DB_PREFIX . "manufacturer` `m` WHERE `m`.`manufacturer_id` = `p`.`manufacturer_id` LIMIT 1) AS `manufacturer`,
                (SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1) AS `special`
                FROM `" . DB_PREFIX . "product_to_store` `p2s`
                LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `p2s`.`product_id`)
                LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id` AND `pd`.`language_id` = '" . (int)$language_id . "')
                WHERE `p2s`.`store_id` = '" . (int)$this->config->get('config_store_id') . "'
                AND `p`.`status` = '1'
                AND `p`.`date_available` <= NOW()
                AND `p`.`master_id` = '0'";

        if ($excluded_categories) {
            // category_path holds every ancestor pair, so excluding a category
            // also excludes everything below it.
            $sql .= " AND `p`.`product_id` NOT IN (SELECT `p2c`.`product_id` FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`category_id` IN (SELECT `cp`.`category_id` FROM `" . DB_PREFIX . "category_path` `cp` WHERE `cp`.`path_id` IN (" . implode(',', $excluded_categories) . ")))";
        }

        $sql .= " ORDER BY `p`.`product_id` ASC";

        $temporary = $cache_file . '.' . getmypid() . '.tmp';

        $handle = @fopen($temporary, 'w+');
        $cacheable = $handle !== false;

        if (!$cacheable) {
            // Unwritable cache directory must not take the feed down.
            $handle = fopen('php://temp/maxmemory:' . (4 * 1024 * 1024), 'w+');
        }

        fwrite($handle, '<?xml version="1.0" encoding="UTF-8"?>' . "\n");
        fwrite($handle, '<Products>' . "\n");

        $start = 0;

        while (true) {
            $products = $this->db->query($sql . " LIMIT " . (int)$start . ", " . (int)$this->batch_size)->rows;

            if (!$products) {
                break;
            }

            $product_ids = [];

            foreach ($products as $product) {
                $product_ids[] = (int)$product['product_id'];
            }

            $codes = $this->loadProductCodes($product_ids);
            $images = $this->loadImages($product_ids);
            $categories = $this->loadCategories($product_ids);

            foreach ($products as $product) {
                $product_id = (int)$product['product_id'];

                fwrite($handle, $this->renderProduct($product, [
                    'currency_code' => $currency_code,
                    'codes'         => $codes[$product_id] ?? [],
                    'images'        => $images[$product_id] ?? [],
                    'category'      => $category_paths[$categories[$product_id] ?? 0] ?? ''
                ]));
            }

            if (count($products) < $this->batch_size) {
                break;
            }

            $start += $this->batch_size;
        }

        fwrite($handle, '</Products>');

        if ($cacheable) {
            fclose($handle);

            @rename($temporary, $cache_file);

            return (string)file_get_contents(is_file($cache_file) ? $cache_file : $temporary);
        }

        rewind($handle);

        $output = (string)stream_get_contents($handle);

        fclose($handle);

        return $output;
    }

    /**
     * @param array<string, mixed> $product
     * @param array<string, mixed> $context
     */
    protected function renderProduct(array $product, array $context): string {
        $codes = $context['codes'];

        $name = $this->text((string)$product['name']);

        if ($name === '') {
            return '';
        }

        $tax_class_id = (int)$product['tax_class_id'];

        $list_price = $this->tax->calculate((float)$product['price'], $tax_class_id, true);
        $sale_price = $list_price;

        if (!empty($product['special'])) {
            $sale_price = $this->tax->calculate((float)$product['special'], $tax_class_id, true);
        }

        // sku first: Hepsiburada matches listings on merchantSku.
        $merchant_sku = $this->identifier([$codes['sku'] ?? '', $product['sku'], $product['model'], (string)(int)$product['product_id']]);
        $barcode = $this->identifier([$codes['ean'] ?? '', $codes['gtin'] ?? '', $codes['upc'] ?? '', $codes['jan'] ?? '', $codes['isbn'] ?? '', $product['ean'], $product['upc'], $product['jan'], $product['isbn']]);

        $xml = [];
        $xml[] = '<Product>';
        $xml[] = '<productCode>' . (int)$product['product_id'] . '</productCode>';
        $xml[] = '<merchantSku>' . $this->esc($merchant_sku) . '</merchantSku>';

        if ($barcode !== '') {
            $xml[] = '<barcode>' . $this->esc($barcode) . '</barcode>';
        }

        $xml[] = '<productName>' . $this->cdata(mb_substr($name, 0, 150)) . '</productName>';
        $xml[] = '<brand>' . $this->cdata(mb_substr($this->text((string)$product['manufacturer']), 0, 100)) . '</brand>';
        $xml[] = '<categoryName>' . $this->cdata(mb_substr((string)$context['category'], 0, 250)) . '</categoryName>';
        $xml[] = '<description>' . $this->cdata(mb_substr($this->plain((string)$product['description']), 0, 5000)) . '</description>';
        $xml[] = '<currency>' . $this->esc((string)$context['currency_code']) . '</currency>';
        $xml[] = '<listPrice>' . $this->money($list_price, (string)$context['currency_code']) . '</listPrice>';
        $xml[] = '<price>' . $this->money($sale_price, (string)$context['currency_code']) . '</price>';
        $xml[] = '<tax>' . $this->vatRate($tax_class_id) . '</tax>';
        $xml[] = '<stock>' . max(0, (int)$product['quantity']) . '</stock>';
        $xml[] = '<productUrl>' . $this->esc($this->productUrl((int)$product['product_id'])) . '</productUrl>';
        $xml[] = '<images>';

        foreach ($context['images'] as $image) {
            $xml[] = '<image><url>' . $this->esc($image) . '</url></image>';
        }

        $xml[] = '</images>';
        $xml[] = '</Product>';

        return implode("\n", $xml) . "\n";
    }

    /**
     * First non-empty identifier of the candidates.
     *
     * @param array<int, mixed> $candidates
     */
    protected function identifier(array $candidates): string {
        foreach ($candidates as $candidate) {
            $candidate = trim((string)$candidate);

            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * OpenCart 4.1 keeps sku/upc/ean/jan/isbn/mpn both on the product row and
     * in the product_code table, so both have to be read.
     *
     * @param array<int, int> $product_ids
     *
     * @return array<int, array<string, string>>
     */
    protected function loadProductCodes(array $product_ids): array {
        $map = [];

        if (!$product_ids) {
            return $map;
        }

        $rows = $this->db->query("SELECT `product_id`, `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `product_id` IN (" . implode(',', $product_ids) . ") AND `value` <> ''")->rows;

        foreach ($rows as $row) {
            $map[(int)$row['product_id']][strtolower((string)$row['code'])] = trim((string)$row['value']);
        }

        return $map;
    }

    /**
     * @param array<int, int> $product_ids
     *
     * @return array<int, array<int, string>>
     */
    protected function loadImages(array $product_ids): array {
        $map = [];

        if (!$product_ids) {
            return $map;
        }

        $rows = $this->db->query("SELECT `p`.`product_id`, `p`.`image`, 0 AS `image_rank`, 0 AS `image_sort` FROM `" . DB_PREFIX . "product` `p` WHERE `p`.`product_id` IN (" . implode(',', $product_ids) . ") AND `p`.`image` <> '' UNION ALL SELECT `pi`.`product_id`, `pi`.`image`, 1 AS `image_rank`, `pi`.`sort_order` AS `image_sort` FROM `" . DB_PREFIX . "product_image` `pi` WHERE `pi`.`product_id` IN (" . implode(',', $product_ids) . ") AND `pi`.`image` <> '' ORDER BY `product_id` ASC, `image_rank` ASC, `image_sort` ASC")->rows;

        foreach ($rows as $row) {
            $product_id = (int)$row['product_id'];

            if (isset($map[$product_id]) && count($map[$product_id]) >= 8) {
                continue;
            }

            $image = $this->model_tool_image->resize((string)$row['image'], 1000, 1000);

            if ($image !== '') {
                $map[$product_id][] = $image;
            }
        }

        return $map;
    }

    /**
     * @param array<int, int> $product_ids
     *
     * @return array<int, int>
     */
    protected function loadCategories(array $product_ids): array {
        $map = [];

        if (!$product_ids) {
            return $map;
        }

        $rows = $this->db->query("SELECT `product_id`, MIN(`category_id`) AS `category_id` FROM `" . DB_PREFIX . "product_to_category` WHERE `product_id` IN (" . implode(',', $product_ids) . ") GROUP BY `product_id`")->rows;

        foreach ($rows as $row) {
            $map[(int)$row['product_id']] = (int)$row['category_id'];
        }

        return $map;
    }

    /**
     * category_id => "Parent > Child" path names.
     *
     * @return array<int, string>
     */
    protected function categoryPaths(int $language_id): array {
        $map = [];

        $rows = $this->db->query("SELECT `cp`.`category_id`, GROUP_CONCAT(`cd`.`name` ORDER BY `cp`.`level` SEPARATOR ' > ') AS `path` FROM `" . DB_PREFIX . "category_path` `cp` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`cp`.`path_id` = `cd`.`category_id` AND `cd`.`language_id` = '" . (int)$language_id . "') GROUP BY `cp`.`category_id`")->rows;

        foreach ($rows as $row) {
            $map[(int)$row['category_id']] = $this->text((string)$row['path']);
        }

        return $map;
    }

    protected function productUrl(int $product_id): string {
        return $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id);
    }

    /**
     * VAT percentage of a tax class, cached per request.
     */
    protected function vatRate(int $tax_class_id): string {
        if (!isset($this->vat_rates[$tax_class_id])) {
            $rate = 0.0;

            foreach ($this->tax->getRates(100.0, $tax_class_id) as $tax_rate) {
                if ($tax_rate['type'] == 'P') {
                    $rate += (float)$tax_rate['rate'];
                }
            }

            $this->vat_rates[$tax_class_id] = $rate;
        }

        return (string)(int)round($this->vat_rates[$tax_class_id]);
    }

    /**
     * Converts to the feed currency and formats with a dot decimal separator.
     */
    protected function money(float $value, string $currency_code): string {
        return number_format((float)$this->currency->format($value, $currency_code, 0, false), 2, '.', '');
    }

    /**
     * Drops characters XML 1.0 cannot carry. CDATA does not make a raw
     * 0x00-0x08 byte legal, so this runs on everything that is written out.
     */
    protected function clean(string $value): string {
        $clean = preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $value);

        if ($clean === null) {
            // Invalid UTF-8 in the row: fall back to a byte level filter.
            $clean = preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value);
        }

        return trim((string)$clean);
    }

    /**
     * Stored product text is HTML encoded, so entities are decoded once here.
     */
    protected function text(string $value): string {
        return $this->clean(html_entity_decode($value, ENT_QUOTES, 'UTF-8'));
    }

    /**
     * Same as text(), with markup flattened to a single line.
     */
    protected function plain(string $value): string {
        $value = $this->text(strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>', '</li>'], ' ', $value)));

        return trim((string)preg_replace('/\s+/u', ' ', $value));
    }

    protected function esc(string $value): string {
        return htmlspecialchars($this->clean($value), ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    protected function cdata(string $value): string {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $this->clean($value)) . ']]>';
    }
}
