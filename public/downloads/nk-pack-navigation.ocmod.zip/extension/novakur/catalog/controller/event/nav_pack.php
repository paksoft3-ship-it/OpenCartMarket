<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

/**
 * NovaKur Mega Menu + Mobile Nav Pack — storefront hooks.
 *
 * assets()     catalog/controller/common/header/before  → register CSS/JS
 * header()     catalog/controller/common/header/after   → inject nav markup
 * breadcrumb() catalog/view/product/{*}/after           → inject BreadcrumbList JSON-LD
 */
class NavPack extends \Opencart\System\Engine\Controller {
	private const CSS = 'extension/novakur/catalog/view/assets/css/nav_pack.css';
	private const JS  = 'extension/novakur/catalog/view/assets/js/nav_pack.js';

	/**
	 * Routes whose rendered view is allowed to receive the JSON-LD block.
	 */
	private const BREADCRUMB_ROUTES = [
		'product/category',
		'product/product',
		'product/manufacturer_info'
	];

	private static bool $header_done = false;

	/**
	 * Memo for getCategories() so a 3-level tree does not re-query a branch.
	 *
	 * @var array<int, array<int, array<string, mixed>>>
	 */
	private array $branch_cache = [];

	/**
	 * @param string               $route
	 * @param array<string, mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!$this->enabled()) {
			return;
		}

		$this->document->addStyle(self::CSS);
		$this->document->addScript(self::JS);
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $args
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function header(string &$route, array &$args, mixed &$output): void {
		if (!$this->enabled() || !is_string($output) || $output === '') {
			return;
		}

		// A theme can legitimately render the header twice (e.g. a print view);
		// only the first pass gets the nav.
		if (self::$header_done || str_contains($output, 'nk-nav-root')) {
			return;
		}

		$show_mega   = $this->toggle('mega_status');
		$show_mobile = $this->toggle('mobile_status');

		if (!$show_mega && !$show_mobile && !$this->toggle('sticky_status')) {
			return;
		}

		$this->load->language('extension/novakur/module/nav_pack');

		$max_depth  = $this->intSetting('max_depth', 3, 1, 3);
		$columns    = $this->intSetting('columns', 4, 2, 6);
		$breakpoint = $this->intSetting('breakpoint', 992, 576, 1600);

		$categories = $this->buildTree(0, '', 1, $max_depth, $this->promoMap());

		if (!$categories) {
			return;
		}

		$view_data = [
			'nk_categories'  => $categories,
			'nk_columns'     => $columns,
			'nk_breakpoint'  => $breakpoint,
			'nk_show_images' => $this->toggle('show_images'),
			'nk_sticky'      => $this->toggle('sticky_status'),
			'nk_show_mega'   => $show_mega,
			'nk_show_mobile' => $show_mobile,
			'nk_home_href'   => $this->url->link('common/home', 'language=' . $this->config->get('config_language')),
			'text_menu'      => $this->language->get('text_menu'),
			'text_close'     => $this->language->get('text_close'),
			'text_open'      => $this->language->get('text_open'),
			'text_back'      => $this->language->get('text_back'),
			'text_home'      => $this->language->get('text_home'),
			'text_view_all'  => $this->language->get('text_view_all'),
			'text_expand'    => $this->language->get('text_expand')
		];

		$html = $this->inlineStyle($breakpoint, $columns);

		if ($show_mega) {
			$html .= $this->load->view('extension/novakur/module/nav_pack_mega', $view_data);
		}

		if ($show_mobile) {
			$html .= $this->load->view('extension/novakur/module/nav_pack_mobile', $view_data);
		}

		$output = $this->inject($output, $html);

		self::$header_done = true;
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function breadcrumb(string &$route, array &$data, mixed &$output): void {
		if (!$this->enabled() || !$this->toggle('breadcrumb_status')) {
			return;
		}

		if (!in_array($route, self::BREADCRUMB_ROUTES, true)) {
			return;
		}

		if (!is_string($output) || $output === '' || empty($data['breadcrumbs']) || !is_array($data['breadcrumbs'])) {
			return;
		}

		// Never emit a second BreadcrumbList — themes and SEO extensions add one too.
		if (str_contains($output, 'BreadcrumbList')) {
			return;
		}

		$items    = [];
		$position = 1;

		foreach ($data['breadcrumbs'] as $crumb) {
			if (!is_array($crumb)) {
				continue;
			}

			$name = trim(html_entity_decode((string)($crumb['text'] ?? ''), ENT_QUOTES, 'UTF-8'));

			if ($name === '') {
				continue;
			}

			$item = [
				'@type'    => 'ListItem',
				'position' => $position++,
				'name'     => $name
			];

			$href = trim(html_entity_decode((string)($crumb['href'] ?? ''), ENT_QUOTES, 'UTF-8'));

			if ($href !== '' && preg_match('#^https?://#i', $href)) {
				$item['item'] = $href;
			}

			$items[] = $item;
		}

		if (count($items) < 2) {
			return;
		}

		$json = json_encode([
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items
		], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		if ($json === false) {
			return;
		}

		$block = "\n" . '<script type="application/ld+json" data-nk-nav-breadcrumb="1">' . $json . '</script>' . "\n";

		$position = strripos($output, '</body>');

		if ($position !== false) {
			$output = substr($output, 0, $position) . $block . substr($output, $position);
		} else {
			$output .= $block;
		}
	}

	// ---------------------------------------------------------------- helpers

	private function enabled(): bool {
		return (bool)(int)$this->config->get('module_nav_pack_status');
	}

	private function toggle(string $key, bool $default = true): bool {
		$value = $this->config->get('module_nav_pack_' . $key);

		if ($value === null || $value === '') {
			return $default;
		}

		return (bool)(int)$value;
	}

	private function intSetting(string $key, int $default, int $min, int $max): int {
		$value = $this->config->get('module_nav_pack_' . $key);

		if ($value === null || $value === '' || !is_numeric($value)) {
			return $default;
		}

		$number = (int)$value;

		return ($number >= $min && $number <= $max) ? $number : $default;
	}

	/**
	 * Promo tiles grouped by the top-level category they belong to.
	 *
	 * @return array<int, array<int, array<string, string>>>
	 */
	private function promoMap(): array {
		$rows = $this->config->get('module_nav_pack_promo');

		if (!is_array($rows) || !$rows) {
			return [];
		}

		$this->load->model('tool/image');

		$map = [];

		foreach ($rows as $row) {
			if (!is_array($row)) {
				continue;
			}

			$category_id = (int)($row['category_id'] ?? 0);

			if ($category_id <= 0) {
				continue;
			}

			$image = (string)($row['image'] ?? '');
			$thumb = '';

			// Re-check the stored path: settings can be edited outside the form.
			if ($image !== '' && !str_contains($image, '..') && !str_starts_with($image, '/')) {
				$thumb = $this->model_tool_image->resize($image, 320, 200);
			}

			$map[$category_id][] = [
				'thumb' => $thumb,
				'link'  => $this->safeLink((string)($row['link'] ?? '')),
				'text'  => trim(strip_tags(html_entity_decode((string)($row['text'] ?? ''), ENT_QUOTES, 'UTF-8')))
			];
		}

		return $map;
	}

	private function safeLink(string $link): string {
		$link = trim($link);

		if ($link === '' || preg_match('/^\s*(javascript|data|vbscript|file)\s*:/i', $link)) {
			return '';
		}

		return $link;
	}

	/**
	 * Recursive category tree, depth-capped, with promo tiles attached to the
	 * top-level nodes.
	 *
	 * @param array<int, array<int, array<string, string>>> $promo
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function buildTree(int $parent_id, string $path, int $level, int $max_depth, array $promo): array {
		if ($level > $max_depth) {
			return [];
		}

		$this->load->model('catalog/category');

		if (!isset($this->branch_cache[$parent_id])) {
			// OpenCart 4.x catalog model takes a plain parent id, not a filter array.
			$this->branch_cache[$parent_id] = $this->model_catalog_category->getCategories($parent_id);
		}

		$results = $this->branch_cache[$parent_id];

		if (!$results) {
			return [];
		}

		$show_images = $this->toggle('show_images');

		if ($show_images) {
			$this->load->model('tool/image');
		}

		$tree = [];

		foreach ($results as $result) {
			$category_id = (int)$result['category_id'];
			$node_path   = $path === '' ? (string)$category_id : $path . '_' . $category_id;

			$thumb = '';

			if ($show_images && !empty($result['image'])) {
				$thumb = $this->model_tool_image->resize((string)$result['image'], 60, 60);
			}

			$tree[] = [
				'category_id' => $category_id,
				'name'        => html_entity_decode((string)$result['name'], ENT_QUOTES, 'UTF-8'),
				'href'        => $this->url->link('product/category', 'language=' . $this->config->get('config_language') . '&path=' . $node_path),
				'thumb'       => $thumb,
				'promo'       => $level === 1 ? ($promo[$category_id] ?? []) : [],
				'children'    => $this->buildTree($category_id, $node_path, $level + 1, $max_depth, $promo)
			];
		}

		return $tree;
	}

	/**
	 * The only per-store dynamic CSS: the desktop/mobile switch breakpoint, the
	 * panel column count, and the optional "hide the theme's own menu" rule.
	 */
	private function inlineStyle(int $breakpoint, int $columns): string {
		$mobile_max = $breakpoint - 1;

		$css = '.nk-nav-root{--nk-nav-columns:' . $columns . ';}';
		$css .= '@media (max-width:' . $mobile_max . 'px){.nk-nav-desktop{display:none !important;}}';
		$css .= '@media (min-width:' . $breakpoint . 'px){.nk-nav-mobile{display:none !important;}}';

		if ($this->toggle('hide_theme_menu', false)) {
			$css .= '#menu,[data-nk-nav-replace]{display:none !important;}';
		}

		return '<style data-nk-nav-style="1">' . $css . '</style>';
	}

	/**
	 * Placement, in order of preference:
	 *   1. a [data-nk-nav-mount] element in the theme header — the JS relocates
	 *      the nav into it on load, so we only need it in the document;
	 *   2. immediately after the theme's </header>;
	 *   3. appended to the header output.
	 */
	private function inject(string $output, string $html): string {
		if (str_contains($output, 'data-nk-nav-mount')) {
			return $output . $html;
		}

		$position = stripos($output, '</header>');

		if ($position !== false) {
			$position += strlen('</header>');

			return substr($output, 0, $position) . $html . substr($output, $position);
		}

		return $output . $html;
	}
}
