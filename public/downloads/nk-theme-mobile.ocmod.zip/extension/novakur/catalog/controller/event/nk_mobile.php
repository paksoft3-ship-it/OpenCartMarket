<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkMobile extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isMobileThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_mobile.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-mobile.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_mobile_primary_color') ?: '#6366f1';
                $data['novakur_secondary_color'] = '#0f172a';
                $data['novakur_container_width'] = 1200;
                $data['novakur_base_font']       = 'system-ui';
                $data['novakur_heading_font']    = 'system-ui';
                $data['cart_quantity']           = $this->cart->countProducts();
                $data['nk_show_tab_bar']         = (int)$this->themeSetting('show_tab_bar', 1);
                $data['nk_show_category_chips']  = (int)$this->themeSetting('show_category_chips', 1);
                $data['nk_compact_cards']        = (int)$this->themeSetting('compact_cards', 1);

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_mobile';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_mobile.twig';
            if (is_file($template)) {
                $data['cart_quantity']          = $this->cart->countProducts();
                $data['nk_show_tab_bar']        = (int)$this->themeSetting('show_tab_bar', 1);
                $data['nk_show_category_chips'] = (int)$this->themeSetting('show_category_chips', 1);

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/footer_mobile';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_mobile';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            $data['nk_show_category_chips'] = (int)$this->themeSetting('show_category_chips', 1);
            $data['nk_compact_cards']       = (int)$this->themeSetting('compact_cards', 1);
            $data['customer_first_name']    = $this->customer->isLogged() ? $this->customer->getFirstName() : '';

            // Categories for the chip rail
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            // Latest / new arrivals
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest']   = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['featured'] = $data['latest'];

            // Bestsellers
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_mobile';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['nk_show_category_chips'] = (int)$this->themeSetting('show_category_chips', 1);
            $data['nk_compact_cards']       = (int)$this->themeSetting('compact_cards', 1);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_mobile';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['nk_compact_cards'] = (int)$this->themeSetting('compact_cards', 1);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_mobile';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_mobile';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_mobile';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_mobile';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $data['nk_show_category_chips'] = (int)$this->themeSetting('show_category_chips', 1);
            $data['nk_compact_cards']       = (int)$this->themeSetting('compact_cards', 1);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_mobile';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_mobile';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_mobile';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_mobile';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_mobile';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            $data['nk_compact_cards'] = (int)$this->themeSetting('compact_cards', 1);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_mobile.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_mobile';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function themeSetting(string $key, int $default): int {
        $value = $this->config->get('theme_nk_mobile_' . $key);
        return $value === null ? $default : (int)$value;
    }

    private function isMobileThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_mobile', 'novakur_mobile'], true)
            && (bool)$this->config->get('theme_nk_mobile_status');
    }
}
