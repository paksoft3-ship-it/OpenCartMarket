<?php
$_['heading_title'] = 'NovaKur Mobile-First Theme';
$_['text_edit'] = 'Mobile-first theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Mobile-first theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_tab_bar'] = 'Show Bottom Tab Bar';
$_['entry_show_category_chips'] = 'Show Category Chip Rail';
$_['entry_compact_cards'] = 'Compact Product Cards';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
