<?php
$_['heading_title']                  = 'NovaKur Microsoft Merchant Feed';

$_['text_extension']                 = 'Extensions';
$_['text_success']                   = 'Success: You have modified Microsoft Merchant feed settings!';
$_['text_edit']                      = 'Edit Microsoft Merchant Feed';
$_['text_enabled']                   = 'Enabled';
$_['text_disabled']                  = 'Disabled';
$_['text_new']                       = 'New';
$_['text_used']                      = 'Used';
$_['text_refurbished']               = 'Refurbished';
$_['text_default_store']             = 'Default Store';
$_['text_cache_cleared']             = 'Feed cache has been cleared.';
$_['text_feed_url']                  = 'Feed URL';
$_['text_feed_status']               = 'Feed Status';
$_['text_last_generated']            = 'Last Generated';
$_['text_not_generated']             = 'Not generated yet';
$_['text_platform_notice']           = 'This extension only produces the TSV file. Connecting it is done on Microsoft\'s side: create a store in Microsoft Merchant Center, add this URL as a scheduled catalog feed, and read the first feed report. Microsoft decides which rows it accepts, so validate that first import before you rely on the feed.';

$_['entry_status']                   = 'Status';
$_['entry_store']                    = 'Store';
$_['entry_currency']                 = 'Currency';
$_['entry_language']                 = 'Language';
$_['entry_include_out_of_stock']     = 'Include Out Of Stock';
$_['entry_include_tax']              = 'Prices Include Tax';
$_['entry_brand_attribute']          = 'Brand Attribute';
$_['entry_gtin_attribute']           = 'GTIN Attribute';
$_['entry_mpn_attribute']            = 'MPN Attribute';
$_['entry_condition']                = 'Condition';
$_['entry_google_product_category']  = 'Product Category Override';
$_['entry_max_products']             = 'Maximum Products';
$_['entry_cache_hours']              = 'Cache Duration (Hours)';
$_['entry_excluded_categories']      = 'Excluded Categories';
$_['entry_token']                    = 'Feed Token';

$_['help_feed_url']                  = 'Add this URL as a scheduled catalog feed in Microsoft Merchant Center. It contains the feed token, so treat it as a secret.';
$_['help_excluded_categories']       = 'Products in the selected categories will be excluded from the feed.';
$_['help_include_tax']               = 'Microsoft expects prices that include tax. Leave enabled unless your store prices are already tax inclusive.';
$_['help_google_product_category']   = 'Optional. A single taxonomy value written into the Product Category column of every row, for example "Health &amp; Beauty &gt; Health Care". Leave blank to send the product\'s own OpenCart category path instead.';
$_['help_max_products']              = 'Hard cap on the number of rows written to the feed. 0 means no limit. Products are read from the database in batches of 250 either way.';
$_['help_token']                     = 'Required. The feed URL only answers when this token is supplied, otherwise the route returns 404.';

$_['button_copy']                    = 'Copy';
$_['button_clear_cache']             = 'Clear Cache';
$_['button_regenerate_token']        = 'Regenerate Token';
$_['button_open_merchant_center']    = 'Open Microsoft Merchant Center';

$_['error_permission']               = 'Warning: You do not have permission to modify Microsoft Merchant feed!';
$_['error_currency']                 = 'Select a currency that exists in your store!';
$_['error_token']                    = 'The feed token must be 16 to 64 letters or digits!';
