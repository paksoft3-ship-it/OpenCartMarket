<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkB2b extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isB2bThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_b2b.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-b2b.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_b2b_primary_color') ?: '#14365c';
                $data['novakur_secondary_color'] = '#4a6785';
                $data['novakur_container_width'] = 1280;
                $data['novakur_base_font']       = 'IBM Plex Sans';
                $data['novakur_heading_font']    = 'IBM Plex Sans';
                $data['novakur_mono_font']       = 'IBM Plex Mono';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_b2b';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/footer_b2b';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_b2b';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            // Category quick-order shortcuts
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            // Latest stocked lines
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            // Bestsellers for the table + card hybrid
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 10,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);

            $data['nk_show_bulk_table'] = (bool)$this->config->get('theme_nk_b2b_show_bulk_table');
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_b2b';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $data['nk_show_bulk_table'] = (bool)$this->config->get('theme_nk_b2b_show_bulk_table');
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_b2b';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $data['nk_show_bulk_table'] = (bool)$this->config->get('theme_nk_b2b_show_bulk_table');
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_b2b';
            }

            $data['nk_show_tier_pricing'] = (bool)$this->config->get('theme_nk_b2b_show_tier_pricing');
            $data['nk_show_quote_panel']  = (bool)$this->config->get('theme_nk_b2b_show_quote_panel');

            // Raw unit price + currency symbols so the tier table can be computed in Twig.
            $currency   = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $product_id = (int)($this->request->get['product_id'] ?? 0);

            $data['nk_price_value']  = 0.0;
            $data['nk_symbol_left']  = $this->currency->getSymbolLeft($currency) ?: '';
            $data['nk_symbol_right'] = $this->currency->getSymbolRight($currency) ?: '';
            $data['nk_decimals']     = (int)$this->currency->getDecimalPlace($currency) ?: 2;

            if ($product_id) {
                $this->load->model('catalog/product');
                $product_info = $this->model_catalog_product->getProduct($product_id);
                if ($product_info) {
                    $base_price = ($product_info['special'] ?? false) ? $product_info['special'] : ($product_info['price'] ?? 0);
                    $taxed = $this->tax->calculate(
                        $base_price,
                        $product_info['tax_class_id'] ?? 0,
                        $this->config->get('config_tax')
                    );
                    $data['nk_price_value'] = (float)$this->currency->convert($taxed, $this->config->get('config_currency'), $currency);
                    $data['nk_sku']         = $product_info['model'] ?? '';
                    $data['nk_quantity']    = (int)($product_info['quantity'] ?? 0);
                }
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_b2b';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_b2b';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_b2b';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }

            $data['nk_show_bulk_table'] = (bool)$this->config->get('theme_nk_b2b_show_bulk_table');
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_b2b';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_b2b';
            }
        }

        // ---- Account Dashboard (trade portal) ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_b2b';
            }

            // Orders lead the trade portal, so pull them for the dashboard itself.
            $data['nk_orders']       = [];
            $data['nk_order_count']  = 0;
            $data['nk_open_orders']  = 0;
            $data['nk_lifetime']     = '';

            if ($this->customer->isLogged()) {
                $this->load->model('account/order');

                $currency  = $this->session->data['currency'] ?? $this->config->get('config_currency');
                $raw_orders = $this->model_account_order->getOrders(0, 6);
                $lifetime   = 0.0;

                foreach ($raw_orders as $order) {
                    $status = trim((string)($order['status'] ?? ''));
                    $lifetime += (float)($order['total'] ?? 0);

                    $data['nk_orders'][] = [
                        'order_id'   => (int)($order['order_id'] ?? 0),
                        'status'     => $status,
                        'date_added' => !empty($order['date_added'])
                            ? date('Y-m-d', strtotime((string)$order['date_added']))
                            : '',
                        'total'      => $this->currency->format(
                            $order['total'] ?? 0,
                            $order['currency_code'] ?? $currency,
                            $order['currency_value'] ?? 0
                        ),
                        'href'       => $this->url->link('account/order.info', 'order_id=' . (int)($order['order_id'] ?? 0)),
                    ];

                    if ($status !== '' && !in_array(strtolower($status), ['complete', 'completed', 'shipped', 'cancelled', 'refunded', 'denied'], true)) {
                        $data['nk_open_orders']++;
                    }
                }

                $data['nk_order_count'] = (int)$this->model_account_order->getTotalOrders();
                $data['nk_lifetime']    = $this->currency->format($lifetime, $currency, 1.0);
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_b2b';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_b2b';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }

            $data['nk_show_bulk_table'] = (bool)$this->config->get('theme_nk_b2b_show_bulk_table');
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_b2b.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_b2b';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $quantity = (int)($p['quantity'] ?? 0);
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'sku'          => $p['model'] ?? '',
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'quantity'     => $quantity,
                'in_stock'     => $quantity > 0,
                'stock_label'  => $quantity > 0 ? 'In Stock' : 'Backorder',
                'minimum'      => max(1, (int)($p['minimum'] ?? 1)),
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isB2bThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_b2b', 'novakur_b2b'], true)
            && (bool)$this->config->get('theme_nk_b2b_status');
    }
}
