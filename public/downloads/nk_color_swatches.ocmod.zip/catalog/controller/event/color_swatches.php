<?php
namespace Opencart\Catalog\Controller\Extension\NkColorSwatches\Event;

/**
 * NovaKur Color Swatches - storefront hooks.
 *
 * assets()  catalog/controller/common/header/before  queue CSS + JS
 * product() catalog/view/product/product/after       attach the swatch map
 * thumb()   catalog/view/product/thumb/after         display-only card strip
 *
 * Why the payload is JSON and the swatches are built in the browser rather than
 * rewritten into the HTML here: the stock product template hands the select and
 * the radio list their own ids, error containers and `name="option[n]"` fields,
 * and OpenCart's own add-to-cart handler serialises that form. Rewriting the
 * markup server side would mean re-implementing all of it and would break the
 * moment a theme changed a class. Instead the original control is left exactly
 * where it is - still named, still serialised, still validated - and the JS
 * draws buttons that drive it. That is also what makes this module and NovaKur
 * Variant Images compose: the swatch click ends in a native `change` event on
 * the real field, which is precisely what Variant Images listens for.
 *
 * OpenCart 4.1 notes:
 *   - catalog/controller/product/product.php skips option values that are out
 *     of stock (`!subtract || quantity > 0`), so they never reach the template.
 *     The strikethrough swatches are therefore built from our own query rather
 *     than from $data['options'].
 *   - A variant product renders its *master's* product_option rows, so the map
 *     is looked up by product_option_id, never by product_id.
 */
class ColorSwatches extends \Opencart\System\Engine\Controller {
	private const CSS = 'extension/nk_color_swatches/catalog/view/assets/css/color_swatches.css';
	private const JS  = 'extension/nk_color_swatches/catalog/view/assets/js/color_swatches.js';

	private const MARKER = 'id="nk-swatch-data"';

	/**
	 * Option types whose control the JS knows how to drive.
	 *
	 * @var array<int, string>
	 */
	private const OPTION_TYPES = ['select', 'radio'];

	/**
	 * @var array<int, string>
	 */
	private const SHAPES = ['circle', 'rounded', 'square'];

	/**
	 * @var array<int, string>
	 */
	private const OOS_MODES = ['strike', 'dim', 'hide'];

	/**
	 * Card swatches already resolved this request, keyed by product id. The same
	 * product routinely appears twice on one page (featured + latest).
	 *
	 * @var array<int, array<int, array<string, mixed>>>
	 */
	private static array $cards = [];

	/**
	 * @param string               $route
	 * @param array<string, mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!$this->enabled()) {
			return;
		}

		$this->document->addStyle(self::CSS);
		$this->document->addScript(self::JS);
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function product(string &$route, array &$data, mixed &$output): void {
		if (!$this->enabled() || !is_string($output) || $output === '') {
			return;
		}

		if (str_contains($output, self::MARKER)) {
			return;
		}

		if (!isset($data['options']) || !is_array($data['options'])) {
			return;
		}

		$product_option_ids = [];

		foreach ($data['options'] as $option) {
			if (!is_array($option) || !isset($option['product_option_id'])) {
				continue;
			}

			if (!in_array((string)($option['type'] ?? ''), self::OPTION_TYPES, true)) {
				continue;
			}

			$product_option_ids[] = (int)$option['product_option_id'];
		}

		if (!$product_option_ids) {
			return;
		}

		$this->load->model('extension/nk_color_swatches/module/color_swatches');

		$rows = $this->model_extension_nk_color_swatches_module_color_swatches->getSwatchesByOption($product_option_ids);

		if (!$rows) {
			return;
		}

		$resolver = $this->imageResolver($this->size());

		$options = [];

		foreach ($rows as $row) {
			$entry = self::entry($row, $resolver);

			if (!$entry) {
				continue;
			}

			$options[(string)(int)$row['product_option_id']][] = $entry;
		}

		if (!$options) {
			return;
		}

		$this->load->language('extension/nk_color_swatches/module/color_swatches');

		$payload = [
			'shape'  => $this->shape(),
			'size'   => $this->size(),
			'hide'   => (int)(bool)(int)$this->config->get('module_color_swatches_hide_native'),
			'label'  => (int)(bool)(int)$this->config->get('module_color_swatches_show_label'),
			'oos'    => $this->oosMode(),
			'oosTxt' => (string)$this->language->get('text_out_of_stock'),
			'opts'   => $options
		];

		// JSON_HEX_TAG is what keeps a merchant supplied option name containing
		// "</script>" from ending the block early.
		$json = json_encode($payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);

		if (!is_string($json)) {
			return;
		}

		$output .= '<script type="application/json" ' . self::MARKER . '>' . $json . '</script>';
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function thumb(string &$route, array &$data, mixed &$output): void {
		if (!$this->enabled() || !(int)$this->config->get('module_color_swatches_thumb_status')) {
			return;
		}

		if (!is_string($output) || $output === '') {
			return;
		}

		$product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

		if ($product_id < 1) {
			return;
		}

		$entries = $this->cardEntries($product_id);

		if (!$entries) {
			return;
		}

		$limit = (int)$this->config->get('module_color_swatches_thumb_limit');

		if ($limit < 1 || $limit > 12) {
			$limit = 5;
		}

		$overflow = count($entries) > $limit ? count($entries) - $limit : 0;

		$html = $this->load->view('extension/nk_color_swatches/module/color_swatch_thumb', [
			'swatches' => array_slice($entries, 0, $limit),
			'overflow' => $overflow,
			'shape'    => $this->shape(),
			'size'     => (int)round($this->size() * 0.55)
		]);

		if (!is_string($html) || $html === '') {
			return;
		}

		// Sits directly above the add-to-cart button row of the stock card. If a
		// theme dropped that form the card is returned untouched rather than
		// having markup wedged into an unknown structure.
		$position = strpos($output, '<form method="post"');

		if ($position === false) {
			return;
		}

		$output = substr($output, 0, $position) . $html . substr($output, $position);
	}

	/**
	 * Card swatches for one product, resolved at most once per request.
	 *
	 * @param int $product_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function cardEntries(int $product_id): array {
		if (isset(self::$cards[$product_id])) {
			return self::$cards[$product_id];
		}

		$this->load->model('extension/nk_color_swatches/module/color_swatches');

		$resolver = $this->imageResolver((int)round($this->size() * 0.55));

		$entries = [];

		foreach ($this->model_extension_nk_color_swatches_module_color_swatches->getCardSwatches($product_id) as $row) {
			// Card swatches are display only, so they carry no id and are always
			// treated as in stock (the query already filtered stock out).
			$entry = self::entry(['subtract' => 0, 'quantity' => 1] + $row, $resolver);

			if ($entry) {
				$entries[] = $entry;
			}
		}

		self::$cards[$product_id] = $entries;

		return $entries;
	}

	/**
	 * Turn one `nk_option_swatch` join row into a payload entry.
	 *
	 * Everything is re-validated here even though save() already normalised it:
	 * the table is merchant editable through any SQL client, and this value is
	 * about to be written into a style attribute in the browser.
	 *
	 * @param array<string, mixed> $row
	 * @param callable|null        $image_url path -> URL resolver
	 *
	 * @return array<string, mixed> empty when the row cannot be drawn
	 */
	public static function entry(array $row, ?callable $image_url = null): array {
		$type = strtolower(trim((string)($row['type'] ?? '')));

		$entry = [
			'i' => isset($row['product_option_value_id']) ? (int)$row['product_option_value_id'] : 0,
			'n' => (string)($row['name'] ?? ''),
			's' => (empty($row['subtract']) || (int)($row['quantity'] ?? 0) > 0) ? 1 : 0
		];

		if ($type === 'color') {
			$color = strtolower(trim((string)($row['color'] ?? '')));

			if (!preg_match('/^#[0-9a-f]{6}$/', $color)) {
				return [];
			}

			$entry['t'] = 'c';
			$entry['v'] = $color;

			return $entry;
		}

		if ($type === 'image') {
			$image = trim((string)($row['image'] ?? ''));

			if ($image === '' || str_contains($image, '..') || str_contains($image, "\0") || $image[0] === '/') {
				return [];
			}

			$url = $image_url !== null ? (string)$image_url($image) : '';

			if ($url === '') {
				return [];
			}

			$entry['t'] = 'i';
			$entry['v'] = $url;

			return $entry;
		}

		return [];
	}

	/**
	 * @param int $size
	 *
	 * @return callable
	 */
	private function imageResolver(int $size): callable {
		$this->load->model('tool/image');

		$model = $this->model_tool_image;

		// Swatches are rendered at up to 2x for high density screens.
		$edge = max(20, min(160, $size * 2));

		return static function (string $image) use ($model, $edge): string {
			if (!is_file(DIR_IMAGE . html_entity_decode($image, ENT_QUOTES, 'UTF-8'))) {
				return '';
			}

			$url = (string)$model->resize($image, $edge, $edge);

			// The URL ends up inside a CSS url('...') - in a style attribute on
			// the card and in style.backgroundImage in the browser. HTML
			// attribute escaping does not help there, because the parser hands
			// the decoded text to the CSS parser. A filename carrying a quote,
			// a backslash, a bracket or whitespace is therefore dropped rather
			// than escaped.
			if ($url === '' || preg_match('/[\'"\\\\()\s<>]/', $url)) {
				return '';
			}

			return $url;
		};
	}

	/**
	 * @return string
	 */
	private function shape(): string {
		$shape = (string)$this->config->get('module_color_swatches_shape');

		return in_array($shape, self::SHAPES, true) ? $shape : 'circle';
	}

	/**
	 * @return string
	 */
	private function oosMode(): string {
		$mode = (string)$this->config->get('module_color_swatches_oos_mode');

		return in_array($mode, self::OOS_MODES, true) ? $mode : 'strike';
	}

	/**
	 * @return int
	 */
	private function size(): int {
		$size = (int)$this->config->get('module_color_swatches_size');

		return ($size >= 20 && $size <= 80) ? $size : 34;
	}

	/**
	 * @return bool
	 */
	private function enabled(): bool {
		return (bool)(int)$this->config->get('module_color_swatches_status');
	}
}
