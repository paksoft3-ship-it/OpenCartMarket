/**
 * NovaKur Color Swatches - storefront.
 *
 * The stock OpenCart 4.1 product template renders each option as either
 *
 *   <select name="option[225]" id="input-option-225">          (type select)
 *   <input type="radio" name="option[225]" value="1114">       (type radio)
 *
 * and #form-product is serialised verbatim by the theme's add-to-cart handler.
 * So this script never removes or renames those fields. It draws buttons next
 * to them and, on every click, writes the value into the real field and fires a
 * native `change` event. Add to cart, option validation, price updates and any
 * other module listening to that field (NovaKur Variant Images, for one) carry
 * on working without knowing swatches exist.
 *
 * The original control is only visually hidden - never disabled, never
 * detached - and only when every value it can offer has a swatch, so an
 * unmapped value can never become unreachable.
 */
(function (root, factory) {
  var api = factory();

  if (root) {
    root.NkColorSwatches = api;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        api.boot(document);
      });
    } else {
      api.boot(document);
    }
  }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  var SHAPES = ['circle', 'rounded', 'square'];
  var OOS_MODES = ['strike', 'dim', 'hide'];

  /**
   * Parse and sanity-check the payload the PHP event wrote into the page.
   * Anything malformed yields null and the page is left completely alone.
   *
   * @param {string} text
   * @returns {object|null}
   */
  function readPayload(text) {
    var raw;

    try {
      raw = JSON.parse(text);
    } catch (e) {
      return null;
    }

    if (!raw || typeof raw !== 'object' || !raw.opts || typeof raw.opts !== 'object') {
      return null;
    }

    var size = parseInt(raw.size, 10);

    if (isNaN(size) || size < 20 || size > 80) {
      size = 34;
    }

    var opts = {};
    var found = false;

    Object.keys(raw.opts).forEach(function (key) {
      var list = raw.opts[key];

      if (!Array.isArray(list)) {
        return;
      }

      var entries = list.filter(function (entry) {
        return entry && (entry.t === 'c' || entry.t === 'i') && typeof entry.v === 'string' && entry.v !== '';
      }).map(function (entry) {
        // Normalised here so nothing downstream has to guess whether the stock
        // flag arrived as a number or a string. Anything unrecognised counts as
        // out of stock, which is the direction that fails safely.
        return {
          i: String(entry.i),
          n: typeof entry.n === 'string' ? entry.n : '',
          t: entry.t,
          v: entry.v,
          s: (entry.s === 1 || entry.s === '1' || entry.s === true) ? 1 : 0
        };
      });

      if (entries.length) {
        opts[String(key)] = entries;
        found = true;
      }
    });

    if (!found) {
      return null;
    }

    return {
      shape: SHAPES.indexOf(raw.shape) !== -1 ? raw.shape : 'circle',
      size: size,
      hide: raw.hide === 1 || raw.hide === '1' || raw.hide === true,
      label: raw.label === 1 || raw.label === '1' || raw.label === true,
      oos: OOS_MODES.indexOf(raw.oos) !== -1 ? raw.oos : 'strike',
      oosTxt: typeof raw.oosTxt === 'string' && raw.oosTxt !== '' ? raw.oosTxt : 'Out of stock',
      opts: opts
    };
  }

  /**
   * A control is either a <select> or a set of radio inputs. Both are described
   * by the same shape so the rest of the script does not care which it got.
   *
   * @param {object} control {kind:'select', el} or {kind:'radio', els:[]}
   * @returns {string[]} the values the control can actually take
   */
  function controlValues(control) {
    var values = [];

    if (!control) {
      return values;
    }

    if (control.kind === 'select') {
      var options = control.el.options || [];

      for (var i = 0; i < options.length; i++) {
        if (options[i].value !== '') {
          values.push(String(options[i].value));
        }
      }

      return values;
    }

    (control.els || []).forEach(function (el) {
      if (el.value !== '') {
        values.push(String(el.value));
      }
    });

    return values;
  }

  /**
   * @param {object} control
   * @returns {string} '' when nothing is chosen
   */
  function readSelection(control) {
    if (!control) {
      return '';
    }

    if (control.kind === 'select') {
      return String(control.el.value || '');
    }

    var chosen = '';

    (control.els || []).forEach(function (el) {
      if (el.checked) {
        chosen = String(el.value);
      }
    });

    return chosen;
  }

  /**
   * Write a value into the real form field and tell the page about it.
   *
   * This is the whole point of the module, so it is deliberately the smallest,
   * most boring function here: set the value the way the browser would have,
   * then fire the same `change` event the browser would have fired.
   *
   * @param {object} control
   * @param {string} value
   * @returns {boolean} false when the control cannot take that value
   */
  function syncField(control, value) {
    if (!control) {
      return false;
    }

    value = String(value);

    if (controlValues(control).indexOf(value) === -1) {
      return false;
    }

    var target;

    if (control.kind === 'select') {
      control.el.value = value;
      target = control.el;
    } else {
      (control.els || []).forEach(function (el) {
        var match = String(el.value) === value;

        el.checked = match;

        if (match) {
          target = el;
        }
      });
    }

    if (!target) {
      return false;
    }

    dispatch(target, 'change');

    return true;
  }

  /**
   * @param {object} el
   * @param {string} name
   */
  function dispatch(el, name) {
    if (!el || typeof el.dispatchEvent !== 'function') {
      return;
    }

    var event;

    if (typeof Event === 'function') {
      event = new Event(name, { bubbles: true });
    } else {
      event = { type: name, bubbles: true };
    }

    el.dispatchEvent(event);
  }

  /**
   * True when every value the control offers has a swatch, i.e. hiding the
   * control cannot strand a value the shopper still needs to reach.
   *
   * @param {object} control
   * @param {Array} entries
   * @returns {boolean}
   */
  function fullyCovered(control, entries) {
    var mapped = {};

    entries.forEach(function (entry) {
      mapped[String(entry.i)] = true;
    });

    return controlValues(control).every(function (value) {
      return mapped[value] === true;
    });
  }

  // ---------------------------------------------------------------- DOM ----

  function findControl(form, productOptionId) {
    var name = 'option[' + productOptionId + ']';
    var select = form.querySelector('select[name="' + name + '"]');

    if (select) {
      return { kind: 'select', el: select, nodes: [select] };
    }

    var radios = form.querySelectorAll('input[type="radio"][name="' + name + '"]');

    if (radios && radios.length) {
      var els = Array.prototype.slice.call(radios);

      return { kind: 'radio', els: els, nodes: els };
    }

    return null;
  }

  function wrapperOf(control) {
    var node = control.nodes[0];
    var wrapper = node.closest ? node.closest('.mb-3') : null;

    return wrapper || node.parentNode;
  }

  /**
   * insertBefore() only accepts a direct child of the parent. A <select> is a
   * direct child of its .mb-3, but a radio input is two levels down
   * (.mb-3 > #input-option-n > .form-check > input), so walk back up to the
   * child of the wrapper that contains the control.
   *
   * @param {Element} wrapper
   * @param {Element} node
   * @returns {Element|null}
   */
  function anchorIn(wrapper, node) {
    var current = node;

    while (current && current.parentNode && current.parentNode !== wrapper) {
      current = current.parentNode;
    }

    return current && current.parentNode === wrapper ? current : null;
  }

  function buildSwatch(doc, entry, config, selectable) {
    var button = doc.createElement('button');

    button.type = 'button';
    button.className = 'nk-swatch';
    button.setAttribute('role', 'radio');
    button.setAttribute('aria-checked', 'false');
    button.setAttribute('data-nk-value', String(entry.i));
    button.tabIndex = -1;

    var title = entry.n || '';

    if (!selectable) {
      button.classList.add('nk-swatch--oos');
      button.disabled = true;
      button.setAttribute('aria-disabled', 'true');
      title = title ? title + ' – ' + config.oosTxt : config.oosTxt;
    }

    button.title = title;
    button.setAttribute('aria-label', title);

    if (entry.t === 'c') {
      button.style.backgroundColor = entry.v;
    } else {
      button.style.backgroundImage = "url('" + entry.v + "')";
    }

    if (!config.label) {
      return button;
    }

    var item = doc.createElement('span');

    item.className = 'nk-swatch-item' + (selectable ? '' : ' nk-swatch-item--oos');

    var name = doc.createElement('span');

    name.className = 'nk-swatch-name';
    name.textContent = entry.n || '';

    item.appendChild(button);
    item.appendChild(name);

    return item;
  }

  function buttonsOf(group) {
    return Array.prototype.slice.call(group.querySelectorAll('.nk-swatch'));
  }

  function paint(group, control) {
    var current = readSelection(control);
    var buttons = buttonsOf(group);
    var focusable = null;

    buttons.forEach(function (button) {
      var selected = button.getAttribute('data-nk-value') === current && current !== '';

      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-checked', selected ? 'true' : 'false');
      button.tabIndex = -1;

      if (selected) {
        focusable = button;
      }
    });

    if (!focusable) {
      focusable = buttons.filter(function (button) {
        return !button.disabled;
      })[0] || null;
    }

    if (focusable) {
      focusable.tabIndex = 0;
    }
  }

  function wireKeys(group, control) {
    group.addEventListener('keydown', function (e) {
      var step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];

      if (step === undefined && e.key !== 'Home' && e.key !== 'End') {
        return;
      }

      var enabled = buttonsOf(group).filter(function (button) {
        return !button.disabled;
      });

      if (!enabled.length) {
        return;
      }

      e.preventDefault();

      var index = enabled.indexOf(e.target);
      var next;

      if (e.key === 'Home') {
        next = enabled[0];
      } else if (e.key === 'End') {
        next = enabled[enabled.length - 1];
      } else {
        index = index === -1 ? 0 : (index + step + enabled.length) % enabled.length;
        next = enabled[index];
      }

      syncField(control, next.getAttribute('data-nk-value'));
      paint(group, control);
      next.focus();
    });
  }

  /**
   * @param {Document} doc
   */
  function boot(doc) {
    var holder = doc.getElementById('nk-swatch-data');

    if (!holder) {
      return;
    }

    var config = readPayload(holder.textContent || holder.innerHTML || '');

    if (!config) {
      return;
    }

    var form = doc.getElementById('form-product') || doc.getElementById('product') || doc;

    Object.keys(config.opts).forEach(function (productOptionId) {
      var control = findControl(form, productOptionId);

      if (!control) {
        return;
      }

      var available = controlValues(control);
      var entries = config.opts[productOptionId];

      var group = doc.createElement('div');

      group.className = 'nk-swatches';
      group.setAttribute('role', 'radiogroup');
      group.setAttribute('data-nk-swatch-shape', config.shape);
      group.setAttribute('data-nk-swatch-oos', config.oos);
      group.style.setProperty('--nk-swatch-size', config.size + 'px');

      var rendered = 0;

      entries.forEach(function (entry) {
        var selectable = entry.s === 1 && available.indexOf(String(entry.i)) !== -1;

        if (!selectable && config.oos === 'hide') {
          return;
        }

        group.appendChild(buildSwatch(doc, entry, config, selectable));
        rendered++;
      });

      if (!rendered) {
        return;
      }

      var wrapper = wrapperOf(control);
      var anchor = anchorIn(wrapper, control.nodes[0]);

      // Right after the label, before the control it replaces.
      if (anchor) {
        wrapper.insertBefore(group, anchor);
      } else {
        wrapper.appendChild(group);
      }

      group.addEventListener('click', function (e) {
        var target = e.target;
        var button = target && target.closest ? target.closest('.nk-swatch') : null;

        // With labels turned on the name is a sibling of the button, not a
        // child, so a click on the text has to be walked back to the item.
        if (!button && target && target.closest) {
          var item = target.closest('.nk-swatch-item');

          button = item ? item.querySelector('.nk-swatch') : null;
        }

        if (!button || button.disabled) {
          return;
        }

        e.preventDefault();

        syncField(control, button.getAttribute('data-nk-value'));
        paint(group, control);
      });

      wireKeys(group, control);

      // Anything else that moves the field - another module, the back button,
      // a browser restore - repaints the swatches.
      control.nodes.forEach(function (node) {
        node.addEventListener('change', function () {
          paint(group, control);
        });
      });

      if (config.hide && fullyCovered(control, entries)) {
        control.nodes.forEach(function (node) {
          node.classList.add('nk-swatch-native-hidden');
        });

        // A radio's <label> sits beside the input, not around it, so the
        // whole .form-check row goes with it.
        if (control.kind === 'radio') {
          control.nodes.forEach(function (node) {
            var row = node.closest ? node.closest('.form-check') : null;

            if (row) {
              row.classList.add('nk-swatch-native-hidden');
            }
          });
        }
      }

      paint(group, control);
    });
  }

  return {
    boot: boot,
    readPayload: readPayload,
    controlValues: controlValues,
    readSelection: readSelection,
    syncField: syncField,
    fullyCovered: fullyCovered
  };
});
