<?php
// Text
$_['text_out_of_stock'] = 'Out of stock';
$_['text_choose']       = 'Choose %s';
$_['text_more']         = '+%s more';
