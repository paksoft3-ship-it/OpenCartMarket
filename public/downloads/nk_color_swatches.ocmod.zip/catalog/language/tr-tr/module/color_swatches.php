<?php
// Text
$_['text_out_of_stock'] = 'Stokta yok';
$_['text_choose']       = '%s seçin';
$_['text_more']         = '+%s daha';
