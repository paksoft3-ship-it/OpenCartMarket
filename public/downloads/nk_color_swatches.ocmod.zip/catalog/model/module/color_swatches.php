<?php
namespace Opencart\Catalog\Model\Extension\NkColorSwatches\Module;

/**
 * NovaKur Color Swatches - storefront reads of the swatch map.
 *
 * Both queries are INNER JOINs against `nk_option_swatch`, so a store with no
 * mapping at all pays for one indexed lookup that returns nothing.
 */
class ColorSwatches extends \Opencart\System\Engine\Model {
	/**
	 * Hard ceiling on rows pulled for one product, so a pathological catalogue
	 * cannot turn a product page into a memory problem.
	 */
	private const MAX_ROWS = 200;

	/**
	 * Every value of the given product options, mapped or not, including the
	 * ones OpenCart dropped from the page because they are out of stock.
	 *
	 * Keyed by product_option_id rather than product_id on purpose: a variant
	 * product renders its master's `product_option` rows, so keying on the
	 * product would come back empty for variants.
	 *
	 * @param array<int, int> $product_option_ids
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getSwatchesByOption(array $product_option_ids): array {
		$ids = [];

		foreach ($product_option_ids as $product_option_id) {
			$product_option_id = (int)$product_option_id;

			if ($product_option_id > 0) {
				$ids[$product_option_id] = $product_option_id;
			}
		}

		if (!$ids) {
			return [];
		}

		$query = $this->db->query("SELECT `pov`.`product_option_value_id`, `pov`.`product_option_id`, `pov`.`option_value_id`, `pov`.`quantity`, `pov`.`subtract`, `ovd`.`name`, `s`.`type`, `s`.`color`, `s`.`image` FROM `" . DB_PREFIX . "product_option_value` `pov` INNER JOIN `" . DB_PREFIX . "nk_option_swatch` `s` ON (`s`.`option_value_id` = `pov`.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `pov`.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value_description` `ovd` ON (`ovd`.`option_value_id` = `pov`.`option_value_id` AND `ovd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "') WHERE `pov`.`product_option_id` IN (" . implode(',', $ids) . ") ORDER BY `ov`.`sort_order` ASC, `ovd`.`name` ASC LIMIT " . self::MAX_ROWS);

		return $query->rows;
	}

	/**
	 * Distinct, in-stock, mapped swatches for one product card.
	 *
	 * @param int $product_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getCardSwatches(int $product_id): array {
		if ($product_id < 1) {
			return [];
		}

		$query = $this->db->query("SELECT DISTINCT `s`.`type`, `s`.`color`, `s`.`image`, `ovd`.`name`, `ov`.`sort_order` FROM `" . DB_PREFIX . "product_option_value` `pov` INNER JOIN `" . DB_PREFIX . "nk_option_swatch` `s` ON (`s`.`option_value_id` = `pov`.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `pov`.`option_value_id`) LEFT JOIN `" . DB_PREFIX . "option_value_description` `ovd` ON (`ovd`.`option_value_id` = `pov`.`option_value_id` AND `ovd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "') WHERE `pov`.`product_id` = '" . (int)$product_id . "' AND (`pov`.`subtract` = '0' OR `pov`.`quantity` > '0') ORDER BY `ov`.`sort_order` ASC, `ovd`.`name` ASC LIMIT " . self::MAX_ROWS);

		return $query->rows;
	}
}
