<?php
namespace Opencart\Admin\Controller\Extension\NkColorSwatches\Module;

/**
 * NovaKur Color Swatches - admin settings and the option value -> swatch map.
 *
 * Routes
 *   extension/nk_color_swatches/module/color_swatches             settings + mapper
 *   extension/nk_color_swatches/module/color_swatches.save        settings
 *   extension/nk_color_swatches/module/color_swatches.values      value rows for one option (AJAX)
 *   extension/nk_color_swatches/module/color_swatches.values_save the map for one option
 *
 * Core's `extension/module` install flow already grants access + modify on the
 * base route, and admin/controller/startup/permission.php checks the route with
 * the `.method` suffix stripped, so every method above is covered by that one
 * permission. install() re-grants it anyway so the screen is reachable when the
 * module is installed straight from the Installer by a non-admin group.
 */
class ColorSwatches extends \Opencart\System\Engine\Controller {
	private const ROUTE = 'extension/nk_color_swatches/module/color_swatches';

	private const PREFIX = 'module_color_swatches';

	/**
	 * @var array<int, string>
	 */
	private const SHAPES = ['circle', 'rounded', 'square'];

	/**
	 * @var array<int, string>
	 */
	private const OOS_MODES = ['strike', 'dim', 'hide'];

	/**
	 * @var array<int, string>
	 */
	public const SWATCH_TYPES = ['color', 'image'];

	/**
	 * Storefront events registered on install / removed on uninstall.
	 *
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'nk_color_swatches_assets',
			'description' => 'NovaKur Color Swatches: queue the swatch stylesheet and script in the page head.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/nk_color_swatches/event/color_swatches.assets'
		],
		[
			'code'        => 'nk_color_swatches_product',
			'description' => 'NovaKur Color Swatches: attach the swatch map to the product page.',
			'trigger'     => 'catalog/view/product/product/after',
			'action'      => 'extension/nk_color_swatches/event/color_swatches.product'
		],
		[
			'code'        => 'nk_color_swatches_thumb',
			'description' => 'NovaKur Color Swatches: display-only swatch strip on product cards.',
			'trigger'     => 'catalog/view/product/thumb/after',
			'action'      => 'extension/nk_color_swatches/event/color_swatches.thumb'
		]
	];

	/**
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			self::PREFIX . '_status'       => '0',
			self::PREFIX . '_shape'        => 'circle',
			self::PREFIX . '_size'         => '34',
			self::PREFIX . '_hide_native'  => '1',
			self::PREFIX . '_show_label'   => '0',
			self::PREFIX . '_oos_mode'     => 'strike',
			self::PREFIX . '_thumb_status' => '0',
			self::PREFIX . '_thumb_limit'  => '5'
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language(self::ROUTE);

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting(self::PREFIX, $store_id);

		$data = [];

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		$data['shapes'] = [];

		foreach (self::SHAPES as $shape) {
			$data['shapes'][] = [
				'value' => $shape,
				'text'  => $this->language->get('text_shape_' . $shape)
			];
		}

		$data['oos_modes'] = [];

		foreach (self::OOS_MODES as $mode) {
			$data['oos_modes'][] = [
				'value' => $mode,
				'text'  => $this->language->get('text_oos_' . $mode)
			];
		}

		$this->load->model('extension/nk_color_swatches/module/color_swatches');

		$data['options'] = [];

		foreach ($this->model_extension_nk_color_swatches_module_color_swatches->getOptions() as $option) {
			$data['options'][] = [
				'option_id' => (int)$option['option_id'],
				'name'      => (string)$option['name'],
				'type'      => (string)$option['type']
			];
		}

		$data['total_mapped'] = $this->model_extension_nk_color_swatches_module_color_swatches->getTotalSwatches();

		$data['option_id'] = $data['options'] ? (int)$data['options'][0]['option_id'] : 0;
		$data['values'] = $data['option_id'] ? $this->getValues($data['option_id']) : '';

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save'] = $this->url->link(self::ROUTE . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['values_url'] = $this->url->link(self::ROUTE . '.values', 'user_token=' . $this->session->data['user_token']);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	/**
	 * Presentation settings. Per store, like every other module setting.
	 *
	 * @return void
	 */
	public function save(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$shape = isset($post[self::PREFIX . '_shape']) ? (string)$post[self::PREFIX . '_shape'] : '';

		if (!in_array($shape, self::SHAPES, true)) {
			$json['error']['shape'] = $this->language->get('error_shape');
		}

		$oos_mode = isset($post[self::PREFIX . '_oos_mode']) ? (string)$post[self::PREFIX . '_oos_mode'] : '';

		if (!in_array($oos_mode, self::OOS_MODES, true)) {
			$json['error']['oos_mode'] = $this->language->get('error_oos_mode');
		}

		$size = isset($post[self::PREFIX . '_size']) ? (string)$post[self::PREFIX . '_size'] : '';

		if (!preg_match('/^\d{1,3}$/', $size) || (int)$size < 20 || (int)$size > 80) {
			$json['error']['size'] = $this->language->get('error_size');
		}

		$thumb_limit = isset($post[self::PREFIX . '_thumb_limit']) ? (string)$post[self::PREFIX . '_thumb_limit'] : '';

		if (!preg_match('/^\d{1,2}$/', $thumb_limit) || (int)$thumb_limit < 1 || (int)$thumb_limit > 12) {
			$json['error']['thumb_limit'] = $this->language->get('error_thumb_limit');
		}

		if (!isset($json['error'])) {
			$save = [
				self::PREFIX . '_status'       => !empty($post[self::PREFIX . '_status']) ? '1' : '0',
				self::PREFIX . '_shape'        => $shape,
				self::PREFIX . '_size'         => (string)(int)$size,
				self::PREFIX . '_hide_native'  => !empty($post[self::PREFIX . '_hide_native']) ? '1' : '0',
				self::PREFIX . '_show_label'   => !empty($post[self::PREFIX . '_show_label']) ? '1' : '0',
				self::PREFIX . '_oos_mode'     => $oos_mode,
				self::PREFIX . '_thumb_status' => !empty($post[self::PREFIX . '_thumb_status']) ? '1' : '0',
				self::PREFIX . '_thumb_limit'  => (string)(int)$thumb_limit
			];

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting(self::PREFIX, $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * The mapping rows for one option, as its own AJAX-refreshable block.
	 *
	 * @return void
	 */
	public function values(): void {
		$this->load->language(self::ROUTE);

		$option_id = isset($this->request->get['option_id']) ? (int)$this->request->get['option_id'] : 0;

		$this->response->setOutput($this->getValues($option_id));
	}

	/**
	 * @param int $option_id
	 *
	 * @return string
	 */
	private function getValues(int $option_id): string {
		$this->load->model('extension/nk_color_swatches/module/color_swatches');
		$this->load->model('tool/image');

		$data = [];

		$data['option_id'] = $option_id;
		$data['values'] = [];

		$placeholder = $this->model_tool_image->resize('no_image.png', 50, 50);

		foreach ($this->model_extension_nk_color_swatches_module_color_swatches->getValues($option_id) as $row) {
			$image = (string)($row['swatch_image'] ?? '');

			// Fall back to the value's own option_value.image so a merchant who
			// already uploaded one only has to press "use image".
			$suggested = (string)($row['option_image'] ?? '');

			if ($image !== '' && is_file(DIR_IMAGE . html_entity_decode($image, ENT_QUOTES, 'UTF-8'))) {
				$thumb = $this->model_tool_image->resize($image, 50, 50);
			} else {
				$thumb = $placeholder;
			}

			$type = (string)($row['swatch_type'] ?? '');

			if (!in_array($type, self::SWATCH_TYPES, true)) {
				$type = '';
			}

			$data['values'][] = [
				'option_value_id' => (int)$row['option_value_id'],
				'name'            => (string)($row['name'] ?? ''),
				'type'            => $type,
				'color'           => (string)($row['swatch_color'] ?? ''),
				'image'           => $image,
				'suggested'       => $suggested,
				'thumb'           => $thumb
			];
		}

		$data['placeholder'] = $placeholder;

		$data['save'] = $this->url->link(self::ROUTE . '.values_save', 'user_token=' . $this->session->data['user_token'] . '&option_id=' . $option_id);

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_color_swatches/module/color_swatches_values', $data);
	}

	/**
	 * Persist the map for one option.
	 *
	 * Nothing from the POST is trusted: the option_value_id keys are filtered
	 * against the values that actually belong to the option in the URL, and the
	 * colour and image are normalised before they go anywhere near the database.
	 *
	 * @return void
	 */
	public function values_save(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$option_id = isset($this->request->get['option_id']) ? (int)$this->request->get['option_id'] : 0;

		if ($option_id < 1) {
			$json['error']['warning'] = $this->language->get('error_option');
		}

		$posted = (isset($this->request->post['swatch']) && is_array($this->request->post['swatch'])) ? $this->request->post['swatch'] : [];

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_color_swatches/module/color_swatches');

			$allowed = $this->model_extension_nk_color_swatches_module_color_swatches->getValueIds($option_id);

			$writes = [];
			$deletes = [];

			foreach ($posted as $option_value_id => $row) {
				$option_value_id = (int)$option_value_id;

				if (!isset($allowed[$option_value_id]) || !is_array($row)) {
					continue;
				}

				$type = self::normalizeType(isset($row['type']) ? (string)$row['type'] : '');
				$color = self::normalizeColor(isset($row['color']) ? (string)$row['color'] : '');
				$image = self::normalizeImage(isset($row['image']) ? (string)$row['image'] : '');

				if ($type === 'color' && $color === '') {
					$json['error']['color_' . $option_value_id] = $this->language->get('error_color');

					continue;
				}

				if ($type === 'image' && $image === '') {
					$json['error']['image_' . $option_value_id] = $this->language->get('error_image');

					continue;
				}

				if ($type === '') {
					$deletes[] = $option_value_id;

					continue;
				}

				$writes[] = [
					'option_value_id' => $option_value_id,
					'type'            => $type,
					// Only the field the chosen type uses is kept, so a stale
					// value can never resurface if the type is switched back.
					'color'           => $type === 'color' ? $color : '',
					'image'           => $type === 'image' ? $image : ''
				];
			}

			if (!isset($json['error'])) {
				foreach ($deletes as $option_value_id) {
					$this->model_extension_nk_color_swatches_module_color_swatches->deleteSwatch($option_value_id);
				}

				foreach ($writes as $write) {
					$this->model_extension_nk_color_swatches_module_color_swatches->editSwatch($write['option_value_id'], $write['type'], $write['color'], $write['image']);
				}

				$this->model_extension_nk_color_swatches_module_color_swatches->purgeOrphans();

				$json['success'] = $this->language->get('text_map_success');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * '' means "no swatch, leave this value alone".
	 *
	 * @param string $type
	 *
	 * @return string
	 */
	public static function normalizeType(string $type): string {
		$type = strtolower(trim($type));

		return in_array($type, self::SWATCH_TYPES, true) ? $type : '';
	}

	/**
	 * A swatch colour is written straight into a style attribute, so only a
	 * literal hex triplet survives. `#abc` is expanded so the stored value is
	 * always directly comparable.
	 *
	 * @param string $color
	 *
	 * @return string '' when the input is not a hex colour
	 */
	public static function normalizeColor(string $color): string {
		$color = trim($color);

		if ($color === '') {
			return '';
		}

		if ($color[0] !== '#') {
			$color = '#' . $color;
		}

		if (preg_match('/^#([0-9A-Fa-f]{3})$/', $color, $match)) {
			$short = $match[1];

			$color = '#' . $short[0] . $short[0] . $short[1] . $short[1] . $short[2] . $short[2];
		}

		if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $color)) {
			return '';
		}

		return '#' . strtolower(substr($color, 1));
	}

	/**
	 * Image paths are relative to DIR_IMAGE and must stay there.
	 *
	 * @param string        $image
	 * @param callable|null $exists is_file() replacement, for the test harness
	 *
	 * @return string '' when the path is unusable
	 */
	public static function normalizeImage(string $image, ?callable $exists = null): string {
		$image = trim($image);

		if ($image === '') {
			return '';
		}

		// Reject before decoding *and* after, so neither "%2e%2e/" nor a raw
		// "../" nor a NUL truncation gets through.
		$decoded = html_entity_decode(rawurldecode($image), ENT_QUOTES, 'UTF-8');

		foreach ([$image, $decoded] as $candidate) {
			if (str_contains($candidate, "\0") || str_contains($candidate, '..') || str_contains($candidate, '\\')) {
				return '';
			}

			if ($candidate === '' || $candidate[0] === '/' || preg_match('/^[A-Za-z][A-Za-z0-9+.-]*:/', $candidate)) {
				return '';
			}
		}

		if (oc_strlen($image) > 255) {
			return '';
		}

		if ($exists === null) {
			$exists = static function (string $path): bool {
				return is_file(DIR_IMAGE . $path);
			};
		}

		return $exists($decoded) ? $image : '';
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/nk_color_swatches/module/color_swatches');

		$this->model_extension_nk_color_swatches_module_color_swatches->createTable();

		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting(self::PREFIX, $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}

		$this->load->model('user/user_group');

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', self::ROUTE);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', self::ROUTE);
	}

	/**
	 * The swatch map is merchant data - hours of colour picking - so the table
	 * survives an uninstall/reinstall cycle. Only the events and the
	 * presentation settings go.
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting(self::PREFIX);
	}
}
