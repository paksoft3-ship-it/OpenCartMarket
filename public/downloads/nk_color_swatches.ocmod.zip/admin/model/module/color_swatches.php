<?php
namespace Opencart\Admin\Model\Extension\NkColorSwatches\Module;

/**
 * NovaKur Color Swatches - admin model.
 *
 * Owns `<prefix>nk_option_swatch`, the option value -> swatch mapping.
 *
 * Why a table and not a serialised setting:
 *   OpenCart loads every row of `setting` for the active store on *every*
 *   request (Config is built in framework.php before routing), so a serialised
 *   map would be unserialised on the home page, the checkout and every AJAX
 *   call whether or not a product option is in sight. A catalogue with a few
 *   hundred colour values would drag that blob through every request. A table
 *   keyed on `option_value_id` is read once per product page, by primary key,
 *   through a join that is already touching `product_option_value` - and it can
 *   be indexed, paged and edited one row at a time.
 *
 * The swatch map is intentionally store-independent: `option_value` itself is
 * global in OpenCart, so "Red is #d32f2f" is a fact about the value, not about
 * a storefront. Presentation (shape, size, card strip) is per store and lives
 * in `setting`.
 */
class ColorSwatches extends \Opencart\System\Engine\Model {
	/**
	 * Option types whose rendered control can be turned into swatches.
	 *
	 * @var array<int, string>
	 */
	public const OPTION_TYPES = ['select', 'radio'];

	/**
	 * @return void
	 */
	public function createTable(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_option_swatch` (
			`option_value_id` int(11) NOT NULL,
			`type` varchar(8) NOT NULL DEFAULT 'color',
			`color` varchar(9) NOT NULL DEFAULT '',
			`image` varchar(255) NOT NULL DEFAULT '',
			`date_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`option_value_id`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * Options that can carry swatches, with their translated name.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getOptions(): array {
		$types = [];

		foreach (self::OPTION_TYPES as $type) {
			$types[] = "'" . $this->db->escape($type) . "'";
		}

		$query = $this->db->query("SELECT `o`.`option_id`, `o`.`type`, `od`.`name` FROM `" . DB_PREFIX . "option` `o` LEFT JOIN `" . DB_PREFIX . "option_description` `od` ON (`o`.`option_id` = `od`.`option_id`) WHERE `od`.`language_id` = '" . (int)$this->config->get('config_language_id') . "' AND `o`.`type` IN (" . implode(',', $types) . ") ORDER BY `od`.`name` ASC");

		return $query->rows;
	}

	/**
	 * Every value of one option, with the swatch mapped to it (if any).
	 *
	 * @param int $option_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getValues(int $option_id): array {
		$query = $this->db->query("SELECT `ov`.`option_value_id`, `ov`.`image` AS `option_image`, `ovd`.`name`, `s`.`type` AS `swatch_type`, `s`.`color` AS `swatch_color`, `s`.`image` AS `swatch_image` FROM `" . DB_PREFIX . "option_value` `ov` LEFT JOIN `" . DB_PREFIX . "option_value_description` `ovd` ON (`ov`.`option_value_id` = `ovd`.`option_value_id` AND `ovd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "') LEFT JOIN `" . DB_PREFIX . "nk_option_swatch` `s` ON (`s`.`option_value_id` = `ov`.`option_value_id`) WHERE `ov`.`option_id` = '" . (int)$option_id . "' ORDER BY `ov`.`sort_order` ASC, `ovd`.`name` ASC");

		return $query->rows;
	}

	/**
	 * The option_value_id set that legitimately belongs to one option.
	 *
	 * save() posts a map keyed by option_value_id; anything outside this set is
	 * discarded rather than trusted.
	 *
	 * @param int $option_id
	 *
	 * @return array<int, bool> option_value_id => true
	 */
	public function getValueIds(int $option_id): array {
		$query = $this->db->query("SELECT `option_value_id` FROM `" . DB_PREFIX . "option_value` WHERE `option_id` = '" . (int)$option_id . "'");

		$ids = [];

		foreach ($query->rows as $row) {
			$ids[(int)$row['option_value_id']] = true;
		}

		return $ids;
	}

	/**
	 * @param int $option_value_id
	 *
	 * @return array<string, mixed>
	 */
	public function getSwatch(int $option_value_id): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_option_swatch` WHERE `option_value_id` = '" . (int)$option_value_id . "'");

		return $query->row;
	}

	/**
	 * Upsert one mapping.
	 *
	 * @param int    $option_value_id
	 * @param string $type            'color' or 'image'
	 * @param string $color
	 * @param string $image
	 *
	 * @return void
	 */
	public function editSwatch(int $option_value_id, string $type, string $color, string $image): void {
		$this->db->query("REPLACE INTO `" . DB_PREFIX . "nk_option_swatch` SET `option_value_id` = '" . (int)$option_value_id . "', `type` = '" . $this->db->escape($type) . "', `color` = '" . $this->db->escape($color) . "', `image` = '" . $this->db->escape($image) . "', `date_modified` = NOW()");
	}

	/**
	 * @param int $option_value_id
	 *
	 * @return void
	 */
	public function deleteSwatch(int $option_value_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_option_swatch` WHERE `option_value_id` = '" . (int)$option_value_id . "'");
	}

	/**
	 * @return int
	 */
	public function getTotalSwatches(): int {
		$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_option_swatch`");

		return (int)($query->row['total'] ?? 0);
	}

	/**
	 * Drop mappings whose option value has since been deleted.
	 *
	 * OpenCart deletes `option_value` rows without telling anyone, so the map
	 * is swept whenever the mapping screen is saved.
	 *
	 * @return void
	 */
	public function purgeOrphans(): void {
		$this->db->query("DELETE `s` FROM `" . DB_PREFIX . "nk_option_swatch` `s` LEFT JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `s`.`option_value_id`) WHERE `ov`.`option_value_id` IS NULL");
	}
}
