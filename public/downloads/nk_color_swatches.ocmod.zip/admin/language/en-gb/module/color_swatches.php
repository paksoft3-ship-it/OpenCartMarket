<?php
// Heading
$_['heading_title']         = 'NovaKur Color Swatches';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified NovaKur Color Swatches settings!';
$_['text_map_success']      = 'Success: You have modified the swatch map for this option!';
$_['text_edit']             = 'Edit NovaKur Color Swatches';
$_['text_mapping']          = 'Swatch Map';
$_['text_mapped']           = 'Option values mapped so far:';
$_['text_no_options']       = 'No select or radio options exist yet. Create one under Catalog &raquo; Options first, then come back to give its values a colour.';
$_['text_no_values']        = 'This option has no values yet.';
$_['text_type_color']       = 'Colour';
$_['text_type_image']       = 'Image';
$_['text_use_option_image'] = 'This value already has an option image you can pick from the image manager.';
$_['text_shape_circle']     = 'Circle';
$_['text_shape_rounded']    = 'Rounded square';
$_['text_shape_square']     = 'Square';
$_['text_oos_strike']       = 'Show struck through';
$_['text_oos_dim']          = 'Show dimmed';
$_['text_oos_hide']         = 'Hide completely';

// Entry
$_['entry_status']          = 'Status';
$_['entry_shape']           = 'Swatch Shape';
$_['entry_size']            = 'Swatch Size';
$_['entry_hide_native']     = 'Hide Original Control';
$_['entry_show_label']      = 'Show Value Name';
$_['entry_oos_mode']        = 'Out Of Stock Values';
$_['entry_thumb_status']    = 'Swatches On Product Cards';
$_['entry_thumb_limit']     = 'Card Swatch Limit';
$_['entry_option']          = 'Option';

// Column
$_['column_value']          = 'Option Value';
$_['column_type']           = 'Swatch';
$_['column_color']          = 'Colour';
$_['column_image']          = 'Image';

// Help
$_['help_status']           = 'Turns mapped select and radio options into visual swatches on the product page.';
$_['help_size']             = 'Edge length of one swatch in pixels, between 20 and 80.';
$_['help_hide_native']      = 'Hides the original dropdown or radio list. It stays in the form and keeps being submitted &mdash; only its pixels go away. Turn this off to show both.';
$_['help_show_label']       = 'Prints the value name underneath each swatch as well as in its tooltip.';
$_['help_oos_mode']         = 'How a value whose stock has run out is drawn. OpenCart normally drops it from the page entirely; showing it struck through tells the shopper the colour exists and is simply gone right now.';
$_['help_thumb_status']     = 'Adds a small, display-only strip of swatches to product cards in category, search and module listings. The strip is not clickable &mdash; it only advertises the colours.';
$_['help_thumb_limit']      = 'Maximum number of swatches on one product card, between 1 and 12. A "+n" counter is shown when there are more.';
$_['help_mapping']          = 'Map an option value to a colour or an image once and every product using that value gets the swatch. Values left on "None" keep the stock OpenCart control.';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify NovaKur Color Swatches!';
$_['error_shape']           = 'Please choose one of the listed shapes!';
$_['error_size']            = 'Swatch size must be a whole number between 20 and 80!';
$_['error_oos_mode']        = 'Please choose one of the listed out of stock styles!';
$_['error_thumb_limit']     = 'Card swatch limit must be a whole number between 1 and 12!';
$_['error_option']          = 'Warning: That option does not exist!';
$_['error_color']           = 'Enter a hex colour such as #d32f2f.';
$_['error_image']           = 'Choose an image from the image manager.';
