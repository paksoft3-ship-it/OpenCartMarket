<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeMarketplace\Event;

class NkMarketplace extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isMarketplaceThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/common/header_marketplace.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_marketplace/catalog/view/assets/dist/css/nk-marketplace.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_marketplace/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_marketplace_primary_color') ?: '#2563eb';
                $data['novakur_accent_color']    = '#f59e0b';
                $data['novakur_header_color']    = '#111827';
                $data['novakur_container_width'] = 1360;
                $data['novakur_base_font']       = 'Inter';
                $data['novakur_heading_font']    = 'Inter';
                $data['cart_quantity']           = $this->cart->countProducts();
                $this->injectToggles($data);

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'category_id' => (int)$cat['category_id'],
                        'name'        => $cat['name'],
                        'href'        => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image'       => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/nk_theme_marketplace/common/header_marketplace';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/common/footer_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/common/footer_marketplace';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/common/home_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/common/home_marketplace';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $this->injectToggles($data);

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 300);

            // Category boxes with sub-links (4-up grid)
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['category_boxes'] = [];
            foreach ($cats_raw as $cat) {
                $children = [];
                $children_raw = array_slice($this->model_catalog_category->getCategories((int)$cat['category_id']), 0, 4);
                foreach ($children_raw as $child) {
                    $children[] = [
                        'name' => $child['name'],
                        'href' => $this->url->link('product/category', 'path=' . $cat['category_id'] . '_' . $child['category_id']),
                    ];
                }
                $data['category_boxes'][] = [
                    'name'     => $cat['name'],
                    'href'     => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image'    => $cat['image'] ?? '',
                    'children' => $children,
                ];
            }

            // Deals band: bestsellers / specials for the carousel
            $deals_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 12,
            ]);
            $data['deals'] = $this->buildProductArray($deals_raw, $img_w, $img_h, $currency);

            // Wide recommendation grid
            $latest_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 18,
            ]);
            $data['latest'] = $this->buildProductArray($latest_raw, $img_w, $img_h, $currency);

            // Bestsellers strip
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'p.viewed',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 12,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/product/category_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/product/category_marketplace';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $this->injectToggles($data);

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'category_id' => (int)$cat['category_id'],
                    'name'        => $cat['name'],
                    'href'        => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image'       => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers / Deals ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/product/special_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/product/special_marketplace';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $this->injectToggles($data);

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'category_id' => (int)$cat['category_id'],
                    'name'        => $cat['name'],
                    'href'        => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image'       => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/product/product_marketplace.twig';
            if (is_file($template)) {
                $this->injectToggles($data);
                $route = 'extension/nk_theme_marketplace/product/product_marketplace';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/checkout/cart_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/checkout/cart_marketplace';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/checkout/checkout_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/checkout/checkout_marketplace';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/product/search_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/product/search_marketplace';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $this->injectToggles($data);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'category_id' => (int)$cat['category_id'],
                    'name'        => $cat['name'],
                    'href'        => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image'       => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/account/login_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/account/login_marketplace';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/account/register_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/account/register_marketplace';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/account/account_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/account/account_marketplace';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/account/order_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/account/order_marketplace';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/account/wishlist_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/account/wishlist_marketplace';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');
            $this->injectToggles($data);

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_marketplace/catalog/view/template/error/not_found_marketplace.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_marketplace/error/not_found_marketplace';
            }
        }
    }

    private function injectToggles(array &$data): void {
        $data['nk_show_vendor_strip'] = (string)((int)($this->config->get('theme_nk_marketplace_show_vendor_strip') ?? 1));
        $data['nk_show_deals']        = (string)((int)($this->config->get('theme_nk_marketplace_show_deals') ?? 1));
        $data['nk_dense_grid']        = (string)((int)($this->config->get('theme_nk_marketplace_dense_grid') ?? 1));
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );

            $special_raw = $p['special'] ?? false;
            $discount = 0;
            if ($special_raw && (float)($p['price'] ?? 0) > 0) {
                $discount = (int)round(100 - ((float)$special_raw / (float)$p['price']) * 100);
            }

            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => $special_raw
                    ? $this->currency->format(
                        $this->tax->calculate($special_raw, $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'discount'     => $discount,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isMarketplaceThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_marketplace', 'novakur_marketplace'], true)
            && (bool)$this->config->get('theme_nk_marketplace_status');
    }
}
