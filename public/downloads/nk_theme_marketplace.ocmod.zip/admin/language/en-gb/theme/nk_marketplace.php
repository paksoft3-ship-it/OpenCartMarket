<?php
$_['heading_title'] = 'NovaKur Marketplace Theme';
$_['text_edit'] = 'Marketplace theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Marketplace theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_vendor_strip'] = 'Show Vendor Strip';
$_['entry_show_deals'] = 'Show Deals Carousel';
$_['entry_dense_grid'] = 'Dense Product Grid';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
