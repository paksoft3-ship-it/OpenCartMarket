<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

/**
 * NovaKur Size Guide
 *
 * Settings namespace: module_size_guide_*
 * Route:              extension/novakur/module/size_guide
 *
 * Charts are stored as a serialized `module_size_guide_charts` setting rather
 * than a bespoke table, so install/uninstall stays a single deleteSetting() and
 * there is no schema to migrate between OpenCart point releases.
 */
class SizeGuide extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/novakur/module/size_guide';
    private string $prefix = 'module_size_guide';

    private const MAX_CHARTS = 20;
    private const MAX_ROWS = 30;

    /**
     * @return array<string, mixed>
     */
    private function defaults(): array {
        return [
            'module_size_guide_status'          => '0',
            'module_size_guide_button_text'     => '',
            'module_size_guide_unit'            => 'cm',
            'module_size_guide_allow_unit_swap' => '1',
            'module_size_guide_show_calculator' => '1',
            'module_size_guide_charts'          => []
        ];
    }

    /**
     * @return array<int, string>
     */
    private function units(): array {
        return ['cm', 'inch'];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        foreach (['status', 'allow_unit_swap', 'show_calculator'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        $unit = trim((string)($post[$this->prefix . '_unit'] ?? 'cm'));

        if (!in_array($unit, $this->units(), true)) {
            $json['error'][$this->prefix . '_unit'] = $this->language->get('error_unit');
        } else {
            $save[$this->prefix . '_unit'] = $unit;
        }

        $button_text = $this->sanitizeText((string)($post[$this->prefix . '_button_text'] ?? ''), 40);

        $save[$this->prefix . '_button_text'] = $button_text;

        // --- Charts ----------------------------------------------------------
        $charts = [];
        $posted = $post[$this->prefix . '_charts'] ?? [];

        if (is_array($posted)) {
            foreach ($posted as $index => $chart) {
                if (!is_array($chart) || count($charts) >= self::MAX_CHARTS) {
                    continue;
                }

                $title = $this->sanitizeText((string)($chart['title'] ?? ''), 60);
                $rows = $this->parseRows((string)($chart['rows'] ?? ''));

                // A chart with no measurements is noise; drop it silently so a
                // merchant can clear a block by emptying it.
                if ($title === '' && !$rows) {
                    continue;
                }

                if ($title === '') {
                    $json['error'][$this->prefix . '_charts_' . (int)$index . '_title'] = $this->language->get('error_chart_title');

                    continue;
                }

                if (!$rows) {
                    $json['error'][$this->prefix . '_charts_' . (int)$index . '_rows'] = $this->language->get('error_chart_rows');

                    continue;
                }

                $charts[] = [
                    'title'       => $title,
                    'category_id' => (int)($chart['category_id'] ?? 0),
                    'rows'        => $rows
                ];
            }
        }

        $save[$this->prefix . '_charts'] = $charts;

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    /**
     * @return array<string, mixed>
     */
    private function buildFormData(): array {
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_charts',
            'text_no_charts',
            'text_all_categories',
            'text_cm',
            'text_inch',
            'entry_status',
            'entry_button_text',
            'entry_unit',
            'entry_allow_unit_swap',
            'entry_show_calculator',
            'entry_chart_title',
            'entry_chart_category',
            'entry_chart_rows',
            'help_layout',
            'help_button_text',
            'help_unit',
            'help_allow_unit_swap',
            'help_show_calculator',
            'help_chart_category',
            'help_chart_rows',
            'button_save',
            'button_back',
            'button_chart_add',
            'button_remove'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if ($key === $this->prefix . '_charts') {
                continue;
            }

            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        // Admin\Model\Catalog\Category::getCategories() takes an ARRAY of filters
        // (the catalog-side model of the same name takes an int parent id).
        $this->load->model('catalog/category');

        $data['categories'] = [];

        foreach ($this->model_catalog_category->getCategories() as $category) {
            $data['categories'][] = [
                'category_id' => (int)$category['category_id'],
                'name'        => (string)$category['name']
            ];
        }

        // Prefer unsaved POST data so a validation error does not lose input.
        $charts = $this->request->post[$this->prefix . '_charts'] ?? ($settings[$this->prefix . '_charts'] ?? []);

        if (!is_array($charts)) {
            $charts = [];
        }

        $data['charts'] = [];

        foreach ($charts as $chart) {
            if (!is_array($chart)) {
                continue;
            }

            $data['charts'][] = [
                'title'       => (string)($chart['title'] ?? ''),
                'category_id' => (int)($chart['category_id'] ?? 0),
                // Round-trip the stored rows back into the textarea format.
                'rows'        => is_array($chart['rows'] ?? null) ? $this->formatRows($chart['rows']) : (string)($chart['rows'] ?? '')
            ];
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }

    /**
     * Parses the textarea format — one row per line, "Size, Chest, Waist, Hips",
     * comma, semicolon or tab separated. Measurements are optional.
     *
     * @return array<int, array<string, mixed>>
     */
    private function parseRows(string $input): array {
        $rows = [];

        foreach (preg_split('/\R/u', $input) ?: [] as $line) {
            if (count($rows) >= self::MAX_ROWS) {
                break;
            }

            $line = trim($line);

            if ($line === '') {
                continue;
            }

            $parts = preg_split('/\s*[,;\t]\s*/u', $line) ?: [];

            $size = $this->sanitizeText((string)($parts[0] ?? ''), 20);

            if ($size === '') {
                continue;
            }

            $rows[] = [
                'size'  => $size,
                'chest' => $this->sanitizeNumber((string)($parts[1] ?? '')),
                'waist' => $this->sanitizeNumber((string)($parts[2] ?? '')),
                'hips'  => $this->sanitizeNumber((string)($parts[3] ?? ''))
            ];
        }

        return $rows;
    }

    /**
     * @param array<int, mixed> $rows
     */
    private function formatRows(array $rows): string {
        $lines = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $lines[] = implode(', ', [
                (string)($row['size'] ?? ''),
                (string)($row['chest'] ?? ''),
                (string)($row['waist'] ?? ''),
                (string)($row['hips'] ?? '')
            ]);
        }

        return implode("\n", $lines);
    }

    private function sanitizeText(string $text, int $length): string {
        $text = trim(strip_tags($text));
        $text = preg_replace('/\s+/u', ' ', $text) ?? '';

        return oc_substr($text, 0, $length);
    }

    /**
     * Measurements are rendered into a table and fed to a JS calculator, so only
     * a plain positive decimal is ever stored. Anything else becomes ''.
     */
    private function sanitizeNumber(string $value): string {
        $value = str_replace(',', '.', trim($value));

        if ($value === '' || !preg_match('/^\d{1,3}(\.\d{1,2})?$/', $value)) {
            return '';
        }

        return (string)(float)$value;
    }
}
