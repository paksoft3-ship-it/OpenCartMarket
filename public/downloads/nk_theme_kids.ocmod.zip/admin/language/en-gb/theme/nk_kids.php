<?php
$_['heading_title'] = 'NovaKur Kids & Toys Theme';
$_['text_edit'] = 'Kids & toys theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Kids & Toys theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_age_filter'] = 'Show Age Filter Pills';
$_['entry_show_gift_sets'] = 'Show Gift Sets Band';
$_['entry_show_fun_badges'] = 'Show Fun Badges';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
