<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeKids\Event;

class NkKids extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isKidsThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/common/header_kids.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_kids/catalog/view/assets/dist/css/nk-kids.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_kids/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_kids_primary_color') ?: '#ff6b6b';
                $data['novakur_secondary_color'] = '#ffd93d';
                $data['novakur_accent_color']    = '#4ecdc4';
                $data['novakur_container_width'] = 1200;
                $data['novakur_base_font']       = 'Nunito';
                $data['novakur_heading_font']    = 'Baloo 2';
                $data['cart_quantity']           = $this->cart->countProducts();
                $data['nk_show_age_filter']      = (int)$this->config->get('theme_nk_kids_show_age_filter');
                $data['nk_show_gift_sets']       = (int)$this->config->get('theme_nk_kids_show_gift_sets');
                $data['nk_show_fun_badges']      = (int)$this->config->get('theme_nk_kids_show_fun_badges');

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/nk_theme_kids/common/header_kids';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/common/footer_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/common/footer_kids';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/common/home_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/common/home_kids';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            $data['nk_show_age_filter'] = (int)$this->config->get('theme_nk_kids_show_age_filter');
            $data['nk_show_gift_sets']  = (int)$this->config->get('theme_nk_kids_show_gift_sets');
            $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');

            // Categories with images (colorful chips)
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            // Latest / new arrivals
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest']   = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['featured'] = $data['latest'];

            // Bestsellers — power the gift sets merchandising band
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/product/category_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/product/category_kids';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $data['nk_show_age_filter'] = (int)$this->config->get('theme_nk_kids_show_age_filter');
            $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/product/special_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/product/special_kids';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/product/product_kids.twig';
            if (is_file($template)) {
                $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');
                $route = 'extension/nk_theme_kids/product/product_kids';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/checkout/cart_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/checkout/cart_kids';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/checkout/checkout_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/checkout/checkout_kids';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/product/search_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/product/search_kids';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $data['nk_show_age_filter'] = (int)$this->config->get('theme_nk_kids_show_age_filter');
            $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/account/login_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/account/login_kids';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/account/register_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/account/register_kids';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/account/account_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/account/account_kids';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/account/order_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/account/order_kids';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/account/wishlist_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/account/wishlist_kids';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            $data['nk_show_fun_badges'] = (int)$this->config->get('theme_nk_kids_show_fun_badges');

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_kids/catalog/view/template/error/not_found_kids.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_kids/error/not_found_kids';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isKidsThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_kids', 'novakur_kids'], true)
            && (bool)$this->config->get('theme_nk_kids_status');
    }
}
