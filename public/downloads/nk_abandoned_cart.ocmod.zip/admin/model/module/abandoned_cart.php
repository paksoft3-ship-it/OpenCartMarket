<?php
namespace Opencart\Admin\Model\Extension\NkAbandonedCart\Module;

/**
 * NovaKur Abandoned Cart Recovery - admin model.
 */
class AbandonedCart extends \Opencart\System\Engine\Model {
	/**
	 * Create the snapshot table.
	 *
	 * @return void
	 */
	public function createTable(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_abandoned_cart` (
			`abandoned_cart_id` int(11) NOT NULL AUTO_INCREMENT,
			`store_id` int(11) NOT NULL DEFAULT '0',
			`customer_id` int(11) NOT NULL DEFAULT '0',
			`email` varchar(96) NOT NULL DEFAULT '',
			`name` varchar(96) NOT NULL DEFAULT '',
			`session_id` varchar(64) NOT NULL DEFAULT '',
			`language_id` int(11) NOT NULL DEFAULT '0',
			`currency_code` varchar(3) NOT NULL DEFAULT '',
			`cart_data` mediumtext NOT NULL,
			`product_count` int(11) NOT NULL DEFAULT '0',
			`total` decimal(15,4) NOT NULL DEFAULT '0.0000',
			`token` varchar(64) NOT NULL DEFAULT '',
			`last_emailed_stage` tinyint(1) NOT NULL DEFAULT '0',
			`date_last_emailed` datetime DEFAULT NULL,
			`recovered` tinyint(1) NOT NULL DEFAULT '0',
			`order_id` int(11) NOT NULL DEFAULT '0',
			`recovered_total` decimal(15,4) NOT NULL DEFAULT '0.0000',
			`date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`date_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`abandoned_cart_id`),
			UNIQUE KEY `token` (`token`),
			KEY `email` (`email`),
			KEY `customer_id` (`customer_id`),
			KEY `pending` (`store_id`,`recovered`,`last_emailed_stage`,`date_modified`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * @return void
	 */
	public function dropTable(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "nk_abandoned_cart`");
	}

	/**
	 * Build the shared WHERE clause for the dashboard list.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return string
	 */
	private function buildWhere(array $data): string {
		$where = "WHERE `store_id` = '" . (int)($data['filter_store_id'] ?? 0) . "'";

		if (isset($data['filter_status']) && $data['filter_status'] !== '') {
			$status = (string)$data['filter_status'];

			if ($status === 'recovered') {
				$where .= " AND `recovered` = '1'";
			} elseif ($status === 'pending') {
				$where .= " AND `recovered` = '0'";
			} elseif ($status === 'closed') {
				$where .= " AND `recovered` = '2'";
			}
		}

		if (!empty($data['filter_email'])) {
			$where .= " AND `email` LIKE '" . $this->db->escape((string)$data['filter_email'] . '%') . "'";
		}

		return $where;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getCarts(array $data = []): array {
		$sql = "SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` " . $this->buildWhere($data);

		$sort_data = ['email', 'total', 'product_count', 'last_emailed_stage', 'recovered', 'date_added', 'date_modified'];

		if (isset($data['sort']) && in_array($data['sort'], $sort_data, true)) {
			$sql .= " ORDER BY `" . $data['sort'] . "`";
		} else {
			$sql .= " ORDER BY `date_modified`";
		}

		if (isset($data['order']) && strtoupper((string)$data['order']) === 'ASC') {
			$sql .= " ASC";
		} else {
			$sql .= " DESC";
		}

		$start = isset($data['start']) ? (int)$data['start'] : 0;
		$limit = isset($data['limit']) ? (int)$data['limit'] : 10;

		if ($start < 0) {
			$start = 0;
		}

		if ($limit < 1) {
			$limit = 10;
		}

		$sql .= " LIMIT " . (int)$start . "," . (int)$limit;

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function getTotalCarts(array $data = []): int {
		$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_abandoned_cart` " . $this->buildWhere($data));

		return (int)$query->row['total'];
	}

	/**
	 * Headline numbers for the dashboard tab.
	 *
	 * @param int $store_id
	 *
	 * @return array<string, float|int>
	 */
	public function getSummary(int $store_id): array {
		$query = $this->db->query("SELECT
			SUM(CASE WHEN `recovered` = 0 THEN 1 ELSE 0 END) AS `pending_total`,
			SUM(CASE WHEN `recovered` = 0 THEN `total` ELSE 0 END) AS `pending_value`,
			SUM(CASE WHEN `recovered` = 1 THEN 1 ELSE 0 END) AS `recovered_total`,
			SUM(CASE WHEN `recovered` = 1 THEN `recovered_total` ELSE 0 END) AS `recovered_value`,
			SUM(CASE WHEN `last_emailed_stage` > 0 THEN 1 ELSE 0 END) AS `emailed_total`,
			COUNT(*) AS `all_total`
			FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "'");

		$row = $query->row;

		$emailed = (int)($row['emailed_total'] ?? 0);
		$recovered = (int)($row['recovered_total'] ?? 0);

		return [
			'pending_total'   => (int)($row['pending_total'] ?? 0),
			'pending_value'   => (float)($row['pending_value'] ?? 0),
			'recovered_total' => $recovered,
			'recovered_value' => (float)($row['recovered_value'] ?? 0),
			'emailed_total'   => $emailed,
			'all_total'       => (int)($row['all_total'] ?? 0),
			'recovery_rate'   => $emailed > 0 ? round(($recovered / $emailed) * 100, 1) : 0
		];
	}

	/**
	 * @param int $abandoned_cart_id
	 *
	 * @return void
	 */
	public function deleteCart(int $abandoned_cart_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `abandoned_cart_id` = '" . (int)$abandoned_cart_id . "'");
	}
}
