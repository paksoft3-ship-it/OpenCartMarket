<?php
namespace Opencart\Catalog\Controller\Extension\NkAbandonedCart\Event;

/**
 * NovaKur Abandoned Cart Recovery - storefront event hooks.
 *
 * Registered by the admin controller's install():
 *   catalog/view/common/footer/after            -> footer()    inject guest capture JS + snapshot
 *   catalog/controller/common/cart.info/before  -> snapshot()  fires right after add-to-cart
 *   catalog/controller/checkout/checkout/before -> snapshot()
 *   catalog/controller/checkout/success/before  -> recovered()
 */
class AbandonedCart extends \Opencart\System\Engine\Controller {
	/**
	 * Snapshot hook for controller events.
	 *
	 * Controller `/before` events pass 2 args, `/after` events pass 3, so the third is optional.
	 *
	 * @param string            $route
	 * @param array<int, mixed> $args
	 * @param mixed             $output
	 *
	 * @return void
	 */
	public function snapshot(string &$route, array &$args, &$output = null): void {
		$this->capture();
	}

	/**
	 * Footer view hook: snapshot the cart and inject the guest e-mail capture script.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function footer(string &$route, array &$data, &$output): void {
		if (!(int)$this->config->get('module_abandoned_cart_status')) {
			return;
		}

		$this->capture();

		if (!is_string($output)) {
			return;
		}

		// Guests only - logged in shoppers already have an e-mail on file.
		if (!(int)$this->config->get('module_abandoned_cart_capture_guests') || $this->customer->isLogged()) {
			return;
		}

		$config = [
			'url'   => $this->url->link('extension/nk_abandoned_cart/module/abandoned_cart.capture', 'language=' . $this->config->get('config_language'), true),
			'saved' => isset($this->session->data['nk_abandoned_cart_email']) ? (string)$this->session->data['nk_abandoned_cart_email'] : ''
		];

		$html = '<script type="text/javascript">var nk_abandoned_cart = ' . json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>' . "\n";
		$html .= '<script src="extension/nk_abandoned_cart/catalog/view/assets/js/abandoned_cart.js" type="text/javascript"></script>' . "\n";

		if (str_contains($output, '</body>')) {
			$output = str_replace('</body>', $html . '</body>', $output);
		} else {
			$output .= $html;
		}
	}

	/**
	 * Order placed: close the snapshot and record the recovered value.
	 *
	 * @param string            $route
	 * @param array<int, mixed> $args
	 * @param mixed             $output
	 *
	 * @return void
	 */
	public function recovered(string &$route, array &$args, &$output = null): void {
		if (!(int)$this->config->get('module_abandoned_cart_status')) {
			return;
		}

		if (empty($this->session->data['order_id'])) {
			return;
		}

		$order_id = (int)$this->session->data['order_id'];
		$store_id = (int)$this->config->get('config_store_id');

		$this->load->model('extension/nk_abandoned_cart/module/abandoned_cart');

		// Order total in the store's default currency.
		$order_query = $this->db->query("SELECT `total`, `email` FROM `" . DB_PREFIX . "order` WHERE `order_id` = '" . (int)$order_id . "' LIMIT 1");

		if (!$order_query->num_rows) {
			return;
		}

		$total = (float)$order_query->row['total'];
		$email = (string)$order_query->row['email'];

		$abandoned_cart_id = 0;

		if (!empty($this->session->data['nk_abandoned_cart_id'])) {
			$abandoned_cart_id = (int)$this->session->data['nk_abandoned_cart_id'];

			// Recovered through a recovery link.
			$this->model_extension_nk_abandoned_cart_module_abandoned_cart->markRecovered($abandoned_cart_id, $order_id, $total, 1);
		}

		// Stop the series for anything else still pending for this shopper.
		$this->model_extension_nk_abandoned_cart_module_abandoned_cart->closeOtherPending($store_id, (int)$this->customer->getId(), $email, $abandoned_cart_id, $order_id);

		unset($this->session->data['nk_abandoned_cart_id']);
		unset($this->session->data['nk_abandoned_cart_email']);
	}

	/**
	 * Write (or clear) the pending snapshot for the current shopper.
	 *
	 * Kept public so the storefront capture endpoint can reuse it through
	 * $this->load->controller('extension/nk_abandoned_cart/event/abandoned_cart.capture').
	 *
	 * @return void
	 */
	public function capture(): void {
		if (!(int)$this->config->get('module_abandoned_cart_status')) {
			return;
		}

		// Never snapshot while the shopper is mid-way through the success page.
		if (!empty($this->session->data['order_id'])) {
			return;
		}

		$store_id = (int)$this->config->get('config_store_id');
		$customer_id = (int)$this->customer->getId();
		$session_id = (string)$this->session->getId();

		$this->load->model('extension/nk_abandoned_cart/module/abandoned_cart');

		if (!$this->cart->hasProducts()) {
			$this->model_extension_nk_abandoned_cart_module_abandoned_cart->deletePending($store_id, $customer_id, $session_id);

			return;
		}

		$email = '';
		$name = '';

		if ($customer_id) {
			$email = (string)$this->customer->getEmail();
			$name = trim((string)$this->customer->getFirstName() . ' ' . (string)$this->customer->getLastName());

			// They may have been captured as a guest earlier in the same visit; that row
			// covers the same cart, so drop it instead of mailing the series twice.
			$this->model_extension_nk_abandoned_cart_module_abandoned_cart->deleteGuestPendingByEmail($store_id, $email);

			unset($this->session->data['nk_abandoned_cart_email']);
			unset($this->session->data['nk_abandoned_cart_name']);
		} elseif (isset($this->session->data['nk_abandoned_cart_email'])) {
			$email = (string)$this->session->data['nk_abandoned_cart_email'];
			$name = isset($this->session->data['nk_abandoned_cart_name']) ? (string)$this->session->data['nk_abandoned_cart_name'] : '';
		}

		// Nothing to mail to yet - wait until an address is known.
		if ($email === '') {
			return;
		}

		$total = (float)$this->cart->getSubTotal();

		$min_total = (float)$this->config->get('module_abandoned_cart_min_total');

		if ($min_total > 0 && $total < $min_total) {
			$this->model_extension_nk_abandoned_cart_module_abandoned_cart->deletePending($store_id, $customer_id, $session_id);

			return;
		}

		$items = $this->buildItems();

		if (!$items) {
			return;
		}

		$existing = $this->model_extension_nk_abandoned_cart_module_abandoned_cart->getPending($store_id, $customer_id, $session_id);

		if ($existing) {
			$token = (string)$existing['token'];
		} else {
			$token = $this->createToken();
		}

		$product_count = 0;

		foreach ($items as $item) {
			$product_count += (int)$item['quantity'];
		}

		$this->model_extension_nk_abandoned_cart_module_abandoned_cart->saveSnapshot([
			'store_id'      => $store_id,
			'customer_id'   => $customer_id,
			'email'         => $email,
			'name'          => $name,
			'session_id'    => $session_id,
			'language_id'   => (int)$this->config->get('config_language_id'),
			'currency_code' => (string)$this->config->get('config_currency'),
			'items'         => $items,
			'product_count' => $product_count,
			'total'         => $total,
			'token'         => $token
		]);
	}

	/**
	 * Build the restorable cart snapshot.
	 *
	 * The raw `cart` rows carry exactly what Cart::add() needs (product_id, option map,
	 * subscription_plan_id, quantity); Cart::getProducts() is used only for the display
	 * fields shown inside the recovery e-mail.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function buildItems(): array {
		$display = [];

		foreach ($this->cart->getProducts() as $product) {
			$display[(int)$product['cart_id']] = $product;
		}

		$query = $this->db->query("SELECT `cart_id`, `product_id`, `subscription_plan_id`, `option`, `quantity` FROM `" . DB_PREFIX . "cart` WHERE `store_id` = '" . (int)$this->config->get('config_store_id') . "' AND `customer_id` = '" . (int)$this->customer->getId() . "' AND `session_id` = '" . $this->db->escape((string)$this->session->getId()) . "'");

		$items = [];

		foreach ($query->rows as $row) {
			$cart_id = (int)$row['cart_id'];

			if (!isset($display[$cart_id])) {
				continue;
			}

			$option = json_decode((string)$row['option'], true);

			if (!is_array($option)) {
				$option = [];
			}

			$option_text = [];

			foreach ((array)$display[$cart_id]['option'] as $value) {
				if (isset($value['name']) && isset($value['value'])) {
					$option_text[] = $value['name'] . ': ' . $value['value'];
				}
			}

			$items[] = [
				'product_id'           => (int)$row['product_id'],
				'subscription_plan_id' => (int)$row['subscription_plan_id'],
				'option'               => $option,
				'quantity'             => (int)$row['quantity'],
				'name'                 => (string)$display[$cart_id]['name'],
				'model'                => (string)$display[$cart_id]['model'],
				'image'                => (string)$display[$cart_id]['image'],
				'option_text'          => implode(', ', $option_text),
				'price'                => (float)$display[$cart_id]['price'],
				'total'                => (float)$display[$cart_id]['total']
			];
		}

		return $items;
	}

	/**
	 * @return string
	 */
	private function createToken(): string {
		if (function_exists('oc_token')) {
			return oc_token(32);
		}

		return substr(bin2hex(random_bytes(32)), 0, 32);
	}
}
