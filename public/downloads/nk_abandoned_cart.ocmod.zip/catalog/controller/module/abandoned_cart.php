<?php
namespace Opencart\Catalog\Controller\Extension\NkAbandonedCart\Module;

/**
 * NovaKur Abandoned Cart Recovery - storefront endpoints.
 *
 *   extension/nk_abandoned_cart/module/abandoned_cart.capture  POST e-mail capture for guests
 *   extension/nk_abandoned_cart/module/abandoned_cart.recover  &token=... restores a cart snapshot
 *   extension/nk_abandoned_cart/module/abandoned_cart.cron     &token=... sends the due recovery stages
 */
class AbandonedCart extends \Opencart\System\Engine\Controller {
	/**
	 * Guest e-mail capture. Called by the storefront JS when a shopper types their
	 * address into the checkout e-mail field.
	 *
	 * @return void
	 */
	public function capture(): void {
		$json = [];

		if (!(int)$this->config->get('module_abandoned_cart_status') || !(int)$this->config->get('module_abandoned_cart_capture_guests')) {
			$json['error'] = 'disabled';
		}

		$email = isset($this->request->post['email']) ? trim((string)$this->request->post['email']) : '';

		if (!isset($json['error']) && (oc_strlen($email) > 96 || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
			$json['error'] = 'email';
		}

		if (!isset($json['error'])) {
			// The name is shopper supplied and ends up in the admin list and the e-mail, so
			// strip markup and control characters before it is ever stored.
			$name = isset($this->request->post['name']) ? (string)$this->request->post['name'] : '';
			$name = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', strip_tags($name)) ?? '');

			$this->session->data['nk_abandoned_cart_email'] = $email;
			$this->session->data['nk_abandoned_cart_name'] = oc_substr($name, 0, 96);

			// Reuse the shared snapshot routine.
			$this->load->controller('extension/nk_abandoned_cart/event/abandoned_cart.capture');

			$json['success'] = 1;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Recovery link target. Restores the snapshot into the live session cart.
	 *
	 * @return void
	 */
	public function recover(): void {
		$this->load->language('extension/nk_abandoned_cart/module/abandoned_cart');

		$token = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

		$cart_url = $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'));
		$home_url = $this->url->link('common/home', 'language=' . $this->config->get('config_language'));

		if (!(int)$this->config->get('module_abandoned_cart_status') || $token === '' || !preg_match('/^[a-f0-9]{16,64}$/i', $token)) {
			$this->response->redirect($home_url);

			return;
		}

		$this->load->model('extension/nk_abandoned_cart/module/abandoned_cart');

		$cart_info = $this->model_extension_nk_abandoned_cart_module_abandoned_cart->getCartByToken($token);

		if (!$cart_info || (int)$cart_info['store_id'] !== (int)$this->config->get('config_store_id')) {
			$this->response->redirect($home_url);

			return;
		}

		if ((int)$cart_info['recovered'] !== 0) {
			// Already converted - just send them to their cart.
			$this->response->redirect($cart_url);

			return;
		}

		$items = json_decode((string)$cart_info['cart_data'], true);

		if (!is_array($items) || !$items) {
			$this->response->redirect($cart_url);

			return;
		}

		$this->cart->clear();

		foreach ($items as $item) {
			if (!isset($item['product_id'])) {
				continue;
			}

			$option = (isset($item['option']) && is_array($item['option'])) ? $item['option'] : [];
			$quantity = isset($item['quantity']) ? (int)$item['quantity'] : 1;

			if ($quantity < 1) {
				$quantity = 1;
			}

			$this->cart->add((int)$item['product_id'], $quantity, $option, isset($item['subscription_plan_id']) ? (int)$item['subscription_plan_id'] : 0);
		}

		// Remember which snapshot this session came from so checkout/success can score it.
		$this->session->data['nk_abandoned_cart_id'] = (int)$cart_info['abandoned_cart_id'];

		if (!$this->customer->isLogged() && (string)$cart_info['email'] !== '') {
			$this->session->data['nk_abandoned_cart_email'] = (string)$cart_info['email'];
			$this->session->data['nk_abandoned_cart_name'] = (string)$cart_info['name'];
		}

		// The stage 3 coupon, if the merchant enabled one.
		$coupon_code = trim((string)$this->config->get('module_abandoned_cart_coupon_code'));

		if ((int)$this->config->get('module_abandoned_cart_coupon_status') && $coupon_code !== '') {
			$this->session->data['coupon'] = $coupon_code;
		}

		$this->response->redirect($cart_url);
	}

	/**
	 * Token guarded cron endpoint. Processes every due stage for this store.
	 *
	 * index.php?route=extension/nk_abandoned_cart/module/abandoned_cart.cron&token=SECRET
	 *
	 * @return void
	 */
	public function cron(): void {
		$this->response->addHeader('Content-Type: application/json');

		$secret = (string)$this->config->get('module_abandoned_cart_cron_token');
		$token = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

		if ($secret === '' || !hash_equals($secret, $token)) {
			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 403 Forbidden');
			$this->response->setOutput((string)json_encode(['error' => 'Invalid cron token.']));

			return;
		}

		if (!(int)$this->config->get('module_abandoned_cart_status')) {
			$this->response->setOutput((string)json_encode(['error' => 'Module disabled.']));

			return;
		}

		// Nothing can be delivered without a mail engine, so stop before touching the queue
		// rather than burning through rows and marking them all as failures.
		if (!$this->config->get('config_mail_engine')) {
			$this->response->setOutput((string)json_encode(['error' => 'No mail engine configured under System > Settings > Mail.']));

			return;
		}

		$this->load->language('extension/nk_abandoned_cart/module/abandoned_cart');
		$this->load->model('extension/nk_abandoned_cart/module/abandoned_cart');

		$store_id = (int)$this->config->get('config_store_id');
		$limit = (int)$this->config->get('module_abandoned_cart_batch_limit');

		if ($limit < 1) {
			$limit = 50;
		}

		$result = ['sent' => 0, 'skipped' => 0, 'failed' => 0, 'stages' => [], 'purged' => 0];

		for ($stage = 1; $stage <= 3; $stage++) {
			$result['stages'][$stage] = 0;

			if (!(int)$this->config->get('module_abandoned_cart_stage_' . $stage . '_status')) {
				continue;
			}

			$hours = (int)$this->config->get('module_abandoned_cart_stage_' . $stage . '_hours');

			if ($hours < 0) {
				$hours = 0;
			}

			$carts = $this->model_extension_nk_abandoned_cart_module_abandoned_cart->getDue($store_id, $stage, $hours, $limit);

			foreach ($carts as $cart_info) {
				$status = $this->send($cart_info, $stage);

				if ($status === 'fail') {
					// Transient problem (the mail server rejected it). Leave the stage alone
					// so the next run retries this row.
					$result['failed']++;

					continue;
				}

				// 'sent' and 'skip' both advance the stage: a row that can never be mailed
				// (no valid address, empty snapshot) must not block the head of the queue.
				$this->model_extension_nk_abandoned_cart_module_abandoned_cart->markEmailed((int)$cart_info['abandoned_cart_id'], $stage);

				if ($status === 'sent') {
					$result['sent']++;
					$result['stages'][$stage]++;
				} else {
					$result['skipped']++;
				}
			}
		}

		$result['purged'] = $this->model_extension_nk_abandoned_cart_module_abandoned_cart->purge($store_id, (int)$this->config->get('module_abandoned_cart_expire_days'));

		$this->response->setOutput((string)json_encode($result));
	}

	/**
	 * Render and send one recovery e-mail.
	 *
	 * @param array<string, mixed> $cart_info
	 * @param int                  $stage
	 *
	 * @return string 'sent', 'skip' (permanently unsendable) or 'fail' (retry next run)
	 */
	private function send(array $cart_info, int $stage): string {
		$email = (string)$cart_info['email'];

		// Permanent conditions: retrying these would only stall the queue.
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			return 'skip';
		}

		$items = json_decode((string)$cart_info['cart_data'], true);

		if (!is_array($items) || !$items) {
			return 'skip';
		}

		$store_name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
		$store_url = rtrim((string)$this->config->get('config_url'), '/') . '/';

		// Fall back to the store currency if the one captured with the cart has since been
		// removed - Currency::format() returns an empty string for an unknown code.
		$currency = (string)$cart_info['currency_code'];

		if ($currency === '' || !$this->currency->has($currency)) {
			$currency = (string)$this->config->get('config_currency');
		}

		$cart_link = $this->url->link('extension/nk_abandoned_cart/module/abandoned_cart.recover', 'language=' . $this->config->get('config_language') . '&token=' . rawurlencode((string)$cart_info['token']), true);

		$coupon = '';

		// The coupon is only ever offered on the final stage.
		if ($stage === 3 && (int)$this->config->get('module_abandoned_cart_coupon_status')) {
			$coupon = trim((string)$this->config->get('module_abandoned_cart_coupon_code'));
		}

		$products = [];

		foreach ($items as $item) {
			$products[] = [
				'name'        => (string)($item['name'] ?? ''),
				'model'       => (string)($item['model'] ?? ''),
				'option_text' => (string)($item['option_text'] ?? ''),
				'quantity'    => (int)($item['quantity'] ?? 0),
				'total'       => $this->currency->format((float)($item['total'] ?? 0), $currency)
			];
		}

		$name = trim((string)$cart_info['name']);

		if ($name === '') {
			$name = $this->language->get('text_customer');
		}

		$total = $this->currency->format((float)$cart_info['total'], $currency);

		// Plain text product list for the {products} placeholder in the editable body.
		$product_lines = [];

		foreach ($products as $product) {
			$product_lines[] = $product['quantity'] . ' x ' . $product['name'] . ($product['option_text'] !== '' ? ' (' . $product['option_text'] . ')' : '');
		}

		$replace = [
			'{name}'      => $name,
			'{store}'     => $store_name,
			'{total}'     => $total,
			'{coupon}'    => $coupon,
			'{cart_link}' => $cart_link,
			'{products}'  => implode("\n", $product_lines)
		];

		$subject = (string)$this->config->get('module_abandoned_cart_subject_' . $stage);

		if (trim($subject) === '') {
			$subject = $this->language->get('text_default_subject_' . $stage);
		}

		$body = (string)$this->config->get('module_abandoned_cart_body_' . $stage);

		if (trim($body) === '') {
			$body = $this->language->get('text_default_body_' . $stage);
		}

		$subject = strtr($subject, $replace);

		// The body is merchant authored HTML; the merge values are escaped before insertion.
		$escaped = [];

		foreach ($replace as $key => $value) {
			if ($key === '{products}') {
				$escaped[$key] = nl2br(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
			} else {
				$escaped[$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
			}
		}

		$data = [
			'title'       => $subject,
			'store_name'  => $store_name,
			'store_url'   => $store_url,
			'logo'        => $this->config->get('config_logo') ? $store_url . 'image/' . html_entity_decode((string)$this->config->get('config_logo'), ENT_QUOTES, 'UTF-8') : '',
			'body_html'   => strtr($body, $escaped),
			'products'    => $products,
			'total'       => $total,
			'cart_link'   => $cart_link,
			'coupon'      => $coupon,
			'text_button_recover' => $this->language->get('text_button_recover'),
			'text_items'  => $this->language->get('text_items'),
			'text_total'  => $this->language->get('text_total'),
			'text_coupon' => $this->language->get('text_coupon'),
			'text_mail_footer' => sprintf($this->language->get('text_mail_footer'), $store_name)
		];

		$mail_option = [
			'parameter'     => $this->config->get('config_mail_parameter'),
			'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
			'smtp_username' => $this->config->get('config_mail_smtp_username'),
			'smtp_password' => html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
			'smtp_port'     => $this->config->get('config_mail_smtp_port'),
			'smtp_timeout'  => $this->config->get('config_mail_smtp_timeout')
		];

		try {
			$mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_option);
			$mail->setTo($email);
			$mail->setFrom((string)$this->config->get('config_email'));
			$mail->setSender($store_name);
			$mail->setSubject($subject);
			$mail->setHtml($this->load->view('extension/nk_abandoned_cart/mail/abandoned_cart', $data));
			$mail->send();
		} catch (\Throwable $e) {
			$this->log->write('NovaKur Abandoned Cart: ' . $e->getMessage());

			return 'fail';
		}

		return 'sent';
	}
}
