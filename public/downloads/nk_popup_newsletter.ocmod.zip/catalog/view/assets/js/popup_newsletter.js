(function () {
  var config = window.nk_popup_newsletter || {};
  var cookieName = 'nk_newsletter_dismissed';
  var opened = false;

  function modal() {
    return document.getElementById('nk-newsletter');
  }

  function cookieDays() {
    var days = parseInt(config.cookie_days, 10);

    return days > 0 ? Math.min(days, 365) : 7;
  }

  function suppressed() {
    return document.cookie.indexOf(cookieName + '=1') !== -1;
  }

  function setCookie() {
    var expires = new Date();
    expires.setTime(expires.getTime() + (cookieDays() * 86400000));
    document.cookie = cookieName + '=1; expires=' + expires.toUTCString() + '; path=/; SameSite=Lax';
  }

  function open() {
    var el = modal();
    if (!el || opened || suppressed()) return;

    opened = true;
    el.classList.add('is-open');
    el.setAttribute('aria-hidden', 'false');

    var input = el.querySelector('input[name="email"]');
    if (input) input.focus();
  }

  function close() {
    var el = modal();
    if (!el) return;

    el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true');
    setCookie();
  }

  function showError(message) {
    var el = modal();
    if (!el) return;

    var box = el.querySelector('[data-nk-error]');
    if (!box) return;

    box.textContent = message;
    box.hidden = !message;
  }

  // --- triggers -------------------------------------------------------------------------
  function armDelay() {
    var delay = parseInt(config.delay, 10);

    setTimeout(open, (isNaN(delay) || delay < 0 ? 5 : Math.min(delay, 600)) * 1000);
  }

  function armScroll() {
    var target = Math.max(1, Math.min(100, parseInt(config.scroll, 10) || 50));

    function onScroll() {
      var height = document.documentElement.scrollHeight - window.innerHeight;
      var percent = height > 0 ? (window.pageYOffset / height) * 100 : 100;

      if (percent >= target) {
        window.removeEventListener('scroll', onScroll);
        open();
      }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function armExit() {
    // Exit intent needs a mouse; touch devices fall back to the delay.
    if (!window.matchMedia || !window.matchMedia('(hover: hover)').matches) {
      armDelay();

      return;
    }

    document.addEventListener('mouseout', function (e) {
      if (!e.relatedTarget && e.clientY <= 0) open();
    });
  }

  function arm() {
    if (suppressed() || !modal()) return;

    if (config.trigger === 'scroll') {
      armScroll();
    } else if (config.trigger === 'exit') {
      armExit();
    } else {
      armDelay();
    }
  }

  document.addEventListener('click', function (e) {
    if (e.target.closest('#nk-newsletter [data-close="1"]')) {
      e.preventDefault();
      close();
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && opened) close();
  });

  function bind() {
    var form = document.getElementById('nk-newsletter-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      showError('');

      var body = new URLSearchParams(new FormData(form));

      fetch(config.url || form.getAttribute('action') || 'index.php?route=extension/nk_popup_newsletter/module/popup_newsletter.subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
        body: body.toString()
      })
        .then(function (r) { return r.json(); })
        .then(function (json) {
          if (json.error) {
            showError(json.error);

            return;
          }

          // Build the confirmation with the DOM so a coupon code can never inject markup.
          var success = document.createElement('div');
          success.className = 'nk-newsletter__success';
          success.textContent = json.success || '';

          if (json.code) {
            var code = document.createElement('strong');
            code.textContent = json.code;
            success.appendChild(document.createTextNode(' '));
            success.appendChild(code);
          }

          form.parentNode.replaceChild(success, form);

          setCookie();
        })
        .catch(function () {
          showError('');
        });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); arm(); });
  } else {
    bind();
    arm();
  }
})();
