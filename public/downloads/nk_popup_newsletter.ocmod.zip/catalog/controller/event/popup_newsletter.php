<?php
namespace Opencart\Catalog\Controller\Extension\NkPopupNewsletter\Event;

/**
 * NovaKur Popup Newsletter - storefront event hooks.
 *
 * Registered by the admin controller's install():
 *   catalog/controller/common/header/before -> header()  queue the popup css/js in <head>
 *   catalog/view/common/footer/after        -> footer()  inject the popup + trigger config
 */
class PopupNewsletter extends \Opencart\System\Engine\Controller {
	/**
	 * @param string            $route
	 * @param array<int, mixed> $args
	 *
	 * @return void
	 */
	public function header(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_popup_newsletter_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_popup_newsletter/catalog/view/assets/css/popup_newsletter.css');
		$this->document->addScript('extension/nk_popup_newsletter/catalog/view/assets/js/popup_newsletter.js');
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function footer(string &$route, array &$data, &$output): void {
		if (!(int)$this->config->get('module_popup_newsletter_status') || !is_string($output)) {
			return;
		}

		if (str_contains($output, 'id="nk-newsletter"')) {
			return;
		}

		$popup = $this->load->controller('extension/nk_popup_newsletter/module/popup_newsletter.render');

		if (!is_string($popup) || $popup === '') {
			return;
		}

		$trigger = (string)$this->config->get('module_popup_newsletter_trigger');

		if (!in_array($trigger, ['delay', 'scroll', 'exit'], true)) {
			$trigger = 'delay';
		}

		$config = [
			'url'         => $this->url->link('extension/nk_popup_newsletter/module/popup_newsletter.subscribe', 'language=' . $this->config->get('config_language')),
			'trigger'     => $trigger,
			'delay'       => max(0, min(600, (int)$this->config->get('module_popup_newsletter_delay'))),
			'scroll'      => max(1, min(100, (int)$this->config->get('module_popup_newsletter_scroll') ?: 50)),
			'cookie_days' => max(1, min(365, (int)$this->config->get('module_popup_newsletter_cookie_days') ?: 7))
		];

		$html = '<script type="text/javascript">var nk_popup_newsletter = ' . json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>' . "\n" . $popup;

		if (str_contains($output, '</body>')) {
			$output = str_replace('</body>', $html . '</body>', $output);
		} else {
			$output .= $html;
		}
	}
}
