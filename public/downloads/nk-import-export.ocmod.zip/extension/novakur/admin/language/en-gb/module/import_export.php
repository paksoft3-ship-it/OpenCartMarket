<?php
// Heading
$_['heading_title']            = 'NovaKur Import / Export Pro';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified NovaKur Import / Export Pro settings!';
$_['text_edit']                = 'Edit NovaKur Import / Export Pro';
$_['text_enabled']             = 'Enabled';
$_['text_disabled']            = 'Disabled';
$_['text_ignore']              = '--- Ignore this column ---';
$_['text_all']                 = 'Select all';
$_['text_none']                = 'Select none';
$_['text_loading']             = 'Working...';

$_['text_product']             = 'Products';
$_['text_category']            = 'Categories';
$_['text_customer']            = 'Customers';

$_['text_comma']               = 'Comma  ,';
$_['text_semicolon']           = 'Semicolon  ;';
$_['text_tab']                 = 'Tab';

$_['text_step_1']              = 'Step 1 — Choose what to import and upload a CSV';
$_['text_step_2']              = 'Step 2 — Map your columns to OpenCart fields';
$_['text_step_3']              = 'Step 3 — Validate, then import';

$_['text_mapping']             = 'Column mapping';
$_['text_preview']             = 'Preview (first 5 rows)';
$_['text_progress']            = 'Progress';
$_['text_summary']             = 'Summary';
$_['text_errors']              = 'Row errors';
$_['text_no_errors']           = 'No problems found.';
$_['text_no_file']             = 'No file uploaded yet.';

$_['text_mode_both']           = 'Create new records and update existing ones';
$_['text_mode_create']         = 'Only create new records (skip rows that already exist)';
$_['text_mode_update']         = 'Only update existing records (skip rows with no match)';

$_['text_format_csv']          = 'CSV (UTF-8 with BOM)';
$_['text_format_xls']          = 'Excel (.xls HTML table)';

$_['text_uploaded']            = 'Uploaded "%s" — %s data rows found.';
$_['text_processing']          = 'Processed %s of %s rows...';
$_['text_exporting']           = 'Exported %s of %s records...';
$_['text_row_error']           = 'Row %s: %s';
$_['text_row_skipped_exists']  = 'Row %s: skipped, a matching record already exists.';
$_['text_row_skipped_missing'] = 'Row %s: skipped, no existing record matched.';
$_['text_import_complete']     = 'Import finished. Created: %s, updated: %s, skipped: %s, failed: %s.';
$_['text_dry_run_complete']    = 'Dry run finished — nothing was written. Would create: %s, would update: %s, would skip: %s, would fail: %s.';
$_['text_export_complete']     = 'Export finished — %s records written.';

$_['text_xls_note']            = 'Honest note about Excel: the .xls option writes an HTML table with an .xls extension. Excel, LibreOffice and Google Sheets all open it correctly, but it is not a true binary XLSX workbook (building one would need a Composer library this extension deliberately does not ship). CSV with a UTF-8 BOM is the real, lossless format and is what you should re-import.';
$_['text_storage_note']        = 'Uploaded CSVs and generated exports are written to system/storage/nk_import_export/, which is not reachable over the web. Files are removed automatically 24 hours after they are created, and an uploaded file is deleted as soon as its import finishes.';

// Tab
$_['tab_import']               = 'Import';
$_['tab_export']               = 'Export';
$_['tab_setting']              = 'Settings';

// Entry
$_['entry_entity']             = 'Data type';
$_['entry_file']               = 'CSV file';
$_['entry_delimiter']          = 'CSV delimiter';
$_['entry_mode']               = 'Import mode';
$_['entry_match']              = 'Match existing records on';
$_['entry_store']              = 'Store';
$_['entry_language']           = 'Language';
$_['entry_status']             = 'Status';
$_['entry_chunk_size']         = 'Rows per request';
$_['entry_fields']             = 'Fields to export';
$_['entry_format']             = 'Format';

// Help
$_['help_chunk_size']          = 'How many rows each background request handles. Lower this (25–50) on shared hosting with a short max_execution_time; raise it (250–500) on a fast server to finish large files sooner. Allowed range 5–2000.';
$_['help_language']            = 'Descriptions are read from and written to this language. When a brand new product or category is created the same text is also copied into every other installed language, so the record is never invisible on a translated storefront.';
$_['help_delimiter']           = 'Applies to both uploaded files and generated exports. Use semicolon if your Excel locale saves CSVs that way.';
$_['help_dry_run']             = 'Runs every validation check and lists the problems row by row without writing a single record. Always dry run a new file first.';
$_['help_match']               = 'The column used to decide whether a row is a new record or an update to an existing one. It must be one of the columns you mapped.';
$_['help_mode']                = 'Controls what happens when a row matches an existing record.';
$_['help_categories']          = 'Categories accept IDs, plain names or full "Parent > Child" paths, separated by a pipe character, for example: Components|Laptops > Macs. Names must already exist; nothing is auto created.';
$_['help_password']            = 'Customer passwords are imported as plain text and hashed with PHP password_hash() before storage. Leave the column blank on an update to keep the current password. Passwords are never included in an export.';
$_['help_encoding']            = 'Files must be UTF-8. Exports are written with a UTF-8 byte order mark so Excel shows accented characters correctly.';

// Button
$_['button_upload']            = 'Upload CSV';
$_['button_validate']          = 'Dry run';
$_['button_import']            = 'Run import';
$_['button_export']            = 'Run export';
$_['button_template']          = 'Download blank template';
$_['button_download']          = 'Download file';
$_['button_reset']             = 'Start over';
$_['button_save']              = 'Save';
$_['button_back']              = 'Back';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify NovaKur Import / Export Pro!';
$_['error_entity']             = 'Please choose a valid data type.';
$_['error_directory']          = 'The storage directory system/storage/nk_import_export/ could not be created or is not writable.';
$_['error_upload']             = 'The file could not be uploaded. Please try again.';
$_['error_filename']           = 'The file name must be between 5 and 128 characters.';
$_['error_file_type']          = 'Only .csv files can be imported.';
$_['error_file_size']          = 'The file is larger than the %s MB limit.';
$_['error_file']               = 'The working file no longer exists — please upload it again.';
$_['error_header']             = 'The first line of the file could not be read as a header row.';
$_['error_empty']              = 'The file contains a header row but no data rows.';
$_['error_mapping']            = 'Map at least one column before continuing.';
$_['error_field']              = 'Unknown target field "%s".';
$_['error_duplicate_field']    = 'Two columns are both mapped to "%s". Each field can only be used once.';
$_['error_mode']               = 'Please choose a valid import mode.';
$_['error_match']              = 'Please choose a valid column to match existing records on.';
$_['error_match_unmapped']     = 'You are matching on "%s", but no CSV column is mapped to it.';
$_['error_fields']             = 'Select at least one field to export.';
$_['error_format']             = 'Please choose a valid export format.';
$_['error_job']                = 'This import job could not be found. It may have expired — please upload the file again.';
$_['error_chunk_size']         = 'Rows per request must be between %s and %s.';
$_['error_language']           = 'Please choose an installed language.';
$_['error_delimiter']          = 'Please choose a valid CSV delimiter.';
