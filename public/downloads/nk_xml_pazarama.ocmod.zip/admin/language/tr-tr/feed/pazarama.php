<?php
$_['heading_title']                 = 'NovaKur Pazarama XML';

$_['text_extension']                = 'Eklentiler';
$_['text_success']                  = 'Başarılı: Pazarama besleme ayarları kaydedildi!';
$_['text_edit']                     = 'Pazarama Beslemesi Ayarları';
$_['text_enabled']                  = 'Etkin';
$_['text_disabled']                 = 'Pasif';
$_['text_default_store']            = 'Varsayılan Mağaza';
$_['text_plain']                    = 'Düz metin';
$_['text_html']                     = 'Temel HTML';
$_['text_cache_cleared']            = 'Besleme önbelleği temizlendi.';
$_['text_feed_url']                 = 'Besleme Adresi (URL)';
$_['text_feed_status']              = 'Besleme Durumu';
$_['text_last_generated']           = 'Son Oluşturulma';
$_['text_not_generated']            = 'Henüz oluşturulmadı';

$_['text_field_notice']             = 'Bu eklenti, Pazarama\'nın çekmesi veya sizin yüklemeniz için besleme adresini üretir. Pazarama sistemlerine bağlanmaz, kendiliğinden ürün açmaz veya güncellemez. Alan seti (stockCode, barcode, productName, brand, categoryName, listPrice, salePrice, vatRate, stockQuantity, images, description) Pazarama\'nın kamuya açık besleme kurallarına göre hazırlanmıştır; zorunlu alanlar ve kategori eşleme kuralları mağaza anlaşmanıza göre değişebileceğinden, canlıya almadan önce kendi Pazarama satıcı panelinizdeki entegrasyon dokümanıyla doğrulayın.';

$_['entry_status']                  = 'Durum';
$_['entry_store']                   = 'Mağaza';
$_['entry_currency']                = 'Para Birimi';
$_['entry_language']                = 'Dil';
$_['entry_include_out_of_stock']    = 'Stokta Olmayanları Dahil Et';
$_['entry_brand_attribute']         = 'Marka Özelliği';
$_['entry_barcode_attribute']       = 'Barkod Özelliği';
$_['entry_description_html']        = 'Açıklama Biçimi';
$_['entry_max_products']            = 'En Fazla Ürün';
$_['entry_cache_hours']             = 'Önbellek Süresi (Saat)';
$_['entry_excluded_categories']     = 'Hariç Tutulan Kategoriler';
$_['entry_token']                   = 'Besleme Anahtarı';

$_['help_feed_url']                 = 'Bu adresi Pazarama\'ya verin veya dosyayı kendiniz indirin. Adres besleme anahtarını içerir, gizli tutun.';
$_['help_token']                    = 'Zorunlu. Besleme adresi yalnızca bu anahtar ile yanıt verir; anahtar yoksa veya yanlışsa adres 404 döner.';
$_['help_brand_attribute']          = 'İsteğe bağlı. Marka bilgisini üretici yerine seçilen ürün özelliğinden okur. Özellik boşsa üretici bilgisi kullanılır.';
$_['help_barcode_attribute']        = 'İsteğe bağlı. Barkodu seçilen ürün özelliğinden okur. Özellik boşsa üründeki EAN / GTIN / UPC / JAN / ISBN değeri kullanılır.';
$_['help_description_html']         = 'Düz metin tüm etiketleri temizler. Temel HTML güvenli bir etiket kümesini (paragraf, liste, tablo) korur; script, iframe ve gömülü nesneler her durumda kaldırılır.';
$_['help_excluded_categories']      = 'Seçilen kategorilerdeki ve altlarındaki tüm kategorilerdeki ürünler beslemeye eklenmez.';
$_['help_max_products']             = 'Beslemeye yazılacak en fazla ürün sayısı. 0 sınırsız demektir. Ürünler her durumda 250\'lik gruplar hâlinde okunur.';

$_['button_copy']                   = 'Kopyala';
$_['button_clear_cache']            = 'Önbelleği Temizle';
$_['button_regenerate_token']       = 'Yeni Anahtar Üret';

$_['error_permission']              = 'Uyarı: Pazarama beslemesini düzenleme yetkiniz yok!';
$_['error_currency']                = 'Mağazanızda tanımlı bir para birimi seçin!';
$_['error_token']                   = 'Besleme anahtarı 16 ile 64 arasında harf veya rakam içermelidir!';
