<?php
// Başlık
$_['heading_title']             = 'NovaKur e-Fatura / e-Arşiv XML';

// Sekmeler
$_['tab_general']               = 'Genel';
$_['tab_supplier']              = 'Satıcı Bilgileri';
$_['tab_numbering']             = 'Numaralandırma ve KDV';
$_['tab_customer']              = 'Alıcı Alanları';
$_['tab_orders']                = 'Siparişler ve Toplu Aktarım';

// Metin
$_['text_extension']            = 'Eklentiler';
$_['text_success']              = 'Başarılı: NovaKur e-Fatura / e-Arşiv ayarları kaydedildi!';
$_['text_edit']                 = 'NovaKur e-Fatura / e-Arşiv XML Ayarları';
$_['text_enabled']              = 'Etkin';
$_['text_disabled']             = 'Pasif';
$_['text_yes']                  = 'Evet';
$_['text_no']                   = 'Hayır';
$_['text_none']                 = '--- Yok ---';
$_['text_select']               = '--- Seçiniz ---';
$_['text_all_statuses']         = 'Tüm sipariş durumları';
$_['text_list']                 = 'Sipariş Listesi';
$_['text_filter']               = 'Filtre';
$_['text_batch']                = 'Toplu Aktarım (Tarih Aralığı → ZIP)';
$_['text_pagination']           = '%d - %d / %d (%d Sayfa) gösteriliyor';
$_['text_no_results']           = 'Sipariş bulunamadı!';
$_['text_not_generated']        = 'Henüz oluşturulmadı';
$_['text_document_total']       = 'Şu ana kadar düzenlenen belge sayısı';
$_['text_last_sequence']        = 'Bu yıl kullanılan son sıra numarası';
$_['text_distribute']           = 'İndirimi satırlara dağıt (önerilen)';
$_['text_allowance']            = 'Belge seviyesinde iskonto olarak yaz';
$_['text_payment_1']            = '1 - Belirsiz';
$_['text_payment_10']           = '10 - Nakit';
$_['text_payment_42']           = '42 - Banka Havalesi / EFT';
$_['text_payment_48']           = '48 - Kredi Kartı / Banka Kartı';
$_['text_payment_68']           = '68 - Online Ödeme';
$_['text_payment_zzz']          = 'ZZZ - Diğer';

// Uyarı panelleri
$_['text_signature_notice']     = 'ÖNEMLİ: Bu eklenti UBL-TR 1.2 yapısında XML üretir, ancak belgeyi MALİ MÜHÜR / E-İMZA İLE İMZALAMAZ. İmzalama işlemi GİB portalında veya özel entegratörünüzün sisteminde yapılır. Üretilen XML dosyasını canlı kullanımdan önce mutlaka güncel GİB şematron (schematron) kurallarına göre doğrulatın. Vergisel sorumluluk mükellefe aittir.';
$_['text_no_upload_notice']     = 'Bu eklenti GİB veya entegratör sistemlerine hiçbir bağlantı kurmaz, veri göndermez. Yalnızca indirilebilir XML dosyası üretir; yüklemeyi siz yaparsınız.';
$_['text_uninstall_notice']     = 'Not: Eklenti kaldırıldığında düzenlenen belge kaydı tablosu (fatura numaraları ve ETTN değerleri) korunur. Yine de yedek olarak toplu aktarım almanız önerilir.';
$_['text_zip_missing']          = 'PHP ZipArchive sınıfı sunucunuzda bulunamadı. Toplu aktarım devre dışı; belgeleri tek tek indirebilirsiniz.';
$_['text_table_missing']        = 'Düzenlenen belge kayıt tablosu bulunamadı. Tablonun oluşturulması için eklentiyi Eklentiler > Beslemeler ekranından kurun.';
$_['text_dom_missing']          = 'PHP DOM eklentisi sunucunuzda bulunamadı. XML üretimi çalışmaz; hosting sağlayıcınızdan php-xml paketini etkinleştirmesini isteyin.';

$_['text_readme']               = "NovaKur e-Fatura / e-Arsiv XML\r\n\r\nBu arsivdeki dosyalar UBL-TR 1.2 yapisinda uretilmis fatura belgeleridir.\r\nBelgeler MALI MUHUR / E-IMZA ILE IMZALANMAMISTIR. Imzalama islemi GIB\r\nportalinda veya ozel entegratorunuzun sisteminde yapilir.\r\n\r\nCanli kullanimdan once belgeleri guncel GIB sematron kurallarina gore\r\ndogrulatiniz. _report.csv dosyasi her siparis icin uretilen fatura\r\nnumarasini, ETTN degerini ve varsa uyarilari icerir.\r\n";

// Alanlar - Genel
$_['entry_status']              = 'Durum';
$_['entry_profile']             = 'Senaryo (ProfileID)';
$_['entry_invoice_type']        = 'Fatura Tipi (InvoiceTypeCode)';
$_['entry_currency']            = 'Belge Para Birimi';
$_['entry_exchange_rate']       = 'TRY Çevrim Kuru';
$_['entry_note']                = 'Ek Fatura Notu';
$_['entry_batch_limit']         = 'Toplu Aktarım Sipariş Limiti';

// Alanlar - Satıcı
$_['entry_supplier_name']       = 'Ünvan / Ad Soyad';
$_['entry_supplier_vkn']        = 'Vergi Kimlik No (VKN / TCKN)';
$_['entry_supplier_tax_office'] = 'Vergi Dairesi';
$_['entry_supplier_mersis']     = 'MERSİS No';
$_['entry_supplier_sicil']      = 'Ticaret Sicil No';
$_['entry_supplier_street']     = 'Cadde / Sokak';
$_['entry_supplier_building']   = 'Bina No';
$_['entry_supplier_district']   = 'İlçe';
$_['entry_supplier_city']       = 'İl';
$_['entry_supplier_postcode']   = 'Posta Kodu';
$_['entry_supplier_country']    = 'Ülke';
$_['entry_supplier_phone']      = 'Telefon';
$_['entry_supplier_email']      = 'E-posta';
$_['entry_supplier_website']    = 'Web Adresi';

// Alanlar - Numaralandırma / KDV
$_['entry_serial']              = 'e-Fatura Seri Öneki';
$_['entry_earsiv_serial']       = 'e-Arşiv Seri Öneki';
$_['entry_start_no']            = 'Başlangıç Sıra Numarası';
$_['entry_kdv_rate']            = 'Varsayılan KDV Oranı (%)';
$_['entry_shipping_kdv_rate']   = 'Kargo / Hizmet KDV Oranı (%)';
$_['entry_discount_mode']       = 'İndirim İşleme Yöntemi';
$_['entry_unit_code']           = 'Varsayılan Birim Kodu';
$_['entry_exemption_code']      = 'KDV İstisna Kodu';
$_['entry_exemption_reason']    = 'KDV İstisna Gerekçesi';

// Alanlar - Alıcı
$_['entry_cf_vkn']              = 'VKN Özel Alanı';
$_['entry_cf_tckn']             = 'TCKN Özel Alanı';
$_['entry_cf_tax_office']       = 'Vergi Dairesi Özel Alanı';
$_['entry_use_default_tckn']    = 'TCKN yoksa 11111111111 kullan';
$_['entry_earsiv_send_type']    = 'e-Arşiv Gönderim Şekli';
$_['entry_earsiv_internet']     = 'İnternet Satışı Notlarını Ekle';
$_['entry_payment_means_code']  = 'Ödeme Şekli Kodu (e-Arşiv)';

// Alanlar - Filtre / Toplu
$_['entry_order_id']            = 'Sipariş No';
$_['entry_customer']            = 'Müşteri';
$_['entry_order_status']        = 'Sipariş Durumu';
$_['entry_date_from']           = 'Başlangıç Tarihi';
$_['entry_date_to']             = 'Bitiş Tarihi';
$_['entry_scenario']            = 'Belge Türü';

// Sütunlar
$_['column_order_id']           = 'Sipariş No';
$_['column_customer']           = 'Müşteri';
$_['column_status']             = 'Durum';
$_['column_total']              = 'Tutar';
$_['column_date_added']         = 'Tarih';
$_['column_efatura_no']         = 'e-Fatura No';
$_['column_earsiv_no']          = 'e-Arşiv No';
$_['column_action']             = 'İşlem';

// Yardım
$_['help_profile']              = 'GİB e-Fatura senaryosu. Alıcı e-Fatura mükellefi ise TİCARİFATURA veya TEMELFATURA; mükellef değilse e-Arşiv düğmesini kullanın (ProfileID otomatik EARSIVFATURA olur).';
$_['help_invoice_type']         = 'Normal satışlarda SATIS kullanılır.';
$_['help_currency']             = 'e-Fatura belgeleri kural olarak TRY düzenlenir. Mağaza ana para biriminiz TRY değilse aşağıdaki çevrim kurunu doldurun.';
$_['help_exchange_rate']        = 'Mağaza ana para biriminden TRY değerine çarpım katsayısı. Ana para biriminiz zaten TRY ise bu alan yok sayılır.';
$_['help_supplier_vkn']         = 'Tüzel kişiler için 10 haneli VKN, şahıs şirketleri için 11 haneli TCKN girin.';
$_['help_serial']               = 'Fatura numarası GİB kuralına göre 3 karakter seri öneki + 4 haneli yıl + 9 haneli sıra numarasından oluşur. Örnek: EFT2026000000001. Yalnızca büyük harf ve rakam kullanın.';
$_['help_start_no']             = 'Bu seri için ilk faturanın sıra numarası. Sonraki numaralar otomatik artar ve her sipariş için bir kez üretilip saklanır; aynı siparişi tekrar indirdiğinizde numara ve ETTN değişmez.';
$_['help_kdv_rate']             = 'Sipariş satırından KDV oranı hesaplanamadığında kullanılır. Satır bazlı oran, OpenCart siparişindeki vergi tutarından türetilir.';
$_['help_discount_mode']        = 'Kupon / hediye çeki gibi indirimler için: "satırlara dağıt" seçeneği KDV matrahını orantılı düşürür ve toplamların sipariş tutarıyla uyuşmasını sağlar.';
$_['help_unit_code']            = 'UN/ECE Rec 20 birim kodu. Adet için genellikle C62 veya NIU kullanılır.';
$_['help_exemption']            = 'Yalnızca %0 KDV içeren satırlarda yazılır. Kod ve gerekçeyi güncel GİB istisna kodları listesinden alın.';
$_['help_cf_vkn']               = 'Müşterinin VKN değerini tuttuğunuz OpenCart özel alanını (custom field) seçin. Değer 10 haneli ise belge kurumsal alıcı (VKN) olarak düzenlenir.';
$_['help_cf_tckn']              = 'Müşterinin TCKN değerini tuttuğunuz özel alanı seçin. Değer 11 haneli ise belge şahıs alıcı (TCKN) olarak düzenlenir.';
$_['help_use_default_tckn']     = 'e-Arşiv belgelerinde alıcının TCKN bilgisi yoksa GİB uygulamasında yaygın olarak kabul edilen 11111111111 değeri yazılır.';
$_['help_batch']                = 'Seçilen tarih aralığındaki siparişler için XML üretir ve tek bir ZIP dosyası olarak indirir. ZIP içinde ayrıca fatura numaralarını ve uyarıları listeleyen _report.csv bulunur.';
$_['help_batch_limit']          = 'Tek seferde işlenecek en fazla sipariş sayısı. Sunucu zaman aşımı yaşarsanız düşürün.';

// Düğmeler
$_['button_save']               = 'Kaydet';
$_['button_filter']             = 'Filtrele';
$_['button_efatura']            = 'e-Fatura XML Oluştur';
$_['button_earsiv']             = 'e-Arşiv XML Oluştur';
$_['button_check']              = 'Doğrula';
$_['button_batch']              = 'ZIP İndir';
$_['button_view']               = 'Siparişi Görüntüle';

// Doğrulama sonucu
$_['text_check_title']          = 'Belge Doğrulama Sonucu';
$_['text_check_ok']             = 'XML yapısı geçerli (well-formed) ve UBL-TR 1.2 Invoice kökü doğrulandı.';
$_['text_check_fail']           = 'XML doğrulanamadı.';
$_['text_check_invoice_no']     = 'Fatura No';
$_['text_check_uuid']           = 'ETTN (UUID)';
$_['text_check_profile']        = 'Senaryo';
$_['text_check_payable']        = 'Ödenecek Tutar';
$_['text_check_order_total']    = 'Sipariş Tutarı';
$_['text_check_size']           = 'Belge Boyutu (bayt)';

// Uyarılar (model tarafından döndürülen kodlar)
$_['warning_total_mismatch']    = 'Uyarı: Hesaplanan ödenecek tutar sipariş toplamıyla birebir örtüşmüyor. Sipariş toplamları ve KDV ayarlarını kontrol edin.';
$_['warning_missing_tckn']      = 'Uyarı: Alıcının VKN/TCKN bilgisi bulunamadı. Alıcı Alanları sekmesinden özel alan eşlemesini yapın.';
$_['warning_default_tckn']      = 'Bilgi: Alıcının TCKN bilgisi bulunamadığı için 11111111111 kullanıldı.';
$_['warning_unknown_total']     = 'Uyarı: Tanınmayan bir sipariş toplamı satırı varsayılan KDV oranıyla faturaya eklendi.';
$_['warning_discount_exceeds']  = 'Uyarı: İndirim tutarı satır toplamlarını aşıyor; satır tutarları sıfırlandı.';
$_['warning_exchange_rate']     = 'Uyarı: Mağaza ana para birimi belge para biriminden farklı ancak çevrim kuru 1 olarak ayarlı.';

// Hatalar
$_['error_permission']          = 'Uyarı: Bu eklentiyi düzenleme yetkiniz yok!';
$_['error_order']               = 'Geçersiz sipariş numarası.';
$_['error_order_missing']       = 'Sipariş bulunamadı.';
$_['error_no_lines']            = 'Siparişte faturalanabilir satır yok.';
$_['error_generate']            = 'Belge oluşturulamadı.';
$_['error_vkn']                 = 'VKN 10, TCKN 11 haneli olmalıdır!';
$_['error_supplier_name']       = 'Ünvan en az 3 karakter olmalıdır!';
$_['error_tax_office']          = 'Vergi dairesi zorunludur!';
$_['error_serial']              = 'Seri öneki tam 3 karakter olmalı ve yalnızca büyük harf/rakam içermelidir!';
$_['error_rate']                = 'KDV oranı 0 ile 100 arasında olmalıdır!';
$_['error_exchange_rate']       = 'Çevrim kuru sıfırdan büyük olmalıdır!';
$_['error_start_no']            = 'Başlangıç sıra numarası geçerli bir pozitif tam sayı olmalıdır!';
$_['error_date']                = 'Geçerli bir başlangıç ve bitiş tarihi seçin (YYYY-AA-GG)!';
$_['error_date_range']          = 'Başlangıç tarihi bitiş tarihinden sonra olamaz!';
$_['error_batch_empty']         = 'Seçilen aralıkta aktarılabilir sipariş bulunamadı.';
$_['error_zip']                 = 'PHP ZipArchive sınıfı bulunamadığı için toplu aktarım yapılamıyor.';
$_['error_zip_create']          = 'ZIP dosyası oluşturulamadı. storage klasörünün yazma iznini kontrol edin.';
