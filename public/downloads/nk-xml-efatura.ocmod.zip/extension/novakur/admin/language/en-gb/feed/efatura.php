<?php
// Heading
$_['heading_title']             = 'NovaKur e-Fatura / e-Arşiv XML';

// Tabs
$_['tab_general']               = 'General';
$_['tab_supplier']              = 'Supplier';
$_['tab_numbering']             = 'Numbering & VAT';
$_['tab_customer']              = 'Buyer Fields';
$_['tab_orders']                = 'Orders & Batch Export';

// Text
$_['text_extension']            = 'Extensions';
$_['text_success']              = 'Success: NovaKur e-Fatura / e-Arşiv settings saved!';
$_['text_edit']                 = 'Edit NovaKur e-Fatura / e-Arşiv XML';
$_['text_enabled']              = 'Enabled';
$_['text_disabled']             = 'Disabled';
$_['text_yes']                  = 'Yes';
$_['text_no']                   = 'No';
$_['text_none']                 = '--- None ---';
$_['text_select']               = '--- Select ---';
$_['text_all_statuses']         = 'All order statuses';
$_['text_list']                 = 'Orders';
$_['text_filter']               = 'Filter';
$_['text_batch']                = 'Batch Export (date range → ZIP)';
$_['text_pagination']           = 'Showing %d to %d of %d (%d Pages)';
$_['text_no_results']           = 'No orders found!';
$_['text_not_generated']        = 'Not generated yet';
$_['text_document_total']       = 'Documents issued so far';
$_['text_last_sequence']        = 'Last sequence number used this year';
$_['text_distribute']           = 'Distribute discounts across lines (recommended)';
$_['text_allowance']            = 'Write as a document level allowance';
$_['text_payment_1']            = '1 - Unspecified';
$_['text_payment_10']           = '10 - Cash';
$_['text_payment_42']           = '42 - Bank transfer / EFT';
$_['text_payment_48']           = '48 - Credit / debit card';
$_['text_payment_68']           = '68 - Online payment';
$_['text_payment_zzz']          = 'ZZZ - Other';

// Notices
$_['text_signature_notice']     = 'IMPORTANT: this extension produces structurally UBL-TR 1.2 XML, but it does NOT apply a digital signature (mali mühür / e-imza). Signing happens in the GİB portal or in your integrator\'s system. Always validate the generated XML against the current GİB schematron rules before using it in production. Tax compliance remains the taxpayer\'s responsibility.';
$_['text_no_upload_notice']     = 'This extension never contacts GİB or any integrator. It only produces downloadable XML files; uploading them is up to you.';
$_['text_uninstall_notice']     = 'Note: the issued-document ledger (invoice numbers and ETTN values) is preserved when the extension is uninstalled. Keep a batch export as a backup regardless.';
$_['text_zip_missing']          = 'The PHP ZipArchive class is not available on this server. Batch export is disabled; you can still download documents one by one.';
$_['text_table_missing']      = 'The issued-document ledger table is missing. Install the extension from Extensions > Feeds so it can be created.';
$_['text_dom_missing']          = 'The PHP DOM extension is not available on this server. XML generation will not work - ask your host to enable php-xml.';

$_['text_readme']               = "NovaKur e-Fatura / e-Arsiv XML\r\n\r\nThe files in this archive are invoice documents generated in UBL-TR 1.2\r\nstructure. They are NOT digitally signed (mali muhur / e-imza). Signing is\r\nperformed in the GIB portal or by your integrator.\r\n\r\nValidate the documents against the current GIB schematron rules before\r\nproduction use. _report.csv lists the invoice number, ETTN and any warnings\r\nfor every order in this batch.\r\n";

// Entry - General
$_['entry_status']              = 'Status';
$_['entry_profile']             = 'Scenario (ProfileID)';
$_['entry_invoice_type']        = 'Invoice Type (InvoiceTypeCode)';
$_['entry_currency']            = 'Document Currency';
$_['entry_exchange_rate']       = 'TRY Conversion Rate';
$_['entry_note']                = 'Additional Invoice Note';
$_['entry_batch_limit']         = 'Batch Export Order Limit';

// Entry - Supplier
$_['entry_supplier_name']       = 'Legal Name / Title';
$_['entry_supplier_vkn']        = 'Tax Number (VKN / TCKN)';
$_['entry_supplier_tax_office'] = 'Tax Office (Vergi Dairesi)';
$_['entry_supplier_mersis']     = 'MERSİS No';
$_['entry_supplier_sicil']      = 'Trade Registry No';
$_['entry_supplier_street']     = 'Street';
$_['entry_supplier_building']   = 'Building No';
$_['entry_supplier_district']   = 'District (İlçe)';
$_['entry_supplier_city']       = 'City (İl)';
$_['entry_supplier_postcode']   = 'Postcode';
$_['entry_supplier_country']    = 'Country';
$_['entry_supplier_phone']      = 'Telephone';
$_['entry_supplier_email']      = 'E-Mail';
$_['entry_supplier_website']    = 'Website';

// Entry - Numbering / VAT
$_['entry_serial']              = 'e-Fatura Serial Prefix';
$_['entry_earsiv_serial']       = 'e-Arşiv Serial Prefix';
$_['entry_start_no']            = 'Starting Sequence Number';
$_['entry_kdv_rate']            = 'Default KDV Rate (%)';
$_['entry_shipping_kdv_rate']   = 'Shipping / Service KDV Rate (%)';
$_['entry_discount_mode']       = 'Discount Handling';
$_['entry_unit_code']           = 'Default Unit Code';
$_['entry_exemption_code']      = 'KDV Exemption Code';
$_['entry_exemption_reason']    = 'KDV Exemption Reason';

// Entry - Buyer
$_['entry_cf_vkn']              = 'VKN Custom Field';
$_['entry_cf_tckn']             = 'TCKN Custom Field';
$_['entry_cf_tax_office']       = 'Tax Office Custom Field';
$_['entry_use_default_tckn']    = 'Use 11111111111 when TCKN is unknown';
$_['entry_earsiv_send_type']    = 'e-Arşiv Delivery Type';
$_['entry_earsiv_internet']     = 'Add internet-sale notes';
$_['entry_payment_means_code']  = 'Payment Means Code (e-Arşiv)';

// Entry - Filter / Batch
$_['entry_order_id']            = 'Order ID';
$_['entry_customer']            = 'Customer';
$_['entry_order_status']        = 'Order Status';
$_['entry_date_from']           = 'Date From';
$_['entry_date_to']             = 'Date To';
$_['entry_scenario']            = 'Document Type';

// Columns
$_['column_order_id']           = 'Order ID';
$_['column_customer']           = 'Customer';
$_['column_status']             = 'Status';
$_['column_total']              = 'Total';
$_['column_date_added']         = 'Date Added';
$_['column_efatura_no']         = 'e-Fatura No';
$_['column_earsiv_no']          = 'e-Arşiv No';
$_['column_action']             = 'Action';

// Help
$_['help_profile']              = 'GİB e-Fatura scenario. Use TİCARİFATURA or TEMELFATURA when the buyer is a registered e-Fatura taxpayer; otherwise use the e-Arşiv button (ProfileID becomes EARSIVFATURA automatically).';
$_['help_invoice_type']         = 'SATIS is used for normal sales.';
$_['help_currency']             = 'Turkish e-invoices are issued in TRY. If your store base currency is not TRY, fill in the conversion rate below.';
$_['help_exchange_rate']        = 'Multiplier from your store base currency to TRY. Ignored when the base currency already matches the document currency.';
$_['help_supplier_vkn']         = 'Enter a 10 digit VKN for companies or an 11 digit TCKN for sole traders.';
$_['help_serial']               = 'Per GİB rules the invoice number is a 3 character serial prefix + 4 digit year + 9 digit sequence, e.g. EFT2026000000001. Uppercase letters and digits only.';
$_['help_start_no']             = 'Sequence number of the first invoice in this serial. Numbers increase automatically and are stored once per order, so re-downloading a document never changes its number or ETTN.';
$_['help_kdv_rate']             = 'Used when the KDV rate cannot be derived from the order line. Per-line rates are derived from the tax amounts stored on the OpenCart order.';
$_['help_discount_mode']        = 'For coupons and vouchers: "distribute" reduces the taxable base proportionally so the document totals match the order total.';
$_['help_unit_code']            = 'UN/ECE Rec 20 unit code. C62 or NIU are commonly used for "piece".';
$_['help_exemption']            = 'Only written on lines with 0% KDV. Take the code and reason from the current GİB exemption code list.';
$_['help_cf_vkn']               = 'Select the OpenCart custom field holding the buyer VKN. A 10 digit value makes the document a corporate (VKN) invoice.';
$_['help_cf_tckn']              = 'Select the OpenCart custom field holding the buyer TCKN. An 11 digit value makes the document an individual (TCKN) invoice.';
$_['help_use_default_tckn']     = 'On e-Arşiv documents, write the widely accepted 11111111111 placeholder when the buyer TCKN is unknown.';
$_['help_batch']                = 'Generates XML for every order in the selected date range and downloads them as a single ZIP. The archive also contains _report.csv listing invoice numbers and warnings.';
$_['help_batch_limit']          = 'Maximum number of orders processed in one run. Lower it if your server times out.';

// Buttons
$_['button_save']               = 'Save';
$_['button_filter']             = 'Filter';
$_['button_efatura']            = 'Generate e-Fatura XML';
$_['button_earsiv']             = 'Generate e-Arşiv XML';
$_['button_check']              = 'Validate';
$_['button_batch']              = 'Download ZIP';
$_['button_view']               = 'View order';

// Validation result
$_['text_check_title']          = 'Document Validation Result';
$_['text_check_ok']             = 'The XML is well-formed and the UBL-TR 1.2 Invoice root was verified.';
$_['text_check_fail']           = 'The XML could not be validated.';
$_['text_check_invoice_no']     = 'Invoice No';
$_['text_check_uuid']           = 'ETTN (UUID)';
$_['text_check_profile']        = 'Scenario';
$_['text_check_payable']        = 'Payable Amount';
$_['text_check_order_total']    = 'Order Total';
$_['text_check_size']           = 'Document size (bytes)';

// Warnings (codes returned by the model)
$_['warning_total_mismatch']    = 'Warning: the calculated payable amount does not exactly match the order total. Check the order totals and your KDV settings.';
$_['warning_missing_tckn']      = 'Warning: no buyer VKN/TCKN was found. Map the custom fields on the Buyer Fields tab.';
$_['warning_default_tckn']      = 'Notice: the buyer TCKN was unknown, so 11111111111 was used.';
$_['warning_unknown_total']     = 'Warning: an unrecognised order total row was added to the invoice at the default KDV rate.';
$_['warning_discount_exceeds']  = 'Warning: the discount exceeds the line totals, so line amounts were reduced to zero.';
$_['warning_exchange_rate']     = 'Warning: the store base currency differs from the document currency but the conversion rate is still 1.';

// Errors
$_['error_permission']          = 'Warning: You do not have permission to modify this extension!';
$_['error_order']               = 'Invalid order ID.';
$_['error_order_missing']       = 'Order not found.';
$_['error_no_lines']            = 'The order has no invoiceable lines.';
$_['error_generate']            = 'The document could not be generated.';
$_['error_vkn']                 = 'VKN must be 10 digits, TCKN 11 digits!';
$_['error_supplier_name']       = 'Legal name must be at least 3 characters!';
$_['error_tax_office']          = 'Tax office is required!';
$_['error_serial']              = 'The serial prefix must be exactly 3 uppercase letters or digits!';
$_['error_rate']                = 'The KDV rate must be between 0 and 100!';
$_['error_exchange_rate']       = 'The conversion rate must be greater than zero!';
$_['error_start_no']            = 'The starting sequence number must be a positive integer!';
$_['error_date']                = 'Select a valid date range (YYYY-MM-DD)!';
$_['error_date_range']          = 'The start date cannot be later than the end date!';
$_['error_batch_empty']         = 'No exportable orders were found in the selected range.';
$_['error_zip']                 = 'Batch export is unavailable because the PHP ZipArchive class is missing.';
$_['error_zip_create']          = 'The ZIP file could not be created. Check the write permissions on the storage directory.';
