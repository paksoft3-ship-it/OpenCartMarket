<?php
namespace Opencart\Admin\Model\Extension\Novakur\Feed;

/**
 * NovaKur e-Fatura / e-Arsiv Fatura
 *
 * Builds UBL-TR 1.2 compliant Invoice documents from OpenCart 4 orders.
 *
 * IMPORTANT: the generated document is structurally UBL-TR 1.2 but it is NOT
 * digitally signed. The mali muhur / e-imza is applied by the GIB portal or by
 * your integrator. Always validate against the current GIB schematron package
 * before using the output in production.
 */
class Efatura extends \Opencart\System\Engine\Model {
	const NS_INV = 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2';
	const NS_CAC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2';
	const NS_CBC = 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2';
	const NS_EXT = 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2';

	/**
	 * Order total codes that are billed to the customer as an extra invoice line.
	 */
	const CHARGE_CODES = ['shipping', 'handling', 'low_order_fee', 'klarna_fee'];

	/**
	 * Order total codes that are never rendered (they are structural, not billable).
	 */
	const SKIP_CODES = ['sub_total', 'total', 'tax'];

	/**
	 * Build
	 *
	 * Generates the UBL-TR 1.2 XML document for one order.
	 *
	 * @param int                  $order_id
	 * @param string               $scenario 'efatura' or 'earsiv'
	 * @param array<string, mixed> $setting  resolved extension settings
	 * @param bool                 $reserve  false = dry run, never allocates a number
	 *
	 * @return array<string, mixed>
	 */
	public function build(int $order_id, string $scenario, array $setting, bool $reserve = true): array {
		$result = [
			'order_id'    => $order_id,
			'scenario'    => $scenario,
			'preview'     => false,
			'profile_id'  => '',
			'invoice_no'  => '',
			'uuid'        => '',
			'filename'    => '',
			'xml'         => '',
			'well_formed' => false,
			'errors'      => [],
			'warnings'    => [],
			'payable'     => 0.0,
			'order_total' => 0.0
		];

		if ($scenario !== 'earsiv') {
			$scenario = 'efatura';
			$result['scenario'] = $scenario;
		}

		$this->load->model('sale/order');

		$order_info = $this->model_sale_order->getOrder($order_id);

		if (!$order_info) {
			$result['errors'][] = 'error_order_missing';

			return $result;
		}

		$profile_id = $scenario == 'earsiv' ? 'EARSIVFATURA' : (string)($setting['feed_efatura_profile'] ?? 'TICARIFATURA');

		if (!in_array($profile_id, ['TEMELFATURA', 'TICARIFATURA', 'IHRACAT', 'YOLCUBERABERFATURA', 'KAMU', 'EARSIVFATURA'], true)) {
			$profile_id = 'TICARIFATURA';
		}

		$result['profile_id'] = $profile_id;

		$currency = strtoupper(substr((string)($setting['feed_efatura_currency'] ?? 'TRY'), 0, 3)) ?: 'TRY';
		$rate = (float)($setting['feed_efatura_exchange_rate'] ?? 1);

		if ($rate <= 0) {
			$rate = 1.0;
		}

		if (strtoupper((string)$this->config->get('config_currency')) == $currency) {
			$rate = 1.0;
		} elseif ($rate == 1.0) {
			$result['warnings'][] = 'warning_exchange_rate';
		}

		$issue_stamp = strtotime((string)$order_info['date_added']) ?: time();

		// Reserve (or re-use) the legal invoice number + ETTN for this order/scenario.
		$serial = $scenario == 'earsiv' ? (string)($setting['feed_efatura_earsiv_serial'] ?? 'EAR') : (string)($setting['feed_efatura_serial'] ?? 'EFT');
		$serial = strtoupper(preg_replace('/[^A-Z0-9]/', '', strtoupper($serial)));
		$serial = substr(str_pad($serial !== '' ? $serial : 'EFT', 3, 'X'), 0, 3);

		$record = $this->reserve($order_id, $scenario, $serial, (int)($setting['feed_efatura_start_no'] ?? 1), $profile_id, $issue_stamp, $currency, $reserve);

		$result['invoice_no'] = $record['invoice_no'];
		$result['uuid'] = $record['uuid'];
		$result['preview'] = empty($record['efatura_id']);

		// ------------------------------------------------------------------
		// Amount model
		// ------------------------------------------------------------------
		$default_rate = $this->normaliseRate((float)($setting['feed_efatura_kdv_rate'] ?? 20));
		$shipping_rate = $this->normaliseRate((float)($setting['feed_efatura_shipping_kdv_rate'] ?? $default_rate));
		$unit_code = (string)($setting['feed_efatura_unit_code'] ?? 'C62') ?: 'C62';

		$lines = [];

		foreach ($order_info['products'] as $product) {
			$quantity = (float)$product['quantity'];

			if ($quantity <= 0) {
				$quantity = 1.0;
			}

			$unit_price = (float)$product['price'] * $rate;
			$unit_tax = (float)$product['tax'] * $rate;
			$line_amount = (float)$product['total'] * $rate;

			if ($unit_price > 0) {
				$kdv = $this->normaliseRate(($unit_tax / $unit_price) * 100);
			} else {
				$kdv = $unit_tax > 0 ? $default_rate : 0.0;
			}

			$lines[] = [
				'name'       => trim((string)$product['name']) !== '' ? (string)$product['name'] : '-',
				'code'       => (string)$product['model'],
				'quantity'   => $quantity,
				'unit_code'  => $unit_code,
				'unit_price' => $unit_price,
				'amount'     => $line_amount,
				'tax'        => $unit_tax * $quantity,
				'kdv'        => $kdv
			];
		}

		$allowances = [];
		$totals = $this->model_sale_order->getTotals($order_id);

		foreach ($totals as $total) {
			$code = (string)$total['code'];

			if (in_array($code, self::SKIP_CODES, true)) {
				continue;
			}

			$value = (float)$total['value'] * $rate;

			if (abs($value) < 0.005) {
				continue;
			}

			$title = trim((string)$total['title']) !== '' ? (string)$total['title'] : $code;

			if ($value > 0 && in_array($code, self::CHARGE_CODES, true)) {
				$kdv = $shipping_rate;

				$lines[] = [
					'name'       => $title,
					'code'       => strtoupper($code),
					'quantity'   => 1.0,
					'unit_code'  => 'C62',
					'unit_price' => $value,
					'amount'     => $value,
					'tax'        => round($value * $kdv / 100, 2),
					'kdv'        => $kdv
				];
			} elseif ($value < 0) {
				$allowances[] = ['reason' => $title, 'amount' => abs($value)];
			} else {
				// An unrecognised positive total (custom extension). Bill it at the
				// default rate rather than silently losing money from the document.
				$lines[] = [
					'name'       => $title,
					'code'       => strtoupper($code),
					'quantity'   => 1.0,
					'unit_code'  => 'C62',
					'unit_price' => $value,
					'amount'     => $value,
					'tax'        => round($value * $default_rate / 100, 2),
					'kdv'        => $default_rate
				];

				$result['warnings'][] = 'warning_unknown_total';
			}
		}

		if (!$lines) {
			$result['errors'][] = 'error_no_lines';

			return $result;
		}

		$gross_lines = 0.0;

		foreach ($lines as $line) {
			$gross_lines += $line['amount'];
		}

		$allowance_total = 0.0;

		foreach ($allowances as $allowance) {
			$allowance_total += $allowance['amount'];
		}

		$distribute = ($setting['feed_efatura_discount_mode'] ?? 'distribute') == 'distribute';

		if ($distribute && $allowance_total > 0 && $gross_lines > 0) {
			// Spread the discount proportionally over the lines so that the tax base
			// of every KDV rate is reduced the same way OpenCart reduces it.
			$factor = ($gross_lines - $allowance_total) / $gross_lines;

			if ($factor < 0) {
				$factor = 0.0;
				$result['warnings'][] = 'warning_discount_exceeds';
			}

			$reason = [];

			foreach ($allowances as $allowance) {
				$reason[] = $allowance['reason'];
			}

			foreach ($lines as $key => $line) {
				$net = round($line['amount'] * $factor, 2);

				$lines[$key]['allowance'] = round($line['amount'] - $net, 2);
				$lines[$key]['allowance_reason'] = implode(', ', $reason);
				$lines[$key]['base'] = $line['amount'];
				$lines[$key]['amount'] = $net;
				$lines[$key]['tax'] = round($net * $line['kdv'] / 100, 2);
			}

			$allowances = [];
			$allowance_total = 0.0;
		}

		$line_extension = 0.0;
		$tax_total = 0.0;
		$breakdown = [];

		foreach ($lines as $key => $line) {
			$amount = round($line['amount'], 2);
			$tax = round($line['tax'], 2);

			$lines[$key]['amount'] = $amount;
			$lines[$key]['tax'] = $tax;

			$line_extension += $amount;
			$tax_total += $tax;

			$bucket = number_format($line['kdv'], 2, '.', '');

			if (!isset($breakdown[$bucket])) {
				$breakdown[$bucket] = ['percent' => $line['kdv'], 'taxable' => 0.0, 'tax' => 0.0];
			}

			$breakdown[$bucket]['taxable'] += $amount;
			$breakdown[$bucket]['tax'] += $tax;
		}

		krsort($breakdown, SORT_NUMERIC);

		$line_extension = round($line_extension, 2);
		$tax_total = round($tax_total, 2);
		$allowance_total = round($allowance_total, 2);
		$tax_exclusive = round($line_extension - $allowance_total, 2);
		$tax_inclusive = round($tax_exclusive + $tax_total, 2);
		$payable = $tax_inclusive;

		$order_total = round((float)$order_info['total'] * $rate, 2);

		$result['payable'] = $payable;
		$result['order_total'] = $order_total;

		if (abs($payable - $order_total) > 0.01) {
			$result['warnings'][] = 'warning_total_mismatch';
		}

		// ------------------------------------------------------------------
		// Document
		// ------------------------------------------------------------------
		$doc = new \DOMDocument('1.0', 'UTF-8');
		$doc->formatOutput = true;

		$root = $doc->createElementNS(self::NS_INV, 'Invoice');
		$doc->appendChild($root);

		$root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cac', self::NS_CAC);
		$root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:cbc', self::NS_CBC);
		$root->setAttributeNS('http://www.w3.org/2000/xmlns/', 'xmlns:ext', self::NS_EXT);

		// Empty extension slot: this is where the mali muhur / e-imza is placed
		// later by the GIB portal or the integrator.
		$extensions = $this->add($doc, $root, 'ext:UBLExtensions');
		$extension = $this->add($doc, $extensions, 'ext:UBLExtension');
		$this->add($doc, $extension, 'ext:ExtensionContent');

		$this->add($doc, $root, 'cbc:UBLVersionID', '2.1');
		$this->add($doc, $root, 'cbc:CustomizationID', 'TR1.2');
		$this->add($doc, $root, 'cbc:ProfileID', $profile_id);
		$this->add($doc, $root, 'cbc:ID', $record['invoice_no']);
		$this->add($doc, $root, 'cbc:CopyIndicator', 'false');
		$this->add($doc, $root, 'cbc:UUID', $record['uuid']);
		$this->add($doc, $root, 'cbc:IssueDate', date('Y-m-d', $issue_stamp));
		$this->add($doc, $root, 'cbc:IssueTime', date('H:i:s', $issue_stamp));

		$invoice_type = (string)($setting['feed_efatura_invoice_type'] ?? 'SATIS');

		if (!in_array($invoice_type, ['SATIS', 'IADE', 'TEVKIFAT', 'ISTISNA', 'OZELMATRAH', 'IHRACKAYITLI', 'SGK', 'KOMISYONCU'], true)) {
			$invoice_type = 'SATIS';
		}

		$this->add($doc, $root, 'cbc:InvoiceTypeCode', $invoice_type);

		foreach ($this->buildNotes($order_info, $scenario, $setting, $payable, $currency) as $note) {
			$this->add($doc, $root, 'cbc:Note', $note);
		}

		$this->add($doc, $root, 'cbc:DocumentCurrencyCode', $currency);
		$this->add($doc, $root, 'cbc:LineCountNumeric', (string)count($lines));

		// Order reference
		$order_reference = $this->add($doc, $root, 'cac:OrderReference');
		$this->add($doc, $order_reference, 'cbc:ID', (string)$order_id);
		$this->add($doc, $order_reference, 'cbc:IssueDate', date('Y-m-d', $issue_stamp));

		// Signature placeholder (points at the yet-to-be-applied signature).
		$supplier = $this->supplierData($setting);

		$signature = $this->add($doc, $root, 'cac:Signature');
		$this->add($doc, $signature, 'cbc:ID', $supplier['id'], ['schemeID' => 'VKN_TCKN']);
		$signatory = $this->add($doc, $signature, 'cac:SignatoryParty');
		$signatory_identification = $this->add($doc, $signatory, 'cac:PartyIdentification');
		$this->add($doc, $signatory_identification, 'cbc:ID', $supplier['id'], ['schemeID' => $supplier['scheme']]);
		$signatory_address = $this->add($doc, $signatory, 'cac:PostalAddress');
		$this->add($doc, $signatory_address, 'cbc:CitySubdivisionName', $supplier['district'] ?: '-');
		$this->add($doc, $signatory_address, 'cbc:CityName', $supplier['city'] ?: '-');
		$signatory_country = $this->add($doc, $signatory_address, 'cac:Country');
		$this->add($doc, $signatory_country, 'cbc:Name', $supplier['country'] ?: 'Türkiye');
		$attachment = $this->add($doc, $signature, 'cac:DigitalSignatureAttachment');
		$external = $this->add($doc, $attachment, 'cac:ExternalReference');
		$this->add($doc, $external, 'cbc:URI', '#Signature');

		// Parties
		$this->addSupplierParty($doc, $root, $supplier);
		$this->addCustomerParty($doc, $root, $order_info, $scenario, $setting, $result);

		// Payment means (mainly relevant for e-Arsiv internet sales).
		$payment_means_code = trim((string)($setting['feed_efatura_payment_means_code'] ?? ''));

		if ($payment_means_code !== '' && $scenario == 'earsiv') {
			$payment_means = $this->add($doc, $root, 'cac:PaymentMeans');
			$this->add($doc, $payment_means, 'cbc:PaymentMeansCode', $payment_means_code);
			$this->add($doc, $payment_means, 'cbc:PaymentDueDate', date('Y-m-d', $issue_stamp));
		}

		// Document level allowances (only reached when discount mode = allowance).
		foreach ($allowances as $allowance) {
			$allowance_charge = $this->add($doc, $root, 'cac:AllowanceCharge');
			$this->add($doc, $allowance_charge, 'cbc:ChargeIndicator', 'false');
			$this->add($doc, $allowance_charge, 'cbc:AllowanceChargeReason', $allowance['reason']);
			$this->add($doc, $allowance_charge, 'cbc:Amount', $this->money($allowance['amount']), ['currencyID' => $currency]);
			$this->add($doc, $allowance_charge, 'cbc:BaseAmount', $this->money($line_extension), ['currencyID' => $currency]);
		}

		// Tax total + KDV breakdown
		$tax_total_element = $this->add($doc, $root, 'cac:TaxTotal');
		$this->add($doc, $tax_total_element, 'cbc:TaxAmount', $this->money($tax_total), ['currencyID' => $currency]);

		foreach ($breakdown as $group) {
			$subtotal = $this->add($doc, $tax_total_element, 'cac:TaxSubtotal');
			$this->add($doc, $subtotal, 'cbc:TaxableAmount', $this->money($group['taxable']), ['currencyID' => $currency]);
			$this->add($doc, $subtotal, 'cbc:TaxAmount', $this->money($group['tax']), ['currencyID' => $currency]);
			$this->add($doc, $subtotal, 'cbc:Percent', $this->money($group['percent']));
			$this->addTaxCategory($doc, $subtotal, $group['percent'], $setting);
		}

		// Monetary totals
		$monetary = $this->add($doc, $root, 'cac:LegalMonetaryTotal');
		$this->add($doc, $monetary, 'cbc:LineExtensionAmount', $this->money($line_extension), ['currencyID' => $currency]);
		$this->add($doc, $monetary, 'cbc:TaxExclusiveAmount', $this->money($tax_exclusive), ['currencyID' => $currency]);
		$this->add($doc, $monetary, 'cbc:TaxInclusiveAmount', $this->money($tax_inclusive), ['currencyID' => $currency]);
		$this->add($doc, $monetary, 'cbc:AllowanceTotalAmount', $this->money($allowance_total), ['currencyID' => $currency]);
		$this->add($doc, $monetary, 'cbc:PayableAmount', $this->money($payable), ['currencyID' => $currency]);

		// Lines
		$number = 0;

		foreach ($lines as $line) {
			$number++;

			$element = $this->add($doc, $root, 'cac:InvoiceLine');
			$this->add($doc, $element, 'cbc:ID', (string)$number);
			$this->add($doc, $element, 'cbc:InvoicedQuantity', $this->money($line['quantity'], 3), ['unitCode' => $line['unit_code']]);
			$this->add($doc, $element, 'cbc:LineExtensionAmount', $this->money($line['amount']), ['currencyID' => $currency]);

			if (!empty($line['allowance']) && $line['allowance'] > 0) {
				$allowance_charge = $this->add($doc, $element, 'cac:AllowanceCharge');
				$this->add($doc, $allowance_charge, 'cbc:ChargeIndicator', 'false');
				$this->add($doc, $allowance_charge, 'cbc:AllowanceChargeReason', (string)$line['allowance_reason']);
				$this->add($doc, $allowance_charge, 'cbc:Amount', $this->money($line['allowance']), ['currencyID' => $currency]);
				$this->add($doc, $allowance_charge, 'cbc:BaseAmount', $this->money($line['base']), ['currencyID' => $currency]);
			}

			$line_tax = $this->add($doc, $element, 'cac:TaxTotal');
			$this->add($doc, $line_tax, 'cbc:TaxAmount', $this->money($line['tax']), ['currencyID' => $currency]);
			$line_subtotal = $this->add($doc, $line_tax, 'cac:TaxSubtotal');
			$this->add($doc, $line_subtotal, 'cbc:TaxableAmount', $this->money($line['amount']), ['currencyID' => $currency]);
			$this->add($doc, $line_subtotal, 'cbc:TaxAmount', $this->money($line['tax']), ['currencyID' => $currency]);
			$this->add($doc, $line_subtotal, 'cbc:Percent', $this->money($line['kdv']));
			$this->addTaxCategory($doc, $line_subtotal, $line['kdv'], $setting);

			$item = $this->add($doc, $element, 'cac:Item');
			$this->add($doc, $item, 'cbc:Name', $this->text($line['name'], 500));

			$item_code = $this->text((string)$line['code'], 64);

			if ($item_code !== '') {
				$seller = $this->add($doc, $item, 'cac:SellersItemIdentification');
				$this->add($doc, $seller, 'cbc:ID', $item_code);
			}

			$price = $this->add($doc, $element, 'cac:Price');
			$this->add($doc, $price, 'cbc:PriceAmount', $this->money($line['unit_price'], 4), ['currencyID' => $currency]);
		}

		$xml = (string)$doc->saveXML();

		// ------------------------------------------------------------------
		// Well-formedness check: re-parse what we are about to hand out.
		// ------------------------------------------------------------------
		$check = $this->validate($xml);

		$result['well_formed'] = $check['well_formed'];
		$result['errors'] = array_merge($result['errors'], $check['errors']);
		$result['xml'] = $xml;
		$result['filename'] = $record['invoice_no'] . '-' . ($scenario == 'earsiv' ? 'earsiv' : 'efatura') . '.xml';

		if (!empty($record['efatura_id'])) {
			$this->touch((int)$record['efatura_id'], $payable, $currency);
		}

		return $result;
	}

	/**
	 * Validate
	 *
	 * Re-parses generated XML with DOMDocument and reports libxml errors.
	 *
	 * @param string $xml
	 *
	 * @return array<string, mixed>
	 */
	public function validate(string $xml): array {
		$previous = libxml_use_internal_errors(true);
		libxml_clear_errors();

		$doc = new \DOMDocument();
		$loaded = $doc->loadXML($xml, LIBXML_NONET);

		$errors = [];

		foreach (libxml_get_errors() as $error) {
			$errors[] = trim($error->message) . ' (line ' . $error->line . ')';
		}

		libxml_clear_errors();
		libxml_use_internal_errors($previous);

		$well_formed = (bool)$loaded && !$errors;

		if ($well_formed) {
			// Sanity check the structural contract we promise: UBL-TR 1.2 root.
			$root = $doc->documentElement;

			if (!$root || $root->localName != 'Invoice' || $root->namespaceURI != self::NS_INV) {
				$well_formed = false;
				$errors[] = 'Root element is not a UBL Invoice.';
			}
		}

		return ['well_formed' => $well_formed, 'errors' => $errors];
	}

	/**
	 * Reserve
	 *
	 * Allocates (once) the legal invoice number and ETTN for an order/scenario
	 * pair. Re-generating the same document must never change these values.
	 *
	 * @param int    $order_id
	 * @param string $scenario
	 * @param string $serial
	 * @param int    $start_no
	 * @param string $profile_id
	 * @param int    $issue_stamp
	 * @param string $currency
	 * @param bool   $persist    false = return a preview number without storing it
	 *
	 * @return array<string, mixed>
	 */
	public function reserve(int $order_id, string $scenario, string $serial, int $start_no, string $profile_id, int $issue_stamp, string $currency, bool $persist = true): array {
		$existing = $this->db->query("SELECT * FROM `" . DB_PREFIX . "novakur_efatura` WHERE `order_id` = '" . (int)$order_id . "' AND `scenario` = '" . $this->db->escape($scenario) . "'");

		if ($existing->num_rows) {
			return $existing->row;
		}

		$year = (int)date('Y', $issue_stamp);

		if ($start_no < 1) {
			$start_no = 1;
		}

		$max = $this->db->query("SELECT MAX(`sequence_no`) AS `sequence_no` FROM `" . DB_PREFIX . "novakur_efatura` WHERE `serial` = '" . $this->db->escape($serial) . "' AND `year` = '" . (int)$year . "'");

		if ($max->row && $max->row['sequence_no']) {
			$sequence_no = (int)$max->row['sequence_no'] + 1;
		} else {
			$sequence_no = $start_no;
		}

		$invoice_no = $serial . $year . str_pad((string)$sequence_no, 9, '0', STR_PAD_LEFT);
		$uuid = $this->uuid();

		if (!$persist) {
			// Dry run: hand back what WOULD be issued without consuming the number.
			return [
				'efatura_id'  => 0,
				'order_id'    => $order_id,
				'scenario'    => $scenario,
				'profile_id'  => $profile_id,
				'invoice_no'  => $invoice_no,
				'uuid'        => $uuid,
				'serial'      => $serial,
				'year'        => $year,
				'sequence_no' => $sequence_no
			];
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "novakur_efatura` SET `order_id` = '" . (int)$order_id . "', `scenario` = '" . $this->db->escape($scenario) . "', `profile_id` = '" . $this->db->escape($profile_id) . "', `invoice_no` = '" . $this->db->escape($invoice_no) . "', `uuid` = '" . $this->db->escape($uuid) . "', `serial` = '" . $this->db->escape($serial) . "', `year` = '" . (int)$year . "', `sequence_no` = '" . (int)$sequence_no . "', `currency_code` = '" . $this->db->escape($currency) . "', `date_added` = NOW(), `date_modified` = NOW()");

		return [
			'efatura_id'  => (int)$this->db->getLastId(),
			'order_id'    => $order_id,
			'scenario'    => $scenario,
			'profile_id'  => $profile_id,
			'invoice_no'  => $invoice_no,
			'uuid'        => $uuid,
			'serial'      => $serial,
			'year'        => $year,
			'sequence_no' => $sequence_no
		];
	}

	/**
	 * Touch
	 *
	 * @param int    $efatura_id
	 * @param float  $payable
	 * @param string $currency
	 *
	 * @return void
	 */
	public function touch(int $efatura_id, float $payable, string $currency): void {
		$this->db->query("UPDATE `" . DB_PREFIX . "novakur_efatura` SET `payable_amount` = '" . (float)$payable . "', `currency_code` = '" . $this->db->escape($currency) . "', `date_modified` = NOW() WHERE `efatura_id` = '" . (int)$efatura_id . "'");
	}

	/**
	 * Has Table
	 *
	 * The ledger is created by the controller's install(). Reading it before the
	 * extension has been installed must not blow up the settings page.
	 *
	 * @return bool
	 */
	public function hasTable(): bool {
		$query = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'novakur_efatura') . "'");

		return (bool)$query->num_rows;
	}

	/**
	 * Get Records By Order
	 *
	 * @param array<int, int> $order_ids
	 *
	 * @return array<int, array<string, array<string, mixed>>>
	 */
	public function getRecordsByOrder(array $order_ids): array {
		$order_ids = array_filter(array_map('intval', $order_ids));

		if (!$order_ids || !$this->hasTable()) {
			return [];
		}

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "novakur_efatura` WHERE `order_id` IN (" . implode(',', $order_ids) . ")");

		$records = [];

		foreach ($query->rows as $row) {
			$records[(int)$row['order_id']][(string)$row['scenario']] = $row;
		}

		return $records;
	}

	/**
	 * Get Total Documents
	 *
	 * @return int
	 */
	public function getTotalDocuments(): int {
		if (!$this->hasTable()) {
			return 0;
		}

		$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "novakur_efatura`");

		return (int)$query->row['total'];
	}

	/**
	 * Get Last Sequence
	 *
	 * @param string $serial
	 *
	 * @return int
	 */
	public function getLastSequence(string $serial): int {
		if (!$this->hasTable()) {
			return 0;
		}

		$query = $this->db->query("SELECT MAX(`sequence_no`) AS `sequence_no` FROM `" . DB_PREFIX . "novakur_efatura` WHERE `serial` = '" . $this->db->escape($serial) . "' AND `year` = '" . (int)date('Y') . "'");

		return (int)($query->row['sequence_no'] ?? 0);
	}

	// ----------------------------------------------------------------------
	// Party builders
	// ----------------------------------------------------------------------

	/**
	 * Supplier Data
	 *
	 * @param array<string, mixed> $setting
	 *
	 * @return array<string, string>
	 */
	protected function supplierData(array $setting): array {
		$id = preg_replace('/[^0-9]/', '', (string)($setting['feed_efatura_supplier_vkn'] ?? ''));

		return [
			'id'          => $id,
			'scheme'      => strlen($id) == 11 ? 'TCKN' : 'VKN',
			'name'        => trim((string)($setting['feed_efatura_supplier_name'] ?? '')),
			'tax_office'  => trim((string)($setting['feed_efatura_supplier_tax_office'] ?? '')),
			'mersis'      => trim((string)($setting['feed_efatura_supplier_mersis'] ?? '')),
			'sicil'       => trim((string)($setting['feed_efatura_supplier_sicil'] ?? '')),
			'street'      => trim((string)($setting['feed_efatura_supplier_street'] ?? '')),
			'building'    => trim((string)($setting['feed_efatura_supplier_building'] ?? '')),
			'district'    => trim((string)($setting['feed_efatura_supplier_district'] ?? '')),
			'city'        => trim((string)($setting['feed_efatura_supplier_city'] ?? '')),
			'postcode'    => trim((string)($setting['feed_efatura_supplier_postcode'] ?? '')),
			'country'     => trim((string)($setting['feed_efatura_supplier_country'] ?? '')) ?: 'Türkiye',
			'phone'       => trim((string)($setting['feed_efatura_supplier_phone'] ?? '')),
			'email'       => trim((string)($setting['feed_efatura_supplier_email'] ?? '')),
			'website'     => trim((string)($setting['feed_efatura_supplier_website'] ?? ''))
		];
	}

	/**
	 * Add Supplier Party
	 *
	 * @param \DOMDocument          $doc
	 * @param \DOMElement           $root
	 * @param array<string, string> $supplier
	 *
	 * @return void
	 */
	protected function addSupplierParty(\DOMDocument $doc, \DOMElement $root, array $supplier): void {
		$wrapper = $this->add($doc, $root, 'cac:AccountingSupplierParty');
		$party = $this->add($doc, $wrapper, 'cac:Party');

		if ($supplier['website'] !== '') {
			$this->add($doc, $party, 'cbc:WebsiteURI', $supplier['website']);
		}

		$identification = $this->add($doc, $party, 'cac:PartyIdentification');
		$this->add($doc, $identification, 'cbc:ID', $supplier['id'], ['schemeID' => $supplier['scheme']]);

		if ($supplier['mersis'] !== '') {
			$mersis = $this->add($doc, $party, 'cac:PartyIdentification');
			$this->add($doc, $mersis, 'cbc:ID', $supplier['mersis'], ['schemeID' => 'MERSISNO']);
		}

		if ($supplier['sicil'] !== '') {
			$sicil = $this->add($doc, $party, 'cac:PartyIdentification');
			$this->add($doc, $sicil, 'cbc:ID', $supplier['sicil'], ['schemeID' => 'TICARETSICILNO']);
		}

		$name = $this->add($doc, $party, 'cac:PartyName');
		$this->add($doc, $name, 'cbc:Name', $supplier['name'] !== '' ? $supplier['name'] : '-');

		$address = $this->add($doc, $party, 'cac:PostalAddress');

		if ($supplier['street'] !== '') {
			$this->add($doc, $address, 'cbc:StreetName', $supplier['street']);
		}

		if ($supplier['building'] !== '') {
			$this->add($doc, $address, 'cbc:BuildingNumber', $supplier['building']);
		}

		$this->add($doc, $address, 'cbc:CitySubdivisionName', $supplier['district'] !== '' ? $supplier['district'] : '-');
		$this->add($doc, $address, 'cbc:CityName', $supplier['city'] !== '' ? $supplier['city'] : '-');

		if ($supplier['postcode'] !== '') {
			$this->add($doc, $address, 'cbc:PostalZone', $supplier['postcode']);
		}

		$country = $this->add($doc, $address, 'cac:Country');
		$this->add($doc, $country, 'cbc:Name', $supplier['country']);

		$tax_scheme_party = $this->add($doc, $party, 'cac:PartyTaxScheme');
		$tax_scheme = $this->add($doc, $tax_scheme_party, 'cac:TaxScheme');
		$this->add($doc, $tax_scheme, 'cbc:Name', $supplier['tax_office'] !== '' ? $supplier['tax_office'] : '-');

		if ($supplier['phone'] !== '' || $supplier['email'] !== '') {
			$contact = $this->add($doc, $party, 'cac:Contact');

			if ($supplier['phone'] !== '') {
				$this->add($doc, $contact, 'cbc:Telephone', $supplier['phone']);
			}

			if ($supplier['email'] !== '') {
				$this->add($doc, $contact, 'cbc:ElectronicMail', $supplier['email']);
			}
		}
	}

	/**
	 * Add Customer Party
	 *
	 * @param \DOMDocument         $doc
	 * @param \DOMElement          $root
	 * @param array<string, mixed> $order_info
	 * @param string               $scenario
	 * @param array<string, mixed> $setting
	 * @param array<string, mixed> $result
	 *
	 * @return void
	 */
	protected function addCustomerParty(\DOMDocument $doc, \DOMElement $root, array $order_info, string $scenario, array $setting, array &$result): void {
		$custom = $this->customerIdentity($order_info, $scenario, $setting, $result);

		$wrapper = $this->add($doc, $root, 'cac:AccountingCustomerParty');
		$party = $this->add($doc, $wrapper, 'cac:Party');

		$identification = $this->add($doc, $party, 'cac:PartyIdentification');
		$this->add($doc, $identification, 'cbc:ID', $custom['id'], ['schemeID' => $custom['scheme']]);

		$name = $this->add($doc, $party, 'cac:PartyName');
		$this->add($doc, $name, 'cbc:Name', $custom['name']);

		$address = $this->add($doc, $party, 'cac:PostalAddress');

		$street = trim((string)$order_info['payment_address_1'] . ' ' . (string)$order_info['payment_address_2']);

		if ($street !== '') {
			$this->add($doc, $address, 'cbc:StreetName', $this->text($street, 240));
		}

		$this->add($doc, $address, 'cbc:CitySubdivisionName', $this->text((string)$order_info['payment_zone'], 120) ?: '-');
		$this->add($doc, $address, 'cbc:CityName', $this->text((string)$order_info['payment_city'], 120) ?: '-');

		if (trim((string)$order_info['payment_postcode']) !== '') {
			$this->add($doc, $address, 'cbc:PostalZone', $this->text((string)$order_info['payment_postcode'], 20));
		}

		$country = $this->add($doc, $address, 'cac:Country');

		if (!empty($order_info['payment_iso_code_2'])) {
			$this->add($doc, $country, 'cbc:IdentificationCode', (string)$order_info['payment_iso_code_2']);
		}

		$this->add($doc, $country, 'cbc:Name', $this->text((string)$order_info['payment_country'], 120) ?: 'Türkiye');

		if ($custom['scheme'] == 'VKN' || $custom['tax_office'] !== '') {
			$tax_scheme_party = $this->add($doc, $party, 'cac:PartyTaxScheme');
			$tax_scheme = $this->add($doc, $tax_scheme_party, 'cac:TaxScheme');
			$this->add($doc, $tax_scheme, 'cbc:Name', $custom['tax_office'] !== '' ? $custom['tax_office'] : '-');
		}

		$contact = $this->add($doc, $party, 'cac:Contact');

		if (trim((string)$order_info['telephone']) !== '') {
			$this->add($doc, $contact, 'cbc:Telephone', $this->text((string)$order_info['telephone'], 40));
		}

		if (trim((string)$order_info['email']) !== '') {
			$this->add($doc, $contact, 'cbc:ElectronicMail', $this->text((string)$order_info['email'], 120));
		}

		if ($custom['scheme'] == 'TCKN') {
			$person = $this->add($doc, $party, 'cac:Person');
			$this->add($doc, $person, 'cbc:FirstName', $this->text((string)$order_info['payment_firstname'] ?: (string)$order_info['firstname'], 120) ?: '-');
			$this->add($doc, $person, 'cbc:FamilyName', $this->text((string)$order_info['payment_lastname'] ?: (string)$order_info['lastname'], 120) ?: '-');
		}
	}

	/**
	 * Customer Identity
	 *
	 * Resolves VKN / TCKN / tax office from the mapped OpenCart custom fields.
	 *
	 * @param array<string, mixed> $order_info
	 * @param string               $scenario
	 * @param array<string, mixed> $setting
	 * @param array<string, mixed> $result
	 *
	 * @return array<string, string>
	 */
	protected function customerIdentity(array $order_info, string $scenario, array $setting, array &$result): array {
		$bag = [];

		foreach (['custom_field', 'payment_custom_field'] as $key) {
			if (!empty($order_info[$key]) && is_array($order_info[$key])) {
				foreach ($order_info[$key] as $custom_field_id => $value) {
					if (is_scalar($value) && trim((string)$value) !== '') {
						$bag[(int)$custom_field_id] = trim((string)$value);
					}
				}
			}
		}

		$vkn = preg_replace('/[^0-9]/', '', (string)($bag[(int)($setting['feed_efatura_cf_vkn'] ?? 0)] ?? ''));
		$tckn = preg_replace('/[^0-9]/', '', (string)($bag[(int)($setting['feed_efatura_cf_tckn'] ?? 0)] ?? ''));
		$tax_office = (string)($bag[(int)($setting['feed_efatura_cf_tax_office'] ?? 0)] ?? '');

		$company = trim((string)$order_info['payment_company']);
		$person_name = trim((string)$order_info['payment_firstname'] . ' ' . (string)$order_info['payment_lastname']);

		if ($person_name == '') {
			$person_name = trim((string)$order_info['firstname'] . ' ' . (string)$order_info['lastname']);
		}

		if (strlen($vkn) == 10) {
			return [
				'id'         => $vkn,
				'scheme'     => 'VKN',
				'name'       => $this->text($company !== '' ? $company : $person_name, 240) ?: '-',
				'tax_office' => $this->text($tax_office, 120)
			];
		}

		if (strlen($tckn) == 11) {
			return [
				'id'         => $tckn,
				'scheme'     => 'TCKN',
				'name'       => $this->text($person_name !== '' ? $person_name : $company, 240) ?: '-',
				'tax_office' => $this->text($tax_office, 120)
			];
		}

		// No identity number on file.
		if ($scenario == 'earsiv' && (int)($setting['feed_efatura_use_default_tckn'] ?? 1)) {
			$result['warnings'][] = 'warning_default_tckn';

			return [
				'id'         => '11111111111',
				'scheme'     => 'TCKN',
				'name'       => $this->text($person_name !== '' ? $person_name : $company, 240) ?: '-',
				'tax_office' => $this->text($tax_office, 120)
			];
		}

		$result['warnings'][] = 'warning_missing_tckn';

		return [
			'id'         => '',
			'scheme'     => 'TCKN',
			'name'       => $this->text($person_name !== '' ? $person_name : $company, 240) ?: '-',
			'tax_office' => $this->text($tax_office, 120)
		];
	}

	/**
	 * Add Tax Category
	 *
	 * @param \DOMDocument         $doc
	 * @param \DOMElement          $subtotal
	 * @param float                $percent
	 * @param array<string, mixed> $setting
	 *
	 * @return void
	 */
	protected function addTaxCategory(\DOMDocument $doc, \DOMElement $subtotal, float $percent, array $setting): void {
		$category = $this->add($doc, $subtotal, 'cac:TaxCategory');

		if ($percent <= 0) {
			$code = trim((string)($setting['feed_efatura_exemption_code'] ?? ''));
			$reason = trim((string)($setting['feed_efatura_exemption_reason'] ?? ''));

			if ($code !== '') {
				$this->add($doc, $category, 'cbc:TaxExemptionReasonCode', $code);
			}

			if ($reason !== '') {
				$this->add($doc, $category, 'cbc:TaxExemptionReason', $this->text($reason, 240));
			}
		}

		$scheme = $this->add($doc, $category, 'cac:TaxScheme');
		$this->add($doc, $scheme, 'cbc:Name', 'KDV');
		$this->add($doc, $scheme, 'cbc:TaxTypeCode', '0015');
	}

	/**
	 * Build Notes
	 *
	 * @param array<string, mixed> $order_info
	 * @param string               $scenario
	 * @param array<string, mixed> $setting
	 * @param float                $payable
	 * @param string               $currency
	 *
	 * @return array<int, string>
	 */
	protected function buildNotes(array $order_info, string $scenario, array $setting, float $payable, string $currency): array {
		$notes = [];

		$notes[] = 'Yalnız ' . $this->words($payable, $currency);

		if ($scenario == 'earsiv') {
			$send_type = (string)($setting['feed_efatura_earsiv_send_type'] ?? 'ELEKTRONIK');

			if (!in_array($send_type, ['ELEKTRONIK', 'KAGIT'], true)) {
				$send_type = 'ELEKTRONIK';
			}

			$notes[] = 'Gönderim Şekli: ' . $send_type;

			if ((int)($setting['feed_efatura_earsiv_internet'] ?? 1)) {
				$notes[] = 'Bu satış internet üzerinden yapılmıştır.';

				$website = trim((string)($setting['feed_efatura_supplier_website'] ?? ''));

				if ($website !== '') {
					$notes[] = 'Web Adresi: ' . $website;
				}
			}
		}

		$custom_note = trim((string)($setting['feed_efatura_note'] ?? ''));

		if ($custom_note !== '') {
			foreach (preg_split('/\r\n|\r|\n/', $custom_note) as $line) {
				$line = trim($line);

				if ($line !== '') {
					$notes[] = $this->text($line, 500);
				}
			}
		}

		if (trim((string)$order_info['comment']) !== '') {
			$notes[] = $this->text('Sipariş Notu: ' . (string)$order_info['comment'], 500);
		}

		return $notes;
	}

	// ----------------------------------------------------------------------
	// Helpers
	// ----------------------------------------------------------------------

	/**
	 * Add
	 *
	 * @param \DOMDocument          $doc
	 * @param \DOMNode              $parent
	 * @param string                $qname
	 * @param string|null           $value
	 * @param array<string, string> $attributes
	 *
	 * @return \DOMElement
	 */
	protected function add(\DOMDocument $doc, \DOMNode $parent, string $qname, ?string $value = null, array $attributes = []): \DOMElement {
		$element = $doc->createElementNS($this->ns($qname), $qname);

		if ($value !== null && $value !== '') {
			// createTextNode escapes for us, so no unescaped data can reach the file.
			$element->appendChild($doc->createTextNode($value));
		}

		foreach ($attributes as $name => $attribute) {
			$element->setAttribute($name, (string)$attribute);
		}

		$parent->appendChild($element);

		return $element;
	}

	/**
	 * Namespace
	 *
	 * @param string $qname
	 *
	 * @return string
	 */
	protected function ns(string $qname): string {
		$position = strpos($qname, ':');

		if ($position === false) {
			return self::NS_INV;
		}

		switch (substr($qname, 0, $position)) {
			case 'cac':
				return self::NS_CAC;
			case 'cbc':
				return self::NS_CBC;
			case 'ext':
				return self::NS_EXT;
		}

		return self::NS_INV;
	}

	/**
	 * Money
	 *
	 * @param float $value
	 * @param int   $decimals
	 *
	 * @return string
	 */
	protected function money(float $value, int $decimals = 2): string {
		if (abs($value) < 0.0000001) {
			$value = 0.0;
		}

		return number_format($value, $decimals, '.', '');
	}

	/**
	 * Text
	 *
	 * Cleans a database value for use as XML character data.
	 *
	 * @param string $value
	 * @param int    $limit
	 *
	 * @return string
	 */
	protected function text(string $value, int $limit = 240): string {
		$value = html_entity_decode($value, ENT_QUOTES, 'UTF-8');
		$value = strip_tags($value);
		// Strip control characters that are illegal in XML 1.0.
		$value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $value);
		$value = trim(preg_replace('/\s+/u', ' ', (string)$value));

		return function_exists('mb_substr') ? mb_substr($value, 0, $limit, 'UTF-8') : substr($value, 0, $limit);
	}

	/**
	 * Normalise Rate
	 *
	 * Snaps a derived KDV percentage onto a clean value.
	 *
	 * @param float $rate
	 *
	 * @return float
	 */
	protected function normaliseRate(float $rate): float {
		if ($rate < 0) {
			$rate = 0.0;
		}

		if ($rate > 100) {
			$rate = 100.0;
		}

		$rate = round($rate, 2);
		$nearest = round($rate);

		if (abs($rate - $nearest) <= 0.05) {
			$rate = (float)$nearest;
		}

		return $rate;
	}

	/**
	 * UUID
	 *
	 * RFC 4122 version 4 identifier, used as the ETTN.
	 *
	 * @return string
	 */
	protected function uuid(): string {
		$bytes = random_bytes(16);

		$bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
		$bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);

		return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
	}

	/**
	 * Words
	 *
	 * Turkish "yazı ile" amount, required on the face of Turkish invoices.
	 *
	 * @param float  $amount
	 * @param string $currency
	 *
	 * @return string
	 */
	protected function words(float $amount, string $currency): string {
		$amount = round(abs($amount), 2);

		$major = (int)floor($amount);
		$minor = (int)round(($amount - $major) * 100);

		$names = $currency == 'TRY' ? ['TL', 'Kuruş'] : [$currency, 'Cent'];

		$text = $this->numberToWords($major) . ' ' . $names[0];

		if ($minor > 0) {
			$text .= ' ' . $this->numberToWords($minor) . ' ' . $names[1];
		}

		return $text;
	}

	/**
	 * Number To Words
	 *
	 * @param int $number
	 *
	 * @return string
	 */
	protected function numberToWords(int $number): string {
		if ($number == 0) {
			return 'Sıfır';
		}

		$ones = ['', 'Bir', 'İki', 'Üç', 'Dört', 'Beş', 'Altı', 'Yedi', 'Sekiz', 'Dokuz'];
		$tens = ['', 'On', 'Yirmi', 'Otuz', 'Kırk', 'Elli', 'Altmış', 'Yetmiş', 'Seksen', 'Doksan'];
		$scales = ['', 'Bin', 'Milyon', 'Milyar', 'Trilyon'];

		$groups = [];

		while ($number > 0) {
			$groups[] = $number % 1000;
			$number = intdiv($number, 1000);
		}

		$parts = [];

		for ($index = count($groups) - 1; $index >= 0; $index--) {
			$group = $groups[$index];

			if ($group == 0) {
				continue;
			}

			$chunk = '';
			$hundreds = intdiv($group, 100);
			$remainder = $group % 100;

			if ($hundreds > 0) {
				$chunk .= ($hundreds > 1 ? $ones[$hundreds] : '') . 'Yüz';
			}

			$chunk .= $tens[intdiv($remainder, 10)] . $ones[$remainder % 10];

			// Turkish drops the "Bir" in "BirBin".
			if ($index == 1 && $group == 1) {
				$chunk = '';
			}

			$parts[] = $chunk . $scales[$index];
		}

		return implode('', $parts);
	}
}
