/**
 * NovaKur Meta Pixel + CAPI Pack — storefront event layer.
 *
 * The pixel base code (fbq init) is already injected in <head> by the header
 * event. This file fires the standard events:
 *
 *   PageView          — on load
 *   ViewContent       — queued server-side on product pages
 *   InitiateCheckout  — queued server-side on the checkout page
 *   Purchase          — queued server-side on checkout/success
 *   AddToCart         — detected live by watching OpenCart's checkout/cart.add
 *                       request, then resolved server-side for the real price
 *
 * AddToCart detection hooks XMLHttpRequest and fetch rather than a specific
 * theme's button markup. jQuery's $.ajax (used by the default theme's product
 * form and by most third-party themes) runs through XMLHttpRequest, so the one
 * hook covers both, with no risk of firing the event twice.
 */
(function () {
    'use strict';

    var config = window.nkMetaAds || {};

    if (!config.pixelId || typeof window.fbq !== 'function') {
        return;
    }

    var CART_ADD = 'route=checkout/cart.add';

    function log() {
        if (config.debug && window.console && window.console.log) {
            window.console.log.apply(window.console, ['[nk-meta-ads]'].concat(Array.prototype.slice.call(arguments)));
        }
    }

    function track(name, params, eventId) {
        try {
            if (eventId) {
                window.fbq('track', name, params || {}, { eventID: eventId });
            } else {
                window.fbq('track', name, params || {});
            }

            log('track', name, params, eventId);
        } catch (e) {
            log('track failed', e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Server-queued events                                                */
    /* ------------------------------------------------------------------ */

    if (config.pageView) {
        track('PageView');
    }

    if (Object.prototype.toString.call(config.queue) === '[object Array]') {
        for (var i = 0; i < config.queue.length; i++) {
            var queued = config.queue[i];

            if (queued && queued.name) {
                track(queued.name, queued.params, queued.event_id);
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* AddToCart                                                           */
    /* ------------------------------------------------------------------ */

    if (!config.addToCart) {
        return;
    }

    function isCartAdd(url) {
        if (!url) {
            return false;
        }

        return String(url).indexOf(CART_ADD) !== -1;
    }

    /**
     * OpenCart posts an urlencoded form body. Pull product_id / quantity out of
     * whatever shape the theme happened to send.
     */
    function readBody(body) {
        var result = { product_id: 0, quantity: 1 };

        if (!body) {
            return result;
        }

        try {
            if (typeof window.FormData !== 'undefined' && body instanceof window.FormData) {
                result.product_id = parseInt(body.get('product_id'), 10) || 0;
                result.quantity = parseInt(body.get('quantity'), 10) || 1;

                return result;
            }

            if (typeof window.URLSearchParams !== 'undefined' && body instanceof window.URLSearchParams) {
                result.product_id = parseInt(body.get('product_id'), 10) || 0;
                result.quantity = parseInt(body.get('quantity'), 10) || 1;

                return result;
            }

            if (typeof body === 'string') {
                var pairs = body.split('&');

                for (var i = 0; i < pairs.length; i++) {
                    var pair = pairs[i].split('=');
                    var key = decodeURIComponent((pair[0] || '').replace(/\+/g, ' '));
                    var value = decodeURIComponent((pair[1] || '').replace(/\+/g, ' '));

                    if (key === 'product_id') {
                        result.product_id = parseInt(value, 10) || 0;
                    } else if (key === 'quantity') {
                        result.quantity = parseInt(value, 10) || 1;
                    }
                }
            }
        } catch (e) {
            log('body parse failed', e);
        }

        return result;
    }

    /**
     * OpenCart returns {"success": "..."} on a real add and {"error": {...}} when
     * options are missing or the product is out of stock. Only the former counts.
     */
    function wasAdded(responseText) {
        if (!responseText) {
            return false;
        }

        try {
            var json = JSON.parse(responseText);

            return !!(json && json.success && !json.error);
        } catch (e) {
            return false;
        }
    }

    function fallback(details) {
        track('AddToCart', {
            content_type: 'product',
            content_ids: [String(details.product_id)],
            contents: [{ id: String(details.product_id), quantity: details.quantity }]
        });
    }

    /**
     * Ask the server for the authoritative price and the event_id. The same call
     * mirrors the event to the Conversions API, so the browser event and the
     * server event share an event_id and Meta deduplicates them.
     */
    function handleCartAdd(body, responseText) {
        if (!wasAdded(responseText)) {
            return;
        }

        var details = readBody(body);

        if (!details.product_id) {
            log('cart add seen but no product_id in the request body');

            return;
        }

        if (!config.capiUrl) {
            fallback(details);

            return;
        }

        var request = new window.XMLHttpRequest();

        // Flag so our own hook ignores this request.
        request.__nkInternal = true;
        request.open('POST', config.capiUrl, true);
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        request.onreadystatechange = function () {
            if (request.readyState !== 4) {
                return;
            }

            var payload = null;

            try {
                payload = JSON.parse(request.responseText);
            } catch (e) {
                payload = null;
            }

            if (payload && payload.event_id && payload.params) {
                track('AddToCart', payload.params, payload.event_id);
            } else {
                fallback(details);
            }
        };

        request.send('product_id=' + encodeURIComponent(details.product_id) + '&quantity=' + encodeURIComponent(details.quantity));
    }

    // XMLHttpRequest hook — also covers jQuery $.ajax.
    (function () {
        var open = window.XMLHttpRequest.prototype.open;
        var send = window.XMLHttpRequest.prototype.send;

        window.XMLHttpRequest.prototype.open = function (method, url) {
            this.__nkUrl = url;

            return open.apply(this, arguments);
        };

        window.XMLHttpRequest.prototype.send = function (body) {
            var xhr = this;

            if (!xhr.__nkInternal && isCartAdd(xhr.__nkUrl)) {
                xhr.addEventListener('load', function () {
                    handleCartAdd(body, xhr.responseText);
                });
            }

            return send.apply(this, arguments);
        };
    }());

    // fetch hook — for themes that skipped jQuery.
    if (typeof window.fetch === 'function') {
        var originalFetch = window.fetch;

        window.fetch = function (input, init) {
            var url = (typeof input === 'string') ? input : (input && input.url);
            var promise = originalFetch.apply(this, arguments);

            if (isCartAdd(url) && url.indexOf('meta_ads') === -1) {
                promise.then(function (response) {
                    try {
                        response.clone().text().then(function (text) {
                            handleCartAdd(init && init.body, text);
                        });
                    } catch (e) {
                        log('fetch clone failed', e);
                    }
                }).catch(function () { /* the store's own error handling owns this */ });
            }

            return promise;
        };
    }
}());
