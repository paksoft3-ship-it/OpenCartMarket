<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Module;

/**
 * NovaKur Meta Pixel + CAPI Pack — storefront endpoints.
 *
 * cart() : called by meta_ads.js the moment OpenCart's checkout/cart.add request
 *          succeeds. It resolves the real price server-side, mirrors the event to
 *          the Conversions API and hands the browser back the event_id so the
 *          pixel AddToCart deduplicates against the server event.
 *
 * send() : token guarded cron entry point that flushes the server event queue.
 *          index.php?route=extension/novakur/module/meta_ads.send&token=xxxx
 */
class MetaAds extends \Opencart\System\Engine\Controller {
    public function cart(): void {
        $this->response->addHeader('Content-Type: application/json');

        $json = [];

        if (!(int)$this->config->get('module_meta_ads_status') || !(int)$this->config->get('module_meta_ads_event_addtocart')) {
            $this->response->setOutput(json_encode(['error' => 'disabled']));

            return;
        }

        $product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;
        $quantity   = isset($this->request->post['quantity']) ? (int)$this->request->post['quantity'] : 1;

        if ($quantity < 1) {
            $quantity = 1;
        }

        if ($quantity > 9999) {
            $quantity = 9999;
        }

        if (!$product_id) {
            $this->response->setOutput(json_encode(['error' => 'product_id required']));

            return;
        }

        $this->load->model('catalog/product');

        $product_info = $this->model_catalog_product->getProduct($product_id);

        if (!$product_info) {
            $this->response->setOutput(json_encode(['error' => 'product not found']));

            return;
        }

        $capi = new \Opencart\System\Library\Extension\Novakur\MetaAds($this->registry);

        $content_id = $this->contentId($product_id, (string)$product_info['model'], (string)$product_info['sku']);

        $price = !empty($product_info['special']) ? (float)$product_info['special'] : (float)$product_info['price'];

        if ((bool)(int)$this->config->get('module_meta_ads_value_tax')) {
            $price = (float)$this->tax->calculate($price, (int)$product_info['tax_class_id'], (bool)$this->config->get('config_tax'));
        }

        $currency   = isset($this->session->data['currency']) ? (string)$this->session->data['currency'] : (string)$this->config->get('config_currency');
        $item_price = round((float)$this->currency->format($price, $currency, 0, false), 2);

        $custom_data = [
            'content_type' => 'product',
            'content_ids'  => [$content_id],
            'contents'     => [['id' => $content_id, 'quantity' => $quantity, 'item_price' => $item_price]],
            'content_name' => html_entity_decode((string)$product_info['name'], ENT_QUOTES, 'UTF-8'),
            'value'        => round($item_price * $quantity, 2),
            'currency'     => $currency
        ];

        $event_id = $capi->makeEventId('AddToCart');

        // Server-side mirror (no-op when the Conversions API is switched off).
        $capi->dispatch('AddToCart', $event_id, $custom_data, $capi->buildUserData(), (string)$product_id);

        $json['event_id'] = $event_id;
        $json['params']   = $custom_data;

        $this->response->setOutput(\Opencart\System\Library\Extension\Novakur\MetaAds::json($json));
    }

    /**
     * Cron / queue flush. Guarded by the token setting shown in the admin form.
     */
    public function send(): void {
        $this->response->addHeader('Content-Type: text/plain; charset=utf-8');

        $token    = (string)$this->config->get('module_meta_ads_cron_token');
        $supplied = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied)) {
            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 403 Forbidden');
            $this->response->setOutput('Forbidden');

            return;
        }

        if (!(int)$this->config->get('module_meta_ads_status')) {
            $this->response->setOutput('Module disabled.');

            return;
        }

        $capi = new \Opencart\System\Library\Extension\Novakur\MetaAds($this->registry);

        if (!$capi->isEnabled()) {
            $this->response->setOutput('Conversions API disabled or not configured.');

            return;
        }

        $limit = isset($this->request->get['limit']) ? (int)$this->request->get['limit'] : 50;

        $report = $capi->flush($limit);

        $capi->prune(14);

        $this->response->setOutput('sent=' . $report['sent'] . ' failed=' . $report['failed'] . ' skipped=' . $report['skipped'] . ' | ' . $report['message']);
    }

    protected function contentId(int $product_id, string $model, string $sku): string {
        switch ((string)$this->config->get('module_meta_ads_content_id_type')) {
            case 'model':
                return $model !== '' ? $model : (string)$product_id;
            case 'sku':
                return $sku !== '' ? $sku : (string)$product_id;
            default:
                return (string)$product_id;
        }
    }
}
