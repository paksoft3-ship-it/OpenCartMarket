<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

/**
 * NovaKur Meta Pixel + CAPI Pack — storefront event wiring.
 *
 * header()       -> catalog/view/common/header/after   : injects the pixel base code + queued events
 * orderSuccess() -> catalog/controller/checkout/success/before : captures the order before the
 *                   session is cleared, fires the server-side Purchase and hands the browser the
 *                   matching event_id for deduplication.
 */
class MetaAds extends \Opencart\System\Engine\Controller {
    /**
     * Shared between the two hooks in a single request (OpenCart caches the
     * controller instance in the registry, but a static keeps it explicit).
     *
     * @var array<string, mixed>
     */
    protected static array $purchase = [];

    /* ------------------------------------------------------------------ */
    /* Hooks                                                               */
    /* ------------------------------------------------------------------ */

    /**
     * Capture the completed order before checkout/success wipes the session.
     *
     * @param array<int, mixed> $args
     */
    public function orderSuccess(string &$route, array &$args): void {
        if (!$this->isActive() || !$this->eventEnabled('purchase')) {
            return;
        }

        if (empty($this->session->data['order_id'])) {
            return;
        }

        $order_id = (int)$this->session->data['order_id'];

        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (!$order_info) {
            return;
        }

        $value_rate = (float)$order_info['currency_value'] ?: 1.0;
        $currency   = (string)$order_info['currency_code'] ?: (string)$this->config->get('config_currency');

        $content_ids = [];
        $contents    = [];
        $num_items   = 0;

        foreach ((array)$order_info['products'] as $product) {
            $content_id = $this->contentId((int)$product['product_id'], (string)$product['model'], '');

            $content_ids[] = $content_id;
            $contents[]    = [
                'id'         => $content_id,
                'quantity'   => (int)$product['quantity'],
                'item_price' => $this->money((float)$product['price'] * $value_rate)
            ];

            $num_items += (int)$product['quantity'];
        }

        $custom_data = [
            'currency'     => $currency,
            'value'        => $this->money((float)$order_info['total'] * $value_rate),
            'content_type' => 'product',
            'content_ids'  => $content_ids,
            'contents'     => $contents,
            'num_items'    => $num_items,
            'order_id'     => (string)$order_id
        ];

        $capi     = $this->capi();
        $event_id = $capi->makeEventId('Purchase', (string)$order_id);

        self::$purchase = [
            'name'     => 'Purchase',
            'event_id' => $event_id,
            'params'   => $custom_data
        ];

        // Server-side mirror — same event_id as the browser pixel event below.
        $capi->dispatch(
            'Purchase',
            $event_id,
            $custom_data,
            $capi->buildUserData([
                'em'          => (string)$order_info['email'],
                'ph'          => (string)$order_info['telephone'],
                'fn'          => (string)$order_info['firstname'],
                'ln'          => (string)$order_info['lastname'],
                'ct'          => (string)$order_info['payment_city'],
                'st'          => (string)$order_info['payment_zone'],
                'zp'          => (string)$order_info['payment_postcode'],
                'country'     => (string)($order_info['payment_iso_code_2'] ?? ''),
                'external_id' => (string)$order_info['customer_id']
            ]),
            (string)$order_id
        );
    }

    /**
     * Inject the pixel base code and the page's queued standard events.
     *
     * @param array<string, mixed> $data
     */
    public function header(string &$route, array &$data, mixed &$output): void {
        if (!$this->isActive() || !is_string($output)) {
            return;
        }

        $pixel_id = preg_replace('/[^0-9]/', '', (string)$this->config->get('module_meta_ads_pixel_id'));

        if ($pixel_id === '') {
            return;
        }

        $config = [
            'pixelId'  => $pixel_id,
            'pageView' => $this->eventEnabled('pageview'),
            'addToCart' => $this->eventEnabled('addtocart'),
            'capiUrl'  => $this->url->link('extension/novakur/module/meta_ads.cart', 'language=' . $this->config->get('config_language'), true),
            'debug'    => (bool)(int)$this->config->get('module_meta_ads_debug'),
            'queue'    => $this->buildQueue()
        ];

        $json = \Opencart\System\Library\Extension\Novakur\MetaAds::json($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($json === '') {
            return;
        }

        $script = "\n<!-- NovaKur Meta Pixel + CAPI Pack -->\n"
            . '<script>window.nkMetaAds = ' . str_replace('</', '<\\/', $json) . ";</script>\n"
            . "<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" . $pixel_id . "');</script>\n"
            . '<noscript><img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=' . $pixel_id . '&amp;ev=PageView&amp;noscript=1"/></noscript>' . "\n"
            . '<script src="extension/novakur/catalog/view/assets/js/meta_ads.js?v=1.0.0"></script>' . "\n"
            . "<!-- /NovaKur Meta Pixel + CAPI Pack -->\n";

        $position = stripos($output, '</head>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $script . substr($output, $position);
        } else {
            $output = $script . $output;
        }
    }

    /* ------------------------------------------------------------------ */
    /* Event payload builders                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Events the browser should fire on this particular page, built server-side
     * so the values are always accurate (no DOM price scraping).
     *
     * @return array<int, array<string, mixed>>
     */
    protected function buildQueue(): array {
        $queue = [];
        $route = isset($this->request->get['route']) ? (string)$this->request->get['route'] : 'common/home';

        if ($route === 'product/product' && $this->eventEnabled('viewcontent')) {
            $event = $this->buildViewContent();

            if ($event) {
                $queue[] = $event;
            }
        }

        if ($route === 'checkout/checkout' && $this->eventEnabled('initiatecheckout')) {
            $event = $this->buildInitiateCheckout();

            if ($event) {
                $queue[] = $event;
            }
        }

        if (self::$purchase) {
            $queue[] = self::$purchase;
            self::$purchase = [];
        }

        return $queue;
    }

    /**
     * @return array<string, mixed>
     */
    protected function buildViewContent(): array {
        $product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

        if (!$product_id) {
            return [];
        }

        $this->load->model('catalog/product');

        $product_info = $this->model_catalog_product->getProduct($product_id);

        if (!$product_info) {
            return [];
        }

        $currency   = (string)$this->currencyCode();
        $content_id = $this->contentId($product_id, (string)$product_info['model'], (string)$product_info['sku']);

        $price = !empty($product_info['special']) ? (float)$product_info['special'] : (float)$product_info['price'];
        $value = $this->displayValue($price, (int)$product_info['tax_class_id']);

        $params = [
            'content_type' => 'product',
            'content_ids'  => [$content_id],
            'contents'     => [['id' => $content_id, 'quantity' => 1, 'item_price' => $value]],
            'content_name' => html_entity_decode((string)$product_info['name'], ENT_QUOTES, 'UTF-8'),
            'value'        => $value,
            'currency'     => $currency
        ];

        $category = $this->productCategoryName($product_id);

        if ($category !== '') {
            $params['content_category'] = $category;
        }

        return [
            'name'     => 'ViewContent',
            'event_id' => $this->capi()->makeEventId('ViewContent'),
            'params'   => $params
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function buildInitiateCheckout(): array {
        $products = $this->cart->getProducts();

        if (!$products) {
            return [];
        }

        $currency    = $this->currencyCode();
        $content_ids = [];
        $contents    = [];
        $num_items   = 0;
        $value       = 0.0;

        foreach ($products as $product) {
            $content_id = $this->contentId((int)$product['product_id'], (string)$product['model'], (string)($product['sku'] ?? ''));
            $item_price = $this->displayValue((float)$product['price'], (int)$product['tax_class_id']);

            $content_ids[] = $content_id;
            $contents[]    = [
                'id'         => $content_id,
                'quantity'   => (int)$product['quantity'],
                'item_price' => $item_price
            ];

            $num_items += (int)$product['quantity'];
            $value     += $item_price * (int)$product['quantity'];
        }

        return [
            'name'     => 'InitiateCheckout',
            'event_id' => $this->capi()->makeEventId('InitiateCheckout'),
            'params'   => [
                'content_type' => 'product',
                'content_ids'  => $content_ids,
                'contents'     => $contents,
                'num_items'    => $num_items,
                'value'        => $this->money($value),
                'currency'     => $currency
            ]
        ];
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                             */
    /* ------------------------------------------------------------------ */

    protected function isActive(): bool {
        return (bool)(int)$this->config->get('module_meta_ads_status');
    }

    protected function eventEnabled(string $key): bool {
        return (bool)(int)$this->config->get('module_meta_ads_event_' . $key);
    }

    protected function capi(): \Opencart\System\Library\Extension\Novakur\MetaAds {
        return new \Opencart\System\Library\Extension\Novakur\MetaAds($this->registry);
    }

    /**
     * Content id must match the <g:id> emitted by the catalog feed.
     */
    protected function contentId(int $product_id, string $model, string $sku): string {
        switch ((string)$this->config->get('module_meta_ads_content_id_type')) {
            case 'model':
                return $model !== '' ? $model : (string)$product_id;
            case 'sku':
                return $sku !== '' ? $sku : (string)$product_id;
            default:
                return (string)$product_id;
        }
    }

    protected function currencyCode(): string {
        $code = isset($this->session->data['currency']) ? (string)$this->session->data['currency'] : '';

        return $code !== '' ? $code : (string)$this->config->get('config_currency');
    }

    /**
     * Price converted to the shopper's currency, tax applied when configured.
     */
    protected function displayValue(float $price, int $tax_class_id): float {
        if ((bool)(int)$this->config->get('module_meta_ads_value_tax')) {
            $price = (float)$this->tax->calculate($price, $tax_class_id, (bool)$this->config->get('config_tax'));
        }

        $converted = $this->currency->format($price, $this->currencyCode(), 0, false);

        return $this->money((float)$converted);
    }

    protected function money(float $value): float {
        return round($value, 2);
    }

    protected function productCategoryName(int $product_id): string {
        $this->load->model('catalog/product');

        $categories = $this->model_catalog_product->getCategories($product_id);

        if (!$categories) {
            return '';
        }

        $this->load->model('catalog/category');

        $category_info = $this->model_catalog_category->getCategory((int)$categories[0]['category_id']);

        return $category_info ? html_entity_decode((string)$category_info['name'], ENT_QUOTES, 'UTF-8') : '';
    }
}
