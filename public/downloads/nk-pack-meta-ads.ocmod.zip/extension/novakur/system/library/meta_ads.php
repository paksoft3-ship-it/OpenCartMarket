<?php
namespace Opencart\System\Library\Extension\Novakur;

/**
 * NovaKur Meta Pixel + CAPI Pack — Conversions API helper.
 *
 * Shared by the catalog event/module controllers and the admin controller.
 * Instantiate directly:
 *
 *   $capi = new \Opencart\System\Library\Extension\Novakur\MetaAds($this->registry);
 *
 * Server events are always written to the queue table first so the admin panel
 * has an auditable log, then sent (immediately or by the cron route) to
 * https://graph.facebook.com/<version>/<pixel_id>/events.
 */
class MetaAds {
    public const STATUS_PENDING = 0;
    public const STATUS_SENT    = 1;
    public const STATUS_FAILED  = 2;

    public const MAX_ATTEMPTS   = 5;
    public const DEFAULT_API_VERSION = 'v21.0';

    protected \Opencart\System\Engine\Registry $registry;

    public function __construct(\Opencart\System\Engine\Registry $registry) {
        $this->registry = $registry;
    }

    public function __get(string $key): ?object {
        return $this->registry->get($key);
    }

    /* ------------------------------------------------------------------ */
    /* JSON                                                                */
    /* ------------------------------------------------------------------ */

    /**
     * json_encode with the float precision pinned.
     *
     * Some hosts still ship serialize_precision=17, which turns a rounded
     * 129.99 into 129.990000000000009 in both the pixel payload and the
     * Conversions API body. Forcing -1 gives the shortest round-trippable
     * representation on every server.
     *
     * @param mixed $value
     */
    public static function json($value, int $flags = 0): string {
        $previous = ini_get('serialize_precision');
        $restore  = ($previous !== false && $previous !== '-1');

        if ($restore) {
            ini_set('serialize_precision', '-1');
        }

        $json = json_encode($value, $flags);

        if ($restore) {
            ini_set('serialize_precision', (string)$previous);
        }

        return $json === false ? '' : $json;
    }

    /* ------------------------------------------------------------------ */
    /* Schema                                                              */
    /* ------------------------------------------------------------------ */

    public function table(): string {
        return DB_PREFIX . 'nk_meta_ads_event';
    }

    public function createTable(): void {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . $this->table() . "` (
            `meta_ads_event_id` int(11) NOT NULL AUTO_INCREMENT,
            `store_id` int(11) NOT NULL DEFAULT '0',
            `event_name` varchar(64) NOT NULL DEFAULT '',
            `event_id` varchar(64) NOT NULL DEFAULT '',
            `reference` varchar(64) NOT NULL DEFAULT '',
            `payload` mediumtext NOT NULL,
            `status` tinyint(1) NOT NULL DEFAULT '0',
            `attempts` int(11) NOT NULL DEFAULT '0',
            `response` text NOT NULL,
            `date_added` datetime NOT NULL,
            `date_sent` datetime DEFAULT NULL,
            PRIMARY KEY (`meta_ads_event_id`),
            KEY `idx_nk_meta_status` (`status`),
            KEY `idx_nk_meta_event_id` (`event_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    }

    public function dropTable(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . $this->table() . "`");
    }

    /* ------------------------------------------------------------------ */
    /* Configuration                                                       */
    /* ------------------------------------------------------------------ */

    public function getPixelId(): string {
        return preg_replace('/[^0-9]/', '', (string)$this->config->get('module_meta_ads_pixel_id'));
    }

    public function getAccessToken(): string {
        return trim((string)$this->config->get('module_meta_ads_access_token'));
    }

    public function getTestEventCode(): string {
        return trim((string)$this->config->get('module_meta_ads_test_event_code'));
    }

    public function getApiVersion(): string {
        $version = trim((string)$this->config->get('module_meta_ads_api_version'));

        return preg_match('/^v[0-9]+\.[0-9]+$/', $version) ? $version : self::DEFAULT_API_VERSION;
    }

    /**
     * True when the Conversions API mirror is switched on AND usable.
     */
    public function isEnabled(): bool {
        return (bool)(int)$this->config->get('module_meta_ads_capi_status')
            && $this->getPixelId() !== ''
            && $this->getAccessToken() !== '';
    }

    public function isInstantMode(): bool {
        return (string)$this->config->get('module_meta_ads_capi_mode') !== 'queue';
    }

    /* ------------------------------------------------------------------ */
    /* Event ids                                                           */
    /* ------------------------------------------------------------------ */

    /**
     * Deterministic id so the browser pixel and the server event dedupe.
     * Meta matches on event_name + event_id.
     */
    public function makeEventId(string $event_name, string $reference = ''): string {
        if ($reference !== '') {
            return strtolower($event_name) . '.' . preg_replace('/[^A-Za-z0-9_.-]/', '', $reference);
        }

        try {
            $random = bin2hex(random_bytes(8));
        } catch (\Exception $e) {
            $random = substr(md5(uniqid('', true)), 0, 16);
        }

        return strtolower($event_name) . '.' . $random;
    }

    /* ------------------------------------------------------------------ */
    /* User data (all PII SHA-256 hashed, per Meta's requirements)         */
    /* ------------------------------------------------------------------ */

    public function hash(string $value): string {
        $value = trim($value);

        return $value === '' ? '' : hash('sha256', $value);
    }

    protected function normalise(string $value): string {
        return strtolower(trim($value));
    }

    protected function normalisePhone(string $value): string {
        return preg_replace('/[^0-9]/', '', $value);
    }

    /**
     * @param array<string, string> $extra raw (unhashed) values: em, ph, fn, ln, ct, st, zp, country, external_id
     *
     * @return array<string, mixed>
     */
    public function buildUserData(array $extra = []): array {
        $user_data = [];

        if ((bool)(int)$this->config->get('module_meta_ads_capi_user_data')) {
            // Blank values must not block the customer fallback below.
            foreach ($extra as $key => $value) {
                if (trim((string)$value) === '') {
                    unset($extra[$key]);
                }
            }

            // Fall back to the logged in customer when the caller gave us nothing.
            if ($this->registry->has('customer') && $this->customer && $this->customer->isLogged()) {
                $extra += [
                    'em'          => (string)$this->customer->getEmail(),
                    'ph'          => (string)$this->customer->getTelephone(),
                    'fn'          => (string)$this->customer->getFirstName(),
                    'ln'          => (string)$this->customer->getLastName(),
                    'external_id' => (string)$this->customer->getId()
                ];
            }

            $map = [
                'em'      => 'normalise',
                'fn'      => 'normalise',
                'ln'      => 'normalise',
                'ct'      => 'city',
                'st'      => 'normalise',
                'zp'      => 'city',
                'country' => 'normalise'
            ];

            foreach ($map as $key => $mode) {
                if (!empty($extra[$key])) {
                    $value = (string)$extra[$key];
                    $value = ($mode === 'city') ? preg_replace('/\s+/', '', $this->normalise($value)) : $this->normalise($value);

                    // Meta expects a two letter ISO country code — anything else
                    // would hash to noise and drag the match quality down.
                    if ($key === 'country' && strlen($value) !== 2) {
                        continue;
                    }

                    $hashed = $this->hash($value);

                    if ($hashed !== '') {
                        $user_data[$key] = [$hashed];
                    }
                }
            }

            if (!empty($extra['ph'])) {
                $phone = $this->normalisePhone((string)$extra['ph']);

                if ($phone !== '') {
                    $user_data['ph'] = [$this->hash($phone)];
                }
            }

            if (!empty($extra['external_id'])) {
                $user_data['external_id'] = [$this->hash((string)$extra['external_id'])];
            }
        }

        // Non-PII signals — always sent, they are what makes CAPI match well.
        $ip = $this->getClientIp();

        if ($ip !== '') {
            $user_data['client_ip_address'] = $ip;
        }

        if (!empty($this->request->server['HTTP_USER_AGENT'])) {
            $user_data['client_user_agent'] = substr((string)$this->request->server['HTTP_USER_AGENT'], 0, 500);
        }

        $fbp = $this->getCookie('_fbp');

        if ($fbp !== '') {
            $user_data['fbp'] = $fbp;
        }

        $fbc = $this->getCookie('_fbc');

        if ($fbc === '' && !empty($this->request->get['fbclid'])) {
            $fbclid = preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$this->request->get['fbclid']);

            if ($fbclid !== '') {
                $fbc = 'fb.1.' . (time() * 1000) . '.' . $fbclid;
            }
        }

        if ($fbc !== '') {
            $user_data['fbc'] = $fbc;
        }

        return $user_data;
    }

    protected function getCookie(string $name): string {
        if (!isset($this->request->cookie[$name])) {
            return '';
        }

        return preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$this->request->cookie[$name]);
    }

    protected function getClientIp(): string {
        $ip = (string)($this->request->server['REMOTE_ADDR'] ?? '');

        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
    }

    /* ------------------------------------------------------------------ */
    /* Queue                                                               */
    /* ------------------------------------------------------------------ */

    /**
     * Build a Conversions API event envelope.
     *
     * @param array<string, mixed> $custom_data
     * @param array<string, mixed> $user_data
     *
     * @return array<string, mixed>
     */
    public function buildEvent(string $event_name, string $event_id, array $custom_data, array $user_data, string $source_url = ''): array {
        if ($source_url === '') {
            $source_url = $this->getCurrentUrl();
        }

        $event = [
            'event_name'       => $event_name,
            'event_time'       => time(),
            'event_id'         => $event_id,
            'action_source'    => 'website',
            'user_data'        => $user_data,
            'custom_data'      => $custom_data
        ];

        if ($source_url !== '') {
            $event['event_source_url'] = $source_url;
        }

        return $event;
    }

    public function getCurrentUrl(): string {
        if (empty($this->request->server['REQUEST_URI'])) {
            return (string)$this->config->get('config_url');
        }

        $scheme = (!empty($this->request->server['HTTPS']) && $this->request->server['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = (string)($this->request->server['HTTP_HOST'] ?? '');

        if ($host === '') {
            return (string)$this->config->get('config_url');
        }

        return $scheme . '://' . $host . (string)$this->request->server['REQUEST_URI'];
    }

    /**
     * Insert a built event into the queue. Returns the queue row id.
     *
     * @param array<string, mixed> $event
     */
    public function queue(array $event, string $reference = ''): int {
        $this->db->query("INSERT INTO `" . $this->table() . "` SET
            `store_id` = '" . (int)$this->config->get('config_store_id') . "',
            `event_name` = '" . $this->db->escape((string)$event['event_name']) . "',
            `event_id` = '" . $this->db->escape((string)$event['event_id']) . "',
            `reference` = '" . $this->db->escape($reference) . "',
            `payload` = '" . $this->db->escape(self::json($event)) . "',
            `status` = '" . (int)self::STATUS_PENDING . "',
            `attempts` = '0',
            `response` = '',
            `date_added` = NOW()");

        return (int)$this->db->getLastId();
    }

    /**
     * Queue an event and, in instant mode, send it straight away.
     *
     * @param array<string, mixed> $custom_data
     * @param array<string, mixed> $user_data
     *
     * @return array{event_id: string, queue_id: int, sent: bool}
     */
    public function dispatch(string $event_name, string $event_id, array $custom_data, array $user_data, string $reference = '', string $source_url = ''): array {
        $result = ['event_id' => $event_id, 'queue_id' => 0, 'sent' => false];

        if (!$this->isEnabled()) {
            return $result;
        }

        // Never queue the same event twice (page refresh, double submit).
        if ($this->hasEvent($event_name, $event_id)) {
            return $result;
        }

        $event = $this->buildEvent($event_name, $event_id, $custom_data, $user_data, $source_url);

        $result['queue_id'] = $this->queue($event, $reference);

        if ($this->isInstantMode() && $result['queue_id']) {
            $report = $this->flush(1, $result['queue_id']);
            $result['sent'] = ($report['sent'] > 0);
        }

        return $result;
    }

    public function hasEvent(string $event_name, string $event_id): bool {
        $query = $this->db->query("SELECT `meta_ads_event_id` FROM `" . $this->table() . "` WHERE `event_name` = '" . $this->db->escape($event_name) . "' AND `event_id` = '" . $this->db->escape($event_id) . "' LIMIT 1");

        return (bool)$query->num_rows;
    }

    /* ------------------------------------------------------------------ */
    /* Sending                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Send pending queue rows to Meta.
     *
     * @return array{sent: int, failed: int, skipped: int, message: string}
     */
    public function flush(int $limit = 25, int $only_id = 0): array {
        $report = ['sent' => 0, 'failed' => 0, 'skipped' => 0, 'message' => ''];

        if (!$this->isEnabled()) {
            $report['message'] = 'Conversions API is disabled or not configured.';

            return $report;
        }

        $limit = max(1, min(200, $limit));

        $sql = "SELECT `meta_ads_event_id`, `payload`, `attempts` FROM `" . $this->table() . "` WHERE `status` = '" . (int)self::STATUS_PENDING . "' AND `attempts` < '" . (int)self::MAX_ATTEMPTS . "'";

        if ($only_id > 0) {
            $sql .= " AND `meta_ads_event_id` = '" . (int)$only_id . "'";
        }

        $sql .= " ORDER BY `meta_ads_event_id` ASC LIMIT " . (int)$limit;

        $rows = $this->db->query($sql)->rows;

        if (!$rows) {
            $report['message'] = 'No pending events.';

            return $report;
        }

        $events = [];
        $ids    = [];

        foreach ($rows as $row) {
            $payload = json_decode((string)$row['payload'], true);

            if (is_array($payload) && isset($payload['event_name'])) {
                $events[] = $payload;
                $ids[]    = (int)$row['meta_ads_event_id'];
            } else {
                $this->markFailed([(int)$row['meta_ads_event_id']], 'Corrupt payload.');
                $report['skipped']++;
            }
        }

        if (!$events) {
            $report['message'] = 'Nothing sendable.';

            return $report;
        }

        $response = $this->post($events);

        if ($response['ok']) {
            $this->markSent($ids, $response['body']);
            $report['sent'] = count($ids);
            $report['message'] = 'Sent ' . count($ids) . ' event(s) to Meta.';
        } else {
            $this->markFailed($ids, $response['body']);
            $report['failed'] = count($ids);
            $report['message'] = $response['body'];
        }

        return $report;
    }

    /**
     * Raw POST to the Conversions API. Also used by the admin "test" button.
     *
     * @param array<int, array<string, mixed>> $events
     *
     * @return array{ok: bool, body: string, http_code: int}
     */
    public function post(array $events): array {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'body' => 'PHP cURL extension is not available on this server.', 'http_code' => 0];
        }

        $pixel_id = $this->getPixelId();
        $token    = $this->getAccessToken();

        if ($pixel_id === '' || $token === '') {
            return ['ok' => false, 'body' => 'Pixel ID or access token missing.', 'http_code' => 0];
        }

        $url = 'https://graph.facebook.com/' . $this->getApiVersion() . '/' . $pixel_id . '/events';

        $post = [
            'data'         => self::json(array_values($events)),
            'access_token' => $token
        ];

        $test_code = $this->getTestEventCode();

        if ($test_code !== '') {
            $post['test_event_code'] = $test_code;
        }

        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_USERAGENT, 'NovaKur-MetaAds/1.0 (OpenCart 4)');

        $body      = curl_exec($curl);
        $http_code = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error     = curl_error($curl);

        curl_close($curl);

        if ($body === false) {
            return ['ok' => false, 'body' => 'cURL error: ' . $error, 'http_code' => $http_code];
        }

        $body = (string)$body;
        $json = json_decode($body, true);

        $ok = ($http_code >= 200 && $http_code < 300) && is_array($json) && !isset($json['error']);

        if (!$ok && is_array($json) && isset($json['error']['message'])) {
            $body = 'Meta API error (' . $http_code . '): ' . (string)$json['error']['message'];
        }

        return ['ok' => $ok, 'body' => substr($body, 0, 2000), 'http_code' => $http_code];
    }

    /**
     * @param array<int, int> $ids
     */
    protected function markSent(array $ids, string $response): void {
        if (!$ids) {
            return;
        }

        $this->db->query("UPDATE `" . $this->table() . "` SET `status` = '" . (int)self::STATUS_SENT . "', `attempts` = `attempts` + 1, `response` = '" . $this->db->escape(substr($response, 0, 2000)) . "', `date_sent` = NOW() WHERE `meta_ads_event_id` IN (" . implode(',', array_map('intval', $ids)) . ")");
    }

    /**
     * @param array<int, int> $ids
     */
    protected function markFailed(array $ids, string $response): void {
        if (!$ids) {
            return;
        }

        $list = implode(',', array_map('intval', $ids));

        $this->db->query("UPDATE `" . $this->table() . "` SET `attempts` = `attempts` + 1, `response` = '" . $this->db->escape(substr($response, 0, 2000)) . "' WHERE `meta_ads_event_id` IN (" . $list . ")");

        // Rows that exhausted their retries are parked as failed so the cron stops picking them up.
        $this->db->query("UPDATE `" . $this->table() . "` SET `status` = '" . (int)self::STATUS_FAILED . "' WHERE `meta_ads_event_id` IN (" . $list . ") AND `attempts` >= '" . (int)self::MAX_ATTEMPTS . "'");
    }

    /* ------------------------------------------------------------------ */
    /* Log helpers (admin panel)                                           */
    /* ------------------------------------------------------------------ */

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getLog(int $start = 0, int $limit = 20): array {
        $start = max(0, $start);
        $limit = max(1, min(200, $limit));

        return $this->db->query("SELECT `meta_ads_event_id`, `event_name`, `event_id`, `reference`, `status`, `attempts`, `response`, `date_added`, `date_sent` FROM `" . $this->table() . "` ORDER BY `meta_ads_event_id` DESC LIMIT " . (int)$start . "," . (int)$limit)->rows;
    }

    /**
     * @return array<string, int>
     */
    public function getCounts(): array {
        $counts = ['pending' => 0, 'sent' => 0, 'failed' => 0];

        foreach ($this->db->query("SELECT `status`, COUNT(*) AS `total` FROM `" . $this->table() . "` GROUP BY `status`")->rows as $row) {
            switch ((int)$row['status']) {
                case self::STATUS_SENT:
                    $counts['sent'] = (int)$row['total'];
                    break;
                case self::STATUS_FAILED:
                    $counts['failed'] = (int)$row['total'];
                    break;
                default:
                    $counts['pending'] = (int)$row['total'];
            }
        }

        return $counts;
    }

    public function clearLog(): void {
        $this->db->query("DELETE FROM `" . $this->table() . "` WHERE `status` <> '" . (int)self::STATUS_PENDING . "'");
    }

    /**
     * Housekeeping — drop delivered rows older than $days.
     */
    public function prune(int $days = 14): void {
        $days = max(1, min(365, $days));

        $this->db->query("DELETE FROM `" . $this->table() . "` WHERE `status` = '" . (int)self::STATUS_SENT . "' AND `date_sent` IS NOT NULL AND `date_sent` < DATE_SUB(NOW(), INTERVAL " . (int)$days . " DAY)");
    }
}
