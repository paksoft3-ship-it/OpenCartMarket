<?php
// Heading
$_['heading_title']    = 'NovaKur Meta Pixel + CAPI Pack';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified the Meta Pixel + CAPI Pack settings!';
$_['text_edit']        = 'Edit Meta Pixel + CAPI Pack';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_yes']         = 'Yes';
$_['text_no']          = 'No';
$_['text_none']        = 'None yet';

$_['text_tab_general'] = 'Pixel &amp; CAPI';
$_['text_tab_events']  = 'Events';
$_['text_tab_feed']    = 'Catalog Feed';
$_['text_tab_log']     = 'Server Event Log';
$_['text_tab_guide']   = 'Setup Guide';

$_['text_instant']     = 'Send immediately (on the page request)';
$_['text_queue']       = 'Queue only — send from cron';

$_['text_not_generated'] = 'Not generated yet';
$_['text_last_generated'] = 'Feed last generated';

$_['text_status_pending'] = 'Pending';
$_['text_status_sent']    = 'Sent';
$_['text_status_failed']  = 'Failed';

$_['text_pending']     = 'Pending';
$_['text_sent']        = 'Sent';
$_['text_failed']      = 'Failed';

$_['text_curl_missing'] = 'Warning: the PHP cURL extension is not enabled on this server. The Conversions API cannot send events without it — the browser pixel will still work.';

$_['text_events_intro'] = 'Browser (pixel) events. ViewContent, InitiateCheckout and Purchase are built server-side from real OpenCart data, so prices and currencies are always accurate — no DOM scraping.';
$_['text_capi_intro']   = 'The Conversions API mirrors AddToCart and Purchase from your server to Meta. Every server event carries the same <code>event_id</code> as its browser twin, which is how Meta deduplicates the pair — you will see one event in Events Manager, not two.';
$_['text_feed_intro']   = 'A Meta Commerce Manager product feed (RSS 2.0 + Google namespace). Add the URL below as a scheduled data feed in Commerce Manager. The feed <code>g:id</code> uses the same rule as the pixel <code>content_ids</code>, so catalog items match your events.';

$_['text_test_success'] = 'Meta accepted the test event (event_id: %s). If you set a Test Event Code, it will appear in Events Manager &rarr; Test Events within a few seconds.';
$_['text_test_failed']  = 'Meta rejected the test event.';
$_['text_flush_result'] = 'Queue flushed: %d sent, %d failed.';
$_['text_log_cleared']  = 'Success: Delivered and failed rows were removed from the log.';
$_['text_cache_cleared'] = 'Success: The cached catalog feed was deleted — the next request rebuilds it.';

// Setup guide
$_['text_guide_intro'] = 'Everything below is done once, inside Meta Business Suite. The extension needs two values from it: a <strong>Pixel ID</strong> and a <strong>Conversions API access token</strong>.';
$_['text_guide_step1'] = '<strong>Create or open your dataset.</strong> Go to Meta Events Manager (business.facebook.com/events_manager). Pick your pixel/dataset, or create one with <em>Connect data sources &rarr; Web</em>. Copy the numeric <strong>Dataset (Pixel) ID</strong> into the Pixel ID field on the first tab.';
$_['text_guide_step2'] = '<strong>Generate an access token.</strong> In Events Manager open your dataset &rarr; <em>Settings</em> &rarr; <em>Conversions API</em> &rarr; <em>Generate access token</em>. Paste it into the Access Token field, switch Conversions API on, and save.';
$_['text_guide_step3'] = '<strong>Verify with Test Events.</strong> Open <em>Test Events</em> in Events Manager, copy the test event code (looks like <code>TEST12345</code>) into the Test Event Code field, save, then press <em>Send Test Event</em> here. The event should appear in the Test Events panel within seconds. Clear the code again once you are happy — it should not stay set in production.';
$_['text_guide_step4'] = '<strong>Check deduplication.</strong> With the test code still set, place a real test order on the storefront. Events Manager shows one Purchase, not two, and marks the server event as deduplicated against the browser event. If you see doubles, the browser and server event_id did not match — check that the Purchase toggle and Conversions API are both on.';
$_['text_guide_step5'] = '<strong>Upload the catalog.</strong> In Commerce Manager create a catalog &rarr; <em>Data sources</em> &rarr; <em>Scheduled feed</em> and paste the feed URL from the Catalog Feed tab. Set the schedule to daily. Then connect the catalog to your pixel/dataset so dynamic ads can use the events.';
$_['text_guide_step6'] = '<strong>Optional: cron for the queue.</strong> If you set the Conversions API to "Queue only", add the cron URL from the Catalog Feed tab to your server crontab (for example every 5 minutes) so queued events get delivered. In "Send immediately" mode no cron is needed.';
$_['text_guide_limits'] = '<strong>Honest limitations.</strong> The Conversions API can only be exercised with your own real access token — it cannot be pre-verified for you, and a token that is expired, scoped to the wrong dataset, or revoked will fail at send time (the failure is written to the Server Event Log tab, with Meta\'s own error message). Full end-to-end confirmation — deduplication, match quality, catalog matching — is only possible against Meta\'s Test Events tool on a live, publicly reachable store; localhost cannot receive the server-to-server verification and Meta cannot crawl a local feed URL. Event match quality also depends on how much customer data your checkout collects.';

// Entry
$_['entry_status']           = 'Status';
$_['entry_pixel_id']         = 'Pixel (Dataset) ID';
$_['entry_access_token']     = 'CAPI Access Token';
$_['entry_test_event_code']  = 'Test Event Code';
$_['entry_api_version']      = 'Graph API Version';
$_['entry_capi_status']      = 'Conversions API';
$_['entry_capi_mode']        = 'Sending Mode';
$_['entry_capi_user_data']   = 'Send Hashed Customer Data';
$_['entry_content_id_type']  = 'Content ID Source';
$_['entry_value_tax']        = 'Include Tax in Values';
$_['entry_debug']            = 'Browser Console Debug';

$_['entry_event_pageview']         = 'PageView';
$_['entry_event_viewcontent']      = 'ViewContent (product pages)';
$_['entry_event_addtocart']        = 'AddToCart';
$_['entry_event_initiatecheckout'] = 'InitiateCheckout';
$_['entry_event_purchase']         = 'Purchase';

$_['entry_feed_status']       = 'Catalog Feed';
$_['entry_feed_token']        = 'Feed Token';
$_['entry_feed_url']          = 'Feed URL';
$_['entry_feed_language']     = 'Feed Language';
$_['entry_feed_currency']     = 'Feed Currency';
$_['entry_feed_condition']    = 'Item Condition';
$_['entry_feed_brand_default'] = 'Default Brand';
$_['entry_feed_cache_hours']  = 'Feed Cache';
$_['entry_cron_url']          = 'Queue Cron URL';

// Help
$_['help_pixel_id']        = 'Numbers only. Events Manager &rarr; your dataset &rarr; the ID under the dataset name.';
$_['help_access_token']    = 'Events Manager &rarr; Settings &rarr; Conversions API &rarr; Generate access token. Stored in your OpenCart settings — treat it like a password.';
$_['help_test_event_code'] = 'Optional. Only set this while testing: it routes every server event into the Test Events panel instead of live reporting. Clear it before going live.';
$_['help_api_version']     = 'Format vNN.N (for example v21.0). Leave as-is unless Meta deprecates the version.';
$_['help_capi_status']     = 'Mirrors AddToCart and Purchase server-to-server. Requires an access token and the PHP cURL extension.';
$_['help_capi_mode']       = '"Send immediately" posts to Meta during the page request (simplest, adds up to ~1s on add-to-cart and order confirmation). "Queue only" writes to the queue table and a cron job delivers them — better for high-traffic stores.';
$_['help_capi_user_data']  = 'Sends SHA-256 hashed email, phone, name, city, state, postcode and country from the order (never plain text). Raises Meta\'s event match quality. Turn off if your privacy policy does not cover it.';
$_['help_content_id_type'] = 'Which product field becomes the Meta content ID. This must match the g:id column in your uploaded catalog — the feed on the next tab uses the same setting automatically.';
$_['help_value_tax']       = 'Apply the customer\'s tax rate to reported event and feed values.';
$_['help_debug']           = 'Logs every fired event to the browser console. Development only.';
$_['help_addtocart']       = 'AddToCart is detected by watching OpenCart\'s own <code>checkout/cart.add</code> request (XHR and fetch), so it works with the default theme and with custom themes without any template edits. Price and currency are resolved server-side from the real product record.';
$_['help_feed_url']        = 'Paste this into Commerce Manager as a scheduled feed. The token keeps the feed private — regenerate it by clearing the field and saving.';
$_['help_cron_url']        = 'Only needed in "Queue only" mode. Example crontab entry: */5 * * * * curl -s "URL" > /dev/null';
$_['help_feed_cache_hours'] = 'How long a generated feed is served from cache before being rebuilt. Meta only fetches it on your feed schedule, so 6-24 hours is usually right.';
$_['help_feed_brand_default'] = 'Used when a product has no manufacturer assigned. Falls back to your store name when left empty.';

// Column
$_['column_event']      = 'Event';
$_['column_event_id']   = 'Event ID';
$_['column_reference']  = 'Reference';
$_['column_status']     = 'Status';
$_['column_attempts']   = 'Attempts';
$_['column_response']   = 'Last Response';
$_['column_date_added'] = 'Queued';
$_['column_date_sent']  = 'Sent';

// Button
$_['button_save']        = 'Save';
$_['button_back']        = 'Back';
$_['button_copy']        = 'Copy';
$_['button_test']        = 'Send Test Event';
$_['button_flush']       = 'Send Pending Now';
$_['button_clear_log']   = 'Clear Log';
$_['button_clear_cache'] = 'Rebuild Feed';
$_['button_regenerate']  = 'Regenerate';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify the Meta Pixel + CAPI Pack!';
$_['error_pixel_id']     = 'A Pixel ID is required to enable the module.';
$_['error_access_token'] = 'An access token is required to enable the Conversions API.';
$_['error_api_version']  = 'Graph API version must look like v21.0.';
$_['error_test_config']  = 'Set a Pixel ID and an access token, save, then run the test.';
$_['error_curl']         = 'The PHP cURL extension is not available on this server.';
$_['error_capi_disabled'] = 'The Conversions API is switched off or missing credentials.';
$_['error_no_table']     = 'The server event queue table is missing — reinstall the extension.';
