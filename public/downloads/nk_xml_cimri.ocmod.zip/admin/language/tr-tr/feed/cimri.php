<?php
$_['heading_title']                 = 'NovaKur Cimri XML';

$_['text_extension']                = 'Eklentiler';
$_['text_success']                  = 'Başarılı: Cimri besleme ayarları kaydedildi!';
$_['text_edit']                     = 'Cimri Beslemesi Ayarları';
$_['text_enabled']                  = 'Etkin';
$_['text_disabled']                 = 'Pasif';
$_['text_default_store']            = 'Varsayılan Mağaza';
$_['text_cache_cleared']            = 'Besleme önbelleği temizlendi.';
$_['text_feed_url']                 = 'Besleme Adresi (URL)';
$_['text_feed_status']              = 'Besleme Durumu';
$_['text_last_generated']           = 'Son Oluşturulma';
$_['text_not_generated']            = 'Henüz oluşturulmadı';

$_['text_field_notice']             = 'Bu eklenti, Cimri\'nin çekmesi veya sizin yüklemeniz için besleme adresini üretir. Cimri sistemlerine bağlanmaz, kendiliğinden ürün eklemez veya güncellemez. Alan seti (id, productId, title, brand, categoryTree, price, currency, stock, stockQuantity, link, imageUrl, mpn, gtin) Cimri\'nin kamuya açık besleme kurallarına göre hazırlanmıştır; zorunlu alanlar, etiket adları ve kategori eşleme kuralları mağaza anlaşmanıza göre değişebileceğinden, canlıya almadan önce kendi Cimri satıcı hesabınızdaki entegrasyon dokümanıyla doğrulayın.';

$_['entry_status']                  = 'Durum';
$_['entry_store']                   = 'Mağaza';
$_['entry_currency']                = 'Para Birimi';
$_['entry_language']                = 'Dil';
$_['entry_include_out_of_stock']    = 'Stokta Olmayanları Dahil Et';
$_['entry_include_tax']             = 'Fiyatlar KDV Dahil';
$_['entry_include_identifiers']     = 'MPN / GTIN Yaz';
$_['entry_brand_attribute']         = 'Marka Özelliği';
$_['entry_gtin_attribute']          = 'GTIN Özelliği';
$_['entry_mpn_attribute']           = 'MPN Özelliği';
$_['entry_max_products']            = 'En Fazla Ürün';
$_['entry_cache_hours']             = 'Önbellek Süresi (Saat)';
$_['entry_excluded_categories']     = 'Hariç Tutulan Kategoriler';
$_['entry_token']                   = 'Besleme Anahtarı';

$_['help_feed_url']                 = 'Bu adresi Cimri\'ye verin veya dosyayı kendiniz indirin. Adres besleme anahtarını içerir, gizli tutun.';
$_['help_token']                    = 'Zorunlu. Besleme adresi yalnızca bu anahtar ile yanıt verir; anahtar yoksa veya yanlışsa adres 404 döner.';
$_['help_currency']                 = 'Cimri Türkiye mağazalarını TRY üzerinden listeler. Fiyatlar, OpenCart\'ta seçilen para birimi için tanımlı kur ile mağaza para biriminden çevrilir.';
$_['help_include_tax']              = 'Cimri müşterinin ödediği KDV dahil fiyatı bekler. Ürün fiyatlarınız zaten KDV dahil değilse bu seçeneği etkin bırakın.';
$_['help_include_identifiers']      = 'İsteğe bağlı mpn ve gtin alanlarını yazar. GTIN için sırasıyla EAN / UPC / JAN / ISBN, MPN için ürün modeli yedek olarak kullanılır. Değer bulunamazsa ilgili alan hiç yazılmaz.';
$_['help_brand_attribute']          = 'İsteğe bağlı. Marka bilgisini üretici yerine seçilen ürün özelliğinden okur. Özellik boşsa üretici bilgisi kullanılır.';
$_['help_identifier_attribute']     = 'İsteğe bağlı. Bu tanımlayıcıyı üründeki değerler yerine seçilen ürün özelliğinden okur.';
$_['help_excluded_categories']      = 'Seçilen kategorilerdeki ve altlarındaki tüm kategorilerdeki ürünler beslemeye eklenmez.';
$_['help_max_products']             = 'Beslemeye yazılacak en fazla ürün sayısı. 0 sınırsız demektir. Ürünler her durumda 250\'lik gruplar hâlinde okunur.';

$_['button_copy']                   = 'Kopyala';
$_['button_clear_cache']            = 'Önbelleği Temizle';
$_['button_regenerate_token']       = 'Yeni Anahtar Üret';

$_['error_permission']              = 'Uyarı: Cimri beslemesini düzenleme yetkiniz yok!';
$_['error_currency']                = 'Mağazanızda tanımlı bir para birimi seçin!';
$_['error_token']                   = 'Besleme anahtarı 16 ile 64 arasında harf veya rakam içermelidir!';
