<?php
namespace Opencart\Catalog\Controller\Extension\NkXmlCimri\Feed;

/**
 * NovaKur Cimri price comparison XML feed.
 *
 * index.php?route=extension/nk_xml_cimri/feed/cimri&token=xxxx
 *
 * Emits one <product> per catalogue item with id, title, brand, categoryTree,
 * price, stock, link, imageUrl and the optional mpn / gtin identifiers. Prices
 * are written with a dot decimal separator regardless of the store's display
 * locale.
 *
 * The field set follows Cimri's published feed conventions; validate it against
 * the merchant's own Cimri account documentation before go-live.
 */
class Cimri extends \Opencart\System\Engine\Controller {
    /**
     * Rows fetched and rendered per query, so a large catalogue never has to
     * fit in memory in one go.
     */
    private const CHUNK_SIZE = 250;

    /** @var array<string, bool> */
    private array $product_columns = [];

    /** @var array<int, string> category_id => "Parent > Child" */
    private array $category_paths = [];

    public function index(): void {
        if (!(int)$this->config->get('feed_cimri_status')) {
            $this->notFound();

            return;
        }

        // The feed exposes the whole catalogue, so it is token guarded. An
        // unset token locks the feed rather than opening it.
        $token = trim((string)$this->config->get('feed_cimri_token'));
        $supplied_token = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied_token)) {
            $this->notFound();

            return;
        }

        $cache_hours = (int)$this->config->get('feed_cimri_cache_hours');

        if (!in_array($cache_hours, [1, 6, 12, 24], true)) {
            $cache_hours = 6;
        }

        $cache_file = DIR_CACHE . 'nk_feed_cimri_' . (int)$this->config->get('config_store_id') . '.xml';

        if (is_file($cache_file) && (time() - filemtime($cache_file)) < ($cache_hours * 3600)) {
            $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
            $this->response->setOutput((string)file_get_contents($cache_file));

            return;
        }

        $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
        $this->response->setOutput($this->generate($cache_file));
    }

    private function notFound(): void {
        $protocol = isset($this->request->server['SERVER_PROTOCOL']) ? (string)$this->request->server['SERVER_PROTOCOL'] : 'HTTP/1.1';

        $this->response->addHeader($protocol . ' 404 Not Found');
        $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
        $this->response->setOutput('Not Found');
    }

    /**
     * Builds the feed in batches, streamed straight into a temp file that is
     * only then renamed over the cache file, so a half generated feed is never
     * served.
     */
    private function generate(string $cache_file): string {
        $base_currency = (string)$this->config->get('config_currency');

        $currency_code = (string)$this->config->get('feed_cimri_currency_code');

        if ($currency_code === '' || !$this->currency->has($currency_code)) {
            $currency_code = $base_currency;
        }

        $language_id = (int)$this->config->get('feed_cimri_language_id');

        if (!$language_id) {
            $language_id = (int)$this->config->get('config_language_id');
        }

        $store_id = $this->config->get('feed_cimri_store_id');
        $store_id = ($store_id === null || $store_id === '') ? (int)$this->config->get('config_store_id') : (int)$store_id;

        $include_out_of_stock = (int)$this->config->get('feed_cimri_include_out_of_stock');

        $include_tax = $this->config->get('feed_cimri_include_tax');
        $include_tax = ($include_tax === null) ? true : (bool)(int)$include_tax;

        $include_identifiers = $this->config->get('feed_cimri_include_identifiers');
        $include_identifiers = ($include_identifiers === null) ? true : (bool)(int)$include_identifiers;

        $max_products = (int)$this->config->get('feed_cimri_max_products');

        if ($max_products < 0) {
            $max_products = 0;
        }

        $brand_attribute_id = (int)$this->config->get('feed_cimri_brand_attribute_id');
        $gtin_attribute_id = (int)$this->config->get('feed_cimri_gtin_attribute_id');
        $mpn_attribute_id = (int)$this->config->get('feed_cimri_mpn_attribute_id');

        $excluded_categories = $this->config->get('feed_cimri_excluded_categories');

        if (!is_array($excluded_categories)) {
            $excluded_categories = ($excluded_categories !== null && $excluded_categories !== '') ? explode(',', (string)$excluded_categories) : [];
        }

        $excluded_categories = array_values(array_filter(array_map('intval', $excluded_categories)));

        $store_url = $this->getStoreUrl($store_id);
        $local_store = ($store_id === (int)$this->config->get('config_store_id'));

        $temporary = $cache_file . '.' . getmypid() . '.tmp';

        $handle = @fopen($temporary, 'w+');
        $cacheable = ($handle !== false);

        if (!$cacheable) {
            // An unwritable cache directory must not take the feed down.
            $handle = fopen('php://temp/maxmemory:' . (4 * 1024 * 1024), 'w+');
        }

        fwrite($handle, '<?xml version="1.0" encoding="UTF-8"?>' . "\n");
        fwrite($handle, '<products>' . "\n");

        $start = 0;
        $written = 0;

        while (true) {
            $limit = self::CHUNK_SIZE;

            if ($max_products && ($written + $limit) > $max_products) {
                $limit = $max_products - $written;
            }

            if ($limit < 1) {
                break;
            }

            $products = $this->getProducts($language_id, $store_id, $include_out_of_stock, $excluded_categories, $start, $limit);

            if (!$products) {
                break;
            }

            $product_ids = [];

            foreach ($products as $product) {
                $product_ids[] = (int)$product['product_id'];
            }

            $identifiers = $this->getIdentifiers($product_ids);
            $attributes = $this->getAttributes($product_ids, $language_id, [$brand_attribute_id, $gtin_attribute_id, $mpn_attribute_id]);

            foreach ($products as $product) {
                $product_id = (int)$product['product_id'];

                $product_identifiers = $identifiers[$product_id] ?? [];
                $product_attributes = $attributes[$product_id] ?? [];

                $title = $this->text((string)$product['name']);

                if ($title === '') {
                    // A product with no description row for this language has
                    // nothing a comparison engine can list.
                    continue;
                }

                $brand = '';

                if ($brand_attribute_id && isset($product_attributes[$brand_attribute_id])) {
                    $brand = $this->text((string)$product_attributes[$brand_attribute_id]);
                }

                if ($brand === '') {
                    $brand = $this->text((string)($product['manufacturer'] ?? ''));
                }

                $gtin = '';
                $mpn = '';

                if ($include_identifiers) {
                    if ($gtin_attribute_id && isset($product_attributes[$gtin_attribute_id])) {
                        $gtin = trim((string)$product_attributes[$gtin_attribute_id]);
                    }

                    if ($gtin === '') {
                        $gtin = $this->firstIdentifier($product, $product_identifiers, ['EAN', 'GTIN', 'UPC', 'JAN', 'ISBN']);
                    }

                    if ($mpn_attribute_id && isset($product_attributes[$mpn_attribute_id])) {
                        $mpn = trim((string)$product_attributes[$mpn_attribute_id]);
                    }

                    if ($mpn === '') {
                        $mpn = $this->firstIdentifier($product, $product_identifiers, ['MPN']);
                    }

                    if ($mpn === '') {
                        $mpn = trim((string)$product['model']);
                    }
                }

                $offer_id = $this->firstIdentifier($product, $product_identifiers, ['SKU']);

                if ($offer_id === '') {
                    $offer_id = (string)$product_id;
                }

                $tax_class_id = (int)$product['tax_class_id'];

                $price = $this->money((float)$product['price'], $tax_class_id, $include_tax, $base_currency, $currency_code);

                if ($product['special'] !== null && (float)$product['special'] >= 0) {
                    $special = $this->money((float)$product['special'], $tax_class_id, $include_tax, $base_currency, $currency_code);

                    if ((float)$special < (float)$price) {
                        // Comparison engines list the price a shopper actually pays.
                        $price = $special;
                    }
                }

                $category = $this->getCategoryPath((int)$product['category_id'], $language_id);

                $image = (string)$product['image'] !== '' ? $store_url . '/image/' . $this->encodeImagePath((string)$product['image']) : '';

                $item = [];
                $item[] = '<product>';
                $item[] = '<id>' . $this->esc($offer_id) . '</id>';
                $item[] = '<productId>' . $product_id . '</productId>';
                $item[] = '<title>' . $this->cdata(mb_substr($title, 0, 150)) . '</title>';
                $item[] = '<brand>' . $this->cdata(mb_substr($brand, 0, 100)) . '</brand>';
                $item[] = '<categoryTree>' . $this->cdata(mb_substr($category, 0, 250)) . '</categoryTree>';
                $item[] = '<price>' . $price . '</price>';
                $item[] = '<currency>' . $this->esc($currency_code) . '</currency>';
                $item[] = '<stock>' . ((int)$product['quantity'] > 0 ? '1' : '0') . '</stock>';
                $item[] = '<stockQuantity>' . max(0, (int)$product['quantity']) . '</stockQuantity>';
                $item[] = '<link>' . $this->esc($this->getProductLink($product_id, $local_store, $store_url)) . '</link>';

                if ($image !== '') {
                    $item[] = '<imageUrl>' . $this->esc($image) . '</imageUrl>';
                }

                if ($mpn !== '') {
                    $item[] = '<mpn>' . $this->esc($mpn) . '</mpn>';
                }

                if ($gtin !== '') {
                    $item[] = '<gtin>' . $this->esc($gtin) . '</gtin>';
                }

                $item[] = '</product>';

                fwrite($handle, implode("\n", $item) . "\n");

                $written++;
            }

            if (count($products) < $limit) {
                break;
            }

            $start += $limit;
        }

        fwrite($handle, '</products>');

        if ($cacheable) {
            fclose($handle);

            if (!@rename($temporary, $cache_file)) {
                @unlink($temporary);
            }

            return is_file($cache_file) ? (string)file_get_contents($cache_file) : '';
        }

        rewind($handle);

        $output = (string)stream_get_contents($handle);

        fclose($handle);

        return $output;
    }

    /**
     * @param array<int, int> $excluded_categories
     *
     * @return array<int, array<string, mixed>>
     */
    private function getProducts(int $language_id, int $store_id, int $include_out_of_stock, array $excluded_categories, int $start, int $limit): array {
        $sql = "SELECT `p`.`product_id`, `p`.`model`, `p`.`price`, `p`.`quantity`, `p`.`image`, `p`.`tax_class_id`";

        foreach ($this->getLegacyIdentifierColumns() as $column) {
            $sql .= ", `p`.`" . $column . "`";
        }

        $sql .= ", `pd`.`name`, `m`.`name` AS `manufacturer`";
        $sql .= ", (SELECT MIN(`p2c`.`category_id`) FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`product_id` = `p`.`product_id`) AS `category_id`";
        $sql .= ", (SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1) AS `special`";
        $sql .= " FROM `" . DB_PREFIX . "product` `p`";
        $sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `p`.`product_id` AND `p2s`.`store_id` = '" . $store_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `p`.`product_id` AND `pd`.`language_id` = '" . $language_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "manufacturer` `m` ON (`m`.`manufacturer_id` = `p`.`manufacturer_id`)";
        $sql .= " WHERE `p`.`status` = '1' AND `p`.`date_available` <= NOW()";

        if (!$include_out_of_stock) {
            $sql .= " AND `p`.`quantity` > 0";
        }

        if ($excluded_categories) {
            // category_path holds every ancestor pair, so excluding a category
            // also excludes everything below it.
            $sql .= " AND `p`.`product_id` NOT IN (SELECT `p2c`.`product_id` FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`category_id` IN (SELECT `cp`.`category_id` FROM `" . DB_PREFIX . "category_path` `cp` WHERE `cp`.`path_id` IN (" . implode(',', $excluded_categories) . ")))";
        }

        $sql .= " ORDER BY `p`.`product_id` ASC LIMIT " . $start . "," . $limit;

        return $this->db->query($sql)->rows;
    }

    /**
     * OpenCart 4.1 keeps SKU/UPC/EAN/JAN/ISBN/MPN in `product_code`, but stores
     * upgraded from 4.0 have the legacy `product` columns dropped while fresh
     * 4.1 installs still have them. Only select the ones that actually exist so
     * the feed query cannot fatal.
     *
     * @return array<int, string>
     */
    private function getLegacyIdentifierColumns(): array {
        if (!$this->product_columns) {
            foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`")->rows as $row) {
                $this->product_columns[strtolower((string)$row['Field'])] = true;
            }
        }

        $columns = [];

        foreach (['sku', 'upc', 'ean', 'jan', 'isbn', 'mpn'] as $column) {
            if (isset($this->product_columns[$column])) {
                $columns[] = $column;
            }
        }

        return $columns;
    }

    /**
     * @param array<int, int> $product_ids
     *
     * @return array<int, array<string, string>>
     */
    private function getIdentifiers(array $product_ids): array {
        if (!$product_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `value` != ''");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][strtoupper((string)$row['code'])] = (string)$row['value'];
        }

        return $result;
    }

    /**
     * product_code rows win over the legacy product columns when both are present.
     *
     * @param array<string, mixed>  $product
     * @param array<string, string> $product_identifiers
     * @param array<int, string>    $codes
     */
    private function firstIdentifier(array $product, array $product_identifiers, array $codes): string {
        foreach ($codes as $code) {
            if (isset($product_identifiers[$code]) && trim($product_identifiers[$code]) !== '') {
                return trim($product_identifiers[$code]);
            }

            $column = strtolower($code);

            if (isset($product[$column]) && trim((string)$product[$column]) !== '') {
                return trim((string)$product[$column]);
            }
        }

        return '';
    }

    /**
     * @param array<int, int> $product_ids
     * @param array<int, int> $attribute_ids
     *
     * @return array<int, array<int, string>>
     */
    private function getAttributes(array $product_ids, int $language_id, array $attribute_ids): array {
        $attribute_ids = array_values(array_unique(array_filter(array_map('intval', $attribute_ids))));

        if (!$product_ids || !$attribute_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `attribute_id`, `text` FROM `" . DB_PREFIX . "product_attribute` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `language_id` = '" . $language_id . "' AND `attribute_id` IN (" . implode(',', $attribute_ids) . ")");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][(int)$row['attribute_id']] = (string)$row['text'];
        }

        return $result;
    }

    private function getCategoryPath(int $category_id, int $language_id): string {
        if ($category_id <= 0) {
            return '';
        }

        if (isset($this->category_paths[$category_id])) {
            return $this->category_paths[$category_id];
        }

        $query = $this->db->query("SELECT GROUP_CONCAT(`cd`.`name` ORDER BY `cp`.`level` SEPARATOR ' > ') AS `path` FROM `" . DB_PREFIX . "category_path` `cp` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`cd`.`category_id` = `cp`.`path_id` AND `cd`.`language_id` = '" . $language_id . "') WHERE `cp`.`category_id` = '" . $category_id . "'");

        $path = $query->num_rows ? $this->text((string)$query->row['path']) : '';

        $this->category_paths[$category_id] = $path;

        return $path;
    }

    private function getStoreUrl(int $store_id): string {
        if ($store_id) {
            $query = $this->db->query("SELECT `url` FROM `" . DB_PREFIX . "store` WHERE `store_id` = '" . $store_id . "'");

            if ($query->num_rows && $query->row['url']) {
                return rtrim(html_entity_decode((string)$query->row['url'], ENT_QUOTES, 'UTF-8'), '/');
            }
        } else {
            $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = 'config' AND `key` = 'config_url'");

            if ($query->num_rows && $query->row['value']) {
                return rtrim(html_entity_decode((string)$query->row['value'], ENT_QUOTES, 'UTF-8'), '/');
            }
        }

        return rtrim(html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8'), '/');
    }

    /**
     * SEO URLs only resolve for the store this request is being served from, so
     * a remote store falls back to the non-rewritten route.
     */
    private function getProductLink(int $product_id, bool $local_store, string $store_url): string {
        if ($local_store) {
            return html_entity_decode($this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id), ENT_QUOTES, 'UTF-8');
        }

        return $store_url . '/index.php?route=product/product&product_id=' . $product_id;
    }

    private function encodeImagePath(string $image): string {
        $parts = explode('/', ltrim($image, '/'));

        return implode('/', array_map('rawurlencode', $parts));
    }

    /**
     * Optionally tax inclusive, converted into the feed currency and formatted
     * with a dot decimal separator.
     */
    private function money(float $value, int $tax_class_id, bool $include_tax, string $from, string $to): string {
        if ($include_tax && $this->registry->has('tax')) {
            $value = (float)$this->tax->calculate($value, $tax_class_id, true);
        }

        return number_format((float)$this->currency->convert($value, $from, $to), 2, '.', '');
    }

    /**
     * Drops characters XML 1.0 cannot carry. CDATA does not make a raw
     * 0x00-0x08 byte legal, so this runs on everything that is written out.
     */
    private function clean(string $value): string {
        if (!mb_check_encoding($value, 'UTF-8')) {
            $value = (string)mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }

        $clean = preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $value);

        if ($clean === null) {
            // Invalid UTF-8 that survived the check: fall back to a byte filter.
            $clean = preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value);
        }

        return trim((string)$clean);
    }

    /**
     * Stored product text is HTML encoded, so entities are decoded once here.
     */
    private function text(string $value): string {
        $value = html_entity_decode($value, ENT_QUOTES, 'UTF-8');

        return trim((string)preg_replace('/\s+/u', ' ', $this->clean(strip_tags($value))));
    }

    private function esc(string $value): string {
        return htmlspecialchars($this->clean($value), ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private function cdata(string $value): string {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $this->clean($value)) . ']]>';
    }
}
