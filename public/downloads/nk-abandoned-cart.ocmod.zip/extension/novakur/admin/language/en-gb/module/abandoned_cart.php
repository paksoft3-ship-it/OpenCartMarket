<?php
// Heading
$_['heading_title']            = 'NovaKur Abandoned Cart Recovery';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified NovaKur Abandoned Cart Recovery settings!';
$_['text_delete_success']      = 'Success: The selected abandoned carts have been deleted!';
$_['text_edit']                = 'Edit NovaKur Abandoned Cart Recovery';
$_['text_enabled']             = 'Enabled';
$_['text_disabled']            = 'Disabled';
$_['text_yes']                 = 'Yes';
$_['text_no']                  = 'No';
$_['text_dashboard']           = 'Dashboard';
$_['text_settings']            = 'Settings';
$_['text_emails']              = 'E-mail Series';
$_['text_cron']                = 'Cron';
$_['text_list']                = 'Abandoned carts';
$_['text_no_results']          = 'No abandoned carts have been captured yet.';
$_['text_confirm']             = 'Are you sure you want to delete the selected carts?';
$_['text_all_status']          = 'All statuses';
$_['text_status_pending']      = 'Pending';
$_['text_status_recovered']    = 'Recovered';
$_['text_status_closed']       = 'Ordered (no link)';
$_['text_stage']               = 'Stage %d';
$_['text_stage_none']          = 'Not e-mailed';
$_['text_stage_1']             = 'Stage 1 - first reminder';
$_['text_stage_2']             = 'Stage 2 - second reminder';
$_['text_stage_3']             = 'Stage 3 - final reminder';
$_['text_pending_carts']       = 'Pending carts';
$_['text_pending_value']       = 'Pending value';
$_['text_recovered_carts']     = 'Recovered carts';
$_['text_recovered_value']     = 'Recovered value';
$_['text_emailed_carts']       = 'Carts e-mailed';
$_['text_recovery_rate']       = 'Recovery rate';
$_['text_placeholders']        = 'Placeholders: {name} {store} {total} {coupon} {cart_link} {products}';

// Default e-mail templates
$_['text_default_subject_1']   = 'You left something in your cart at {store}';
$_['text_default_subject_2']   = '{name}, your cart is still waiting';
$_['text_default_subject_3']   = 'Last chance - your cart at {store}';
$_['text_default_body_1']      = '<p>Hi {name},</p><p>You left a few items in your cart at {store}. We saved them for you - pick up right where you left off.</p>';
$_['text_default_body_2']      = '<p>Hi {name},</p><p>Your cart at {store} is still here, but stock is not guaranteed. Your basket total is {total}.</p>';
$_['text_default_body_3']      = '<p>Hi {name},</p><p>This is the last reminder about your cart at {store}. Use the code below at checkout to save on your order.</p>';

// Column
$_['column_email']             = 'E-mail';
$_['column_products']          = 'Cart contents';
$_['column_product_count']     = 'Items';
$_['column_total']             = 'Cart value';
$_['column_last_emailed_stage'] = 'Stage';
$_['column_recovered']         = 'Status';
$_['column_recovered_value']   = 'Recovered';
$_['column_date_added']        = 'Abandoned';
$_['column_date_modified']     = 'Last activity';
$_['column_action']            = 'Order';

// Entry
$_['entry_status']             = 'Status';
$_['entry_capture_guests']     = 'Capture guest e-mails';
$_['entry_stage_status']       = 'Send this stage';
$_['entry_stage_hours']        = 'Send after (hours)';
$_['entry_subject']            = 'Subject';
$_['entry_body']               = 'Body (HTML)';
$_['entry_coupon_status']      = 'Attach coupon to final e-mail';
$_['entry_coupon_code']        = 'Coupon code';
$_['entry_batch_limit']        = 'E-mails per cron run';
$_['entry_expire_days']        = 'Delete carts after (days)';
$_['entry_min_total']          = 'Minimum cart value';
$_['entry_cron_token']         = 'Cron token';
$_['entry_cron_url']           = 'Cron URL';
$_['entry_filter_status']      = 'Status';
$_['entry_filter_email']       = 'E-mail';

// Help
$_['help_capture_guests']      = 'Adds a small script to the storefront that records the e-mail a guest types at checkout, so their cart can be recovered too. Logged in customers are always captured.';
$_['help_stage_hours']         = 'Hours of inactivity before this reminder is sent. Each stage must be later than the one before it.';
$_['help_coupon_code']         = 'Create the coupon first under Marketing &gt; Coupons, then enter its code here. It is shown in the final e-mail and applied automatically when the shopper follows the recovery link.';
$_['help_batch_limit']         = 'Maximum number of e-mails sent per cron run (1-500). Keep this within your host\'s hourly sending limit.';
$_['help_expire_days']         = 'Snapshots older than this are removed on each cron run. Use 0 to keep them forever.';
$_['help_min_total']           = 'Carts below this value (store default currency) are ignored. Use 0 to capture every cart.';
$_['help_cron_token']          = 'Secret that guards the cron URL. Clear the field and save to generate a new one - the old URL stops working immediately.';
$_['help_cron_url']            = 'Call this URL on a schedule (hourly is a good default). Nothing is sent until it runs.';
$_['help_cron_command']        = 'Example crontab entry:';
$_['help_mail']                = 'E-mails are sent with the mail engine configured under System &gt; Settings &gt; Mail. Delivery, SPF/DKIM and the cron schedule are part of your live store setup and cannot be verified from this screen.';
$_['help_placeholders']        = 'Leave a subject or body empty to fall back to the built-in default text.';

// Button
$_['button_save']              = 'Save';
$_['button_back']              = 'Back';
$_['button_delete']            = 'Delete';
$_['button_copy']              = 'Copy';
$_['button_filter']            = 'Filter';
$_['button_view']              = 'View order';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify this module!';
$_['error_coupon_code']        = 'A coupon code is required when the coupon is enabled!';
$_['error_coupon_code_format'] = 'Coupon code must be 1-20 letters, numbers, hyphens or underscores!';
$_['error_hours']              = 'Delay must be between 0 and 8760 hours!';
$_['error_stage_order']        = 'Each stage must be sent later than the stage before it!';
$_['error_batch_limit']        = 'E-mails per cron run must be between 1 and 500!';
$_['error_expire_days']        = 'Retention must be between 0 and 3650 days!';
$_['error_min_total']          = 'Minimum cart value cannot be negative!';
$_['error_subject']            = 'Subject must be under 256 characters!';
