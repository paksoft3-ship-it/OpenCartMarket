<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

/**
 * NovaKur Abandoned Cart Recovery - admin controller.
 */
class AbandonedCart extends \Opencart\System\Engine\Controller {
	/**
	 * Storefront events registered on install / removed on uninstall.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	private array $events = [
		[
			'code'        => 'nk_abandoned_cart_footer',
			'description' => 'NovaKur Abandoned Cart: snapshot the cart and inject the guest e-mail capture script.',
			'trigger'     => 'catalog/view/common/footer/after',
			'action'      => 'extension/novakur/event/abandoned_cart.footer'
		],
		[
			'code'        => 'nk_abandoned_cart_add',
			'description' => 'NovaKur Abandoned Cart: snapshot the cart after an add-to-cart.',
			'trigger'     => 'catalog/controller/common/cart.info/before',
			'action'      => 'extension/novakur/event/abandoned_cart.snapshot'
		],
		[
			'code'        => 'nk_abandoned_cart_checkout',
			'description' => 'NovaKur Abandoned Cart: snapshot the cart when checkout is opened.',
			'trigger'     => 'catalog/controller/checkout/checkout/before',
			'action'      => 'extension/novakur/event/abandoned_cart.snapshot'
		],
		[
			'code'        => 'nk_abandoned_cart_success',
			'description' => 'NovaKur Abandoned Cart: mark a snapshot recovered once the order completes.',
			'trigger'     => 'catalog/controller/checkout/success/before',
			'action'      => 'extension/novakur/event/abandoned_cart.recovered'
		]
	];

	/**
	 * Setting keys and their factory values. save() writes exactly these keys, so an
	 * unchecked box or a missing field can never silently drop a setting.
	 *
	 * @return array<string, string>
	 */
	private function defaults(): array {
		$this->load->language('extension/novakur/module/abandoned_cart');

		return [
			'module_abandoned_cart_status'         => '0',
			'module_abandoned_cart_capture_guests' => '1',
			'module_abandoned_cart_stage_1_status' => '1',
			'module_abandoned_cart_stage_1_hours'  => '1',
			'module_abandoned_cart_stage_2_status' => '1',
			'module_abandoned_cart_stage_2_hours'  => '24',
			'module_abandoned_cart_stage_3_status' => '1',
			'module_abandoned_cart_stage_3_hours'  => '72',
			'module_abandoned_cart_coupon_status'  => '0',
			'module_abandoned_cart_coupon_code'    => '',
			'module_abandoned_cart_batch_limit'    => '50',
			'module_abandoned_cart_expire_days'    => '30',
			'module_abandoned_cart_min_total'      => '0',
			'module_abandoned_cart_cron_token'     => '',
			'module_abandoned_cart_subject_1'      => $this->language->get('text_default_subject_1'),
			'module_abandoned_cart_subject_2'      => $this->language->get('text_default_subject_2'),
			'module_abandoned_cart_subject_3'      => $this->language->get('text_default_subject_3'),
			'module_abandoned_cart_body_1'         => $this->language->get('text_default_body_1'),
			'module_abandoned_cart_body_2'         => $this->language->get('text_default_body_2'),
			'module_abandoned_cart_body_3'         => $this->language->get('text_default_body_3')
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/novakur/module/abandoned_cart');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting('module_abandoned_cart', $store_id);

		$data = [];

		foreach ($this->defaults() as $key => $value) {
			if (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $value;
			}
		}

		// A token is minted on install; regenerate it here if the store was upgraded from
		// an older build or the value was cleared by hand.
		if ((string)$data['module_abandoned_cart_cron_token'] === '') {
			$data['module_abandoned_cart_cron_token'] = oc_token(32);
		}

		foreach ($this->language->all() as $key => $value) {
			$data[$key] = $value;
		}

		$data['store_id'] = $store_id;

		// Multi-store: the cron has to be hit on the URL of the store it belongs to.
		$catalog_url = HTTP_CATALOG;

		if ($store_id) {
			$this->load->model('setting/store');

			$store_info = $this->model_setting_store->getStore($store_id);

			if ($store_info && !empty($store_info['url'])) {
				$catalog_url = rtrim((string)$store_info['url'], '/') . '/';
			}
		}

		$data['cron_url'] = $catalog_url . 'index.php?route=extension/novakur/module/abandoned_cart.cron&token=' . rawurlencode((string)$data['module_abandoned_cart_cron_token']);
		$data['cron_command'] = '0 * * * * wget -q -O - "' . $data['cron_url'] . '" >/dev/null 2>&1';

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/novakur/module/abandoned_cart', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save'] = $this->url->link('extension/novakur/module/abandoned_cart.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['delete'] = $this->url->link('extension/novakur/module/abandoned_cart.delete', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['list_url'] = $this->url->link('extension/novakur/module/abandoned_cart.list', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id, true);
		$data['list'] = $this->getList();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/novakur/module/abandoned_cart', $data));
	}

	/**
	 * AJAX partial for the dashboard tab.
	 *
	 * @return void
	 */
	public function list(): void {
		$this->load->language('extension/novakur/module/abandoned_cart');

		$this->response->setOutput($this->getList());
	}

	/**
	 * @return string
	 */
	public function getList(): string {
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$sort_data = ['email', 'total', 'product_count', 'last_emailed_stage', 'recovered', 'date_added', 'date_modified'];

		$sort = (isset($this->request->get['sort']) && in_array($this->request->get['sort'], $sort_data, true)) ? (string)$this->request->get['sort'] : 'date_modified';
		$order = (isset($this->request->get['order']) && strtoupper((string)$this->request->get['order']) === 'ASC') ? 'ASC' : 'DESC';
		$page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;

		$filter_status = isset($this->request->get['filter_status']) ? (string)$this->request->get['filter_status'] : '';

		if (!in_array($filter_status, ['', 'pending', 'recovered', 'closed'], true)) {
			$filter_status = '';
		}

		$filter_email = isset($this->request->get['filter_email']) ? trim((string)$this->request->get['filter_email']) : '';

		$limit = 10;

		$url = '&store_id=' . $store_id;

		if ($filter_status !== '') {
			$url .= '&filter_status=' . urlencode($filter_status);
		}

		if ($filter_email !== '') {
			$url .= '&filter_email=' . urlencode($filter_email);
		}

		$this->load->model('extension/novakur/module/abandoned_cart');

		$filter_data = [
			'filter_store_id' => $store_id,
			'filter_status'   => $filter_status,
			'filter_email'    => $filter_email,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $limit,
			'limit'           => $limit
		];

		$cart_total = $this->model_extension_novakur_module_abandoned_cart->getTotalCarts($filter_data);
		$results = $this->model_extension_novakur_module_abandoned_cart->getCarts($filter_data);

		$currency = (string)$this->config->get('config_currency');

		$data = [];
		$data['carts'] = [];

		foreach ($results as $result) {
			$items = json_decode((string)$result['cart_data'], true);

			$products = [];

			if (is_array($items)) {
				foreach ($items as $item) {
					$products[] = (int)($item['quantity'] ?? 0) . ' x ' . (string)($item['name'] ?? '');
				}
			}

			if ((int)$result['recovered'] === 1) {
				$status = $this->language->get('text_status_recovered');
				$status_class = 'success';
			} elseif ((int)$result['recovered'] === 2) {
				$status = $this->language->get('text_status_closed');
				$status_class = 'secondary';
			} else {
				$status = $this->language->get('text_status_pending');
				$status_class = 'warning';
			}

			// The cart may have been captured in a currency the store no longer has.
			$row_currency = (string)$result['currency_code'];

			if ($row_currency === '' || !$this->currency->has($row_currency)) {
				$row_currency = $currency;
			}

			$data['carts'][] = [
				'abandoned_cart_id' => (int)$result['abandoned_cart_id'],
				'email'             => (string)$result['email'],
				'name'              => (string)$result['name'],
				'products'          => implode(', ', $products),
				'product_count'     => (int)$result['product_count'],
				'total'             => $this->currency->format((float)$result['total'], $row_currency),
				'recovered_total'   => (int)$result['recovered'] === 1 ? $this->currency->format((float)$result['recovered_total'], $currency) : '',
				'stage'             => (int)$result['last_emailed_stage'],
				'status'            => $status,
				'status_class'      => $status_class,
				'order_id'          => (int)$result['order_id'],
				'order_edit'        => (int)$result['order_id'] ? $this->url->link('sale/order.info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . (int)$result['order_id']) : '',
				'date_added'        => date($this->language->get('datetime_format'), strtotime((string)$result['date_added'])),
				'date_modified'     => date($this->language->get('datetime_format'), strtotime((string)$result['date_modified']))
			];
		}

		$summary = $this->model_extension_novakur_module_abandoned_cart->getSummary($store_id);

		$data['summary'] = [
			'pending_total'   => $summary['pending_total'],
			'pending_value'   => $this->currency->format((float)$summary['pending_value'], $currency),
			'recovered_total' => $summary['recovered_total'],
			'recovered_value' => $this->currency->format((float)$summary['recovered_value'], $currency),
			'emailed_total'   => $summary['emailed_total'],
			'recovery_rate'   => $summary['recovery_rate']
		];

		$data['sort'] = $sort;
		$data['order'] = $order;

		$reverse = ($order === 'ASC') ? 'DESC' : 'ASC';

		foreach ($sort_data as $column) {
			$data['sort_' . $column] = $this->url->link('extension/novakur/module/abandoned_cart.list', 'user_token=' . $this->session->data['user_token'] . $url . '&sort=' . $column . '&order=' . ($sort === $column ? $reverse : 'ASC'));
		}

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $cart_total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->url->link('extension/novakur/module/abandoned_cart.list', 'user_token=' . $this->session->data['user_token'] . $url . '&sort=' . $sort . '&order=' . $order . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), $cart_total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($cart_total - $limit)) ? $cart_total : ((($page - 1) * $limit) + $limit), $cart_total, (int)ceil($cart_total / $limit));

		$data['filter_status'] = $filter_status;
		$data['filter_email'] = $filter_email;

		$data['action'] = $this->url->link('extension/novakur/module/abandoned_cart.list', 'user_token=' . $this->session->data['user_token'] . $url);
		$data['delete'] = $this->url->link('extension/novakur/module/abandoned_cart.delete', 'user_token=' . $this->session->data['user_token'] . $url);

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/novakur/module/abandoned_cart_list', $data);
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/novakur/module/abandoned_cart');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/novakur/module/abandoned_cart')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$coupon_code = isset($post['module_abandoned_cart_coupon_code']) ? trim((string)$post['module_abandoned_cart_coupon_code']) : '';
		$coupon_status = !empty($post['module_abandoned_cart_coupon_status']) ? 1 : 0;

		if ($coupon_status && $coupon_code === '') {
			$json['error']['coupon_code'] = $this->language->get('error_coupon_code');
		}

		if ($coupon_code !== '' && (oc_strlen($coupon_code) > 20 || !preg_match('/^[A-Za-z0-9_-]+$/', $coupon_code))) {
			$json['error']['coupon_code'] = $this->language->get('error_coupon_code_format');
		}

		$hours = [];

		for ($stage = 1; $stage <= 3; $stage++) {
			$value = isset($post['module_abandoned_cart_stage_' . $stage . '_hours']) ? (int)$post['module_abandoned_cart_stage_' . $stage . '_hours'] : 0;

			if ($value < 0 || $value > 8760) {
				$json['error']['stage_' . $stage . '_hours'] = $this->language->get('error_hours');
			}

			$hours[$stage] = $value;
		}

		if (!isset($json['error']['stage_2_hours']) && !isset($json['error']['stage_1_hours']) && $hours[2] <= $hours[1]) {
			$json['error']['stage_2_hours'] = $this->language->get('error_stage_order');
		}

		if (!isset($json['error']['stage_3_hours']) && !isset($json['error']['stage_2_hours']) && $hours[3] <= $hours[2]) {
			$json['error']['stage_3_hours'] = $this->language->get('error_stage_order');
		}

		$batch_limit = isset($post['module_abandoned_cart_batch_limit']) ? (int)$post['module_abandoned_cart_batch_limit'] : 50;

		if ($batch_limit < 1 || $batch_limit > 500) {
			$json['error']['batch_limit'] = $this->language->get('error_batch_limit');
		}

		$expire_days = isset($post['module_abandoned_cart_expire_days']) ? (int)$post['module_abandoned_cart_expire_days'] : 30;

		if ($expire_days < 0 || $expire_days > 3650) {
			$json['error']['expire_days'] = $this->language->get('error_expire_days');
		}

		$min_total = isset($post['module_abandoned_cart_min_total']) ? (float)$post['module_abandoned_cart_min_total'] : 0;

		if ($min_total < 0) {
			$json['error']['min_total'] = $this->language->get('error_min_total');
		}

		$cron_token = isset($post['module_abandoned_cart_cron_token']) ? trim((string)$post['module_abandoned_cart_cron_token']) : '';

		if ($cron_token === '' || !preg_match('/^[A-Za-z0-9]{16,64}$/', $cron_token)) {
			$cron_token = oc_token(32);
		}

		for ($stage = 1; $stage <= 3; $stage++) {
			$subject = isset($post['module_abandoned_cart_subject_' . $stage]) ? trim((string)$post['module_abandoned_cart_subject_' . $stage]) : '';

			if (oc_strlen($subject) > 255) {
				$json['error']['subject_' . $stage] = $this->language->get('error_subject');
			}
		}

		if (!$json) {
			$save = [
				'module_abandoned_cart_status'         => !empty($post['module_abandoned_cart_status']) ? '1' : '0',
				'module_abandoned_cart_capture_guests' => !empty($post['module_abandoned_cart_capture_guests']) ? '1' : '0',
				'module_abandoned_cart_coupon_status'  => (string)$coupon_status,
				'module_abandoned_cart_coupon_code'    => $coupon_code,
				'module_abandoned_cart_batch_limit'    => (string)$batch_limit,
				'module_abandoned_cart_expire_days'    => (string)$expire_days,
				'module_abandoned_cart_min_total'      => (string)$min_total,
				'module_abandoned_cart_cron_token'     => $cron_token
			];

			for ($stage = 1; $stage <= 3; $stage++) {
				$save['module_abandoned_cart_stage_' . $stage . '_status'] = !empty($post['module_abandoned_cart_stage_' . $stage . '_status']) ? '1' : '0';
				$save['module_abandoned_cart_stage_' . $stage . '_hours'] = (string)$hours[$stage];
				$save['module_abandoned_cart_subject_' . $stage] = isset($post['module_abandoned_cart_subject_' . $stage]) ? trim((string)$post['module_abandoned_cart_subject_' . $stage]) : '';
				$save['module_abandoned_cart_body_' . $stage] = isset($post['module_abandoned_cart_body_' . $stage]) ? (string)$post['module_abandoned_cart_body_' . $stage] : '';
			}

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_abandoned_cart', $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Remove selected snapshots from the dashboard list.
	 *
	 * @return void
	 */
	public function delete(): void {
		$this->load->language('extension/novakur/module/abandoned_cart');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/novakur/module/abandoned_cart')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$selected = (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) ? $this->request->post['selected'] : [];

		if (!isset($json['error'])) {
			$this->load->model('extension/novakur/module/abandoned_cart');

			foreach ($selected as $abandoned_cart_id) {
				$this->model_extension_novakur_module_abandoned_cart->deleteCart((int)$abandoned_cart_id);
			}

			$json['success'] = $this->language->get('text_delete_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/novakur/module/abandoned_cart');

		$this->model_extension_novakur_module_abandoned_cart->createTable();

		$defaults = $this->defaults();
		$defaults['module_abandoned_cart_cron_token'] = oc_token(32);

		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('module_abandoned_cart', $defaults);

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('module_abandoned_cart');

		$this->load->model('extension/novakur/module/abandoned_cart');

		$this->model_extension_novakur_module_abandoned_cart->dropTable();
	}
}
