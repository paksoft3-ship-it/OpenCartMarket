<?php
// Text
$_['text_customer']        = 'there';
$_['text_items']           = 'Your cart';
$_['text_total']           = 'Total';
$_['text_coupon']          = 'Your discount code';
$_['text_button_recover']  = 'Return to my cart';
$_['text_mail_footer']     = 'You are receiving this message because a cart was left behind at %s. If this was not you, please ignore this e-mail.';

// Default e-mail templates (used when the merchant leaves a field blank)
$_['text_default_subject_1'] = 'You left something in your cart at {store}';
$_['text_default_subject_2'] = '{name}, your cart is still waiting';
$_['text_default_subject_3'] = 'Last chance - your cart at {store}';

$_['text_default_body_1'] = '<p>Hi {name},</p><p>You left a few items in your cart at {store}. We saved them for you - pick up right where you left off.</p>';
$_['text_default_body_2'] = '<p>Hi {name},</p><p>Your cart at {store} is still here, but stock is not guaranteed. Your basket total is {total}.</p>';
$_['text_default_body_3'] = '<p>Hi {name},</p><p>This is the last reminder about your cart at {store}. Use the code below at checkout to save on your order.</p>';
