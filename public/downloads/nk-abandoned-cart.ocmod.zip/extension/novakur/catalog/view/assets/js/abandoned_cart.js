/**
 * NovaKur Abandoned Cart Recovery - guest e-mail capture.
 *
 * Watches the checkout / register e-mail fields and posts the address to the storefront
 * capture endpoint once, so a guest cart can be tied to a mailbox. No third party calls.
 */
(function () {
    'use strict';

    var config = window.nk_abandoned_cart;

    if (!config || !config.url) {
        return;
    }

    var lastSent = config.saved || '';
    var pending = null;

    function isEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
    }

    function findName() {
        var selectors = ['input[name="firstname"]', '#input-firstname', 'input[name="payment_firstname"]'];

        for (var i = 0; i < selectors.length; i++) {
            var field = document.querySelector(selectors[i]);

            if (field && field.value) {
                return field.value.trim().substring(0, 96);
            }
        }

        return '';
    }

    function send(email) {
        if (!isEmail(email) || email === lastSent) {
            return;
        }

        lastSent = email;

        var body = 'email=' + encodeURIComponent(email) + '&name=' + encodeURIComponent(findName());

        try {
            fetch(config.url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                body: body
            }).catch(function () {
                /* offline or blocked - capture is best effort */
            });
        } catch (e) {
            /* fetch unavailable - skip silently */
        }
    }

    function queue(email) {
        if (pending) {
            window.clearTimeout(pending);
        }

        pending = window.setTimeout(function () {
            send(email);
        }, 800);
    }

    function isEmailField(element) {
        if (!element || element.tagName !== 'INPUT') {
            return false;
        }

        var type = (element.getAttribute('type') || '').toLowerCase();
        var name = (element.getAttribute('name') || '').toLowerCase();
        var id = (element.getAttribute('id') || '').toLowerCase();

        return type === 'email' || name === 'email' || id === 'input-email';
    }

    document.addEventListener('change', function (e) {
        if (isEmailField(e.target)) {
            send(e.target.value.trim());
        }
    }, true);

    document.addEventListener('blur', function (e) {
        if (isEmailField(e.target)) {
            send(e.target.value.trim());
        }
    }, true);

    document.addEventListener('input', function (e) {
        if (isEmailField(e.target)) {
            queue(e.target.value.trim());
        }
    }, true);
})();
