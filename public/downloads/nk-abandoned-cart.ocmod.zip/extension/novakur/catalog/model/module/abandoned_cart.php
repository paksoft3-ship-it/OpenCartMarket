<?php
namespace Opencart\Catalog\Model\Extension\Novakur\Module;

/**
 * NovaKur Abandoned Cart Recovery - catalog model.
 *
 * All storefront reads/writes against `DB_PREFIX . nk_abandoned_cart` live here so the
 * event controller, the capture endpoint and the cron endpoint share one implementation.
 *
 * recovered column states:
 *   0 = pending  (still eligible for the recovery email series)
 *   1 = recovered via a recovery link click
 *   2 = ordered without using a recovery link (closed, not counted as recovered value)
 */
class AbandonedCart extends \Opencart\System\Engine\Model {
	/**
	 * Find the pending snapshot belonging to this shopper.
	 *
	 * Logged in customers are matched on customer_id (their session id rotates on login),
	 * guests are matched on the session id.
	 *
	 * @param int    $store_id
	 * @param int    $customer_id
	 * @param string $session_id
	 *
	 * @return array<string, mixed>
	 */
	public function getPending(int $store_id, int $customer_id, string $session_id): array {
		if ($customer_id) {
			$sql = "SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `customer_id` = '" . (int)$customer_id . "' AND `recovered` = '0' ORDER BY `abandoned_cart_id` DESC LIMIT 1";
		} else {
			$sql = "SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `customer_id` = '0' AND `session_id` = '" . $this->db->escape($session_id) . "' AND `recovered` = '0' ORDER BY `abandoned_cart_id` DESC LIMIT 1";
		}

		$query = $this->db->query($sql);

		return $query->row;
	}

	/**
	 * Insert or update the pending snapshot for this shopper.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return int abandoned_cart_id
	 */
	public function saveSnapshot(array $data): int {
		$existing = $this->getPending((int)$data['store_id'], (int)$data['customer_id'], (string)$data['session_id']);

		$fields = "`store_id` = '" . (int)$data['store_id'] . "',
			`customer_id` = '" . (int)$data['customer_id'] . "',
			`email` = '" . $this->db->escape((string)$data['email']) . "',
			`name` = '" . $this->db->escape((string)$data['name']) . "',
			`session_id` = '" . $this->db->escape((string)$data['session_id']) . "',
			`language_id` = '" . (int)$data['language_id'] . "',
			`currency_code` = '" . $this->db->escape((string)$data['currency_code']) . "',
			`cart_data` = '" . $this->db->escape((string)json_encode($data['items'])) . "',
			`product_count` = '" . (int)$data['product_count'] . "',
			`total` = '" . (float)$data['total'] . "',
			`date_modified` = NOW()";

		if ($existing) {
			$this->db->query("UPDATE `" . DB_PREFIX . "nk_abandoned_cart` SET " . $fields . " WHERE `abandoned_cart_id` = '" . (int)$existing['abandoned_cart_id'] . "'");

			return (int)$existing['abandoned_cart_id'];
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_abandoned_cart` SET " . $fields . ", `token` = '" . $this->db->escape((string)$data['token']) . "', `date_added` = NOW()");

		return (int)$this->db->getLastId();
	}

	/**
	 * Drop the pending snapshot for this shopper (cart emptied by hand).
	 *
	 * @param int    $store_id
	 * @param int    $customer_id
	 * @param string $session_id
	 *
	 * @return void
	 */
	public function deletePending(int $store_id, int $customer_id, string $session_id): void {
		if ($customer_id) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `customer_id` = '" . (int)$customer_id . "' AND `recovered` = '0'");
		} else {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `customer_id` = '0' AND `session_id` = '" . $this->db->escape($session_id) . "' AND `recovered` = '0'");
		}
	}

	/**
	 * Drop pending guest snapshots for an address once that shopper is logged in.
	 *
	 * OpenCart moves the guest cart rows onto the customer at login, but the guest snapshot
	 * would otherwise linger and produce a second, duplicate reminder series for the same
	 * cart. Matching on the e-mail rather than the session id keeps this working even
	 * though the session id changes on login.
	 *
	 * @param int    $store_id
	 * @param string $email
	 *
	 * @return void
	 */
	public function deleteGuestPendingByEmail(int $store_id, string $email): void {
		if ($email === '') {
			return;
		}

		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `customer_id` = '0' AND `recovered` = '0' AND `email` = '" . $this->db->escape($email) . "'");
	}

	/**
	 * Look up a snapshot by its public recovery token.
	 *
	 * @param string $token
	 *
	 * @return array<string, mixed>
	 */
	public function getCartByToken(string $token): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `token` = '" . $this->db->escape($token) . "' LIMIT 1");

		return $query->row;
	}

	/**
	 * @param int $abandoned_cart_id
	 *
	 * @return array<string, mixed>
	 */
	public function getCart(int $abandoned_cart_id): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `abandoned_cart_id` = '" . (int)$abandoned_cart_id . "' LIMIT 1");

		return $query->row;
	}

	/**
	 * Flag a snapshot as converted.
	 *
	 * @param int   $abandoned_cart_id
	 * @param int   $order_id
	 * @param float $total
	 * @param int   $state 1 = recovered via link, 2 = ordered without the link
	 *
	 * @return void
	 */
	public function markRecovered(int $abandoned_cart_id, int $order_id, float $total, int $state = 1): void {
		if ($state !== 2) {
			$state = 1;
		}

		$this->db->query("UPDATE `" . DB_PREFIX . "nk_abandoned_cart` SET `recovered` = '" . (int)$state . "', `order_id` = '" . (int)$order_id . "', `recovered_total` = '" . (float)$total . "', `date_modified` = NOW() WHERE `abandoned_cart_id` = '" . (int)$abandoned_cart_id . "' AND `recovered` = '0'");
	}

	/**
	 * Close every other pending snapshot for the same shopper once they order, so the
	 * series stops even when they never clicked a recovery link.
	 *
	 * @param int    $store_id
	 * @param int    $customer_id
	 * @param string $email
	 * @param int    $exclude_id
	 * @param int    $order_id
	 *
	 * @return void
	 */
	public function closeOtherPending(int $store_id, int $customer_id, string $email, int $exclude_id, int $order_id): void {
		$where = [];

		if ($customer_id) {
			$where[] = "`customer_id` = '" . (int)$customer_id . "'";
		}

		if ($email !== '') {
			$where[] = "`email` = '" . $this->db->escape($email) . "'";
		}

		if (!$where) {
			return;
		}

		$this->db->query("UPDATE `" . DB_PREFIX . "nk_abandoned_cart` SET `recovered` = '2', `order_id` = '" . (int)$order_id . "', `date_modified` = NOW() WHERE `store_id` = '" . (int)$store_id . "' AND `recovered` = '0' AND `abandoned_cart_id` != '" . (int)$exclude_id . "' AND (" . implode(' OR ', $where) . ")");
	}

	/**
	 * Snapshots that are due for the given email stage.
	 *
	 * @param int $store_id
	 * @param int $stage 1..3
	 * @param int $hours delay from abandonment
	 * @param int $limit
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getDue(int $store_id, int $stage, int $hours, int $limit): array {
		$stage = max(1, min(3, $stage));
		$hours = max(0, $hours);
		$limit = max(1, min(500, $limit));

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `recovered` = '0' AND `last_emailed_stage` = '" . (int)($stage - 1) . "' AND `email` != '' AND `product_count` > 0 AND `date_modified` <= DATE_SUB(NOW(), INTERVAL " . (int)$hours . " HOUR) ORDER BY `date_modified` ASC LIMIT " . (int)$limit);

		return $query->rows;
	}

	/**
	 * @param int $abandoned_cart_id
	 * @param int $stage
	 *
	 * @return void
	 */
	public function markEmailed(int $abandoned_cart_id, int $stage): void {
		$this->db->query("UPDATE `" . DB_PREFIX . "nk_abandoned_cart` SET `last_emailed_stage` = '" . (int)max(0, min(3, $stage)) . "', `date_last_emailed` = NOW() WHERE `abandoned_cart_id` = '" . (int)$abandoned_cart_id . "'");
	}

	/**
	 * Delete snapshots older than $days. 0 disables housekeeping.
	 *
	 * @param int $store_id
	 * @param int $days
	 *
	 * @return int rows removed
	 */
	public function purge(int $store_id, int $days): int {
		if ($days < 1) {
			return 0;
		}

		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_abandoned_cart` WHERE `store_id` = '" . (int)$store_id . "' AND `date_modified` <= DATE_SUB(NOW(), INTERVAL " . (int)$days . " DAY)");

		return (int)$this->db->countAffected();
	}
}
