<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Theme;

class NkElectronics extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/novakur/theme/nk_electronics';
    private string $setting_code = 'theme_nk_electronics';
    private string $event_code = 'nk_electronics';

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);
        $json = [];

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $post['theme_nk_electronics_status'] = (int)($post['theme_nk_electronics_status'] ?? 0);
        $post['theme_nk_electronics_primary_color'] = trim((string)($post['theme_nk_electronics_primary_color'] ?? ''));
        $post['theme_nk_electronics_bg_mode'] = in_array(($post['theme_nk_electronics_bg_mode'] ?? 'dark'), ['dark', 'light'], true) ? $post['theme_nk_electronics_bg_mode'] : 'dark';
        $post['theme_nk_electronics_show_spec_table'] = (int)!empty($post['theme_nk_electronics_show_spec_table']);
        $post['theme_nk_electronics_comparison_enabled'] = (int)!empty($post['theme_nk_electronics_comparison_enabled']);

        if (!$this->isValidHexColor($post['theme_nk_electronics_primary_color'])) {
            $json['error']['theme_nk_electronics_primary_color'] = $this->language->get('error_color');
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->setting_code, $post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code' => $this->event_code,
            'description' => 'NovaKur Electronics theme hook',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/novakur/event/nk_electronics.view',
            'status' => 1,
            'sort_order' => -1
        ]);

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->event_code);

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->setting_code);
    }

    private function buildFormData(): array {
        $this->load->model('setting/setting');

        $settings = $this->model_setting_setting->getSetting($this->setting_code);
        $data = [];

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'entry_status',
            'entry_primary_color',
            'entry_bg_mode',
            'entry_show_spec_table',
            'entry_comparison_enabled',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $defaults = [
            'theme_nk_electronics_status' => '1',
            'theme_nk_electronics_primary_color' => '#0ea5e9',
            'theme_nk_electronics_bg_mode' => 'dark',
            'theme_nk_electronics_show_spec_table' => '1',
            'theme_nk_electronics_comparison_enabled' => '1'
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
            ]
        ];

        $data['save'] = $this->url->link($this->route . '|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }

    private function isValidHexColor(string $color): bool {
        return (bool)preg_match('/^#(?:[0-9a-fA-F]{3}){1,2}$/', trim($color));
    }
}
