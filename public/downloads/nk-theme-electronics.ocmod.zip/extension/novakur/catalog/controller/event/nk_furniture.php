<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkFurniture extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isFurnitureThemeActive()) {
            return;
        }

        if ($route === 'common/header') {
            $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-furniture.css';
            $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
            $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_furniture_primary_color') ?: '#c2714f';
            $data['novakur_secondary_color'] = '#8b7355';
            $data['novakur_container_width'] = 1200;
            $data['novakur_base_font'] = 'DM Sans';
            $data['novakur_heading_font'] = 'DM Serif Display';
            $route = 'extension/novakur/common/header_furniture';
        }

        if ($route === 'common/footer') {
            $route = 'extension/novakur/common/footer_furniture';
        }

        if ($route === 'product/category') {
            $furniture_template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_furniture.twig';

            if (is_file($furniture_template)) {
                $route = 'extension/novakur/product/category_furniture';
            }
        }

        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/product_furniture';
            }
        }
    }

    public function viewAfter(string &$route, array &$data, string &$output): void {
        if (!$this->isFurnitureThemeActive() || $route !== 'common/header' || !$output) {
            return;
        }

        $css = '<link rel="preconnect" href="https://fonts.googleapis.com">'
             . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
             . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap">'
             . '<link rel="stylesheet" href="' . rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-furniture.css">';
        $output = str_replace('</head>', $css . '</head>', $output);
    }

    private function isFurnitureThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');

        return in_array($current_theme, ['nk_furniture', 'novakur_furniture'], true) && (bool)$this->config->get('theme_nk_furniture_status');
    }
}
