<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkGrocery extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isGroceryThemeActive()) {
            return;
        }

        if ($route === 'common/header') {
            $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-grocery.css';
            $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
            $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_grocery_primary_color') ?: '#16a34a';
            $data['novakur_secondary_color'] = '#4ade80';
            $data['novakur_container_width'] = 1400;
            $data['novakur_base_font'] = 'system-ui';
            $data['novakur_heading_font'] = 'system-ui';
            $data['nk_grocery_default_view'] = (string)$this->config->get('theme_nk_grocery_default_view') ?: 'grid';
            $route = 'extension/novakur/common/header_grocery';
        }

        if ($route === 'common/footer') {
            $route = 'extension/novakur/common/footer_grocery';
        }

        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_grocery.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/common/home_grocery';
            }
        }

        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_grocery.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/category_grocery';
            }
        }
    }

    public function viewAfter(string &$route, array &$data, string &$output): void {
        if (!$this->isGroceryThemeActive() || $route !== 'common/header' || !$output) {
            return;
        }

        $css = '<link rel="stylesheet" href="' . rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-grocery.css">';
        $output = str_replace('</head>', $css . '</head>', $output);
    }

    private function isGroceryThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');

        return in_array($current_theme, ['nk_grocery', 'novakur_grocery'], true) && (bool)$this->config->get('theme_nk_grocery_status');
    }
}
