<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Payment;

class Iyzico extends \Opencart\System\Engine\Controller {

    /** Render the payment widget inside the checkout page */
    public function index(): string {
        $this->load->language('extension/novakur/payment/iyzico');

        $order_info = $this->getOrderInfo();
        if (!$order_info) {
            return '';
        }

        $form = $this->initCheckoutForm($order_info);

        $data['checkout_form_content'] = $form['checkoutFormContent'] ?? '';
        $data['error']                 = $form['errorMessage'] ?? '';
        $data['language']              = $this->config->get('config_language');

        return $this->load->view('extension/novakur/payment/iyzico', $data);
    }

    /** iyzico POSTs back here after payment */
    public function callback(): void {
        $token = $this->request->post['token'] ?? '';

        if (!$token) {
            $this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true));
            return;
        }

        $result = $this->retrieveCheckoutForm($token);
        $status = $result['paymentStatus'] ?? '';

        $this->load->model('checkout/order');

        if ($status === 'SUCCESS') {
            $success_status = (int)($this->config->get('payment_iyzico_order_status_id') ?: 2);
            $this->model_checkout_order->addHistory(
                $this->session->data['order_id'],
                $success_status,
                'iyzico Ödeme Onaylandı. Payment ID: ' . ($result['paymentId'] ?? '-'),
                true
            );
            $this->session->data['iyzico_payment_id'] = $result['paymentId'] ?? '';
            $this->response->redirect($this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true));
        } else {
            $error_msg = $result['errorMessage'] ?? 'Ödeme başarısız.';
            $this->model_checkout_order->addHistory(
                $this->session->data['order_id'],
                7, // Declined
                'iyzico Ödeme Başarısız: ' . $error_msg,
                false
            );
            $this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true) . '&error=' . urlencode($error_msg));
        }
    }

    // ─── iyzico API ───────────────────────────────────────────────────────────

    private function getOrderInfo(): ?array {
        if (empty($this->session->data['order_id'])) {
            return null;
        }
        $this->load->model('checkout/order');
        return $this->model_checkout_order->getOrder($this->session->data['order_id']) ?: null;
    }

    private function initCheckoutForm(array $order): array {
        $api_key    = $this->config->get('payment_iyzico_api_key') ?: '';
        $secret_key = $this->config->get('payment_iyzico_secret_key') ?: '';
        $sandbox    = (bool)$this->config->get('payment_iyzico_sandbox');
        $base_url   = $sandbox
            ? 'https://sandbox-api.iyzipay.com'
            : 'https://api.iyzipay.com';

        $callback_url = $this->url->link(
            'extension/novakur/payment/iyzico.callback',
            'language=' . $this->config->get('config_language'),
            true
        );

        $price      = number_format((float)$order['total'], 2, '.', '');
        $order_id   = $order['order_id'];
        $currency   = strtoupper($order['currency_code']);
        $ip         = $order['ip'] ?: ($this->request->server['REMOTE_ADDR'] ?? '127.0.0.1');

        // Build basket items from order products
        $this->load->model('checkout/order');
        $products   = $this->model_checkout_order->getProducts($order_id);
        $basket     = [];
        foreach ($products as $p) {
            $basket[] = [
                'id'         => (string)$p['product_id'],
                'name'       => mb_substr($p['name'], 0, 120),
                'category1'  => 'Giyim',
                'itemType'   => 'PHYSICAL',
                'price'      => number_format((float)$p['total'], 2, '.', ''),
            ];
        }
        if (empty($basket)) {
            $basket[] = [
                'id'        => 'ORDER-' . $order_id,
                'name'      => 'Sipariş #' . $order_id,
                'category1' => 'Genel',
                'itemType'  => 'PHYSICAL',
                'price'     => $price,
            ];
        }

        $body = json_encode([
            'locale'               => 'tr',
            'conversationId'       => (string)$order_id,
            'price'                => $price,
            'paidPrice'            => $price,
            'currency'             => $currency ?: 'TRY',
            'basketId'             => 'CART-' . $order_id,
            'paymentGroup'         => 'PRODUCT',
            'callbackUrl'          => $callback_url,
            'enabledInstallments'  => [1, 2, 3, 6, 9, 12],
            'buyer'                => [
                'id'                  => 'C-' . ($order['customer_id'] ?: $order_id),
                'name'                => $order['firstname'] ?: 'Misafir',
                'surname'             => $order['lastname'] ?: 'Müşteri',
                'gsmNumber'           => $order['telephone'] ?: '+905000000000',
                'email'               => $order['email'] ?: 'musteri@example.com',
                'identityNumber'      => '11111111111',
                'registrationAddress' => trim(($order['payment_address_1'] ?? '') . ' ' . ($order['payment_address_2'] ?? '')) ?: 'Adres Belirtilmedi',
                'ip'                  => $ip,
                'city'                => $order['payment_city'] ?: 'İstanbul',
                'country'             => $order['payment_country'] ?: 'Turkey',
                'zipCode'             => $order['payment_postcode'] ?: '34000',
            ],
            'shippingAddress'      => [
                'contactName' => trim($order['shipping_firstname'] . ' ' . $order['shipping_lastname']) ?: 'Alıcı',
                'city'        => $order['shipping_city'] ?: 'İstanbul',
                'country'     => $order['shipping_country'] ?: 'Turkey',
                'address'     => trim(($order['shipping_address_1'] ?? '') . ' ' . ($order['shipping_address_2'] ?? '')) ?: 'Adres Belirtilmedi',
                'zipCode'     => $order['shipping_postcode'] ?: '34000',
            ],
            'billingAddress'       => [
                'contactName' => trim($order['payment_firstname'] . ' ' . $order['payment_lastname']) ?: 'Alıcı',
                'city'        => $order['payment_city'] ?: 'İstanbul',
                'country'     => $order['payment_country'] ?: 'Turkey',
                'address'     => trim(($order['payment_address_1'] ?? '') . ' ' . ($order['payment_address_2'] ?? '')) ?: 'Adres Belirtilmedi',
                'zipCode'     => $order['payment_postcode'] ?: '34000',
            ],
            'basketItems'          => $basket,
        ], JSON_UNESCAPED_UNICODE);

        return $this->iyzicoRequest($base_url . '/payment/iyzipos/checkoutform/initialize/auth/ecom', $api_key, $secret_key, $body);
    }

    private function retrieveCheckoutForm(string $token): array {
        $api_key    = $this->config->get('payment_iyzico_api_key') ?: '';
        $secret_key = $this->config->get('payment_iyzico_secret_key') ?: '';
        $sandbox    = (bool)$this->config->get('payment_iyzico_sandbox');
        $base_url   = $sandbox
            ? 'https://sandbox-api.iyzipay.com'
            : 'https://api.iyzipay.com';

        $body = json_encode(['locale' => 'tr', 'conversationId' => (string)($this->session->data['order_id'] ?? ''), 'token' => $token]);

        return $this->iyzicoRequest($base_url . '/payment/iyzipos/checkoutform/auth/ecom/detail', $api_key, $secret_key, $body);
    }

    private function iyzicoRequest(string $url, string $api_key, string $secret_key, string $body): array {
        $random_key = uniqid('', true);
        $timestamp  = time();
        $hash_str   = $api_key . $random_key . $secret_key . $timestamp . $body;
        $signature  = hash('sha256', $hash_str);
        $auth_str   = base64_encode($api_key . ':' . $random_key . ':' . $signature . ':' . $timestamp);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json; charset=utf-8',
                'Accept: application/json',
                'x-iyzi-rnd: ' . $random_key,
                'x-iyzi-client-version: iyzico-php-client-1.0.0',
                'Authorization: IYZWSv2 authorizationString=' . $auth_str,
            ],
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return $response ? (json_decode($response, true) ?? []) : ['errorMessage' => 'API bağlantı hatası'];
    }
}
