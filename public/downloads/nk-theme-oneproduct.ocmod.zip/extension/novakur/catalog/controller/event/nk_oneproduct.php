<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkOneproduct extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isOneproductThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_oneproduct.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-oneproduct.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_oneproduct_primary_color') ?: '#16a34a';
                $data['novakur_secondary_color'] = '#101828';
                $data['novakur_container_width'] = 1160;
                $data['novakur_base_font']       = 'Inter';
                $data['novakur_heading_font']    = 'Poppins';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_oneproduct';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/footer_oneproduct';
            }
        }

        // ---- Homepage: long-form landing page for the flagship product ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_oneproduct';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            // Flagship hero product: newest product in the catalog
            $hero_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 1,
            ]);
            $hero_built = $this->buildProductArray($hero_raw, 720, 720, $currency);

            if ($hero_built) {
                $hero = $hero_built[0];
                $hero_id = (int)($hero_raw[0]['product_id'] ?? 0);

                $info = $this->model_catalog_product->getProduct($hero_id);
                if ($info) {
                    $hero['description'] = trim(strip_tags(html_entity_decode($info['description'] ?? '', ENT_QUOTES, 'UTF-8')));
                    $hero['model']       = $info['model'] ?? '';
                    $hero['quantity']    = (int)($info['quantity'] ?? 0);
                    $hero['minimum']     = (int)($info['minimum'] ?? 1) ?: 1;
                }

                $hero['images'] = [];
                $images_raw = $this->model_catalog_product->getImages($hero_id);
                foreach (array_slice($images_raw, 0, 4) as $img) {
                    if (!empty($img['image'])) {
                        $hero['images'][] = $this->model_tool_image->resize($img['image'], 720, 720);
                    }
                }

                $data['hero_product'] = $hero;
            }

            // Small cross-sell row (skips the hero product)
            $hero_id = isset($hero_id) ? $hero_id : 0;
            $latest_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 5,
            ]);
            $latest_raw = array_filter($latest_raw, function ($p) use ($hero_id) {
                return (int)($p['product_id'] ?? 0) !== $hero_id;
            });
            $latest_raw = array_slice(array_values($latest_raw), 0, 4);
            $data['latest'] = $this->buildProductArray($latest_raw, $img_w, $img_h, $currency);

            $data['show_social_proof'] = (bool)$this->config->get('theme_nk_oneproduct_show_social_proof');
            $data['show_faq']          = (bool)$this->config->get('theme_nk_oneproduct_show_faq');
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_oneproduct';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_oneproduct';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_oneproduct.twig';
            if (is_file($template)) {
                $data['nk_show_sticky_atc'] = (bool)$this->config->get('theme_nk_oneproduct_show_sticky_atc');
                $route = 'extension/novakur/product/product_oneproduct';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_oneproduct';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_oneproduct';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_oneproduct';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_oneproduct';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_oneproduct';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_oneproduct';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_oneproduct';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_oneproduct';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_oneproduct.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_oneproduct';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isOneproductThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_oneproduct', 'novakur_oneproduct'], true)
            && (bool)$this->config->get('theme_nk_oneproduct_status');
    }
}
