<?php
$_['heading_title'] = 'NovaKur One-Product Landing Theme';
$_['text_edit'] = 'One-product landing theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'One-product landing theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_social_proof'] = 'Show Social Proof Grid';
$_['entry_show_faq'] = 'Show FAQ Accordion';
$_['entry_show_sticky_atc'] = 'Show Sticky Add-to-Cart Bar';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
