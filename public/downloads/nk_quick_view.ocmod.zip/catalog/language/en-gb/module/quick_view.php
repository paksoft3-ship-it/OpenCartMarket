<?php
$_['text_quick_view'] = 'Quick View';
$_['text_close'] = 'Close';
$_['text_add_cart'] = 'Add to Cart';
$_['text_options'] = 'Choose Options';
$_['text_details'] = 'View Full Details';
$_['text_loading'] = 'Loading...';
$_['text_error'] = 'This product is no longer available.';
