(function () {
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function init() {
    var modal = document.getElementById('nk-qv-modal');
    if (!modal) return;

    var text = {
      quickView: modal.getAttribute('data-text-quick-view') || 'Quick View',
      addCart: modal.getAttribute('data-text-add-cart') || 'Add to Cart',
      options: modal.getAttribute('data-text-options') || 'Choose Options',
      details: modal.getAttribute('data-text-details') || 'View Full Details',
      loading: modal.getAttribute('data-text-loading') || 'Loading...',
      error: modal.getAttribute('data-text-error') || 'This product is no longer available.'
    };

    var productUrl = modal.getAttribute('data-product-url') || '';
    var cartAddUrl = modal.getAttribute('data-cart-add-url') || '';
    var cartInfoUrl = modal.getAttribute('data-cart-info-url') || '';
    var showReviews = modal.getAttribute('data-show-reviews') === '1';

    var content = modal.querySelector('.nk-qv__content');
    var lastFocus = null;

    function alertMessage(message, type) {
      var box = document.getElementById('alert');
      if (!box) return;

      var el = document.createElement('div');
      el.className = 'alert alert-' + (type || 'success') + ' alert-dismissible';
      el.textContent = message;

      var close = document.createElement('button');
      close.type = 'button';
      close.className = 'btn-close';
      close.setAttribute('data-bs-dismiss', 'alert');
      el.appendChild(close);

      box.prepend(el);
    }

    function refreshCart() {
      if (!cartInfoUrl) return;

      var target = document.getElementById('cart');
      if (!target) return;

      fetch(cartInfoUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function (r) { return r.text(); })
        .then(function (html) { target.innerHTML = html; })
        .catch(function () { /* the header cart just stays stale */ });
    }

    function openModal() {
      lastFocus = document.activeElement;
      modal.setAttribute('aria-hidden', 'false');
      modal.classList.add('is-open');

      var closeBtn = modal.querySelector('.nk-qv__close');
      if (closeBtn) closeBtn.focus();
    }

    function closeModal() {
      if (!modal.classList.contains('is-open')) return;

      modal.setAttribute('aria-hidden', 'true');
      modal.classList.remove('is-open');

      if (lastFocus && typeof lastFocus.focus === 'function') {
        lastFocus.focus();
      }

      lastFocus = null;
    }

    function ratingHtml(rating) {
      var html = '<div class="nk-qv__rating" aria-label="' + escapeHtml(rating) + '/5">';

      for (var i = 1; i <= 5; i++) {
        html += '<span class="nk-qv__star' + (i <= rating ? ' is-on' : '') + '">★</span>';
      }

      return html + '</div>';
    }

    function render(data) {
      if (!content) return;

      if (!data || data.error || !data.product_id) {
        content.innerHTML = '<p class="nk-qv__error">' + escapeHtml((data && data.error) || text.error) + '</p>';
        return;
      }

      var images = Array.isArray(data.images) ? data.images : [];
      var imageHtml = '';

      if (images.length) {
        imageHtml = '<img src="' + escapeHtml(images[0].popup) + '" alt="' + escapeHtml(data.name) + '" class="nk-qv__main-image">';

        if (images.length > 1) {
          imageHtml += '<div class="nk-qv__thumbs">';

          images.forEach(function (image, index) {
            imageHtml += '<button type="button" class="nk-qv__thumb' + (index === 0 ? ' is-active' : '') +
              '" data-qv-popup="' + escapeHtml(image.popup) + '"><img src="' + escapeHtml(image.thumb) +
              '" alt="" loading="lazy"></button>';
          });

          imageHtml += '</div>';
        }
      }

      var price = '';

      if (data.special) {
        price = '<strong>' + escapeHtml(data.special) + '</strong> <del>' + escapeHtml(data.price) + '</del>';
      } else if (data.price) {
        price = '<strong>' + escapeHtml(data.price) + '</strong>';
      }

      // Products with required options cannot be added blind - send the shopper
      // to the full product page instead of firing a request that will fail.
      var primary = data.has_options
        ? '<a class="btn btn-primary" href="' + escapeHtml(data.href) + '">' + escapeHtml(text.options) + '</a>'
        : '<button type="button" class="btn btn-primary" data-add-cart="' + escapeHtml(data.product_id) +
          '" data-quantity="' + escapeHtml(data.minimum || 1) + '">' + escapeHtml(text.addCart) + '</button>';

      content.innerHTML =
        '<div class="nk-qv__grid">' +
          '<div class="nk-qv__left">' + imageHtml + '</div>' +
          '<div class="nk-qv__right">' +
            '<h3>' + escapeHtml(data.name) + '</h3>' +
            (showReviews && data.rating ? ratingHtml(data.rating) : '') +
            (price ? '<div class="nk-qv__price">' + price + '</div>' : '') +
            '<p>' + escapeHtml(data.description) + '</p>' +
            '<div class="nk-qv__actions">' +
              primary +
              '<a class="btn btn-outline-primary" href="' + escapeHtml(data.href) + '">' + escapeHtml(text.details) + '</a>' +
            '</div>' +
          '</div>' +
        '</div>';
    }

    function addTriggers() {
      // OpenCart 4's default theme renders product cards as .product-thumb with
      // the id in a hidden input; themes that expose data-product-id also work.
      document.querySelectorAll('.product-thumb, [data-product-id]').forEach(function (card) {
        if (card.querySelector('.nk-qv-trigger')) return;

        var id = card.getAttribute('data-product-id');

        if (!id) {
          var input = card.querySelector('input[name="product_id"]');
          id = input ? input.value : '';
        }

        if (!id) return;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'nk-qv-trigger';
        btn.setAttribute('data-nk-qv-id', id);
        btn.textContent = text.quickView;

        (card.querySelector('.image') || card).appendChild(btn);
      });
    }

    document.addEventListener('click', function (e) {
      // e.target can be a non-Element (SVG use, text node in old engines).
      if (!e.target || typeof e.target.closest !== 'function') return;

      var trigger = e.target.closest('.nk-qv-trigger');

      if (trigger) {
        e.preventDefault();

        var productId = trigger.getAttribute('data-nk-qv-id');
        if (!productId || !productUrl) return;

        if (content) content.innerHTML = '<p class="nk-qv__loading">' + escapeHtml(text.loading) + '</p>';
        openModal();

        fetch(productUrl + '&product_id=' + encodeURIComponent(productId), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
          .then(function (r) { return r.json(); })
          .then(render)
          .catch(function () { render(null); });

        return;
      }

      if (e.target.closest('[data-close="1"]')) {
        closeModal();
        return;
      }

      var thumb = e.target.closest('[data-qv-popup]');

      if (thumb) {
        var main = modal.querySelector('.nk-qv__main-image');
        if (main) main.src = thumb.getAttribute('data-qv-popup');

        modal.querySelectorAll('.nk-qv__thumb').forEach(function (el) { el.classList.remove('is-active'); });
        thumb.classList.add('is-active');

        return;
      }

      var addCart = e.target.closest('[data-add-cart]');

      if (addCart && cartAddUrl) {
        addCart.disabled = true;

        var body = 'product_id=' + encodeURIComponent(addCart.getAttribute('data-add-cart')) +
          '&quantity=' + encodeURIComponent(addCart.getAttribute('data-quantity') || 1);

        fetch(cartAddUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: body
        })
          .then(function (r) { return r.json(); })
          .then(function (json) {
            if (json && json.success) {
              alertMessage(json.success, 'success');
              refreshCart();
              closeModal();
              return;
            }

            if (json && typeof json.error === 'string') {
              alertMessage(json.error, 'danger');
              return;
            }

            if (json && json.error) {
              Object.keys(json.error).forEach(function (key) {
                alertMessage(json.error[key], 'danger');
              });
            }
          })
          .catch(function () { alertMessage(text.error, 'danger'); })
          .then(function () { addCart.disabled = false; });
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeModal();
    });

    addTriggers();

    // Themes and modules that swap the product grid in via AJAX get triggers too.
    if (window.MutationObserver) {
      var pending = null;

      new MutationObserver(function () {
        if (pending) return;

        pending = window.setTimeout(function () {
          pending = null;
          addTriggers();
        }, 150);
      }).observe(document.body, { childList: true, subtree: true });
    }
  }

  // The bundle is queued in <head>, so the modal does not exist yet on first run.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
