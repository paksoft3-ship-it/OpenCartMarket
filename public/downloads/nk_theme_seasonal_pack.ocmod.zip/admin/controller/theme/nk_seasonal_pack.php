<?php
namespace Opencart\Admin\Controller\Extension\NkThemeSeasonalPack\Theme;

class NkSeasonalPack extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_theme_seasonal_pack/theme/nk_seasonal_pack';
    private string $setting_code = 'theme_nk_seasonal_pack';
    private string $event_code = 'nk_seasonal_pack';

    private array $seasons = ['auto', 'none', 'winter', 'ramadan', 'spring', 'summer', 'black_friday', 'new_year'];

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);
        $json = [];

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $post['theme_nk_seasonal_pack_status'] = (int)($post['theme_nk_seasonal_pack_status'] ?? 0);
        $post['theme_nk_seasonal_pack_active_season'] = trim((string)($post['theme_nk_seasonal_pack_active_season'] ?? 'auto'));
        $post['theme_nk_seasonal_pack_show_hero_banner'] = (int)!empty($post['theme_nk_seasonal_pack_show_hero_banner']);
        $post['theme_nk_seasonal_pack_show_promo_strip'] = (int)!empty($post['theme_nk_seasonal_pack_show_promo_strip']);
        $post['theme_nk_seasonal_pack_show_countdown'] = (int)!empty($post['theme_nk_seasonal_pack_show_countdown']);
        $post['theme_nk_seasonal_pack_countdown_date'] = trim((string)($post['theme_nk_seasonal_pack_countdown_date'] ?? ''));

        if (!in_array($post['theme_nk_seasonal_pack_active_season'], $this->seasons, true)) {
            $json['error']['theme_nk_seasonal_pack_active_season'] = $this->language->get('error_season');
        }

        if (!$this->isValidCountdownDate($post['theme_nk_seasonal_pack_countdown_date'])) {
            $json['error']['theme_nk_seasonal_pack_countdown_date'] = $this->language->get('error_countdown_date');
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->setting_code, $post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code' => $this->event_code,
            'description' => 'NovaKur Seasonal Homepage Section Pack hook',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/nk_theme_seasonal_pack/event/nk_seasonal_pack.view',
            'status' => 1,
            'sort_order' => 2
        ]);

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->event_code);

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->setting_code);
    }

    private function buildFormData(): array {
        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->setting_code);
        $data = [];

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'text_season_auto',
            'text_season_none',
            'text_season_winter',
            'text_season_ramadan',
            'text_season_spring',
            'text_season_summer',
            'text_season_black_friday',
            'text_season_new_year',
            'entry_status',
            'entry_active_season',
            'entry_show_hero_banner',
            'entry_show_promo_strip',
            'entry_show_countdown',
            'entry_countdown_date',
            'help_active_season',
            'help_countdown_date',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $defaults = [
            'theme_nk_seasonal_pack_status' => '1',
            'theme_nk_seasonal_pack_active_season' => 'auto',
            'theme_nk_seasonal_pack_show_hero_banner' => '1',
            'theme_nk_seasonal_pack_show_promo_strip' => '1',
            'theme_nk_seasonal_pack_show_countdown' => '1',
            'theme_nk_seasonal_pack_countdown_date' => ''
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['seasons'] = $this->seasons;

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
            ]
        ];

        $data['save'] = $this->url->link($this->route . '|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }

    private function isValidCountdownDate(string $date): bool {
        if ($date === '') {
            return true;
        }

        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m)) {
            return false;
        }

        return checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
    }
}
