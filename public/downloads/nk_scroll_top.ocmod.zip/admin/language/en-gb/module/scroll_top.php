<?php
// Heading
$_['heading_title']       = 'NovaKur Scroll To Top';

// Text
$_['text_extension']      = 'Extensions';
$_['text_success']        = 'Success: You have modified NovaKur Scroll To Top settings!';
$_['text_edit']           = 'Edit NovaKur Scroll To Top';
$_['text_enabled']        = 'Enabled';
$_['text_disabled']       = 'Disabled';
$_['text_general']        = 'General';
$_['text_appearance']     = 'Appearance';
$_['text_bottom_right']   = 'Bottom right';
$_['text_bottom_left']    = 'Bottom left';
$_['text_icon_arrow']     = 'Arrow';
$_['text_icon_chevron']   = 'Chevron';
$_['text_icon_caret']     = 'Caret (filled)';

// Entry
$_['entry_status']        = 'Status';
$_['entry_position']      = 'Position';
$_['entry_show_progress'] = 'Progress ring';
$_['entry_icon']          = 'Icon';
$_['entry_bg_color']      = 'Background colour';
$_['entry_icon_color']    = 'Icon colour';
$_['entry_size']          = 'Button size (px)';
$_['entry_show_after_px'] = 'Show after (px)';
$_['entry_offset_bottom'] = 'Bottom offset (px)';

// Help
$_['help_show_progress']  = 'Draws a circular ring around the button that fills as the page is scrolled.';
$_['help_size']           = 'Diameter of the button. Between 32 and 96.';
$_['help_show_after_px']  = 'Vertical scroll distance before the button fades in. Between 0 and 5000.';
$_['help_offset_bottom']  = 'Distance from the bottom edge of the viewport. Between 0 and 400.';

// Button
$_['button_save']         = 'Save';
$_['button_back']         = 'Back';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify this module!';
$_['error_position']      = 'Position must be bottom-right or bottom-left!';
$_['error_icon']          = 'Icon must be arrow, chevron or caret!';
$_['error_color']         = 'Colour must be a 6 digit hex value, e.g. #2563EB!';
$_['error_size']          = 'Button size must be between 32 and 96!';
$_['error_show_after_px'] = 'Show after must be between 0 and 5000!';
$_['error_offset_bottom'] = 'Bottom offset must be between 0 and 400!';
