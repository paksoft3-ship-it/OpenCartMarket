<?php
namespace Opencart\Admin\Controller\Extension\NkScrollTop\Module;

/**
 * NovaKur Scroll To Top
 *
 * Settings namespace: module_scroll_top_*
 * Route:              extension/nk_scroll_top/module/scroll_top
 * Event codes:        nk_scroll_top_assets / nk_scroll_top_render
 */
class ScrollTop extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_scroll_top/module/scroll_top';
    private string $prefix = 'module_scroll_top';

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_scroll_top_status'        => '0',
            'module_scroll_top_position'      => 'bottom-right',
            'module_scroll_top_show_progress' => '1',
            'module_scroll_top_icon'          => 'arrow',
            'module_scroll_top_bg_color'      => '#2563EB',
            'module_scroll_top_icon_color'    => '#FFFFFF',
            'module_scroll_top_size'          => '52',
            'module_scroll_top_show_after_px' => '300',
            'module_scroll_top_offset_bottom' => '24'
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_scroll_top_assets',
                'description' => 'NovaKur Scroll To Top: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_scroll_top/event/scroll_top.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_scroll_top_render',
                'description' => 'NovaKur Scroll To Top: button markup injected into the footer',
                'trigger'     => 'catalog/view/common/footer/after',
                'action'      => 'extension/nk_scroll_top/event/scroll_top.render',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    /**
     * @return array<int, string>
     */
    private function positions(): array {
        return ['bottom-right', 'bottom-left'];
    }

    /**
     * @return array<int, string>
     */
    private function icons(): array {
        return ['arrow', 'chevron', 'caret'];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_appearance',
            'text_bottom_right',
            'text_bottom_left',
            'text_icon_arrow',
            'text_icon_chevron',
            'text_icon_caret',
            'entry_status',
            'entry_position',
            'entry_show_progress',
            'entry_icon',
            'entry_bg_color',
            'entry_icon_color',
            'entry_size',
            'entry_show_after_px',
            'entry_offset_bottom',
            'help_show_progress',
            'help_size',
            'help_show_after_px',
            'help_offset_bottom',
            'button_save',
            'button_back',
            'error_permission',
            'error_position',
            'error_icon',
            'error_color',
            'error_size',
            'error_show_after_px',
            'error_offset_bottom'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['positions'] = $this->positions();
        $data['icons'] = $this->icons();

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        foreach (['status', 'show_progress'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // --- Enumerations ----------------------------------------------------
        $position = trim((string)($post[$this->prefix . '_position'] ?? 'bottom-right'));

        if (!in_array($position, $this->positions(), true)) {
            $json['error'][$this->prefix . '_position'] = $this->language->get('error_position');
        } else {
            $save[$this->prefix . '_position'] = $position;
        }

        $icon = trim((string)($post[$this->prefix . '_icon'] ?? 'arrow'));

        if (!in_array($icon, $this->icons(), true)) {
            $json['error'][$this->prefix . '_icon'] = $this->language->get('error_icon');
        } else {
            $save[$this->prefix . '_icon'] = $icon;
        }

        // --- Colours ---------------------------------------------------------
        foreach (['bg_color', 'icon_color'] as $key) {
            $color = strtoupper(trim((string)($post[$this->prefix . '_' . $key] ?? '')));

            if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_color');
            } else {
                $save[$this->prefix . '_' . $key] = $color;
            }
        }

        // --- Numeric ranges --------------------------------------------------
        foreach (['size' => [32, 96], 'show_after_px' => [0, 5000], 'offset_bottom' => [0, 400]] as $key => $range) {
            $value = trim((string)($post[$this->prefix . '_' . $key] ?? ''));

            if (!$this->inRange($value, $range[0], $range[1])) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_' . $key);
            } else {
                $save[$this->prefix . '_' . $key] = (string)(int)$value;
            }
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    private function inRange(string $value, int $min, int $max): bool {
        if (!preg_match('/^\d{1,5}$/', $value)) {
            return false;
        }

        $number = (int)$value;

        return $number >= $min && $number <= $max;
    }
}
