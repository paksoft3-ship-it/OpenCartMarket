<?php
// Text
$_['text_scroll_top'] = 'Back to top';
