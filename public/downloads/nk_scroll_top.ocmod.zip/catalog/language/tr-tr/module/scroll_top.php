<?php
// Text
$_['text_scroll_top'] = 'Yukarı çık';
