(function () {
  function init() {
    var btn = document.getElementById('nk-scroll-top');
    if (!btn) return;

    var progress = document.getElementById('nk-scroll-progress');
    var showAfter = parseInt(btn.getAttribute('data-nk-show-after'), 10);
    var showProgress = btn.getAttribute('data-nk-progress') === '1';

    if (isNaN(showAfter) || showAfter < 0) showAfter = 300;

    // The ring is drawn with r=15.9 in a 36x36 viewBox, so its circumference is
    // 2*PI*15.9 = 99.9 -- close enough to 100 for stroke-dasharray: 100.
    var CIRCUMFERENCE = 100;
    var ticking = false;

    function update() {
      ticking = false;

      var y = window.scrollY || window.pageYOffset || 0;

      if (y > showAfter) {
        btn.classList.add('is-visible');
      } else {
        btn.classList.remove('is-visible');
      }

      if (progress && showProgress) {
        var h = document.documentElement.scrollHeight - window.innerHeight;
        var percent = h > 0 ? Math.min(100, Math.max(0, (y / h) * 100)) : 0;

        progress.style.strokeDashoffset = String(CIRCUMFERENCE - percent);
      }
    }

    function onScroll() {
      if (ticking) return;

      ticking = true;
      window.requestAnimationFrame(update);
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });

    btn.addEventListener('click', function () {
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
    });

    update();
  }

  // The button is injected into the footer, so by the time this script runs from
  // <head> the element does not exist yet.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
