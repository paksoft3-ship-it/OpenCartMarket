<?php
$_['heading_title'] = 'NovaKur Auto Parts Theme';
$_['text_edit'] = 'Auto parts theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Auto Parts theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_vehicle_finder'] = 'Show Vehicle Finder';
$_['entry_show_fitment'] = 'Show Fitment Table';
$_['entry_show_sku_on_cards'] = 'Show SKU on Product Cards';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
