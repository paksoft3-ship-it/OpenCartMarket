<?php
$_['heading_title'] = 'NovaKur B2B Wholesale Theme';
$_['text_edit'] = 'Wholesale theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'B2B theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_bulk_table'] = 'Show Bulk Order Table';
$_['entry_show_tier_pricing'] = 'Show Tier Pricing Table';
$_['entry_show_quote_panel'] = 'Show Quote Request Panel';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
