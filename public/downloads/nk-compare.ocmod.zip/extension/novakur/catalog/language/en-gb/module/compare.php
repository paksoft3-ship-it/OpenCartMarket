<?php
// Heading
$_['heading_title']      = 'Product Comparison';

// Text
$_['text_home']          = 'Home';
$_['text_empty']         = 'You have not chosen any products to compare.';
$_['text_selected']      = 'Selected for comparison';
$_['text_slots']         = '%d of %d';
$_['text_success']       = 'Added to the comparison.';
$_['text_remove']        = 'Removed from the comparison.';
$_['text_feature']       = 'Feature';
$_['text_price']         = 'Price';
$_['text_model']         = 'Model';
$_['text_manufacturer']  = 'Brand';
$_['text_stock']         = 'Availability';
$_['text_rating_label']  = 'Rating';
$_['text_rating']        = '%d / 5';
$_['text_in_stock']      = 'In Stock';
$_['text_out_of_stock']  = 'Out Of Stock';

// Button
$_['button_compare']     = 'Compare this product';
$_['button_view']        = 'Compare';
$_['button_clear']       = 'Clear all';
$_['button_remove']      = 'Remove';
$_['button_continue']    = 'Continue shopping';

// Error
$_['error_product']      = 'Warning: That product could not be added to the comparison!';
