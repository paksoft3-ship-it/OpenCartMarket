(function () {
  var key = 'nk_compare_products';
  var config = window.nk_compare || {};

  function url(name, fallback) {
    return config[name] || fallback;
  }

  function limit() {
    return Math.max(2, Math.min(4, parseInt(config.limit, 10) || 4));
  }

  function getList() {
    try {
      var list = JSON.parse(localStorage.getItem(key) || '[]');

      return Array.isArray(list) ? list.map(Number).filter(function (id) { return id > 0; }) : [];
    } catch (e) {
      return [];
    }
  }

  function setList(list) {
    try {
      localStorage.setItem(key, JSON.stringify(list.slice(0, limit())));
    } catch (e) {
      /* private mode - the session copy is still authoritative */
    }
  }

  function post(target, body) {
    return fetch(target, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: body
    }).then(function (r) { return r.json(); });
  }

  // Replace the floating bar with whatever the server says the list is now.
  function apply(json) {
    if (!json || json.error) return;

    if (json.items) setList(json.items);

    var bar = document.getElementById('nk-compare-bar');

    if (bar && json.html) bar.outerHTML = json.html;
  }

  document.addEventListener('click', function (e) {
    var add = e.target.closest('[data-compare-add]');

    if (add) {
      e.preventDefault();
      e.stopPropagation();

      var id = Number(add.getAttribute('data-compare-add'));
      if (!id) return;

      post(url('add', 'index.php?route=extension/novakur/module/compare.add'), 'product_id=' + encodeURIComponent(id)).then(apply);

      return;
    }

    var remove = e.target.closest('[data-compare-remove]');

    if (remove) {
      e.preventDefault();

      var rid = Number(remove.getAttribute('data-compare-remove'));

      post(url('remove', 'index.php?route=extension/novakur/module/compare.remove'), 'product_id=' + encodeURIComponent(rid)).then(function (json) {
        apply(json);

        // The comparison page itself has to be redrawn - a column just disappeared.
        if (document.getElementById('product-compare')) window.location.reload();
      });

      return;
    }

    if (e.target.closest('[data-compare-clear]')) {
      e.preventDefault();

      post(url('clear', 'index.php?route=extension/novakur/module/compare.clear'), '').then(function (json) {
        apply(json);

        if (document.getElementById('product-compare')) window.location.reload();
      });
    }
  });

  // The session expires long before localStorage does: hand the saved list back to
  // the server when it has clearly forgotten it.
  function restore() {
    var bar = document.getElementById('nk-compare-bar');
    if (!bar) return;

    var saved = getList();
    if (!saved.length) return;

    if (bar.querySelector('[data-compare-remove]')) return;

    var body = saved.slice(0, limit()).map(function (id) {
      return 'product_id[]=' + encodeURIComponent(id);
    }).join('&');

    post(url('sync', 'index.php?route=extension/novakur/module/compare.sync'), body).then(apply);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', restore);
  } else {
    restore();
  }
})();
