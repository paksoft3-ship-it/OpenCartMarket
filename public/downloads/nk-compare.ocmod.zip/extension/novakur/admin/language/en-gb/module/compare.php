<?php
// Heading
$_['heading_title']          = 'NovaKur Compare Products';

// Text
$_['text_extension']         = 'Extensions';
$_['text_success']           = 'Success: You have modified NovaKur Compare Products settings!';
$_['text_edit']              = 'Edit NovaKur Compare Products';
$_['text_enabled']           = 'Enabled';
$_['text_disabled']          = 'Disabled';
$_['text_yes']               = 'Yes';
$_['text_no']                = 'No';

// Entry
$_['entry_status']           = 'Status';
$_['entry_limit']            = 'Products to compare';
$_['entry_highlight']        = 'Highlight differing rows';
$_['entry_diff_only']        = 'Show differences only';
$_['entry_show_attributes']  = 'Include product attributes';

// Help
$_['help_limit']             = 'How many products a shopper may line up side by side (2-4).';
$_['help_highlight']         = 'Tint the rows where the selected products do not agree.';
$_['help_diff_only']         = 'Hide every row where all selected products share the same value.';
$_['help_show_attributes']   = 'Append the product attribute groups underneath price, model, brand, stock and rating.';

// Button
$_['button_save']            = 'Save';
$_['button_back']            = 'Back';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify this module!';
$_['error_limit']            = 'Choose between 2 and 4 products!';
