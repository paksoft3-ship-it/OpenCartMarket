<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkFashion extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isFashionThemeActive()) {
            return;
        }

        $demo_mode = (bool)$this->config->get('theme_nk_fashion_demo_mode');

        if ($route === 'common/header') {
            // Override English page titles with Turkish.
            // $data['title'] is already set by the header controller before this event fires,
            // so we must override $data['title'] directly (not just document->setTitle).
            $title_map = [
                'Account Login'    => 'Giriş Yap — NovaKur Fashion',
                'Register Account' => 'Kayıt Ol — NovaKur Fashion',
                'My Account'       => 'Hesabım — NovaKur Fashion',
                'Wish List'        => 'Favorilerim — NovaKur Fashion',
                'Order History'    => 'Siparişlerim — NovaKur Fashion',
                'Address Book'     => 'Adreslerim — NovaKur Fashion',
                'Shopping Cart'    => 'Alışveriş Sepeti — NovaKur Fashion',
                'Checkout'         => 'Ödeme — NovaKur Fashion',
                'Your order has been placed!' => 'Siparişiniz Alındı! — NovaKur Fashion',
                'Search'           => 'Koleksiyonda Ara — NovaKur Fashion',
                'Contact Us'       => 'İletişim — NovaKur Fashion',
                'Not Found'        => 'Sayfa Bulunamadı — NovaKur Fashion',
                'Your Store'       => 'NovaKur Fashion',
            ];
            $current_title = $data['title'] ?? $this->document->getTitle();
            foreach ($title_map as $en => $tr) {
                if (stripos($current_title, $en) !== false) {
                    $data['title'] = $tr;
                    $this->document->setTitle($tr);
                    break;
                }
            }

            $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-fashion.css';

            // Clean URLs for header actions
            $data['nk_search_url']  = $this->url->link('product/search');
            $data['nk_cart_url']    = $this->url->link('checkout/cart');
            $data['cart_quantity']  = $this->cart->countProducts();

            // Populate cart products for the mini cart drawer
            $data['products'] = [];
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            
            foreach ($this->cart->getProducts() as $product) {
                if ($product['image']) {
                    $image = $this->model_tool_image->resize(html_entity_decode($product['image'], ENT_QUOTES, 'UTF-8'), 100, 100);
                } else {
                    $image = $this->model_tool_image->resize('placeholder.png', 100, 100);
                }

                $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));
                
                $data['products'][] = [
                    'cart_id'   => $product['cart_id'],
                    'thumb'     => $image,
                    'name'      => $product['name'],
                    'quantity'  => $product['quantity'],
                    'price'     => $this->currency->format($price, $currency),
                    'total'     => $this->currency->format($price * $product['quantity'], $currency),
                    'href'      => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                    'remove'    => $this->url->link('checkout/cart|remove', 'cart_id=' . $product['cart_id'])
                ];
            }
            
            $data['total'] = $this->currency->format($this->cart->getTotal(), $currency);

            // Build nav — labels and children fully overridden with Turkish fashion content
            $this->load->model('catalog/category');
            $top_categories = array_slice($this->model_catalog_category->getCategories(0), 0, 4);
            $fashion_nav = [
                [
                    'name'     => 'Yeni Gelenler',
                    'children' => ['Elbiseler', 'Üstler & Bluzlar', 'Pantolonlar', 'Kazaklar & Hırkalar'],
                ],
                [
                    'name'     => 'Koleksiyonlar',
                    'children' => ['Yaz Koleksiyonu', 'Kış Esansiyelleri', 'Kapsül Koleksiyon', 'Arşiv'],
                ],
                [
                    'name'     => 'İndirim',
                    'children' => ['%30\'a Kadar', '%50\'ye Kadar', 'Son Bedenler'],
                ],
                [
                    'name'     => 'Lookbook',
                    'children' => ['İlkbahar / Yaz 2026', 'Sonbahar / Kış 2025', 'Arşiv'],
                ],
            ];
            $data['nk_nav_categories'] = [];
            foreach ($top_categories as $i => $cat) {
                $fd = $fashion_nav[$i] ?? $fashion_nav[0];
                $children_raw = $this->model_catalog_category->getCategories((int)$cat['category_id']);
                $children = [];
                foreach ($fd['children'] as $j => $child_name) {
                    // Use real child href if it exists, otherwise fall back to parent category
                    $child_href = isset($children_raw[$j])
                        ? $this->url->link('product/category', 'path=' . $cat['category_id'] . '_' . $children_raw[$j]['category_id'])
                        : $this->url->link('product/category', 'path=' . $cat['category_id']);
                    $children[] = ['name' => $child_name, 'href' => $child_href];
                }
                $label = (string)$this->config->get('theme_nk_fashion_nav_label_' . ($i + 1));
                $data['nk_nav_categories'][] = [
                    'name'     => $label !== '' ? $label : $fd['name'],
                    'href'     => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'children' => $children,
                ];
            }
            $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
            $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_fashion_primary_color') ?: '#18181b';
            $data['novakur_secondary_color'] = '#a1a1aa';
            $data['novakur_container_width'] = (int)$this->config->get('theme_nk_fashion_container_width') ?: 1320;
            $data['novakur_base_font'] = 'Inter';
            $data['novakur_heading_font'] = (string)$this->config->get('theme_nk_fashion_heading_font') ?: 'Playfair Display';
            $data['nk_fashion_accent'] = (string)$this->config->get('theme_nk_fashion_accent_color') ?: '#c9a96e';
            $data['nk_fashion_show_lookbook'] = (bool)$this->config->get('theme_nk_fashion_show_lookbook');
            $data['nk_fashion_show_collection_banner'] = (bool)$this->config->get('theme_nk_fashion_show_collection_banner');
            $data['nk_fashion_card_hover_image_swap'] = (bool)$this->config->get('theme_nk_fashion_card_hover_image_swap');
            $route = 'extension/novakur/common/header_fashion';
        }

        if ($route === 'common/footer') {
            $route = 'extension/novakur/common/footer_fashion';
        }

        // Turkish page titles for all routes
        $turkish_titles = [
            'account/login'      => 'Giriş Yap — NovaKur Fashion',
            'account/register'   => 'Kayıt Ol — NovaKur Fashion',
            'account/account'    => 'Hesabım — NovaKur Fashion',
            'account/wishlist'   => 'Favorilerim — NovaKur Fashion',
            'account/order'      => 'Siparişlerim — NovaKur Fashion',
            'account/address'    => 'Adreslerim — NovaKur Fashion',
            'checkout/cart'      => 'Alışveriş Sepeti — NovaKur Fashion',
            'checkout/checkout'  => 'Ödeme — NovaKur Fashion',
            'checkout/success'   => 'Siparişiniz Alındı — NovaKur Fashion',
            'product/search'     => 'Koleksiyonda Ara — NovaKur Fashion',
            'error/not_found'    => 'Sayfa Bulunamadı — NovaKur Fashion',
        ];
        if (isset($turkish_titles[$route])) {
            $this->document->setTitle($turkish_titles[$route]);
            $data['heading_title'] = $data['heading_title'] ?? $turkish_titles[$route];
        }

        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/login_fashion';
            }
        }

        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/register_fashion';
            }
        }

        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/account_fashion';
            }
        }

        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_fashion';
            }
        }

        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/search_fashion';
            }

            $data['nk_search_heading'] = 'Koleksiyonda Ara';
        }

        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_fashion.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_fashion';
            }
        }

        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_fashion';
            }

            // Load categories for homepage category tiles
            // Names and images are overridden with fashion demo data for a premium presentation.
            // Real category hrefs are preserved so links work correctly.
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $img_base = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/img/fashion/';
            $fashion_cats = [
                ['name' => 'Kadın Giyim', 'img' => 'category-womenswear.jpg'],
                ['name' => 'Dış Giyim',   'img' => 'category-outerwear.jpg'],
                ['name' => 'Aksesuar',    'img' => 'category-accessories.jpg'],
                ['name' => 'Erkek Giyim', 'img' => 'category-menswear.jpg'],
            ];
            $categories_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 4);
            $data['categories'] = [];
            foreach ($categories_raw as $i => $category) {
                $fc = $fashion_cats[$i] ?? $fashion_cats[0];

                // Always use fashion Antigravity images and Turkish names for premium presentation
                $data['categories'][] = [
                    'name'  => $fc['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                    'image' => $img_base . $fc['img'],
                ];
            }

            // Load latest products for New Arrivals row
            $this->load->model('catalog/product');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');

            // Fashion product overlays — real prices/links from OC4, names+images overridden with fashion demo data
            $fashion_products = [
                ['name' => 'İpek Midi Elbise',    'img' => 'product-silk-dress.jpg'],
                ['name' => 'Yapısal Yün Blazer',  'img' => 'product-wool-blazer.jpg'],
                ['name' => 'Geniş Keten Pantolon','img' => 'product-linen-trousers.jpg'],
                ['name' => 'Kaşmir Hırka',        'img' => 'product-cashmere-cardigan.jpg'],
            ];
            $fashion_best = [
                ['name' => 'Kaşmir Boğazlı Kazak','img' => 'product-cashmere-cardigan.jpg'],
                ['name' => 'Deri Kemer',          'img' => 'product-leather-belt.jpg'],
                ['name' => 'Keten Gömlek Elbise', 'img' => 'product-linen-trousers.jpg'],
                ['name' => 'Klasik Yün Palto',    'img' => 'product-wool-blazer.jpg'],
            ];

            $products_raw = $this->model_catalog_product->getProducts(['sort' => 'date_added', 'order' => 'DESC', 'start' => 0, 'limit' => 4]);
            $data['products'] = [];
            foreach ($products_raw as $i => $product) {
                $fp = $fashion_products[$i] ?? $fashion_products[0];
                $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));
                // Always use fashion names and Antigravity images for premium presentation
                $data['products'][] = [
                    'name'    => $fp['name'],
                    'price'   => $this->currency->format($price, $currency),
                    'special' => $product['special'] ? $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $currency) : false,
                    'href'    => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                    'image'   => $img_base . $fp['img'],
                    'thumb'   => $img_base . $fp['img'],
                ];
            }

            // Best sellers — sorted by most viewed
            $best_raw = $this->model_catalog_product->getProducts(['sort' => 'viewed', 'order' => 'DESC', 'start' => 0, 'limit' => 4]);
            $data['best_sellers'] = [];
            foreach ($best_raw as $i => $product) {
                $fb = $fashion_best[$i] ?? $fashion_best[0];
                $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));
                // Always use fashion names and Antigravity images for premium presentation
                $data['best_sellers'][] = [
                    'name'    => $fb['name'],
                    'price'   => $this->currency->format($price, $currency),
                    'special' => $product['special'] ? $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $currency) : false,
                    'href'    => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                    'image'   => $img_base . $fb['img'],
                    'thumb'   => $img_base . $fb['img'],
                ];
            }
        }

        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_fashion.twig';
            $this->load->model('catalog/category');
            $path = $this->request->get['path'] ?? '';
            $top_category_id = (int)explode('_', $path)[0];
            $hero_map = [];
            $top_cats = array_slice($this->model_catalog_category->getCategories(0), 0, 4);
            $hero_images = ['category-womenswear', 'category-outerwear', 'category-accessories', 'category-menswear'];

            foreach ($top_cats as $j => $tc) {
                $hero_map[(int)$tc['category_id']] = $hero_images[$j] ?? 'category-womenswear';
            }

            $data['nk_hero_image'] = $hero_map[$top_category_id] ?? 'category-womenswear';

            if (is_file($template)) {
                $route = 'extension/novakur/product/category_fashion';
            }
        }

        // Intercept individual product card rendering (OC4 pre-renders each product via product/thumb)
        if ($route === 'product/thumb') {
            $img_base = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/img/fashion/';
            $fashion_catalog = [
                'product-silk-dress.jpg',
                'product-wool-blazer.jpg',
                'product-linen-trousers.jpg',
                'product-cashmere-cardigan.jpg',
                'product-leather-belt.jpg',
                'product-wool-blazer.jpg',
                'product-silk-dress.jpg',
                'product-cashmere-cardigan.jpg',
            ];
            $fashion_names = [
                'İpek Midi Elbise',
                'Yapısal Yün Blazer',
                'Geniş Keten Pantolon',
                'Kaşmir Hırka',
                'Deri Kemer',
                'Klasik Yün Palto',
                'Saten Bluz',
                'Kaşmir Boğazlı Kazak',
            ];
            $idx = (int)($data['product_id'] ?? 0) % count($fashion_catalog);
            $data['nk_card_hover_swap'] = (bool)$this->config->get('theme_nk_fashion_card_hover_image_swap');

            // Always use fashion names and Antigravity images for premium presentation
            $data['product'] = [
                'product_id' => $data['product_id'] ?? 0,
                'name'       => $fashion_names[$idx],
                'thumb'      => $img_base . $fashion_catalog[$idx],
                'href'       => $data['href'] ?? '#',
                'price'      => $data['price'] ?? '',
                'special'    => $data['special'] ?? false,
                'tag'        => $data['tag'] ?? '',
                'rating'     => $data['rating'] ?? '',
                'reviews'    => $data['reviews'] ?? '',
            ];
            $route = 'extension/novakur/component/commerce/product_card_fashion';
        }

        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_fashion';
            }

            // Always override product detail with fashion Antigravity images for premium presentation
            {
                $img_base = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/img/fashion/';
                $fashion_detail = [
                    ['name' => 'İpek Midi Elbise',         'img' => 'product-silk-dress.jpg',        'desc' => 'Saf ipeğin yumuşak düşüşü ve zarif kesimi ile her ortama uygun, zamansız bir parça. Hafif yapısı ile gündüz şıklığını akşama taşır.'],
                    ['name' => 'Yapısal Yün Blazer',       'img' => 'product-wool-blazer.jpg',       'desc' => 'Soğuk günlerin vazgeçilmezi. Yapısal kesimi ve premium yün dokusu ile hem ofis hem de sokak stiline mükemmel uyum sağlar.'],
                    ['name' => 'Geniş Keten Pantolon',     'img' => 'product-linen-trousers.jpg',    'desc' => 'Doğal keten dokusu, geniş paça kesimi ve rahat fit ile yaz gardırobunuzun temel parçası. Hem günlük hem özel kullanım için ideal.'],
                    ['name' => 'Kaşmir Hırka',             'img' => 'product-cashmere-cardigan.jpg', 'desc' => 'Etik kaynaklı %100 kaşmir. Olağanüstü yumuşaklığı ve sıcaklığı ile hem estetik hem de işlevsel, mevsimler üstü bir klasik.'],
                    ['name' => 'Deri Kemer',               'img' => 'product-leather-belt.jpg',      'desc' => 'El yapımı İtalyan tam grain deri. Temiz çizgileri ve dayanıklı tokası ile her kombin için mükemmel bir aksesuar tamamlayıcı.'],
                    ['name' => 'Klasik Yün Palto',         'img' => 'product-wool-blazer.jpg',       'desc' => 'Çift dokuma premium yün ile üretilen bu klasik palto, kış gardırobunuzun merkezine yerleşir. Temiz silüeti her kombinin üzerine mükemmel oturur.'],
                    ['name' => 'Kaşmir Boğazlı Kazak',    'img' => 'product-cashmere-cardigan.jpg', 'desc' => 'İnce nervürlü balıkçı yaka detayı ile Skotya kaşmiri. Olağanüstü yumuşaklığı ve termal özelliği ile soğuk havaların favorisi.'],
                    ['name' => 'Keten Gömlek Elbise',     'img' => 'product-linen-trousers.jpg',    'desc' => 'Yıkanmış keten dokusu ve düğmeli önü ile şık ve rahat bir günlük şıklık. Belden bağlama detayı silüeti tanımlar.'],
                ];
                $product_id = (int)($this->request->get['product_id'] ?? 0);
                $idx = $product_id % count($fashion_detail);
                $fd  = $fashion_detail[$idx];

                $data['thumb']         = $img_base . $fd['img'];
                $data['popup']         = $img_base . $fd['img'];
                $data['heading_title'] = $fd['name'];
                $data['description']   = $fd['desc'];
                $other = array_values(array_filter($fashion_detail, function($f) use ($fd) { return $f['img'] !== $fd['img']; }));
                $data['images'] = array_map(function($f) use ($img_base) {
                    return ['thumb' => $img_base . $f['img'], 'popup' => $img_base . $f['img']];
                }, array_slice($other, 0, 4));

                if (!empty($data['related'])) {
                    $fashion_catalog = array_column($fashion_detail, 'img');
                    $fashion_names   = array_column($fashion_detail, 'name');
                    foreach ($data['related'] as $i => &$rprod) {
                        $ridx = (int)($rprod['product_id'] ?? $i) % count($fashion_catalog);
                        $rprod['thumb'] = $img_base . $fashion_catalog[$ridx];
                        $rprod['image'] = $img_base . $fashion_catalog[$ridx];
                        $rprod['name']  = $fashion_names[$ridx];
                    }
                    unset($rprod);
                }
            }
        }

        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_fashion';
            }
        }

        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_fashion';
            }
        }

        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_fashion';
            }
        }

        if ($route === 'account/order_info') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_info_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_info_fashion';
            }
        }

        if ($route === 'account/address') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/address_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/address_fashion';
            }
        }

        if ($route === 'account/edit') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/edit_fashion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/edit_fashion';
            }
        }
    }

    public function viewAfter(string &$route, array &$data, string &$output): void {
        if (!$this->isFashionThemeActive() || $route !== 'common/header' || !$output) {
            return;
        }

        $css = '<link rel="preconnect" href="https://fonts.googleapis.com">'
             . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
             . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Inter:wght@300;400;500;600&display=swap">'
             . '<link rel="stylesheet" href="' . rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-fashion.css">';
        $output = str_replace('</head>', $css . '</head>', $output);
    }

    private function isFashionThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');

        return in_array($current_theme, ['nk_fashion', 'novakur_fashion'], true) && (bool)$this->config->get('theme_nk_fashion_status');
    }
}
