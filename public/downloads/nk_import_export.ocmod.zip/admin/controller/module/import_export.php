<?php
namespace Opencart\Admin\Controller\Extension\NkImportExport\Module;
/**
 * Class ImportExport
 *
 * NovaKur Import / Export Pro — admin only CSV import & export tool.
 *
 * @package Opencart\Admin\Controller\Extension\NkImportExport\Module
 */
class ImportExport extends \Opencart\System\Engine\Controller {
	/**
	 * Route used for permission checks and for building AJAX links.
	 */
	const ROUTE = 'extension/nk_import_export/module/import_export';

	/**
	 * Hard bounds for the chunk size setting.
	 */
	const CHUNK_MIN = 5;
	const CHUNK_MAX = 2000;

	/**
	 * Upload ceiling in bytes (64 MB) on top of whatever PHP allows.
	 */
	const MAX_UPLOAD = 67108864;

	/**
	 * Delimiter tokens. Stored as words rather than the raw characters so the
	 * tab option survives a round trip through a form field.
	 */
	const DELIMITERS = [
		'comma'     => ',',
		'semicolon' => ';',
		'tab'       => "\t"
	];

	/**
	 * Index
	 *
	 * @return void
	 */
	public function index(): void {
		$this->load->language(self::ROUTE);

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model(self::ROUTE);

		// Housekeeping: drop working files and job rows older than a day.
		$this->model_extension_nk_import_export_module_import_export->clean(86400);

		// Settings are global: OpenCart only loads store 0 settings into $this->config,
		// and this tool has nothing per-store to configure.
		$settings = $this->model_setting_setting->getSetting('module_import_export');

		$data['module_import_export_status']      = $this->setting($settings, 'status', '0');
		$data['module_import_export_chunk_size']  = (int)$this->setting($settings, 'chunk_size', '100');
		$data['module_import_export_language_id'] = (int)$this->setting($settings, 'language_id', (string)$this->config->get('config_language_id'));
		$data['module_import_export_delimiter']   = $this->setting($settings, 'delimiter', 'comma');

		// Language strings
		foreach ([
			'heading_title', 'text_edit', 'text_enabled', 'text_disabled', 'text_extension',
			'tab_import', 'tab_export', 'tab_setting',
			'text_product', 'text_category', 'text_customer',
			'text_step_1', 'text_step_2', 'text_step_3',
			'text_mapping', 'text_preview', 'text_ignore', 'text_progress', 'text_summary',
			'text_errors', 'text_no_errors', 'text_no_file',
			'text_mode_both', 'text_mode_create', 'text_mode_update',
			'text_format_csv', 'text_format_xls', 'text_xls_note', 'text_storage_note',
			'text_all', 'text_none', 'text_loading',
			'entry_entity', 'entry_file', 'entry_delimiter', 'entry_mode', 'entry_match',
			'entry_store', 'entry_language', 'entry_status', 'entry_chunk_size',
			'entry_fields', 'entry_format',
			'help_chunk_size', 'help_language', 'help_delimiter', 'help_dry_run', 'help_match',
			'help_mode', 'help_categories', 'help_password', 'help_encoding',
			'button_upload', 'button_validate', 'button_import', 'button_export',
			'button_template', 'button_download', 'button_reset', 'button_save', 'button_back',
			'error_upload', 'error_directory', 'error_fields'
		] as $key) {
			$data[$key] = $this->language->get($key);
		}

		// Entities and their field definitions, handed to the browser as JSON so
		// the mapping UI can be rebuilt without another round trip.
		$data['entities'] = [];
		$data['fields']   = [];
		$data['keys']     = [];

		foreach ($this->model_extension_nk_import_export_module_import_export->getEntities() as $entity) {
			$data['entities'][] = [
				'code' => $entity,
				'name' => $this->language->get('text_' . $entity)
			];

			$fields = [];

			foreach ($this->model_extension_nk_import_export_module_import_export->getFields($entity) as $key => $field) {
				$fields[] = [
					'key'      => $key,
					'label'    => $field['label'],
					'required' => !empty($field['required']),
					'export'   => !isset($field['export']) || $field['export']
				];
			}

			$data['fields'][$entity] = $fields;

			$keys = [];

			foreach ($this->model_extension_nk_import_export_module_import_export->getKeyFields($entity) as $key) {
				$keys[] = [
					'key'   => $key,
					'label' => $this->model_extension_nk_import_export_module_import_export->getFields($entity)[$key]['label']
				];
			}

			$data['keys'][$entity] = $keys;
		}

		$data['fields_json'] = json_encode($data['fields']);
		$data['keys_json']   = json_encode($data['keys']);

		// Languages
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		// Stores
		$this->load->model('setting/store');

		$data['stores'] = [['store_id' => 0, 'name' => $this->config->get('config_name')]];

		foreach ($this->model_setting_store->getStores() as $store) {
			$data['stores'][] = ['store_id' => (int)$store['store_id'], 'name' => $store['name']];
		}

		$data['delimiters'] = [];

		foreach (array_keys(self::DELIMITERS) as $token) {
			$data['delimiters'][] = ['value' => $token, 'name' => $this->language->get('text_' . $token)];
		}

		$data['writable'] = $this->model_extension_nk_import_export_module_import_export->makeDirectory();

		$data['max_upload'] = min(self::MAX_UPLOAD, $this->getUploadLimit());

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token'])
		];

		$token = 'user_token=' . $this->session->data['user_token'];

		$data['save']     = $this->url->link(self::ROUTE . '.save', $token);
		$data['upload']   = $this->url->link(self::ROUTE . '.upload', $token, true);
		$data['start']    = $this->url->link(self::ROUTE . '.start', $token, true);
		$data['export']   = $this->url->link(self::ROUTE . '.export', $token, true);
		$data['template'] = $this->url->link(self::ROUTE . '.template', $token, true);
		$data['back']     = $this->url->link('marketplace/extension', $token . '&type=module');

		$data['user_token'] = $this->session->data['user_token'];

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view(self::ROUTE, $data));
	}

	/**
	 * Save
	 *
	 * @return void
	 */
	public function save(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$chunk_size = (int)($post['module_import_export_chunk_size'] ?? 100);

		if (!$json && ($chunk_size < self::CHUNK_MIN || $chunk_size > self::CHUNK_MAX)) {
			$json['error'] = sprintf($this->language->get('error_chunk_size'), self::CHUNK_MIN, self::CHUNK_MAX);
		}

		$language_id = (int)($post['module_import_export_language_id'] ?? 0);

		if (!$json) {
			$this->load->model('localisation/language');

			if (!$language_id || !$this->model_localisation_language->getLanguage($language_id)) {
				$json['error'] = $this->language->get('error_language');
			}
		}

		$delimiter = (string)($post['module_import_export_delimiter'] ?? 'comma');

		if (!$json && !isset(self::DELIMITERS[$delimiter])) {
			$json['error'] = $this->language->get('error_delimiter');
		}

		if (!$json) {
			$save = [
				'module_import_export_status'      => isset($post['module_import_export_status']) ? (string)(int)$post['module_import_export_status'] : '0',
				'module_import_export_chunk_size'  => (string)$chunk_size,
				'module_import_export_language_id' => (string)$language_id,
				'module_import_export_delimiter'   => $delimiter
			];

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_import_export', $save);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Upload
	 *
	 * Receives the CSV, stores it in the private storage directory and returns
	 * the header row, a five row preview and a suggested column mapping.
	 *
	 * @return void
	 */
	public function upload(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$entity = (string)($this->request->post['entity'] ?? '');

		$this->load->model(self::ROUTE);

		if (!$json && !in_array($entity, $this->model_extension_nk_import_export_module_import_export->getEntities(), true)) {
			$json['error'] = $this->language->get('error_entity');
		}

		if (!$json && !$this->model_extension_nk_import_export_module_import_export->makeDirectory()) {
			$json['error'] = $this->language->get('error_directory');
		}

		if (!$json && (empty($this->request->files['file']['name']) || !is_uploaded_file($this->request->files['file']['tmp_name']))) {
			$json['error'] = $this->language->get('error_upload');
		}

		if (!$json && $this->request->files['file']['error'] != UPLOAD_ERR_OK) {
			$json['error'] = $this->language->get('error_upload');
		}

		if (!$json) {
			$original = basename(html_entity_decode($this->request->files['file']['name'], ENT_QUOTES, 'UTF-8'));

			if (!oc_validate_length($original, 5, 128)) {
				$json['error'] = $this->language->get('error_filename');
			}

			if (!$json && strtolower((string)substr(strrchr($original, '.') ?: '', 1)) !== 'csv') {
				$json['error'] = $this->language->get('error_file_type');
			}

			if (!$json && filesize($this->request->files['file']['tmp_name']) > self::MAX_UPLOAD) {
				$json['error'] = sprintf($this->language->get('error_file_size'), round(self::MAX_UPLOAD / 1048576));
			}
		}

		if (!$json) {
			// Random, extension pinned name inside the storage folder. The file
			// is never reachable over HTTP; download() is the only way out.
			$filename = 'import-' . oc_token(24) . '.csv';

			$target = $this->model_extension_nk_import_export_module_import_export->getDirectory() . $filename;

			if (!move_uploaded_file($this->request->files['file']['tmp_name'], $target)) {
				$json['error'] = $this->language->get('error_upload');
			} else {
				@chmod($target, 0644);

				$delimiter = $this->getDelimiter();

				$head = $this->model_extension_nk_import_export_module_import_export->readHead($target, $delimiter, 5);

				if (!$head['headers']) {
					@unlink($target);

					$json['error'] = $this->language->get('error_header');
				} elseif (!$head['total']) {
					@unlink($target);

					$json['error'] = $this->language->get('error_empty');
				} else {
					$json['filename']      = $filename;
					$json['original_name'] = $original;
					$json['headers']       = $head['headers'];
					$json['preview']       = $head['preview'];
					$json['total']         = $head['total'];
					$json['mapping']       = $this->model_extension_nk_import_export_module_import_export->suggestMapping($entity, $head['headers']);
					$json['success']       = sprintf($this->language->get('text_uploaded'), $original, $head['total']);
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Start
	 *
	 * Validates the submitted column mapping and creates the job record that
	 * process() then walks through one chunk at a time.
	 *
	 * @return void
	 */
	public function start(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$this->load->model(self::ROUTE);

		$entity = (string)($this->request->post['entity'] ?? '');

		if (!$json && !in_array($entity, $this->model_extension_nk_import_export_module_import_export->getEntities(), true)) {
			$json['error'] = $this->language->get('error_entity');
		}

		$filename = basename((string)($this->request->post['filename'] ?? ''));

		$file = $this->model_extension_nk_import_export_module_import_export->getDirectory() . $filename;

		if (!$json && (!preg_match('/^import-[a-zA-Z0-9]+\.csv$/', $filename) || !is_file($file))) {
			$json['error'] = $this->language->get('error_file');
		}

		// Column mapping: column index => field key
		$mapping = [];
		$used    = [];
		$fields  = $json ? [] : $this->model_extension_nk_import_export_module_import_export->getFields($entity);

		if (!$json) {
			$posted = (array)($this->request->post['mapping'] ?? []);

			foreach ($posted as $column => $field) {
				$field = (string)$field;

				if ($field === '') {
					continue;
				}

				if (!isset($fields[$field])) {
					$json['error'] = sprintf($this->language->get('error_field'), $field);

					break;
				}

				if (isset($used[$field])) {
					$json['error'] = sprintf($this->language->get('error_duplicate_field'), $fields[$field]['label']);

					break;
				}

				$used[$field] = true;

				$mapping[(int)$column] = $field;
			}

			if (!$json && !$mapping) {
				$json['error'] = $this->language->get('error_mapping');
			}
		}

		$mode = (string)($this->request->post['mode'] ?? 'both');

		if (!$json && !in_array($mode, ['both', 'create', 'update'], true)) {
			$json['error'] = $this->language->get('error_mode');
		}

		$match = (string)($this->request->post['match'] ?? '');

		if (!$json) {
			$keys = $this->model_extension_nk_import_export_module_import_export->getKeyFields($entity);

			if (!in_array($match, $keys, true)) {
				$json['error'] = $this->language->get('error_match');
			} elseif (!isset($used[$match])) {
				// Matching on a column that was never mapped can never find anything
				$json['error'] = sprintf($this->language->get('error_match_unmapped'), $fields[$match]['label']);
			}
		}

		if (!$json) {
			$this->load->model('localisation/language');

			$language_id = (int)($this->request->post['language_id'] ?? $this->getLanguageId());

			if (!$this->model_localisation_language->getLanguage($language_id)) {
				$language_id = $this->getLanguageId();
			}

			$options = [
				'mode'        => $mode,
				'match'       => $match,
				'dry_run'     => !empty($this->request->post['dry_run']) ? 1 : 0,
				'language_id' => $language_id,
				'store_id'    => (int)($this->request->post['store_id'] ?? 0),
				'delimiter'   => $this->getDelimiter(),
				'chunk_size'  => $this->getChunkSize()
			];

			$head = $this->model_extension_nk_import_export_module_import_export->readHead($file, $options['delimiter'], 0);

			$job_id = $this->model_extension_nk_import_export_module_import_export->addJob([
				'user_id'       => (int)$this->user->getId(),
				'entity'        => $entity,
				'filename'      => $filename,
				'original_name' => (string)($this->request->post['original_name'] ?? $filename),
				'mapping'       => $mapping,
				'options'       => $options,
				'total_rows'    => (int)$head['total']
			]);

			$json['job_id'] = $job_id;
			$json['total']  = (int)$head['total'];
			$json['dry_run'] = $options['dry_run'];
			$json['next']   = $this->url->link(self::ROUTE . '.process', 'user_token=' . $this->session->data['user_token'] . '&job_id=' . $job_id, true);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Process
	 *
	 * Handles one chunk of rows per request so that large files never hit the
	 * PHP execution time limit.
	 *
	 * @return void
	 */
	public function process(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$this->load->model(self::ROUTE);

		$job_id = (int)($this->request->get['job_id'] ?? 0);

		// Jobs are scoped to the user that created them.
		$job = $json ? [] : $this->model_extension_nk_import_export_module_import_export->getJob($job_id, (int)$this->user->getId());

		if (!$json && !$job) {
			$json['error'] = $this->language->get('error_job');
		}

		if (!$json) {
			$entity  = (string)$job['entity'];
			$mapping = (array)json_decode((string)$job['mapping'], true);
			$options = (array)json_decode((string)$job['options'], true);

			$file = $this->model_extension_nk_import_export_module_import_export->getDirectory() . basename((string)$job['filename']);

			if (!is_file($file)) {
				$json['error'] = $this->language->get('error_file');
			} else {
				$chunk = (int)($options['chunk_size'] ?? 100);
				$chunk = max(self::CHUNK_MIN, min(self::CHUNK_MAX, $chunk));

				$read = $this->model_extension_nk_import_export_module_import_export->readChunk($file, (string)$options['delimiter'], (int)$job['byte_offset'], $chunk);

				$created = (int)$job['created'];
				$updated = (int)$job['updated'];
				$skipped = (int)$job['skipped'];
				$failed  = (int)$job['failed'];
				$row_no  = (int)$job['row_index'];

				$errors = (array)json_decode((string)$job['errors'], true);
				$fresh  = [];

				foreach ($read['rows'] as $row) {
					$row_no++;

					$data = $this->model_extension_nk_import_export_module_import_export->mapRow($row, $mapping);

					$existing = $this->model_extension_nk_import_export_module_import_export->findExisting($entity, $data, (string)$options['match']);

					if ($options['mode'] === 'create' && $existing) {
						$skipped++;

						$fresh[] = sprintf($this->language->get('text_row_skipped_exists'), $row_no);

						continue;
					}

					// In create mode an existing match was just refused above, so
					// the row always describes a brand new record from here on.
					$record_id = $options['mode'] === 'create' ? 0 : $existing;

					if ($options['mode'] === 'update' && !$record_id) {
						$skipped++;

						$fresh[] = sprintf($this->language->get('text_row_skipped_missing'), $row_no);

						continue;
					}

					$problems = $this->model_extension_nk_import_export_module_import_export->validateRow($entity, $data, $record_id, $options);

					if ($problems) {
						$failed++;

						foreach ($problems as $problem) {
							$fresh[] = sprintf($this->language->get('text_row_error'), $row_no, $problem);
						}

						continue;
					}

					if (!empty($options['dry_run'])) {
						// Dry run: everything above ran, nothing below does.
						if ($record_id) {
							$updated++;
						} else {
							$created++;
						}

						continue;
					}

					$result = $this->model_extension_nk_import_export_module_import_export->writeRow($entity, $data, $record_id, $options);

					if ($result === 'created') {
						$created++;
					} elseif ($result === 'updated') {
						$updated++;
					} else {
						$skipped++;
					}
				}

				$errors = array_merge($errors, $fresh);

				$size     = max(1, (int)filesize($file));
				$offset   = (int)$read['offset'];
				$finished = !$read['rows'] || $read['eof'];

				$this->model_extension_nk_import_export_module_import_export->editJob($job_id, [
					'row_index'   => $row_no,
					'byte_offset' => $offset,
					'created'     => $created,
					'updated'     => $updated,
					'skipped'     => $skipped,
					'failed'      => $failed,
					'errors'      => $errors,
					'status'      => $finished ? 'complete' : 'running'
				]);

				$json['progress'] = $finished ? 100 : min(99, (int)round(($offset / $size) * 100));
				$json['errors']   = array_slice($fresh, 0, 200);
				$json['summary']  = [
					'created' => $created,
					'updated' => $updated,
					'skipped' => $skipped,
					'failed'  => $failed,
					'rows'    => $row_no,
					'total'   => (int)$job['total_rows']
				];

				if ($finished) {
					$key = !empty($options['dry_run']) ? 'text_dry_run_complete' : 'text_import_complete';

					$json['success'] = sprintf($this->language->get($key), $created, $updated, $skipped, $failed);

					// The uploaded file has served its purpose.
					@unlink($file);
				} else {
					$json['text'] = sprintf($this->language->get('text_processing'), $row_no, (int)$job['total_rows']);
					$json['next'] = $this->url->link(self::ROUTE . '.process', 'user_token=' . $this->session->data['user_token'] . '&job_id=' . $job_id, true);
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Export
	 *
	 * Writes chunk_size records per request into a file in the storage folder
	 * and hands back a download link once the last record is written.
	 *
	 * @return void
	 */
	public function export(): void {
		$this->load->language(self::ROUTE);

		$json = [];

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$json['error'] = $this->language->get('error_permission');
		}

		$this->load->model(self::ROUTE);

		$entity = (string)($this->request->get['entity'] ?? '');

		if (!$json && !in_array($entity, $this->model_extension_nk_import_export_module_import_export->getEntities(), true)) {
			$json['error'] = $this->language->get('error_entity');
		}

		$format = (string)($this->request->get['format'] ?? 'csv');

		if (!$json && !in_array($format, ['csv', 'xls'], true)) {
			$json['error'] = $this->language->get('error_format');
		}

		if (!$json && !$this->model_extension_nk_import_export_module_import_export->makeDirectory()) {
			$json['error'] = $this->language->get('error_directory');
		}

		$fields = [];

		if (!$json) {
			$available = $this->model_extension_nk_import_export_module_import_export->getFields($entity);
			$posted    = (array)($this->request->post['field'] ?? []);

			foreach ($posted as $field) {
				$field = (string)$field;

				if (isset($available[$field]) && (!isset($available[$field]['export']) || $available[$field]['export']) && !in_array($field, $fields, true)) {
					$fields[] = $field;
				}
			}

			if (!$fields) {
				$json['error'] = $this->language->get('error_fields');
			}
		}

		$start = max(0, (int)($this->request->get['start'] ?? 0));

		$filename = (string)($this->request->get['filename'] ?? '');

		if (!$json && $start > 0 && !preg_match('/^export-[a-z]+-[0-9]{8}-[a-zA-Z0-9]+\.(csv|xls)$/', basename($filename))) {
			$json['error'] = $this->language->get('error_file');
		}

		if (!$json) {
			$directory = $this->model_extension_nk_import_export_module_import_export->getDirectory();

			$chunk = $this->getChunkSize();
			$total = $this->model_extension_nk_import_export_module_import_export->getExportTotal($entity);

			// The header row carries the raw field keys so an exported file can
			// be imported straight back with a perfect auto mapping.
			$labels = $fields;

			if ($start === 0) {
				$filename = 'export-' . $entity . '-' . date('Ymd') . '-' . oc_token(16) . '.' . $format;

				$handle = fopen($directory . $filename, 'w');

				if ($format === 'csv') {
					// UTF-8 BOM so Excel opens the file in the right encoding.
					fwrite($handle, "\xEF\xBB\xBF");

					fputcsv($handle, $labels, $this->getDelimiter(), '"', '\\');
				} else {
					fwrite($handle, "<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /></head><body><table border=\"1\">\n");
					fwrite($handle, $this->htmlRow($labels, 'th'));
				}
			} else {
				$filename = basename($filename);

				$handle = fopen($directory . $filename, 'a');
			}

			if (!$handle) {
				$json['error'] = $this->language->get('error_directory');
			} else {
				$rows = $this->model_extension_nk_import_export_module_import_export->getExportRows($entity, $fields, $start, $chunk, $this->getLanguageId());

				foreach ($rows as $row) {
					if ($format === 'csv') {
						fputcsv($handle, $row, $this->getDelimiter(), '"', '\\');
					} else {
						fwrite($handle, $this->htmlRow($row, 'td'));
					}
				}

				$start += count($rows);

				$finished = !$rows || $start >= $total;

				if ($finished && $format === 'xls') {
					fwrite($handle, "</table></body></html>");
				}

				fclose($handle);

				$json['progress'] = $total ? min(100, (int)round(($start / $total) * 100)) : 100;

				if ($finished) {
					$json['success']  = sprintf($this->language->get('text_export_complete'), $start);
					$json['download'] = $this->url->link(self::ROUTE . '.download', 'user_token=' . $this->session->data['user_token'] . '&filename=' . urlencode($filename), true);
					$json['filename'] = $filename;
				} else {
					$json['text'] = sprintf($this->language->get('text_exporting'), $start, $total);
					$json['next'] = $this->url->link(self::ROUTE . '.export', 'user_token=' . $this->session->data['user_token'] . '&entity=' . $entity . '&format=' . $format . '&filename=' . urlencode($filename) . '&start=' . $start, true);
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Template
	 *
	 * Streams an empty CSV containing just the header row for an entity, so a
	 * merchant can fill it in and import it straight back.
	 *
	 * @return void
	 */
	public function template(): void {
		$this->load->language(self::ROUTE);

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$this->response->redirect($this->url->link('error/permission', 'user_token=' . $this->session->data['user_token']));

			return;
		}

		$this->load->model(self::ROUTE);

		$entity = (string)($this->request->get['entity'] ?? '');

		if (!in_array($entity, $this->model_extension_nk_import_export_module_import_export->getEntities(), true)) {
			$this->response->redirect($this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token']));

			return;
		}

		$headers = array_keys($this->model_extension_nk_import_export_module_import_export->getFields($entity));

		$handle = fopen('php://temp', 'w+');

		fwrite($handle, "\xEF\xBB\xBF");

		fputcsv($handle, $headers, $this->getDelimiter(), '"', '\\');

		rewind($handle);

		$output = (string)stream_get_contents($handle);

		fclose($handle);

		$this->response->addHeader('Content-Type: text/csv; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="nk-' . $entity . '-template.csv"');
		$this->response->addHeader('Content-Length: ' . strlen($output));
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput($output);
	}

	/**
	 * Download
	 *
	 * The only route out of the storage folder. Anything that is not a file
	 * this module generated is refused.
	 *
	 * @return void
	 */
	public function download(): void {
		$this->load->language(self::ROUTE);

		if (!$this->user->hasPermission('modify', self::ROUTE)) {
			$this->response->redirect($this->url->link('error/permission', 'user_token=' . $this->session->data['user_token']));

			return;
		}

		$this->load->model(self::ROUTE);

		$filename = basename(html_entity_decode((string)($this->request->get['filename'] ?? ''), ENT_QUOTES, 'UTF-8'));

		if (!preg_match('/^export-[a-z]+-[0-9]{8}-[a-zA-Z0-9]+\.(csv|xls)$/', $filename)) {
			$this->response->redirect($this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token']));

			return;
		}

		$file = $this->model_extension_nk_import_export_module_import_export->getDirectory() . $filename;

		if (!is_file($file)) {
			$this->response->redirect($this->url->link(self::ROUTE, 'user_token=' . $this->session->data['user_token']));

			return;
		}

		$mime = substr($filename, -3) === 'xls' ? 'application/vnd.ms-excel' : 'text/csv';

		$this->response->addHeader('Content-Type: ' . $mime . '; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="' . $filename . '"');
		$this->response->addHeader('Content-Length: ' . (string)filesize($file));
		$this->response->addHeader('Cache-Control: no-store');
		$this->response->setOutput((string)file_get_contents($file));
	}

	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void {
		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('module_import_export', [
			'module_import_export_status'      => '0',
			'module_import_export_chunk_size'  => '100',
			'module_import_export_language_id' => (string)(int)$this->config->get('config_language_id'),
			'module_import_export_delimiter'   => 'comma'
		]);

		$this->load->model(self::ROUTE);

		$this->model_extension_nk_import_export_module_import_export->install();
	}

	/**
	 * Uninstall
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('module_import_export');

		$this->load->model(self::ROUTE);

		$this->model_extension_nk_import_export_module_import_export->uninstall();
	}

	/* -----------------------------------------------------------------
	 * Helpers
	 * ----------------------------------------------------------------- */

	/**
	 * Setting
	 *
	 * @param array<string, mixed> $settings
	 * @param string               $key
	 * @param string               $default
	 *
	 * @return string
	 */
	private function setting(array $settings, string $key, string $default): string {
		$name = 'module_import_export_' . $key;

		if (isset($this->request->post[$name])) {
			return (string)$this->request->post[$name];
		}

		if (isset($settings[$name]) && $settings[$name] !== '') {
			return (string)$settings[$name];
		}

		return $default;
	}

	/**
	 * Get Chunk Size
	 *
	 * @return int
	 */
	private function getChunkSize(): int {
		$chunk = (int)$this->config->get('module_import_export_chunk_size');

		if ($chunk < self::CHUNK_MIN || $chunk > self::CHUNK_MAX) {
			$chunk = 100;
		}

		return $chunk;
	}

	/**
	 * Get Language Id
	 *
	 * @return int
	 */
	private function getLanguageId(): int {
		$language_id = (int)$this->config->get('module_import_export_language_id');

		return $language_id ?: (int)$this->config->get('config_language_id');
	}

	/**
	 * Get Delimiter
	 *
	 * @return string
	 */
	private function getDelimiter(): string {
		$delimiter = (string)$this->config->get('module_import_export_delimiter');

		return self::DELIMITERS[$delimiter] ?? ',';
	}

	/**
	 * Get Upload Limit
	 *
	 * @return int
	 */
	private function getUploadLimit(): int {
		$limit = (int)preg_replace('/[^0-9]/', '', (string)ini_get('upload_max_filesize'));

		return $limit ? $limit * 1048576 : self::MAX_UPLOAD;
	}

	/**
	 * Html Row
	 *
	 * One row of the .xls fallback. Values are escaped so a product name with
	 * markup cannot break out of the table.
	 *
	 * @param array<int, string> $cells
	 * @param string             $tag
	 *
	 * @return string
	 */
	private function htmlRow(array $cells, string $tag): string {
		$output = '<tr>';

		foreach ($cells as $cell) {
			$output .= '<' . $tag . '>' . htmlspecialchars((string)$cell, ENT_QUOTES, 'UTF-8') . '</' . $tag . '>';
		}

		return $output . "</tr>\n";
	}
}
