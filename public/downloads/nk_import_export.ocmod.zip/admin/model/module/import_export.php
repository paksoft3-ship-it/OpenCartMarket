<?php
namespace Opencart\Admin\Model\Extension\NkImportExport\Module;
/**
 * Class ImportExport
 *
 * NovaKur Import / Export Pro — data layer.
 *
 * Can be called from $this->load->model('extension/nk_import_export/module/import_export');
 *
 * @package Opencart\Admin\Model\Extension\NkImportExport\Module
 */
class ImportExport extends \Opencart\System\Engine\Model {
	/**
	 * Maximum number of per-row errors persisted on a job record.
	 */
	const ERROR_LIMIT = 500;

	/**
	 * Lazily built lookup caches, rebuilt once per request.
	 *
	 * @var array<string, array<string, int>>
	 */
	private array $lookup = [];

	/* -----------------------------------------------------------------
	 * Install / uninstall
	 * ----------------------------------------------------------------- */

	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_import_export_job` (
			`job_id` int(11) NOT NULL AUTO_INCREMENT,
			`user_id` int(11) NOT NULL DEFAULT '0',
			`entity` varchar(16) NOT NULL DEFAULT '',
			`filename` varchar(255) NOT NULL DEFAULT '',
			`original_name` varchar(255) NOT NULL DEFAULT '',
			`mapping` text NOT NULL,
			`options` text NOT NULL,
			`total_rows` int(11) NOT NULL DEFAULT '0',
			`row_index` int(11) NOT NULL DEFAULT '0',
			`byte_offset` bigint(20) NOT NULL DEFAULT '0',
			`created` int(11) NOT NULL DEFAULT '0',
			`updated` int(11) NOT NULL DEFAULT '0',
			`skipped` int(11) NOT NULL DEFAULT '0',
			`failed` int(11) NOT NULL DEFAULT '0',
			`errors` mediumtext NOT NULL,
			`status` varchar(16) NOT NULL DEFAULT 'pending',
			`date_added` datetime NOT NULL,
			PRIMARY KEY (`job_id`),
			KEY `user_id` (`user_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

		$this->makeDirectory();
	}

	/**
	 * Uninstall
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "nk_import_export_job`");
	}

	/**
	 * Directory
	 *
	 * Absolute path of the private working directory inside the OpenCart storage
	 * folder. The storage folder is never web accessible, so uploaded CSVs and
	 * generated exports cannot be fetched without going through download().
	 *
	 * @return string
	 */
	public function getDirectory(): string {
		return DIR_STORAGE . 'nk_import_export/';
	}

	/**
	 * Make Directory
	 *
	 * @return bool
	 */
	public function makeDirectory(): bool {
		$directory = $this->getDirectory();

		if (!is_dir($directory)) {
			@mkdir($directory, 0755, true);
		}

		if (is_dir($directory) && !is_file($directory . 'index.html')) {
			@file_put_contents($directory . 'index.html', '');
		}

		return is_dir($directory) && is_writable($directory);
	}

	/**
	 * Clean
	 *
	 * Remove working files and job rows older than the given age in seconds.
	 *
	 * @param int $age
	 *
	 * @return void
	 */
	public function clean(int $age = 86400): void {
		$directory = $this->getDirectory();

		if (!is_dir($directory)) {
			return;
		}

		$expires = time() - $age;

		foreach ((array)glob($directory . '*.{csv,xls}', GLOB_BRACE) as $file) {
			if (is_file($file) && filemtime($file) < $expires) {
				@unlink($file);
			}
		}

		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_import_export_job` WHERE `date_added` < DATE_SUB(NOW(), INTERVAL '" . (int)$age . "' SECOND)");
	}

	/* -----------------------------------------------------------------
	 * Field definitions
	 * ----------------------------------------------------------------- */

	/**
	 * Get Entities
	 *
	 * @return array<int, string>
	 */
	public function getEntities(): array {
		return ['product', 'category', 'customer'];
	}

	/**
	 * Get Fields
	 *
	 * Field definition for an entity. Each entry carries:
	 *  - label    human readable column caption
	 *  - type     int|float|bool|string|text|date|datetime|email|password|list|json
	 *  - max      maximum length for string types (mirrors the column width)
	 *  - required whether a value is mandatory when creating a new record
	 *  - key      the field can be used as the "match on" column for updates
	 *  - export   false hides the field from export (passwords)
	 *
	 * @param string $entity
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function getFields(string $entity): array {
		switch ($entity) {
			case 'product':
				return [
					'product_id'        => ['label' => 'Product ID', 'type' => 'int', 'key' => true],
					'model'             => ['label' => 'Model', 'type' => 'string', 'max' => 64, 'required' => true, 'key' => true],
					'name'              => ['label' => 'Name', 'type' => 'string', 'max' => 255, 'required' => true],
					'description'       => ['label' => 'Description (HTML)', 'type' => 'text'],
					'tag'               => ['label' => 'Tags', 'type' => 'text'],
					'meta_title'        => ['label' => 'Meta Title', 'type' => 'string', 'max' => 255],
					'meta_description'  => ['label' => 'Meta Description', 'type' => 'string', 'max' => 255],
					'meta_keyword'      => ['label' => 'Meta Keyword', 'type' => 'string', 'max' => 255],
					'sku'               => ['label' => 'SKU', 'type' => 'string', 'max' => 64, 'key' => true],
					'upc'               => ['label' => 'UPC', 'type' => 'string', 'max' => 12],
					'ean'               => ['label' => 'EAN', 'type' => 'string', 'max' => 14],
					'jan'               => ['label' => 'JAN', 'type' => 'string', 'max' => 13],
					'isbn'              => ['label' => 'ISBN', 'type' => 'string', 'max' => 17],
					'mpn'               => ['label' => 'MPN', 'type' => 'string', 'max' => 64],
					'location'          => ['label' => 'Location', 'type' => 'string', 'max' => 128],
					'image'             => ['label' => 'Image (path under image/)', 'type' => 'string', 'max' => 255],
					'additional_images' => ['label' => 'Additional Images (pipe separated)', 'type' => 'list'],
					'price'             => ['label' => 'Price', 'type' => 'float'],
					'quantity'          => ['label' => 'Quantity', 'type' => 'int'],
					'minimum'           => ['label' => 'Minimum Quantity', 'type' => 'int'],
					'subtract'          => ['label' => 'Subtract Stock', 'type' => 'bool'],
					'stock_status_id'   => ['label' => 'Out Of Stock Status ID', 'type' => 'int'],
					'points'            => ['label' => 'Points', 'type' => 'int'],
					'tax_class_id'      => ['label' => 'Tax Class ID', 'type' => 'int'],
					'manufacturer_id'   => ['label' => 'Manufacturer ID', 'type' => 'int'],
					'manufacturer'      => ['label' => 'Manufacturer (by name)', 'type' => 'string', 'max' => 64],
					'shipping'          => ['label' => 'Requires Shipping', 'type' => 'bool'],
					'date_available'    => ['label' => 'Date Available (YYYY-MM-DD)', 'type' => 'date'],
					'weight'            => ['label' => 'Weight', 'type' => 'float'],
					'weight_class_id'   => ['label' => 'Weight Class ID', 'type' => 'int'],
					'length'            => ['label' => 'Length', 'type' => 'float'],
					'width'             => ['label' => 'Width', 'type' => 'float'],
					'height'            => ['label' => 'Height', 'type' => 'float'],
					'length_class_id'   => ['label' => 'Length Class ID', 'type' => 'int'],
					'status'            => ['label' => 'Status (enabled)', 'type' => 'bool'],
					'sort_order'        => ['label' => 'Sort Order', 'type' => 'int'],
					'categories'        => ['label' => 'Categories (IDs or names, pipe separated)', 'type' => 'list'],
					'stores'            => ['label' => 'Store IDs (pipe separated)', 'type' => 'list'],
					'related'           => ['label' => 'Related Product IDs (pipe separated)', 'type' => 'list'],
					'seo_keyword'       => ['label' => 'SEO Keyword', 'type' => 'string', 'max' => 255]
				];
			case 'category':
				return [
					'category_id'      => ['label' => 'Category ID', 'type' => 'int', 'key' => true],
					'name'             => ['label' => 'Name', 'type' => 'string', 'max' => 255, 'required' => true, 'key' => true],
					'description'      => ['label' => 'Description (HTML)', 'type' => 'text'],
					'meta_title'       => ['label' => 'Meta Title', 'type' => 'string', 'max' => 255],
					'meta_description' => ['label' => 'Meta Description', 'type' => 'string', 'max' => 255],
					'meta_keyword'     => ['label' => 'Meta Keyword', 'type' => 'string', 'max' => 255],
					'parent_id'        => ['label' => 'Parent Category ID', 'type' => 'int'],
					'image'            => ['label' => 'Image (path under image/)', 'type' => 'string', 'max' => 255],
					'sort_order'       => ['label' => 'Sort Order', 'type' => 'int'],
					'status'           => ['label' => 'Status (enabled)', 'type' => 'bool'],
					'stores'           => ['label' => 'Store IDs (pipe separated)', 'type' => 'list'],
					'seo_keyword'      => ['label' => 'SEO Keyword', 'type' => 'string', 'max' => 255]
				];
			case 'customer':
				return [
					'customer_id'       => ['label' => 'Customer ID', 'type' => 'int', 'key' => true],
					'firstname'         => ['label' => 'First Name', 'type' => 'string', 'max' => 32, 'required' => true],
					'lastname'          => ['label' => 'Last Name', 'type' => 'string', 'max' => 32, 'required' => true],
					'email'             => ['label' => 'E-Mail', 'type' => 'email', 'max' => 96, 'required' => true, 'key' => true],
					'telephone'         => ['label' => 'Telephone', 'type' => 'string', 'max' => 32],
					'password'          => ['label' => 'Password (plain text, never exported)', 'type' => 'password', 'export' => false],
					'customer_group_id' => ['label' => 'Customer Group ID', 'type' => 'int'],
					'store_id'          => ['label' => 'Store ID', 'type' => 'int'],
					'language_id'       => ['label' => 'Language ID', 'type' => 'int'],
					'custom_field'      => ['label' => 'Custom Field (JSON)', 'type' => 'json'],
					'newsletter'        => ['label' => 'Newsletter', 'type' => 'bool'],
					'status'            => ['label' => 'Status (enabled)', 'type' => 'bool'],
					'safe'              => ['label' => 'Safe (skip anti-fraud)', 'type' => 'bool'],
					'commenter'         => ['label' => 'Commenter', 'type' => 'bool'],
					'date_added'        => ['label' => 'Date Added (YYYY-MM-DD HH:MM:SS)', 'type' => 'datetime']
				];
		}

		return [];
	}

	/**
	 * Get Key Fields
	 *
	 * Fields that may be used to match an existing record on import.
	 *
	 * @param string $entity
	 *
	 * @return array<int, string>
	 */
	public function getKeyFields(string $entity): array {
		$keys = [];

		foreach ($this->getFields($entity) as $key => $field) {
			if (!empty($field['key'])) {
				$keys[] = $key;
			}
		}

		return $keys;
	}

	/**
	 * Suggest Mapping
	 *
	 * Best-effort auto mapping of CSV header captions onto entity fields.
	 *
	 * @param string            $entity
	 * @param array<int, string> $headers
	 *
	 * @return array<int, string>
	 */
	public function suggestMapping(string $entity, array $headers): array {
		$fields = $this->getFields($entity);

		$index = [];

		foreach ($fields as $key => $field) {
			$index[$this->normalise($key)] = $key;
			$index[$this->normalise($field['label'])] = $key;
		}

		// A few friendly aliases people actually have in their spreadsheets
		$aliases = [
			'id'               => ['product' => 'product_id', 'category' => 'category_id', 'customer' => 'customer_id'],
			'title'            => ['product' => 'name', 'category' => 'name'],
			'productname'      => ['product' => 'name'],
			'categoryname'     => ['category' => 'name'],
			'qty'              => ['product' => 'quantity'],
			'stock'            => ['product' => 'quantity'],
			'category'         => ['product' => 'categories'],
			'brand'            => ['product' => 'manufacturer'],
			'seourl'           => ['product' => 'seo_keyword', 'category' => 'seo_keyword'],
			'slug'             => ['product' => 'seo_keyword', 'category' => 'seo_keyword'],
			'firstname'        => ['customer' => 'firstname'],
			'lastname'         => ['customer' => 'lastname'],
			'phone'            => ['customer' => 'telephone'],
			'mail'             => ['customer' => 'email'],
			'emailaddress'     => ['customer' => 'email']
		];

		foreach ($aliases as $alias => $map) {
			if (isset($map[$entity]) && isset($fields[$map[$entity]]) && !isset($index[$alias])) {
				$index[$alias] = $map[$entity];
			}
		}

		$mapping = [];
		$taken   = [];

		foreach ($headers as $i => $header) {
			$normal = $this->normalise($header);

			if ($normal !== '' && isset($index[$normal]) && !isset($taken[$index[$normal]])) {
				$mapping[$i] = $index[$normal];

				$taken[$index[$normal]] = true;
			} else {
				$mapping[$i] = '';
			}
		}

		return $mapping;
	}

	/**
	 * Normalise
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	private function normalise(string $value): string {
		return preg_replace('/[^a-z0-9]/', '', oc_strtolower(html_entity_decode($value, ENT_QUOTES, 'UTF-8')));
	}

	/* -----------------------------------------------------------------
	 * CSV reading
	 * ----------------------------------------------------------------- */

	/**
	 * Read Head
	 *
	 * Read the header row plus up to $limit preview rows, and count the total
	 * number of data rows in the file.
	 *
	 * @param string $file
	 * @param string $delimiter
	 * @param int    $limit
	 *
	 * @return array<string, mixed>
	 */
	public function readHead(string $file, string $delimiter, int $limit = 5): array {
		$result = ['headers' => [], 'preview' => [], 'total' => 0];

		$handle = fopen($file, 'r');

		if (!$handle) {
			return $result;
		}

		$this->skipBom($handle);

		$headers = fgetcsv($handle, 0, $delimiter, '"', '\\');

		if (!is_array($headers)) {
			fclose($handle);

			return $result;
		}

		foreach ($headers as $header) {
			$result['headers'][] = trim((string)$header);
		}

		$columns = count($result['headers']);

		while (($row = fgetcsv($handle, 0, $delimiter, '"', '\\')) !== false) {
			if ($this->isBlank($row)) {
				continue;
			}

			$result['total']++;

			if (count($result['preview']) < $limit) {
				$cells = [];

				for ($i = 0; $i < $columns; $i++) {
					$cells[] = isset($row[$i]) ? (string)$row[$i] : '';
				}

				$result['preview'][] = $cells;
			}
		}

		fclose($handle);

		return $result;
	}

	/**
	 * Skip Bom
	 *
	 * Consume a UTF-8 byte order mark if present so the first header does not
	 * pick up invisible bytes.
	 *
	 * @param resource $handle
	 *
	 * @return void
	 */
	private function skipBom($handle): void {
		$bom = fread($handle, 3);

		if ($bom !== "\xEF\xBB\xBF") {
			rewind($handle);
		}
	}

	/**
	 * Is Blank
	 *
	 * @param array<int, mixed> $row
	 *
	 * @return bool
	 */
	private function isBlank(array $row): bool {
		if (count($row) === 1 && ($row[0] === null || trim((string)$row[0]) === '')) {
			return true;
		}

		foreach ($row as $value) {
			if (trim((string)$value) !== '') {
				return false;
			}
		}

		return true;
	}

	/**
	 * Read Chunk
	 *
	 * Read at most $limit data rows starting at the stored byte offset. Passing
	 * offset 0 makes the reader consume the BOM and the header row first, so a
	 * fresh job always starts on the first data row.
	 *
	 * @param string $file
	 * @param string $delimiter
	 * @param int    $offset
	 * @param int    $limit
	 *
	 * @return array<string, mixed>
	 */
	public function readChunk(string $file, string $delimiter, int $offset, int $limit): array {
		$result = ['rows' => [], 'offset' => $offset, 'eof' => true];

		$handle = fopen($file, 'r');

		if (!$handle) {
			return $result;
		}

		if ($offset > 0) {
			fseek($handle, $offset);
		} else {
			$this->skipBom($handle);

			fgetcsv($handle, 0, $delimiter, '"', '\\');
		}

		$read = 0;

		while ($read < $limit && ($row = fgetcsv($handle, 0, $delimiter, '"', '\\')) !== false) {
			if ($this->isBlank($row)) {
				continue;
			}

			$result['rows'][] = $row;

			$read++;
		}

		$result['offset'] = ftell($handle);
		$result['eof']    = feof($handle);

		fclose($handle);

		return $result;
	}

	/**
	 * Map Row
	 *
	 * Turn a positional CSV row into a field keyed array using the column map.
	 *
	 * @param array<int, mixed>  $row
	 * @param array<int, string> $mapping
	 *
	 * @return array<string, string>
	 */
	public function mapRow(array $row, array $mapping): array {
		$data = [];

		foreach ($mapping as $column => $field) {
			if ($field === '') {
				continue;
			}

			$data[$field] = isset($row[$column]) ? trim((string)$row[$column]) : '';
		}

		return $data;
	}

	/* -----------------------------------------------------------------
	 * Value casting
	 * ----------------------------------------------------------------- */

	/**
	 * To Bool
	 *
	 * @param string $value
	 *
	 * @return int
	 */
	public function toBool(string $value): int {
		$value = oc_strtolower(trim($value));

		return in_array($value, ['1', 'y', 'yes', 'true', 't', 'on', 'enabled', 'enable', 'active'], true) ? 1 : 0;
	}

	/**
	 * To Float
	 *
	 * Accepts both "1234.56" and the European "1.234,56" / "1234,56" forms.
	 *
	 * @param string $value
	 *
	 * @return float
	 */
	public function toFloat(string $value): float {
		$value = trim(str_replace([' ', "\xC2\xA0"], '', $value));

		if ($value === '') {
			return 0.0;
		}

		$comma = strrpos($value, ',');
		$dot   = strrpos($value, '.');

		if ($comma !== false && ($dot === false || $comma > $dot)) {
			// Comma is the decimal separator
			$value = str_replace('.', '', $value);
			$value = str_replace(',', '.', $value);
		} else {
			$value = str_replace(',', '', $value);
		}

		return (float)$value;
	}

	/**
	 * To List
	 *
	 * @param string $value
	 *
	 * @return array<int, string>
	 */
	public function toList(string $value): array {
		if (trim($value) === '') {
			return [];
		}

		$parts = [];

		foreach (explode('|', $value) as $part) {
			$part = trim($part);

			if ($part !== '') {
				$parts[] = $part;
			}
		}

		return $parts;
	}

	/**
	 * Encode
	 *
	 * OpenCart stores admin submitted text HTML entity encoded (the request
	 * library runs htmlspecialchars over every POST value) and decodes it again
	 * on the storefront. Imported values arrive raw from the file, so they have
	 * to be encoded the same way or the catalog would double decode them.
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	public function encode(string $value): string {
		return htmlspecialchars($value, ENT_COMPAT, 'UTF-8');
	}

	/**
	 * Decode
	 *
	 * Inverse of encode(), used when writing export files so humans see plain
	 * text rather than entities.
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	public function decode(string $value): string {
		return html_entity_decode($value, ENT_QUOTES, 'UTF-8');
	}

	/* -----------------------------------------------------------------
	 * Lookups
	 * ----------------------------------------------------------------- */

	/**
	 * Get Category Lookup
	 *
	 * Builds two indexes: full "parent > child" paths and bare names (the bare
	 * name index only keeps unambiguous entries).
	 *
	 * @param int $language_id
	 *
	 * @return array<string, int>
	 */
	private function getCategoryLookup(int $language_id): array {
		$cache = 'category_' . $language_id;

		if (isset($this->lookup[$cache])) {
			return $this->lookup[$cache];
		}

		$query = $this->db->query("SELECT `c`.`category_id`, `c`.`parent_id`, `cd`.`name` FROM `" . DB_PREFIX . "category` `c` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`c`.`category_id` = `cd`.`category_id` AND `cd`.`language_id` = '" . (int)$language_id . "')");

		$names   = [];
		$parents = [];

		foreach ($query->rows as $row) {
			$names[(int)$row['category_id']]   = (string)$row['name'];
			$parents[(int)$row['category_id']] = (int)$row['parent_id'];
		}

		$index  = [];
		$counts = [];

		foreach ($names as $category_id => $name) {
			$segments = [];
			$current  = $category_id;
			$guard    = 0;

			while (isset($names[$current]) && $guard < 20) {
				array_unshift($segments, $names[$current]);

				$current = $parents[$current] ?? 0;

				$guard++;
			}

			$path = $this->normalise(implode('>', $segments));

			if ($path !== '') {
				$index[$path] = $category_id;
			}

			$bare = $this->normalise($name);

			if ($bare !== '') {
				$counts[$bare] = ($counts[$bare] ?? 0) + 1;

				if ($counts[$bare] === 1) {
					$index['name:' . $bare] = $category_id;
				} else {
					unset($index['name:' . $bare]);
				}
			}
		}

		$this->lookup[$cache] = $index;

		return $index;
	}

	/**
	 * Resolve Category
	 *
	 * Accepts a numeric category id, a bare category name or a full
	 * "Parent > Child" path. Returns 0 when nothing matches.
	 *
	 * @param string $token
	 * @param int    $language_id
	 *
	 * @return int
	 */
	public function resolveCategory(string $token, int $language_id): int {
		$token = trim($token);

		if ($token === '') {
			return 0;
		}

		if (ctype_digit($token)) {
			$query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "category` WHERE `category_id` = '" . (int)$token . "'");

			return $query->num_rows ? (int)$token : 0;
		}

		$index = $this->getCategoryLookup($language_id);
		$key   = $this->normalise($token);

		if (isset($index[$key])) {
			return (int)$index[$key];
		}

		if (isset($index['name:' . $key])) {
			return (int)$index['name:' . $key];
		}

		return 0;
	}

	/**
	 * Resolve Manufacturer
	 *
	 * @param string $name
	 *
	 * @return int
	 */
	public function resolveManufacturer(string $name): int {
		$name = trim($name);

		if ($name === '') {
			return 0;
		}

		if (!isset($this->lookup['manufacturer'])) {
			$query = $this->db->query("SELECT `manufacturer_id`, `name` FROM `" . DB_PREFIX . "manufacturer`");

			$index = [];

			foreach ($query->rows as $row) {
				$index[$this->normalise((string)$row['name'])] = (int)$row['manufacturer_id'];
			}

			$this->lookup['manufacturer'] = $index;
		}

		return $this->lookup['manufacturer'][$this->normalise($name)] ?? 0;
	}

	/**
	 * Exists
	 *
	 * @param string $table
	 * @param string $column
	 * @param int    $value
	 *
	 * @return bool
	 */
	private function exists(string $table, string $column, int $value): bool {
		$query = $this->db->query("SELECT 1 FROM `" . DB_PREFIX . $this->db->escape($table) . "` WHERE `" . $this->db->escape($column) . "` = '" . (int)$value . "' LIMIT 1");

		return (bool)$query->num_rows;
	}

	/**
	 * Get Languages
	 *
	 * @return array<int, int>
	 */
	public function getLanguageIds(): array {
		if (!isset($this->lookup['language'])) {
			$query = $this->db->query("SELECT `language_id` FROM `" . DB_PREFIX . "language` WHERE `status` = '1'");

			$ids = [];

			foreach ($query->rows as $row) {
				$ids[] = (int)$row['language_id'];
			}

			$this->lookup['language'] = $ids ?: [(int)$this->config->get('config_language_id')];
		}

		return $this->lookup['language'];
	}

	/**
	 * Table Exists
	 *
	 * @param string $table
	 *
	 * @return bool
	 */
	public function tableExists(string $table): bool {
		$key = 'table_' . $table;

		if (!isset($this->lookup[$key])) {
			$query = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . $table) . "'");

			$this->lookup[$key] = [$query->num_rows ? 1 : 0];
		}

		return (bool)$this->lookup[$key][0];
	}

	/* -----------------------------------------------------------------
	 * Row lookup / validation
	 * ----------------------------------------------------------------- */

	/**
	 * Find Existing
	 *
	 * Locate the primary key of an existing record using the configured match
	 * field. Returns 0 when the row describes a new record.
	 *
	 * @param string                $entity
	 * @param array<string, string> $data
	 * @param string                $match
	 *
	 * @return int
	 */
	public function findExisting(string $entity, array $data, string $match): int {
		if (!isset($data[$match]) || trim($data[$match]) === '') {
			return 0;
		}

		$value = trim($data[$match]);

		switch ($entity) {
			case 'product':
				if ($match === 'product_id') {
					$query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$value . "'");
				} elseif ($match === 'sku') {
					$query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `sku` = '" . $this->db->escape($this->encode($value)) . "' ORDER BY `product_id` ASC LIMIT 1");
				} else {
					$query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "product` WHERE `model` = '" . $this->db->escape($this->encode($value)) . "' ORDER BY `product_id` ASC LIMIT 1");
				}

				return $query->num_rows ? (int)$query->row['product_id'] : 0;
			case 'category':
				if ($match === 'category_id') {
					$query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "category` WHERE `category_id` = '" . (int)$value . "'");
				} else {
					$query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "category_description` WHERE `name` = '" . $this->db->escape($this->encode($value)) . "' ORDER BY `category_id` ASC LIMIT 1");
				}

				return $query->num_rows ? (int)$query->row['category_id'] : 0;
			case 'customer':
				if ($match === 'customer_id') {
					$query = $this->db->query("SELECT `customer_id` FROM `" . DB_PREFIX . "customer` WHERE `customer_id` = '" . (int)$value . "'");
				} else {
					$query = $this->db->query("SELECT `customer_id` FROM `" . DB_PREFIX . "customer` WHERE LCASE(`email`) = '" . $this->db->escape(oc_strtolower($value)) . "' ORDER BY `customer_id` ASC LIMIT 1");
				}

				return $query->num_rows ? (int)$query->row['customer_id'] : 0;
		}

		return 0;
	}

	/**
	 * Validate Row
	 *
	 * Runs every check the writer relies on and returns a list of human
	 * readable problems. This is the whole of the dry run: nothing here touches
	 * the database beyond SELECTs.
	 *
	 * @param string                $entity
	 * @param array<string, string> $data
	 * @param int                   $record_id
	 * @param array<string, mixed>  $options
	 *
	 * @return array<int, string>
	 */
	public function validateRow(string $entity, array $data, int $record_id, array $options): array {
		$errors      = [];
		$fields      = $this->getFields($entity);
		$language_id = (int)$options['language_id'];

		// Generic per-field checks
		foreach ($fields as $key => $field) {
			if (!array_key_exists($key, $data)) {
				continue;
			}

			$value = $data[$key];
			$label = $field['label'];

			if (trim($value) === '') {
				continue;
			}

			switch ($field['type']) {
				case 'int':
					if (!preg_match('/^-?\d+$/', trim($value))) {
						$errors[] = sprintf('%s: "%s" is not a whole number', $label, $value);
					}
					break;
				case 'float':
					if (!preg_match('/^-?[\d.,\s]+$/', trim($value))) {
						$errors[] = sprintf('%s: "%s" is not a number', $label, $value);
					}
					break;
				case 'date':
					if (!$this->isDate($value, 'Y-m-d')) {
						$errors[] = sprintf('%s: "%s" is not a valid YYYY-MM-DD date', $label, $value);
					}
					break;
				case 'datetime':
					if (!$this->isDate($value, 'Y-m-d H:i:s') && !$this->isDate($value, 'Y-m-d')) {
						$errors[] = sprintf('%s: "%s" is not a valid date/time', $label, $value);
					}
					break;
				case 'email':
					if (!oc_validate_email($value)) {
						$errors[] = sprintf('%s: "%s" is not a valid e-mail address', $label, $value);
					}
					break;
				case 'json':
					json_decode($value, true);

					if (json_last_error() !== JSON_ERROR_NONE) {
						$errors[] = sprintf('%s: value is not valid JSON', $label);
					}
					break;
			}

			if (isset($field['max']) && oc_strlen($value) > (int)$field['max']) {
				$errors[] = sprintf('%s: longer than %d characters', $label, (int)$field['max']);
			}
		}

		// Required fields are only enforced when a new record is being created
		if (!$record_id) {
			foreach ($fields as $key => $field) {
				if (!empty($field['required']) && (!isset($data[$key]) || trim($data[$key]) === '')) {
					$errors[] = sprintf('%s is required for new records', $field['label']);
				}
			}
		}

		switch ($entity) {
			case 'product':
				if (isset($data['categories'])) {
					foreach ($this->toList($data['categories']) as $token) {
						if (!$this->resolveCategory($token, $language_id)) {
							$errors[] = sprintf('Categories: "%s" does not match any category', $token);
						}
					}
				}

				if (isset($data['manufacturer']) && trim($data['manufacturer']) !== '' && !$this->resolveManufacturer($data['manufacturer'])) {
					$errors[] = sprintf('Manufacturer: "%s" does not exist', $data['manufacturer']);
				}

				if (isset($data['manufacturer_id']) && (int)$data['manufacturer_id'] > 0 && !$this->exists('manufacturer', 'manufacturer_id', (int)$data['manufacturer_id'])) {
					$errors[] = sprintf('Manufacturer ID %d does not exist', (int)$data['manufacturer_id']);
				}

				if (isset($data['tax_class_id']) && (int)$data['tax_class_id'] > 0 && !$this->exists('tax_class', 'tax_class_id', (int)$data['tax_class_id'])) {
					$errors[] = sprintf('Tax Class ID %d does not exist', (int)$data['tax_class_id']);
				}

				if (isset($data['related'])) {
					foreach ($this->toList($data['related']) as $token) {
						if (!ctype_digit($token) || !$this->exists('product', 'product_id', (int)$token)) {
							$errors[] = sprintf('Related: product ID "%s" does not exist', $token);
						}
					}
				}

				$errors = array_merge($errors, $this->validateSeo($data, 'product_id', $record_id, $options));
				break;
			case 'category':
				if (isset($data['parent_id']) && (int)$data['parent_id'] > 0) {
					if (!$this->exists('category', 'category_id', (int)$data['parent_id'])) {
						$errors[] = sprintf('Parent Category ID %d does not exist', (int)$data['parent_id']);
					} elseif ($record_id && (int)$data['parent_id'] === $record_id) {
						$errors[] = 'Parent Category ID cannot be the category itself';
					}
				}

				$errors = array_merge($errors, $this->validateSeo($data, 'path', $record_id, $options));
				break;
			case 'customer':
				if (isset($data['email']) && trim($data['email']) !== '') {
					$query = $this->db->query("SELECT `customer_id` FROM `" . DB_PREFIX . "customer` WHERE LCASE(`email`) = '" . $this->db->escape(oc_strtolower(trim($data['email']))) . "'");

					if ($query->num_rows && (int)$query->row['customer_id'] !== $record_id) {
						$errors[] = sprintf('E-Mail: "%s" is already registered to another customer', trim($data['email']));
					}
				}

				if (!$record_id) {
					$password = isset($data['password']) ? trim($data['password']) : '';

					if ($password === '') {
						$errors[] = 'Password is required for new customers';
					} elseif (!oc_validate_length($password, 4, 40)) {
						$errors[] = 'Password must be between 4 and 40 characters';
					}
				} elseif (isset($data['password']) && trim($data['password']) !== '' && !oc_validate_length(trim($data['password']), 4, 40)) {
					$errors[] = 'Password must be between 4 and 40 characters';
				}

				if (isset($data['customer_group_id']) && (int)$data['customer_group_id'] > 0 && !$this->exists('customer_group', 'customer_group_id', (int)$data['customer_group_id'])) {
					$errors[] = sprintf('Customer Group ID %d does not exist', (int)$data['customer_group_id']);
				}
				break;
		}

		return $errors;
	}

	/**
	 * Validate Seo
	 *
	 * @param array<string, string> $data
	 * @param string                $key
	 * @param int                   $record_id
	 * @param array<string, mixed>  $options
	 *
	 * @return array<int, string>
	 */
	private function validateSeo(array $data, string $key, int $record_id, array $options): array {
		if (!isset($data['seo_keyword']) || trim($data['seo_keyword']) === '') {
			return [];
		}

		$keyword = trim($data['seo_keyword']);
		$errors  = [];

		if (!oc_validate_path($keyword)) {
			$errors[] = sprintf('SEO Keyword: "%s" may only contain letters, numbers, dashes, underscores and slashes', $keyword);

			return $errors;
		}

		$query = $this->db->query("SELECT `key`, `value` FROM `" . DB_PREFIX . "seo_url` WHERE `keyword` = '" . $this->db->escape($keyword) . "' AND `store_id` = '" . (int)$options['store_id'] . "' AND `language_id` = '" . (int)$options['language_id'] . "'");

		foreach ($query->rows as $row) {
			$owned = ($row['key'] === $key && $record_id && $this->ownsSeoValue($key, (string)$row['value'], $record_id));

			if (!$owned) {
				$errors[] = sprintf('SEO Keyword: "%s" is already used by %s=%s', $keyword, $row['key'], $row['value']);
			}
		}

		return $errors;
	}

	/**
	 * Owns Seo Value
	 *
	 * @param string $key
	 * @param string $value
	 * @param int    $record_id
	 *
	 * @return bool
	 */
	private function ownsSeoValue(string $key, string $value, int $record_id): bool {
		if ($key === 'path') {
			$segments = explode('_', $value);

			return (int)end($segments) === $record_id;
		}

		return (int)$value === $record_id;
	}

	/**
	 * Is Date
	 *
	 * @param string $value
	 * @param string $format
	 *
	 * @return bool
	 */
	private function isDate(string $value, string $format): bool {
		$date = \DateTime::createFromFormat($format, trim($value));

		return $date !== false && $date->format($format) === trim($value);
	}

	/* -----------------------------------------------------------------
	 * Row writing
	 * ----------------------------------------------------------------- */

	/**
	 * Write Row
	 *
	 * @param string                $entity
	 * @param array<string, string> $data
	 * @param int                   $record_id
	 * @param array<string, mixed>  $options
	 *
	 * @return string created|updated
	 */
	public function writeRow(string $entity, array $data, int $record_id, array $options): string {
		switch ($entity) {
			case 'product':
				return $this->writeProduct($data, $record_id, $options);
			case 'category':
				return $this->writeCategory($data, $record_id, $options);
			case 'customer':
				return $this->writeCustomer($data, $record_id, $options);
		}

		return 'skipped';
	}

	/**
	 * Write Product
	 *
	 * Touches product, product_description, product_to_store,
	 * product_to_category, product_image, product_related, product_code and
	 * seo_url — the full multi table reality of an OpenCart product.
	 *
	 * @param array<string, string> $data
	 * @param int                   $product_id
	 * @param array<string, mixed>  $options
	 *
	 * @return string
	 */
	private function writeProduct(array $data, int $product_id, array $options): string {
		$language_id = (int)$options['language_id'];
		$store_id    = (int)$options['store_id'];
		$new         = !$product_id;

		$columns = [];

		$strings = ['model' => 64, 'sku' => 64, 'upc' => 12, 'ean' => 14, 'jan' => 13, 'isbn' => 17, 'mpn' => 64, 'location' => 128, 'image' => 255];

		foreach ($strings as $key => $max) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . $this->db->escape(oc_substr($this->encode($data[$key]), 0, $max)) . "'";
			}
		}

		$integers = ['quantity', 'minimum', 'stock_status_id', 'points', 'tax_class_id', 'weight_class_id', 'length_class_id', 'sort_order'];

		foreach ($integers as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . (int)$data[$key] . "'";
			}
		}

		$decimals = ['price', 'weight', 'length', 'width', 'height'];

		foreach ($decimals as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . $this->toFloat($data[$key]) . "'";
			}
		}

		foreach (['subtract', 'shipping', 'status'] as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . $this->toBool($data[$key]) . "'";
			}
		}

		if (isset($data['date_available']) && trim($data['date_available']) !== '') {
			$columns[] = "`date_available` = '" . $this->db->escape(trim($data['date_available'])) . "'";
		}

		$manufacturer_id = null;

		if (isset($data['manufacturer_id'])) {
			$manufacturer_id = (int)$data['manufacturer_id'];
		} elseif (isset($data['manufacturer']) && trim($data['manufacturer']) !== '') {
			$manufacturer_id = $this->resolveManufacturer($data['manufacturer']);
		}

		if ($manufacturer_id !== null) {
			$columns[] = "`manufacturer_id` = '" . (int)$manufacturer_id . "'";
		}

		if ($new) {
			// Sensible defaults for anything the sheet did not supply
			$defaults = [
				'model'           => "`model` = ''",
				'quantity'        => "`quantity` = '0'",
				'minimum'         => "`minimum` = '1'",
				'subtract'        => "`subtract` = '1'",
				'shipping'        => "`shipping` = '1'",
				'status'          => "`status` = '1'",
				'price'           => "`price` = '0.0000'",
				'date_available'  => "`date_available` = NOW()",
				'stock_status_id' => "`stock_status_id` = '" . (int)$this->config->get('config_stock_status_id') . "'"
			];

			foreach ($defaults as $key => $sql) {
				if (!isset($data[$key]) || ($key === 'date_available' && trim($data[$key]) === '')) {
					$columns[] = $sql;
				}
			}

			$columns[] = "`date_added` = NOW()";
		}

		$columns[] = "`date_modified` = NOW()";

		if ($new) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET " . implode(', ', $columns));

			$product_id = $this->db->getLastId();
		} else {
			$this->db->query("UPDATE `" . DB_PREFIX . "product` SET " . implode(', ', $columns) . " WHERE `product_id` = '" . (int)$product_id . "'");
		}

		// Descriptions. On create every installed language gets a row so the
		// product is visible in every storefront language; on update only the
		// selected language is touched.
		$description = [];

		foreach (['name', 'description', 'tag', 'meta_title', 'meta_description', 'meta_keyword'] as $key) {
			if (isset($data[$key])) {
				$description[$key] = $this->encode($data[$key]);
			}
		}

		if ($description) {
			if (!isset($description['meta_title']) || $description['meta_title'] === '') {
				$description['meta_title'] = $description['name'] ?? '';
			}

			$targets = $new ? $this->getLanguageIds() : [$language_id];

			foreach ($targets as $target_id) {
				$this->writeDescription('product', $product_id, $target_id, $description, $new);
			}
		}

		// Identifier codes. OpenCart 4.1 mirrors sku/upc/... into product_code;
		// the legacy columns above stay in sync for 4.0 installs.
		if ($this->tableExists('product_code')) {
			$codes = ['SKU' => 'sku', 'UPC' => 'upc', 'EAN' => 'ean', 'JAN' => 'jan', 'ISBN' => 'isbn', 'MPN' => 'mpn'];

			foreach ($codes as $code => $key) {
				if (!isset($data[$key])) {
					continue;
				}

				$this->db->query("DELETE FROM `" . DB_PREFIX . "product_code` WHERE `product_id` = '" . (int)$product_id . "' AND `code` = '" . $this->db->escape($code) . "'");

				if (trim($data[$key]) !== '') {
					$this->db->query("INSERT INTO `" . DB_PREFIX . "product_code` SET `product_id` = '" . (int)$product_id . "', `code` = '" . $this->db->escape($code) . "', `value` = '" . $this->db->escape($this->encode(trim($data[$key]))) . "'");
				}
			}
		}

		// Stores
		if (isset($data['stores'])) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "product_to_store` WHERE `product_id` = '" . (int)$product_id . "'");

			$stores = $this->toList($data['stores']);

			if (!$stores) {
				$stores = ['0'];
			}

			foreach (array_unique($stores) as $value) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_store` SET `product_id` = '" . (int)$product_id . "', `store_id` = '" . (int)$value . "'");
			}
		} elseif ($new) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_store` SET `product_id` = '" . (int)$product_id . "', `store_id` = '" . (int)$store_id . "'");
		}

		// Categories
		if (isset($data['categories'])) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "product_to_category` WHERE `product_id` = '" . (int)$product_id . "'");

			$seen = [];

			foreach ($this->toList($data['categories']) as $token) {
				$category_id = $this->resolveCategory($token, $language_id);

				if ($category_id && !isset($seen[$category_id])) {
					$seen[$category_id] = true;

					$this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_category` SET `product_id` = '" . (int)$product_id . "', `category_id` = '" . (int)$category_id . "'");
				}
			}
		}

		// Additional images
		if (isset($data['additional_images'])) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "product_image` WHERE `product_id` = '" . (int)$product_id . "'");

			$sort_order = 0;

			foreach ($this->toList($data['additional_images']) as $image) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_image` SET `product_id` = '" . (int)$product_id . "', `image` = '" . $this->db->escape(oc_substr($this->encode($image), 0, 255)) . "', `sort_order` = '" . (int)$sort_order++ . "'");
			}
		}

		// Related products (the relation is stored in both directions)
		if (isset($data['related'])) {
			$query = $this->db->query("SELECT `related_id` FROM `" . DB_PREFIX . "product_related` WHERE `product_id` = '" . (int)$product_id . "'");

			foreach ($query->rows as $row) {
				$this->db->query("DELETE FROM `" . DB_PREFIX . "product_related` WHERE `product_id` = '" . (int)$row['related_id'] . "' AND `related_id` = '" . (int)$product_id . "'");
			}

			$this->db->query("DELETE FROM `" . DB_PREFIX . "product_related` WHERE `product_id` = '" . (int)$product_id . "'");

			foreach (array_unique($this->toList($data['related'])) as $token) {
				$related_id = (int)$token;

				if ($related_id && $related_id !== $product_id) {
					$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_related` SET `product_id` = '" . (int)$product_id . "', `related_id` = '" . (int)$related_id . "'");
					$this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "product_related` SET `product_id` = '" . (int)$related_id . "', `related_id` = '" . (int)$product_id . "'");
				}
			}
		}

		// SEO keyword
		if (isset($data['seo_keyword'])) {
			$this->writeSeoUrl('product_id', (string)$product_id, trim($data['seo_keyword']), $options);
		}

		$this->cache->delete('product');

		return $new ? 'created' : 'updated';
	}

	/**
	 * Write Category
	 *
	 * @param array<string, string> $data
	 * @param int                   $category_id
	 * @param array<string, mixed>  $options
	 *
	 * @return string
	 */
	private function writeCategory(array $data, int $category_id, array $options): string {
		$language_id = (int)$options['language_id'];
		$store_id    = (int)$options['store_id'];
		$new         = !$category_id;

		$columns = [];

		if (isset($data['image'])) {
			$columns[] = "`image` = '" . $this->db->escape(oc_substr($this->encode($data['image']), 0, 255)) . "'";
		}

		foreach (['parent_id', 'sort_order'] as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . (int)$data[$key] . "'";
			}
		}

		if (isset($data['status'])) {
			$columns[] = "`status` = '" . $this->toBool($data['status']) . "'";
		}

		if ($new) {
			if (!isset($data['status'])) {
				$columns[] = "`status` = '1'";
			}

			if (!isset($data['parent_id'])) {
				$columns[] = "`parent_id` = '0'";
			}

			$this->db->query("INSERT INTO `" . DB_PREFIX . "category` SET " . implode(', ', $columns));

			$category_id = $this->db->getLastId();
		} elseif ($columns) {
			$this->db->query("UPDATE `" . DB_PREFIX . "category` SET " . implode(', ', $columns) . " WHERE `category_id` = '" . (int)$category_id . "'");
		}

		// Description
		$description = [];

		foreach (['name', 'description', 'meta_title', 'meta_description', 'meta_keyword'] as $key) {
			if (isset($data[$key])) {
				$description[$key] = $this->encode($data[$key]);
			}
		}

		if ($description) {
			if (!isset($description['meta_title']) || $description['meta_title'] === '') {
				$description['meta_title'] = $description['name'] ?? '';
			}

			$targets = $new ? $this->getLanguageIds() : [$language_id];

			foreach ($targets as $target_id) {
				$this->writeDescription('category', $category_id, $target_id, $description, $new);
			}
		}

		// Stores
		if (isset($data['stores'])) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "category_to_store` WHERE `category_id` = '" . (int)$category_id . "'");

			$stores = $this->toList($data['stores']);

			if (!$stores) {
				$stores = ['0'];
			}

			foreach (array_unique($stores) as $value) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_to_store` SET `category_id` = '" . (int)$category_id . "', `store_id` = '" . (int)$value . "'");
			}
		} elseif ($new) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "category_to_store` SET `category_id` = '" . (int)$category_id . "', `store_id` = '" . (int)$store_id . "'");
		}

		// category_path always has to reflect the current parent chain
		if ($new || isset($data['parent_id'])) {
			$this->rebuildPath($category_id);
		}

		// The name based lookup is now stale for the rest of this request.
		foreach (array_keys($this->lookup) as $key) {
			if (str_starts_with($key, 'category_')) {
				unset($this->lookup[$key]);
			}
		}

		// SEO keyword. Category keywords are keyed on the underscore joined path.
		if (isset($data['seo_keyword'])) {
			$this->writeSeoUrl('path', $this->getPathValue($category_id), trim($data['seo_keyword']), $options);
		}

		$this->cache->delete('category');

		return $new ? 'created' : 'updated';
	}

	/**
	 * Write Customer
	 *
	 * @param array<string, string> $data
	 * @param int                   $customer_id
	 * @param array<string, mixed>  $options
	 *
	 * @return string
	 */
	private function writeCustomer(array $data, int $customer_id, array $options): string {
		$new = !$customer_id;

		$columns = [];

		foreach (['firstname' => 32, 'lastname' => 32, 'telephone' => 32] as $key => $max) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . $this->db->escape(oc_substr($this->encode($data[$key]), 0, $max)) . "'";
			}
		}

		if (isset($data['email'])) {
			$columns[] = "`email` = '" . $this->db->escape(oc_strtolower(trim($data['email']))) . "'";
		}

		foreach (['customer_group_id', 'store_id', 'language_id'] as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . (int)$data[$key] . "'";
			}
		}

		foreach (['newsletter', 'status', 'safe', 'commenter'] as $key) {
			if (isset($data[$key])) {
				$columns[] = "`" . $key . "` = '" . $this->toBool($data[$key]) . "'";
			}
		}

		if (isset($data['custom_field'])) {
			$custom_field = json_decode(trim($data['custom_field']), true);

			$columns[] = "`custom_field` = '" . $this->db->escape(json_encode(is_array($custom_field) ? $custom_field : [])) . "'";
		}

		if (isset($data['password']) && trim($data['password']) !== '') {
			$columns[] = "`password` = '" . $this->db->escape(password_hash(html_entity_decode(trim($data['password']), ENT_QUOTES, 'UTF-8'), PASSWORD_DEFAULT)) . "'";
		}

		if ($new) {
			foreach ([
				'customer_group_id' => "`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "'",
				'store_id'          => "`store_id` = '" . (int)$options['store_id'] . "'",
				'language_id'       => "`language_id` = '" . (int)$options['language_id'] . "'",
				'status'            => "`status` = '1'",
				'custom_field'      => "`custom_field` = '[]'"
			] as $key => $sql) {
				if (!isset($data[$key])) {
					$columns[] = $sql;
				}
			}

			if (isset($data['date_added']) && trim($data['date_added']) !== '') {
				$columns[] = "`date_added` = '" . $this->db->escape($this->normaliseDateTime($data['date_added'])) . "'";
			} else {
				$columns[] = "`date_added` = NOW()";
			}

			$columns[] = "`ip` = ''";
			$columns[] = "`token` = ''";
			$columns[] = "`code` = ''";

			$this->db->query("INSERT INTO `" . DB_PREFIX . "customer` SET " . implode(', ', $columns));

			$customer_id = $this->db->getLastId();
		} elseif ($columns) {
			$this->db->query("UPDATE `" . DB_PREFIX . "customer` SET " . implode(', ', $columns) . " WHERE `customer_id` = '" . (int)$customer_id . "'");
		}

		return $new ? 'created' : 'updated';
	}

	/**
	 * Write Description
	 *
	 * Insert or merge a description row without wiping columns the sheet did
	 * not supply.
	 *
	 * @param string                $entity  product|category
	 * @param int                   $id
	 * @param int                   $language_id
	 * @param array<string, string> $values
	 * @param bool                  $new
	 *
	 * @return void
	 */
	private function writeDescription(string $entity, int $id, int $language_id, array $values, bool $new): void {
		$table  = $entity === 'product' ? 'product_description' : 'category_description';
		$column = $entity === 'product' ? 'product_id' : 'category_id';

		$defaults = $entity === 'product'
			? ['name' => '', 'description' => '', 'tag' => '', 'meta_title' => '', 'meta_description' => '', 'meta_keyword' => '']
			: ['name' => '', 'description' => '', 'meta_title' => '', 'meta_description' => '', 'meta_keyword' => ''];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . $table . "` WHERE `" . $column . "` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "'");

		$existing = $query->num_rows ? $query->row : [];

		$row = [];

		foreach ($defaults as $key => $default) {
			if (array_key_exists($key, $values)) {
				$row[$key] = $values[$key];
			} elseif (isset($existing[$key])) {
				$row[$key] = (string)$existing[$key];
			} else {
				$row[$key] = $default;
			}
		}

		$sets = [];

		foreach ($row as $key => $value) {
			$sets[] = "`" . $key . "` = '" . $this->db->escape($value) . "'";
		}

		if ($existing) {
			$this->db->query("UPDATE `" . DB_PREFIX . $table . "` SET " . implode(', ', $sets) . " WHERE `" . $column . "` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "'");
		} else {
			$this->db->query("INSERT INTO `" . DB_PREFIX . $table . "` SET `" . $column . "` = '" . (int)$id . "', `language_id` = '" . (int)$language_id . "', " . implode(', ', $sets));
		}
	}

	/**
	 * Rebuild Path
	 *
	 * Recreate category_path for a category and everything below it.
	 *
	 * @param int $category_id
	 *
	 * @return void
	 */
	public function rebuildPath(int $category_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE `category_id` = '" . (int)$category_id . "'");

		$chain   = [];
		$current = $category_id;
		$guard   = 0;

		while ($current && $guard < 20) {
			array_unshift($chain, $current);

			$query = $this->db->query("SELECT `parent_id` FROM `" . DB_PREFIX . "category` WHERE `category_id` = '" . (int)$current . "'");

			$current = $query->num_rows ? (int)$query->row['parent_id'] : 0;

			$guard++;
		}

		foreach (array_values($chain) as $level => $path_id) {
			$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$path_id . "', `level` = '" . (int)$level . "'");
		}

		$query = $this->db->query("SELECT `category_id` FROM `" . DB_PREFIX . "category` WHERE `parent_id` = '" . (int)$category_id . "'");

		foreach ($query->rows as $row) {
			$this->rebuildPath((int)$row['category_id']);
		}
	}

	/**
	 * Get Path Value
	 *
	 * The seo_url value OpenCart uses for a category, e.g. "20_26".
	 *
	 * @param int $category_id
	 *
	 * @return string
	 */
	private function getPathValue(int $category_id): string {
		$query = $this->db->query("SELECT `path_id` FROM `" . DB_PREFIX . "category_path` WHERE `category_id` = '" . (int)$category_id . "' ORDER BY `level` ASC");

		$path = [];

		foreach ($query->rows as $row) {
			$path[] = (int)$row['path_id'];
		}

		return $path ? implode('_', $path) : (string)$category_id;
	}

	/**
	 * Write Seo Url
	 *
	 * @param string               $key
	 * @param string               $value
	 * @param string               $keyword
	 * @param array<string, mixed> $options
	 *
	 * @return void
	 */
	private function writeSeoUrl(string $key, string $value, string $keyword, array $options): void {
		$store_id    = (int)$options['store_id'];
		$language_id = (int)$options['language_id'];

		$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE `key` = '" . $this->db->escape($key) . "' AND `value` = '" . $this->db->escape($value) . "' AND `store_id` = '" . (int)$store_id . "' AND `language_id` = '" . (int)$language_id . "'");

		if ($keyword !== '') {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `store_id` = '" . (int)$store_id . "', `language_id` = '" . (int)$language_id . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($value) . "', `keyword` = '" . $this->db->escape($keyword) . "', `sort_order` = '0'");
		}
	}

	/**
	 * Normalise Date Time
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	private function normaliseDateTime(string $value): string {
		$value = trim($value);

		$time = strtotime($value);

		return $time ? date('Y-m-d H:i:s', $time) : date('Y-m-d H:i:s');
	}

	/* -----------------------------------------------------------------
	 * Export
	 * ----------------------------------------------------------------- */

	/**
	 * Get Export Total
	 *
	 * @param string $entity
	 *
	 * @return int
	 */
	public function getExportTotal(string $entity): int {
		switch ($entity) {
			case 'product':
				$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "product`");
				break;
			case 'category':
				$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "category`");
				break;
			case 'customer':
				$query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "customer`");
				break;
			default:
				return 0;
		}

		return (int)$query->row['total'];
	}

	/**
	 * Get Export Rows
	 *
	 * @param string             $entity
	 * @param array<int, string> $fields
	 * @param int                $start
	 * @param int                $limit
	 * @param int                $language_id
	 *
	 * @return array<int, array<int, string>>
	 */
	public function getExportRows(string $entity, array $fields, int $start, int $limit, int $language_id): array {
		switch ($entity) {
			case 'product':
				$records = $this->getExportProducts($start, $limit, $language_id);
				break;
			case 'category':
				$records = $this->getExportCategories($start, $limit, $language_id);
				break;
			case 'customer':
				$records = $this->getExportCustomers($start, $limit);
				break;
			default:
				return [];
		}

		$rows = [];

		foreach ($records as $record) {
			$row = [];

			foreach ($fields as $field) {
				$row[] = $this->decode((string)($record[$field] ?? ''));
			}

			$rows[] = $row;
		}

		return $rows;
	}

	/**
	 * Get Export Products
	 *
	 * @param int $start
	 * @param int $limit
	 * @param int $language_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function getExportProducts(int $start, int $limit, int $language_id): array {
		$query = $this->db->query("SELECT `p`.*, `pd`.`name`, `pd`.`description`, `pd`.`tag`, `pd`.`meta_title`, `pd`.`meta_description`, `pd`.`meta_keyword`, `m`.`name` AS `manufacturer` FROM `" . DB_PREFIX . "product` `p` LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id` AND `pd`.`language_id` = '" . (int)$language_id . "') LEFT JOIN `" . DB_PREFIX . "manufacturer` `m` ON (`p`.`manufacturer_id` = `m`.`manufacturer_id`) ORDER BY `p`.`product_id` ASC LIMIT " . (int)$start . "," . (int)$limit);

		$records = [];

		foreach ($query->rows as $row) {
			$product_id = (int)$row['product_id'];

			$row['categories']        = implode('|', $this->getCategoryNames($product_id, $language_id));
			$row['stores']            = implode('|', $this->getColumn("SELECT `store_id` FROM `" . DB_PREFIX . "product_to_store` WHERE `product_id` = '" . $product_id . "' ORDER BY `store_id` ASC", 'store_id'));
			$row['related']           = implode('|', $this->getColumn("SELECT `related_id` FROM `" . DB_PREFIX . "product_related` WHERE `product_id` = '" . $product_id . "' ORDER BY `related_id` ASC", 'related_id'));
			$row['additional_images'] = implode('|', $this->getColumn("SELECT `image` FROM `" . DB_PREFIX . "product_image` WHERE `product_id` = '" . $product_id . "' ORDER BY `sort_order` ASC", 'image'));
			$row['seo_keyword']       = $this->getKeyword('product_id', (string)$product_id, $language_id);

			// Prefer the product_code table where OpenCart 4.1 keeps identifiers
			if ($this->tableExists('product_code')) {
				$codes = $this->db->query("SELECT `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `product_id` = '" . $product_id . "'");

				foreach ($codes->rows as $code) {
					$key = oc_strtolower((string)$code['code']);

					if (isset($row[$key]) && trim((string)$code['value']) !== '') {
						$row[$key] = $code['value'];
					}
				}
			}

			$records[] = $row;
		}

		return $records;
	}

	/**
	 * Get Export Categories
	 *
	 * @param int $start
	 * @param int $limit
	 * @param int $language_id
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function getExportCategories(int $start, int $limit, int $language_id): array {
		$query = $this->db->query("SELECT `c`.*, `cd`.`name`, `cd`.`description`, `cd`.`meta_title`, `cd`.`meta_description`, `cd`.`meta_keyword` FROM `" . DB_PREFIX . "category` `c` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`c`.`category_id` = `cd`.`category_id` AND `cd`.`language_id` = '" . (int)$language_id . "') ORDER BY `c`.`category_id` ASC LIMIT " . (int)$start . "," . (int)$limit);

		$records = [];

		foreach ($query->rows as $row) {
			$category_id = (int)$row['category_id'];

			$row['stores']      = implode('|', $this->getColumn("SELECT `store_id` FROM `" . DB_PREFIX . "category_to_store` WHERE `category_id` = '" . $category_id . "' ORDER BY `store_id` ASC", 'store_id'));
			$row['seo_keyword'] = $this->getKeyword('path', $this->getPathValue($category_id), $language_id);

			$records[] = $row;
		}

		return $records;
	}

	/**
	 * Get Export Customers
	 *
	 * Password hashes are deliberately never selected.
	 *
	 * @param int $start
	 * @param int $limit
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function getExportCustomers(int $start, int $limit): array {
		$query = $this->db->query("SELECT `customer_id`, `customer_group_id`, `store_id`, `language_id`, `firstname`, `lastname`, `email`, `telephone`, `custom_field`, `newsletter`, `status`, `safe`, `commenter`, `date_added` FROM `" . DB_PREFIX . "customer` ORDER BY `customer_id` ASC LIMIT " . (int)$start . "," . (int)$limit);

		return $query->rows;
	}

	/**
	 * Get Category Names
	 *
	 * @param int $product_id
	 * @param int $language_id
	 *
	 * @return array<int, string>
	 */
	private function getCategoryNames(int $product_id, int $language_id): array {
		$query = $this->db->query("SELECT `cd`.`name` FROM `" . DB_PREFIX . "product_to_category` `p2c` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`p2c`.`category_id` = `cd`.`category_id` AND `cd`.`language_id` = '" . (int)$language_id . "') WHERE `p2c`.`product_id` = '" . (int)$product_id . "' ORDER BY `p2c`.`category_id` ASC");

		$names = [];

		foreach ($query->rows as $row) {
			if (trim((string)$row['name']) !== '') {
				$names[] = (string)$row['name'];
			}
		}

		return $names;
	}

	/**
	 * Get Keyword
	 *
	 * @param string $key
	 * @param string $value
	 * @param int    $language_id
	 *
	 * @return string
	 */
	private function getKeyword(string $key, string $value, int $language_id): string {
		$query = $this->db->query("SELECT `keyword` FROM `" . DB_PREFIX . "seo_url` WHERE `key` = '" . $this->db->escape($key) . "' AND `value` = '" . $this->db->escape($value) . "' AND `language_id` = '" . (int)$language_id . "' ORDER BY `store_id` ASC LIMIT 1");

		return $query->num_rows ? (string)$query->row['keyword'] : '';
	}

	/**
	 * Get Column
	 *
	 * @param string $sql
	 * @param string $column
	 *
	 * @return array<int, string>
	 */
	private function getColumn(string $sql, string $column): array {
		$query = $this->db->query($sql);

		$values = [];

		foreach ($query->rows as $row) {
			$values[] = (string)$row[$column];
		}

		return $values;
	}

	/* -----------------------------------------------------------------
	 * Job records
	 * ----------------------------------------------------------------- */

	/**
	 * Add Job
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function addJob(array $data): int {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_import_export_job` SET `user_id` = '" . (int)$data['user_id'] . "', `entity` = '" . $this->db->escape((string)$data['entity']) . "', `filename` = '" . $this->db->escape((string)$data['filename']) . "', `original_name` = '" . $this->db->escape((string)$data['original_name']) . "', `mapping` = '" . $this->db->escape((string)json_encode($data['mapping'])) . "', `options` = '" . $this->db->escape((string)json_encode($data['options'])) . "', `total_rows` = '" . (int)$data['total_rows'] . "', `errors` = '[]', `status` = 'pending', `date_added` = NOW()");

		return $this->db->getLastId();
	}

	/**
	 * Get Job
	 *
	 * @param int $job_id
	 * @param int $user_id
	 *
	 * @return array<string, mixed>
	 */
	public function getJob(int $job_id, int $user_id = 0): array {
		$sql = "SELECT * FROM `" . DB_PREFIX . "nk_import_export_job` WHERE `job_id` = '" . (int)$job_id . "'";

		if ($user_id) {
			$sql .= " AND `user_id` = '" . (int)$user_id . "'";
		}

		$query = $this->db->query($sql);

		return $query->num_rows ? $query->row : [];
	}

	/**
	 * Edit Job
	 *
	 * @param int                  $job_id
	 * @param array<string, mixed> $data
	 *
	 * @return void
	 */
	public function editJob(int $job_id, array $data): void {
		$sets = [];

		foreach (['total_rows', 'row_index', 'byte_offset', 'created', 'updated', 'skipped', 'failed'] as $key) {
			if (isset($data[$key])) {
				$sets[] = "`" . $key . "` = '" . (int)$data[$key] . "'";
			}
		}

		if (isset($data['status'])) {
			$sets[] = "`status` = '" . $this->db->escape((string)$data['status']) . "'";
		}

		if (isset($data['errors'])) {
			$errors = array_slice((array)$data['errors'], 0, self::ERROR_LIMIT);

			$sets[] = "`errors` = '" . $this->db->escape((string)json_encode($errors)) . "'";
		}

		if (!$sets) {
			return;
		}

		$this->db->query("UPDATE `" . DB_PREFIX . "nk_import_export_job` SET " . implode(', ', $sets) . " WHERE `job_id` = '" . (int)$job_id . "'");
	}

	/**
	 * Delete Job
	 *
	 * @param int $job_id
	 *
	 * @return void
	 */
	public function deleteJob(int $job_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_import_export_job` WHERE `job_id` = '" . (int)$job_id . "'");
	}
}
