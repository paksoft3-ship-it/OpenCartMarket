<?php
$_['text_buy_now'] = 'Buy Now';
$_['text_working'] = 'Working...';
$_['text_error']   = 'This product could not be added to the cart.';
