(function () {
  'use strict';

  var FORM_ID = 'form-product';

  function form() {
    return document.getElementById(FORM_ID);
  }

  /**
   * The stock OC 4.1 product page posts `$('#form-product').serialize()`.
   * Using jQuery when the theme loaded it keeps the payload byte-identical
   * (same successful-control rules, same option[] bracket names); the
   * URLSearchParams path is only a fallback for jQuery-less themes.
   */
  function serialize(el) {
    if (window.jQuery) {
      return window.jQuery(el).serialize();
    }

    return new URLSearchParams(new FormData(el)).toString();
  }

  function errorBox(btn, create) {
    var host = btn.closest('.input-group') || btn;
    var box = document.getElementById('nk-buy-now-error');

    if (!box && create) {
      box = document.createElement('div');
      box.id = 'nk-buy-now-error';
      box.className = 'nk-buy-now-error';
      box.setAttribute('role', 'alert');

      if (host.parentNode) {
        host.parentNode.insertBefore(box, host.nextSibling);
      }
    }

    return box;
  }

  function clearErrors(btn) {
    var el = form();

    if (el) {
      Array.prototype.forEach.call(el.querySelectorAll('.is-invalid'), function (node) {
        node.classList.remove('is-invalid');
      });
      // The theme marks #error-quantity with .form-text rather than
      // .invalid-feedback, so clear every error slot the core can write to.
      Array.prototype.forEach.call(el.querySelectorAll('[id^="error-"]'), function (node) {
        node.classList.remove('d-block');
        node.innerHTML = '';
      });
    }

    var box = errorBox(btn, false);

    if (box && box.parentNode) {
      box.parentNode.removeChild(box);
    }
  }

  /**
   * Mirror the core's field marking (so the shopper sees WHICH option is
   * missing) and surface the same messages next to the Buy Now button, which
   * is where the shopper's attention is. Nothing is redirected on error.
   */
  function showErrors(btn, errors) {
    var messages = [];
    var el = form();

    Object.keys(errors).forEach(function (key) {
      var text = String(errors[key]);

      messages.push(text);

      if (!el) {
        return;
      }

      var suffix = key.split('_').join('-');
      var field = el.querySelector('#input-' + suffix);
      var slot = el.querySelector('#error-' + suffix);

      if (field) {
        field.classList.add('is-invalid');

        Array.prototype.forEach.call(field.querySelectorAll('.form-control, .form-select, .form-check-input, .form-check-label'), function (node) {
          node.classList.add('is-invalid');
        });
      }

      if (slot) {
        slot.textContent = text;
        slot.classList.add('d-block');
      }
    });

    if (!messages.length) {
      return;
    }

    var box = errorBox(btn, true);

    if (!box) {
      return;
    }

    box.innerHTML = '';

    if (messages.length === 1) {
      box.textContent = messages[0];

      return;
    }

    var list = document.createElement('ul');

    messages.forEach(function (text) {
      var item = document.createElement('li');

      item.textContent = text;
      list.appendChild(item);
    });

    box.appendChild(list);
  }

  function fail(btn) {
    showErrors(btn, { warning: btn.getAttribute('data-nk-error') || 'Error' });
  }

  function busy(btn, state) {
    btn.disabled = state;

    if (state) {
      btn.setAttribute('data-nk-busy', '1');
    } else {
      btn.removeAttribute('data-nk-busy');
    }
  }

  function buy(btn) {
    if (btn.getAttribute('data-nk-busy') === '1') {
      return;
    }

    var el = form();

    if (!el) {
      return;
    }

    var addUrl = btn.getAttribute('data-nk-add-url');
    var checkoutUrl = btn.getAttribute('data-nk-checkout-url');

    if (!addUrl || !checkoutUrl) {
      return;
    }

    clearErrors(btn);
    busy(btn, true);

    fetch(addUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: serialize(el)
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (json) {
        if (json && json.error) {
          busy(btn, false);
          showErrors(btn, json.error);

          return;
        }

        if (json && json.success) {
          // Straight to checkout - the cart page is deliberately skipped.
          window.location.href = checkoutUrl;

          return;
        }

        busy(btn, false);
        fail(btn);
      })
      .catch(function () {
        busy(btn, false);
        fail(btn);
      });
  }

  function init() {
    var btn = document.getElementById('nk-buy-now');

    if (!btn) {
      return;
    }

    btn.addEventListener('click', function (event) {
      event.preventDefault();
      buy(btn);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
