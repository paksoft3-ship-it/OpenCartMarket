<?php
namespace Opencart\Catalog\Controller\Extension\NkBuyNow\Event;

/**
 * NovaKur Buy Now Button — storefront hooks.
 *
 * assets() catalog/controller/product/product/before → register CSS/JS
 * button() catalog/view/product/product/after        → inject the button markup
 *
 * Both hooks fail open: if the theme does not expose the anchors this module
 * expects, the storefront output is returned untouched.
 */
class BuyNow extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_buy_now/catalog/view/assets/css/buy_now.css';
    private const JS  = 'extension/nk_buy_now/catalog/view/assets/js/buy_now.js';

    private const DEFAULT_COLOR = '#F59E0B';

    private const TEXT_MAX = 48;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * Inject the Buy Now button next to the theme's Add to Cart button.
     *
     * The default OC 4.1 product template renders
     *   <button type="submit" id="button-cart" ...>{{ button_cart }}</button>
     * inside <form id="form-product">. We anchor on `id="button-cart"` and fall
     * back to the end of `#form-product`; if neither is present nothing is
     * changed, so an unusual theme can never be corrupted.
     *
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function button(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || !is_string($output) || $output === '') {
            return;
        }

        // A theme is free to render the product view twice (AJAX fragments);
        // only the first copy gets the button so we never duplicate the id.
        if (str_contains($output, 'id="nk-buy-now"')) {
            return;
        }

        $color = $this->color();

        $this->load->language('extension/nk_buy_now/module/buy_now');

        $html = $this->load->view('extension/nk_buy_now/module/buy_now_button', [
            'button_text'   => $this->label(),
            'text_working'  => $this->language->get('text_working'),
            'text_error'    => $this->language->get('text_error'),
            'color'         => $color,
            'text_color'    => $this->contrast($color),
            'add_url'       => $this->url->link('checkout/cart.add', 'language=' . $this->config->get('config_language')),
            'checkout_url'  => $this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language'), true)
        ]);

        if (!is_string($html) || $html === '') {
            return;
        }

        if ($this->position() === 'before') {
            if ($this->insertBefore($output, $html)) {
                return;
            }
        } elseif ($this->insertAfter($output, $html)) {
            return;
        }

        $this->insertFallback($output, $html);
    }

    /**
     * Insert immediately after the closing tag of the Add to Cart button.
     */
    private function insertAfter(string &$output, string $html): bool {
        $pos = strpos($output, 'id="button-cart"');

        if ($pos === false) {
            return false;
        }

        $close = strpos($output, '</button>', $pos);

        if ($close === false) {
            return false;
        }

        $at = $close + strlen('</button>');

        $output = substr($output, 0, $at) . $html . substr($output, $at);

        return true;
    }

    /**
     * Insert immediately before the opening tag of the Add to Cart button.
     */
    private function insertBefore(string &$output, string $html): bool {
        $pos = strpos($output, 'id="button-cart"');

        if ($pos === false) {
            return false;
        }

        // Walk back to the `<button` that owns the id attribute.
        $open = strrpos(substr($output, 0, $pos), '<button');

        if ($open === false) {
            return false;
        }

        $output = substr($output, 0, $open) . $html . substr($output, $open);

        return true;
    }

    /**
     * Last resort: drop the button just before </form> of #form-product.
     */
    private function insertFallback(string &$output, string $html): void {
        $pos = strpos($output, 'id="form-product"');

        if ($pos === false) {
            return;
        }

        $close = strpos($output, '</form>', $pos);

        if ($close === false) {
            return;
        }

        $output = substr($output, 0, $close) . $html . substr($output, $close);
    }

    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_buy_now_status');
    }

    private function position(): string {
        $position = (string)$this->config->get('module_buy_now_position');

        return in_array($position, ['after', 'before'], true) ? $position : 'after';
    }

    /**
     * Merchant label wins, otherwise the storefront translation for the active
     * language. Settings are written by a validating save(), but a hand-edited
     * `oc_setting` row must never be able to smuggle control characters or an
     * unbounded string into the markup.
     */
    private function label(): string {
        $text = $this->config->get('module_buy_now_button_text');
        $text = is_scalar($text) ? (string)$text : '';
        $text = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $text) ?? '');

        if ($text === '') {
            return (string)$this->language->get('text_buy_now');
        }

        if (function_exists('mb_substr')) {
            return mb_substr($text, 0, self::TEXT_MAX, 'UTF-8');
        }

        return substr($text, 0, self::TEXT_MAX);
    }

    /**
     * A hand-edited setting must never break out of a style attribute.
     */
    private function color(): string {
        $value = $this->config->get('module_buy_now_color');

        if (!is_scalar($value)) {
            return self::DEFAULT_COLOR;
        }

        $color = strtoupper(trim((string)$value));

        return preg_match('/^#[0-9A-F]{6}$/', $color) ? $color : self::DEFAULT_COLOR;
    }

    /**
     * Pick black or white for the label using the WCAG relative-luminance
     * threshold, so a pale merchant colour still yields a readable button.
     */
    private function contrast(string $hex): string {
        $r = (int)hexdec(substr($hex, 1, 2)) / 255;
        $g = (int)hexdec(substr($hex, 3, 2)) / 255;
        $b = (int)hexdec(substr($hex, 5, 2)) / 255;

        $channel = static function (float $value): float {
            return $value <= 0.03928 ? $value / 12.92 : pow(($value + 0.055) / 1.055, 2.4);
        };

        $luminance = 0.2126 * $channel($r) + 0.7152 * $channel($g) + 0.0722 * $channel($b);

        return $luminance > 0.179 ? '#111111' : '#FFFFFF';
    }
}
