<?php
// Heading
$_['heading_title']        = 'NovaKur Buy Now Button';

// Text
$_['text_extension']       = 'Extensions';
$_['text_success']         = 'Success: You have modified NovaKur Buy Now Button settings!';
$_['text_edit']            = 'Edit NovaKur Buy Now Button';
$_['text_enabled']         = 'Enabled';
$_['text_disabled']        = 'Disabled';
$_['text_general']         = 'General';
$_['text_appearance']      = 'Appearance';
$_['text_after']           = 'After Add to Cart';
$_['text_before']          = 'Before Add to Cart';
$_['text_buy_now_default'] = 'Buy Now';

// Entry
$_['entry_status']         = 'Status';
$_['entry_button_text']    = 'Button text';
$_['entry_position']       = 'Position';
$_['entry_color']          = 'Button colour';

// Help
$_['help_button_text']     = 'Leave empty to use the translated default for each storefront language. Maximum 48 characters.';
$_['help_position']        = 'Where the button is inserted relative to the theme\'s Add to Cart button.';
$_['help_color']           = 'Background colour of the button. The label switches between black and white automatically for contrast.';

// Button
$_['button_save']          = 'Save';
$_['button_back']          = 'Back';

// Error
$_['error_permission']     = 'Warning: You do not have permission to modify this module!';
$_['error_button_text']    = 'Button text must be 48 characters or fewer!';
$_['error_position']       = 'Position must be after or before the Add to Cart button!';
$_['error_color']          = 'Colour must be a 6 digit hex value, e.g. #F59E0B!';
