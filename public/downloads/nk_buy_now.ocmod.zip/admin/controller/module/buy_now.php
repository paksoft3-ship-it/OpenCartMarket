<?php
namespace Opencart\Admin\Controller\Extension\NkBuyNow\Module;

/**
 * NovaKur Buy Now Button
 *
 * Settings namespace: module_buy_now_*
 * Route:              extension/nk_buy_now/module/buy_now
 * Event codes:        nk_buy_now_assets / nk_buy_now_button
 */
class BuyNow extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_buy_now/module/buy_now';
    private string $prefix = 'module_buy_now';

    private const TEXT_MAX = 48;

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_buy_now_status'      => '0',
            'module_buy_now_button_text' => '',
            'module_buy_now_position'    => 'after',
            'module_buy_now_color'       => '#F59E0B'
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_buy_now_assets',
                'description' => 'NovaKur Buy Now: stylesheet + script injection on the product page',
                'trigger'     => 'catalog/controller/product/product/before',
                'action'      => 'extension/nk_buy_now/event/buy_now.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_buy_now_button',
                'description' => 'NovaKur Buy Now: injects the Buy Now button beside Add to Cart',
                'trigger'     => 'catalog/view/product/product/after',
                'action'      => 'extension/nk_buy_now/event/buy_now.button',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    /**
     * @return array<int, string>
     */
    private function positions(): array {
        return ['after', 'before'];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_appearance',
            'text_after',
            'text_before',
            'entry_status',
            'entry_button_text',
            'entry_position',
            'entry_color',
            'help_button_text',
            'help_position',
            'help_color',
            'button_save',
            'button_back',
            'error_permission',
            'error_button_text',
            'error_position',
            'error_color'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['text_placeholder'] = $this->language->get('text_buy_now_default');

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        $save[$this->prefix . '_status'] = (string)(int)!empty($post[$this->prefix . '_status']);

        // --- Button label ----------------------------------------------------
        // Empty is legal and means "use the translated default".
        $text = is_scalar($post[$this->prefix . '_button_text'] ?? null) ? (string)$post[$this->prefix . '_button_text'] : '';
        $text = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $text) ?? '');

        if (function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') > self::TEXT_MAX : strlen($text) > self::TEXT_MAX) {
            $json['error'][$this->prefix . '_button_text'] = $this->language->get('error_button_text');
        } else {
            $save[$this->prefix . '_button_text'] = $text;
        }

        // --- Enumerations ----------------------------------------------------
        $position = trim((string)($post[$this->prefix . '_position'] ?? 'after'));

        if (!in_array($position, $this->positions(), true)) {
            $json['error'][$this->prefix . '_position'] = $this->language->get('error_position');
        } else {
            $save[$this->prefix . '_position'] = $position;
        }

        // --- Colour ----------------------------------------------------------
        $color = strtoupper(trim((string)($post[$this->prefix . '_color'] ?? '')));

        if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
            $json['error'][$this->prefix . '_color'] = $this->language->get('error_color');
        } else {
            $save[$this->prefix . '_color'] = $color;
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }
}
