<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkDarkPack extends \Opencart\System\Engine\Controller {

    /**
     * Overlay pack: hooks ONLY common/header and never replaces the route.
     * It appends dark-mode data to $data so any NovaKur header template can
     * consume it (see catalog/view/template/common/dark_head_snippet.twig).
     */
    public function view(string &$route, array &$data, string &$code): void {
        if ($route !== 'common/header') {
            return;
        }

        if (!$this->isDarkPackActive()) {
            return;
        }

        $css_file = DIR_EXTENSION . 'novakur/catalog/view/assets/dist/css/nk-dark.css';
        $js_file = DIR_EXTENSION . 'novakur/catalog/view/assets/dist/js/nk-dark.js';

        if (!is_file($css_file) || !is_file($js_file)) {
            return;
        }

        $mode = (string)$this->config->get('theme_nk_dark_pack_mode');
        if (!in_array($mode, ['auto', 'dark', 'light-default'], true)) {
            $mode = 'auto';
        }

        $accent = trim((string)$this->config->get('theme_nk_dark_pack_accent_color'));
        if (!preg_match('/^#(?:[0-9a-fA-F]{3}){1,2}$/', $accent)) {
            $accent = '#7aa2ff';
        }

        $data['nk_dark_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-dark.css';
        $data['nk_dark_js'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/nk-dark.js';
        $data['nk_dark_mode'] = $mode;
        $data['nk_dark_toggle'] = (bool)$this->config->get('theme_nk_dark_pack_show_toggle_button');
        $data['nk_dark_accent'] = $accent;
    }

    private function isDarkPackActive(): bool {
        if (!(bool)$this->config->get('theme_nk_dark_pack_status')) {
            return false;
        }

        $current_theme = (string)$this->config->get('config_theme');

        return str_starts_with($current_theme, 'nk_') || str_starts_with($current_theme, 'novakur');
    }
}
