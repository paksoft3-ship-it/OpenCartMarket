<?php
namespace Opencart\Catalog\Controller\Extension\NkProductLabels\Event;

/**
 * NovaKur Product Labels — storefront hooks.
 *
 * assets()  catalog/controller/common/header/before          → register the CSS
 * collect() catalog/model/catalog/product.getProduct/after    → cache raw rows
 * collect() catalog/model/catalog/product.getProducts/after   → cache raw rows
 * thumb()   catalog/view/product/thumb/after                  → badge product cards
 * product() catalog/view/product/product/after                → badge the main image
 *
 * Why the model hooks: the data handed to product/thumb.twig has already been
 * run through Currency::format(), so `price`/`special` are display strings and
 * the raw numbers needed for a discount percentage are gone. Caching the rows as
 * the model returns them keeps the badges exact without a single extra query.
 *
 * OpenCart 4.1 schema notes:
 *   - There is no `product_special` table. Specials are `product_discount` rows
 *     with `special` = 1, and Catalog\Model\Catalog\Product already resolves the
 *     winning row into the `special` column it returns.
 *   - `product` has no `viewed` column in 4.1 (it moved to `product_viewed`), so
 *     "hot" is measured from order lines, which is what the label claims anyway.
 *   - There is no `product_bestseller` table in 4.1's db_schema.php, so the
 *     bestseller set is derived from `order_product` + `order` directly.
 *
 * Every hook fails open: on any unexpected shape the storefront output is left
 * exactly as it was.
 */
class ProductLabels extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_product_labels/catalog/view/assets/css/product_labels.css';

    private const POSITIONS = ['top-left', 'top-right', 'bottom-left', 'bottom-right'];

    /**
     * Raw model rows seen this request, keyed by product id.
     *
     * @var array<int, array<string, mixed>>
     */
    private static array $rows = [];

    /**
     * Bestselling product ids for this store, resolved at most once per request.
     *
     * @var array<int, bool>|null
     */
    private static ?array $bestsellers = null;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
    }

    /**
     * @param string               $route
     * @param array<mixed>         $args
     * @param mixed                $output
     *
     * @return void
     */
    public function collect(string &$route, array &$args, mixed &$output): void {
        if (!$this->enabled() || !is_array($output)) {
            return;
        }

        // getProduct() returns one row, getProducts() a list of them.
        $rows = isset($output['product_id']) ? [$output] : $output;

        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row['product_id'])) {
                continue;
            }

            self::$rows[(int)$row['product_id']] = $row;
        }
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function thumb(string &$route, array &$data, mixed &$output): void {
        $this->inject($data, $output, '<div class="image"');
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function product(string &$route, array &$data, mixed &$output): void {
        $this->inject($data, $output, '<div class="image magnific-popup"');
    }

    /**
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    private function inject(array &$data, mixed &$output, string $anchor): void {
        if (!$this->enabled() || !is_string($output) || $output === '') {
            return;
        }

        $product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

        if ($product_id <= 0) {
            return;
        }

        // Loaded before the labels are built: the default badge texts come from
        // this pack whenever the merchant has not overridden them.
        $this->load->language('extension/nk_product_labels/module/product_labels');

        $labels = $this->labels($product_id, $data);

        if (!$labels) {
            return;
        }

        $html = $this->load->view('extension/nk_product_labels/module/product_label', [
            'position' => $this->position(),
            'labels'   => $labels
        ]);

        if ($html === '') {
            return;
        }

        // Drop the badges just inside the image wrapper so they inherit its
        // positioning context. If the theme does not use the stock markup the
        // output is returned untouched rather than mangled.
        $start = strpos($output, $anchor);

        if ($start === false) {
            return;
        }

        $end = strpos($output, '>', $start);

        if ($end === false) {
            return;
        }

        $output = substr($output, 0, $end + 1) . $html . substr($output, $end + 1);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<int, array<string, string>>
     */
    private function labels(int $product_id, array $data): array {
        $row = self::$rows[$product_id] ?? [];

        $labels = [];

        // --- New -------------------------------------------------------------
        if ((int)$this->config->get('module_product_labels_new_status')) {
            $date_added = (string)($row['date_added'] ?? ($data['date_added'] ?? ''));

            if ($this->isNew($date_added)) {
                $labels[] = ['type' => 'new', 'text' => $this->text('new')];
            }
        }

        // --- Sale ------------------------------------------------------------
        if ((int)$this->config->get('module_product_labels_sale_status')) {
            $price = (float)($row['price'] ?? 0);
            $special = isset($row['special']) ? (float)$row['special'] : 0.0;

            // Fall back to the formatted thumb data when the model hook did not
            // see this product (e.g. a module that builds rows by hand).
            $on_sale = $special > 0 && $price > 0 && $special < $price;

            if (!$on_sale && !$row && !empty($data['special'])) {
                $on_sale = true;
                $price = 0.0;
            }

            if ($on_sale) {
                $percent = $price > 0 ? (int)round((1 - ($special / $price)) * 100) : 0;

                if ((int)$this->config->get('module_product_labels_sale_show_percent') && $percent > 0) {
                    // str_replace rather than sprintf: the text is merchant
                    // supplied and a stray % would make sprintf() throw.
                    $text = str_replace('{percent}', (string)$percent, $this->text('sale_percent'));
                } else {
                    $text = $this->text('sale');
                }

                $labels[] = ['type' => 'sale', 'text' => $text];
            }
        }

        // --- Hot -------------------------------------------------------------
        if ((int)$this->config->get('module_product_labels_hot_status') && isset($this->bestsellers()[$product_id])) {
            $labels[] = ['type' => 'hot', 'text' => $this->text('hot')];
        }

        $max = (int)$this->config->get('module_product_labels_max_labels');

        if ($max < 1 || $max > 3) {
            $max = 2;
        }

        return array_slice($labels, 0, $max);
    }

    private function isNew(string $date_added): bool {
        if ($date_added === '' || str_starts_with($date_added, '0000-00-00')) {
            return false;
        }

        $days = (int)$this->config->get('module_product_labels_new_days');

        if ($days < 1 || $days > 365) {
            $days = 30;
        }

        $timestamp = strtotime($date_added);

        if ($timestamp === false) {
            return false;
        }

        return $timestamp >= strtotime('-' . $days . ' days');
    }

    /**
     * Bestselling product ids for the current store.
     *
     * 4.1 ships no `product_bestseller` table in db_schema.php, so this reads
     * the order lines directly — one grouped query per request, then cached.
     *
     * @return array<int, bool>
     */
    private function bestsellers(): array {
        if (self::$bestsellers !== null) {
            return self::$bestsellers;
        }

        $limit = (int)$this->config->get('module_product_labels_hot_limit');

        if ($limit < 1 || $limit > 100) {
            $limit = 10;
        }

        $store_id = (int)$this->config->get('config_store_id');

        $key = 'nk_product_labels.bestseller.' . $store_id . '.' . $limit;

        $ids = $this->cache->get($key);

        if (!is_array($ids)) {
            $query = $this->db->query("SELECT `op`.`product_id`, SUM(`op`.`quantity`) AS `total` FROM `" . DB_PREFIX . "order_product` `op` LEFT JOIN `" . DB_PREFIX . "order` `o` ON (`o`.`order_id` = `op`.`order_id`) WHERE `o`.`order_status_id` > '0' AND `o`.`store_id` = '" . (int)$store_id . "' GROUP BY `op`.`product_id` ORDER BY `total` DESC LIMIT " . (int)$limit);

            $ids = [];

            foreach ($query->rows as $row) {
                $ids[] = (int)$row['product_id'];
            }

            $this->cache->set($key, $ids);
        }

        self::$bestsellers = array_fill_keys($ids, true);

        return self::$bestsellers;
    }

    /**
     * Merchant-supplied label text, falling back to the storefront language pack.
     */
    private function text(string $key): string {
        $custom = trim((string)$this->config->get('module_product_labels_text_' . $key));

        return $custom !== '' ? $custom : $this->language->get('text_' . $key);
    }

    private function position(): string {
        $position = (string)$this->config->get('module_product_labels_label_position');

        return in_array($position, self::POSITIONS, true) ? $position : 'top-left';
    }

    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_product_labels_status');
    }
}
