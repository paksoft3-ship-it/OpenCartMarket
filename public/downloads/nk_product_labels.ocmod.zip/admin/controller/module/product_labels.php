<?php
namespace Opencart\Admin\Controller\Extension\NkProductLabels\Module;

/**
 * NovaKur Product Labels
 *
 * Settings namespace: module_product_labels_*
 * Route:              extension/nk_product_labels/module/product_labels
 * Event codes:        nk_product_labels_assets / _collect_one / _collect_many /
 *                     _thumb / _product
 */
class ProductLabels extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_product_labels/module/product_labels';
    private string $prefix = 'module_product_labels';

    /**
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_product_labels_status'            => '0',
            'module_product_labels_new_status'        => '1',
            'module_product_labels_new_days'          => '30',
            'module_product_labels_sale_status'       => '1',
            'module_product_labels_sale_show_percent' => '1',
            'module_product_labels_hot_status'        => '1',
            'module_product_labels_hot_limit'         => '10',
            'module_product_labels_label_position'    => 'top-left',
            'module_product_labels_max_labels'        => '2',
            'module_product_labels_text_new'          => '',
            'module_product_labels_text_sale'         => '',
            'module_product_labels_text_sale_percent' => '',
            'module_product_labels_text_hot'          => ''
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_product_labels_assets',
                'description' => 'NovaKur Product Labels: stylesheet injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_product_labels/event/product_labels.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                // Caches the raw product row so the badge maths uses real
                // numbers instead of already-formatted currency strings.
                'code'        => 'nk_product_labels_collect_one',
                'description' => 'NovaKur Product Labels: cache getProduct() rows',
                'trigger'     => 'catalog/model/catalog/product.getProduct/after',
                'action'      => 'extension/nk_product_labels/event/product_labels.collect',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_product_labels_collect_many',
                'description' => 'NovaKur Product Labels: cache getProducts() rows',
                'trigger'     => 'catalog/model/catalog/product.getProducts/after',
                'action'      => 'extension/nk_product_labels/event/product_labels.collect',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_product_labels_thumb',
                'description' => 'NovaKur Product Labels: badges on product cards',
                'trigger'     => 'catalog/view/product/thumb/after',
                'action'      => 'extension/nk_product_labels/event/product_labels.thumb',
                'status'      => 1,
                'sort_order'  => 2
            ],
            [
                'code'        => 'nk_product_labels_product',
                'description' => 'NovaKur Product Labels: badges on the product page',
                'trigger'     => 'catalog/view/product/product/after',
                'action'      => 'extension/nk_product_labels/event/product_labels.product',
                'status'      => 1,
                'sort_order'  => 2
            ]
        ];
    }

    /**
     * @return array<int, string>
     */
    private function positions(): array {
        return ['top-left', 'top-right', 'bottom-left', 'bottom-right'];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_new',
            'text_sale',
            'text_hot',
            'text_top_left',
            'text_top_right',
            'text_bottom_left',
            'text_bottom_right',
            'entry_status',
            'entry_label_position',
            'entry_max_labels',
            'entry_new_status',
            'entry_new_days',
            'entry_sale_status',
            'entry_sale_show_percent',
            'entry_hot_status',
            'entry_hot_limit',
            'entry_text_new',
            'entry_text_sale',
            'entry_text_sale_percent',
            'entry_text_hot',
            'help_max_labels',
            'help_new_days',
            'help_sale_show_percent',
            'help_hot_limit',
            'help_custom_text',
            'help_sale_percent_token',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['positions'] = $this->positions();

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        foreach (['status', 'new_status', 'sale_status', 'sale_show_percent', 'hot_status'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        $position = trim((string)($post[$this->prefix . '_label_position'] ?? 'top-left'));

        if (!in_array($position, $this->positions(), true)) {
            $json['error'][$this->prefix . '_label_position'] = $this->language->get('error_label_position');
        } else {
            $save[$this->prefix . '_label_position'] = $position;
        }

        foreach (['max_labels' => [1, 3], 'new_days' => [1, 365], 'hot_limit' => [1, 100]] as $key => $range) {
            $value = trim((string)($post[$this->prefix . '_' . $key] ?? ''));

            if (!$this->inRange($value, $range[0], $range[1])) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_' . $key);
            } else {
                $save[$this->prefix . '_' . $key] = (string)(int)$value;
            }
        }

        // Custom label text. Rendered escaped on the storefront; markup is
        // stripped here too so a badge can never smuggle in an element.
        foreach (['new', 'sale', 'sale_percent', 'hot'] as $key) {
            $text = trim(strip_tags((string)($post[$this->prefix . '_text_' . $key] ?? '')));
            $text = preg_replace('/\s+/u', ' ', $text) ?? '';

            if (oc_strlen($text) > 24) {
                $json['error'][$this->prefix . '_text_' . $key] = $this->language->get('error_text');
            } else {
                $save[$this->prefix . '_text_' . $key] = $text;
            }
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    private function inRange(string $value, int $min, int $max): bool {
        if (!preg_match('/^\d{1,5}$/', $value)) {
            return false;
        }

        $number = (int)$value;

        return $number >= $min && $number <= $max;
    }
}
