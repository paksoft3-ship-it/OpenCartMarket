-- ============================================================
-- NovaKur Grocery Theme — Demo Database Setup
-- Table prefix is substituted before running on the VPS.
-- ============================================================
SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ---- 1. Clear existing data ----
DELETE FROM oc_product_special;
DELETE FROM oc_product_to_layout;
DELETE FROM oc_product_to_store;
DELETE FROM oc_product_to_category;
DELETE FROM oc_product_image;
DELETE FROM oc_product_description;
DELETE FROM oc_product;

DELETE FROM oc_category_to_layout;
DELETE FROM oc_category_to_store;
DELETE FROM oc_category_description;
DELETE FROM oc_category;

ALTER TABLE oc_category AUTO_INCREMENT = 1;
ALTER TABLE oc_product AUTO_INCREMENT = 1;

-- ---- 2. Grocery categories ----
INSERT INTO oc_category
  (category_id, image, parent_id, top, `column`, sort_order, status, date_modified, date_added)
VALUES
  (1, 'catalog/novakur/grocery/cat-produce.png',  0, 1, 1, 1, 1, NOW(), NOW()),
  (2, 'catalog/novakur/grocery/cat-meat.png',     0, 1, 1, 2, 1, NOW(), NOW()),
  (3, 'catalog/novakur/grocery/cat-bakery.png',   0, 1, 1, 3, 1, NOW(), NOW()),
  (4, 'catalog/novakur/grocery/cat-dairy.png',    0, 1, 1, 4, 1, NOW(), NOW()),
  (5, 'catalog/novakur/grocery/cat-drinks.png',   0, 1, 1, 5, 1, NOW(), NOW()),
  (6, 'catalog/novakur/grocery/cat-snacks.png',   0, 1, 1, 6, 1, NOW(), NOW());

INSERT INTO oc_category_description
  (category_id, language_id, name, description, meta_title, meta_description, meta_keyword)
VALUES
  (1,1,'Fresh Produce',       '<p>Locally sourced, organically grown vegetables and fruits delivered fresh to your door.</p>','Fresh Produce',       'Shop organic fresh produce',     'organic,fresh,vegetables,fruits'),
  (2,1,'Meat & Seafood',      '<p>Ethically raised meats and sustainably sourced seafood from certified farms.</p>',          'Meat & Seafood',      'Premium meat and seafood',       'meat,seafood,organic,protein'),
  (3,1,'Artisan Bakery',      '<p>Freshly baked breads, pastries, and artisan goods made daily with organic grains.</p>',     'Artisan Bakery',      'Fresh artisan baked goods',      'bakery,bread,pastry,artisan'),
  (4,1,'Dairy & Eggs',        '<p>Farm-fresh eggs and organic dairy products from free-range certified farms.</p>',           'Dairy & Eggs',        'Organic dairy and eggs',         'dairy,eggs,milk,cheese,organic'),
  (5,1,'Drinks & Juices',     '<p>Fresh-pressed juices, organic teas, and natural craft beverages.</p>',                     'Drinks & Juices',     'Fresh organic drinks',           'drinks,juice,tea,beverages'),
  (6,1,'Pantry & Snacks',     '<p>Curated organic pantry staples, healthy snacks, and natural condiments.</p>',              'Pantry & Snacks',     'Organic pantry essentials',      'pantry,snacks,organic,condiments');

INSERT INTO oc_category_to_store (category_id, store_id) VALUES
  (1,0),(2,0),(3,0),(4,0),(5,0),(6,0);

-- OC4 requires category_path entries for routing to work
INSERT INTO oc_category_path (category_id, path_id, level) VALUES
  (1,1,0),(2,2,0),(3,3,0),(4,4,0),(5,5,0),(6,6,0);

INSERT INTO oc_category_to_layout (category_id, store_id, layout_id) VALUES
  (1,0,3),(2,0,3),(3,0,3),(4,0,3),(5,0,3),(6,0,3);

-- ---- 3. Grocery products ----
-- Columns: product_id, master_id, model, sku, upc, ean, jan, isbn, mpn, location,
--          variant, override, quantity, stock_status_id, image, manufacturer_id,
--          shipping, price, points, tax_class_id, date_available,
--          weight, weight_class_id, length, width, height, length_class_id,
--          subtract, minimum, rating, sort_order, status, date_added, date_modified
INSERT INTO oc_product
  (product_id, master_id, model, sku, upc, ean, jan, isbn, mpn, location,
   variant, override, quantity, stock_status_id, image, manufacturer_id,
   shipping, price, points, tax_class_id, date_available,
   weight, weight_class_id, length, width, height, length_class_id,
   subtract, minimum, rating, sort_order, status, date_added, date_modified)
VALUES
  -- Fresh Produce (cat 1)
  ( 1,0,'GP-001','','','','','','','','','',100,5,'catalog/novakur/grocery/prod-strawberries.png',0,1, 4.99,0,0,NOW(), 250, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  ( 2,0,'GP-002','','','','','','','','','', 80,5,'catalog/novakur/grocery/prod-carrots.png',     0,1, 2.49,0,0,NOW(), 500, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW()),
  ( 3,0,'GP-003','','','','','','','','','', 60,5,'catalog/novakur/grocery/prod-spinach.png',     0,1, 3.29,0,0,NOW(), 200, 2,0,0,0,1,1,1,0,3,1,NOW(),NOW()),
  ( 4,0,'GP-004','','','','','','','','','', 90,5,'catalog/novakur/grocery/prod-oranges.png',     0,1, 5.99,0,0,NOW(),1000, 2,0,0,0,1,1,1,0,4,1,NOW(),NOW()),
  ( 5,0,'GP-005','','','','','','','','','', 70,5,'catalog/novakur/grocery/prod-blueberries.png', 0,1, 6.49,0,0,NOW(), 150, 2,0,0,0,1,1,1,0,5,1,NOW(),NOW()),
  ( 6,0,'GP-006','','','','','','','','','', 50,5,'catalog/novakur/grocery/prod-vegetables.png',  0,1, 7.99,0,0,NOW(), 800, 2,0,0,0,1,1,1,0,6,1,NOW(),NOW()),
  ( 7,0,'GP-007','','','','','','','','','', 40,5,'catalog/novakur/grocery/prod-grapes.png',      0,1, 4.29,0,0,NOW(), 500, 2,0,0,0,1,1,1,0,7,1,NOW(),NOW()),
  ( 8,0,'GP-008','','','','','','','','','', 60,5,'catalog/novakur/grocery/prod-garlic.png',      0,1, 1.99,0,0,NOW(), 100, 2,0,0,0,1,1,1,0,8,1,NOW(),NOW()),
  -- Meat & Seafood (cat 2)
  ( 9,0,'GM-001','','','','','','','','','', 30,5,'catalog/novakur/grocery/prod-steak.png',       0,1,14.99,0,0,NOW(), 400, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  (10,0,'GM-002','','','','','','','','','', 25,5,'catalog/novakur/grocery/prod-steak.png',       0,1, 9.99,0,0,NOW(), 300, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW()),
  -- Bakery (cat 3)
  (11,0,'GB-001','','','','','','','','','', 20,5,'catalog/novakur/grocery/prod-bread.png',       0,1, 3.49,0,0,NOW(), 600, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  (12,0,'GB-002','','','','','','','','','', 15,5,'catalog/novakur/grocery/prod-bread.png',       0,1, 2.99,0,0,NOW(), 400, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW()),
  -- Dairy & Eggs (cat 4)
  (13,0,'GD-001','','','','','','','','','', 50,5,'catalog/novakur/grocery/prod-milk.png',        0,1, 3.99,0,0,NOW(),1000, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  (14,0,'GD-002','','','','','','','','','', 40,5,'catalog/novakur/grocery/prod-butter.png',      0,1, 4.49,0,0,NOW(), 250, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW()),
  -- Drinks & Juices (cat 5)
  (15,0,'GV-001','','','','','','','','','', 60,5,'catalog/novakur/grocery/prod-oj.png',          0,1, 3.79,0,0,NOW(),1000, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  (16,0,'GV-002','','','','','','','','','', 55,5,'catalog/novakur/grocery/prod-juice.png',       0,1, 4.99,0,0,NOW(), 750, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW()),
  -- Pantry & Snacks (cat 6)
  (17,0,'GS-001','','','','','','','','','', 80,5,'catalog/novakur/grocery/prod-honey.png',       0,1, 8.99,0,0,NOW(), 500, 2,0,0,0,1,1,1,0,1,1,NOW(),NOW()),
  (18,0,'GS-002','','','','','','','','','',100,5,'catalog/novakur/grocery/prod-salad.png',       0,1, 2.49,0,0,NOW(), 200, 2,0,0,0,1,1,1,0,2,1,NOW(),NOW());

INSERT INTO oc_product_description
  (product_id, language_id, name, description, tag, meta_title, meta_description, meta_keyword)
VALUES
  ( 1,1,'Organic Strawberries (250g)',    '<p>Sweet, hand-picked strawberries grown without pesticides on local farms.</p>',          'strawberries,organic,fruit',   'Organic Strawberries','',''),
  ( 2,1,'Fresh Carrots (500g)',           '<p>Crisp locally sourced carrots packed with natural sweetness and beta-carotene.</p>',    'carrots,fresh,vegetables',     'Fresh Carrots','',''),
  ( 3,1,'Baby Spinach Leaves (200g)',     '<p>Tender baby spinach leaves, triple washed and ready to eat. Rich in iron.</p>',        'spinach,salad,organic',        'Baby Spinach','',''),
  ( 4,1,'Valencia Oranges (1kg)',         '<p>Juicy Valencia oranges perfect for fresh-pressed juice or snacking.</p>',              'oranges,citrus,fruit',         'Valencia Oranges','',''),
  ( 5,1,'Wild Blueberries (150g)',        '<p>Antioxidant-rich wild blueberries from sustainable certified farms.</p>',              'blueberries,superfood,fruit',  'Wild Blueberries','',''),
  ( 6,1,'Seasonal Vegetables Box (800g)','<p>A curated mix of seasonal organic vegetables fresh from local farms.</p>',             'vegetables,organic,box',       'Seasonal Vegetables Box','',''),
  ( 7,1,'Red Seedless Grapes (500g)',     '<p>Sweet and crisp red grapes, seedless and ready to enjoy.</p>',                        'grapes,fruit,seedless',        'Red Seedless Grapes','',''),
  ( 8,1,'Organic Garlic (100g)',          '<p>Full-flavoured organic garlic bulbs with intense natural aroma.</p>',                 'garlic,organic,seasoning',     'Organic Garlic','',''),
  ( 9,1,'Grass-Fed Ribeye Steak (400g)', '<p>Premium grass-fed ribeye with natural marbling for deep, rich flavour.</p>',           'steak,beef,grass-fed',         'Grass-Fed Ribeye Steak','',''),
  (10,1,'Free-Range Chicken Breast',     '<p>Tender free-range chicken breast raised without antibiotics.</p>',                     'chicken,free-range,protein',   'Free-Range Chicken Breast','',''),
  (11,1,'Sourdough Boule (600g)',         '<p>Artisan sourdough baked fresh daily with organic stone-ground flour.</p>',            'bread,sourdough,artisan',      'Sourdough Boule','',''),
  (12,1,'Rye & Seed Loaf (400g)',         '<p>Dense, flavourful rye loaf packed with seeds and whole grains.</p>',                  'bread,rye,seeds',              'Rye & Seed Loaf','',''),
  (13,1,'Organic Whole Milk (1L)',        '<p>Creamy organic whole milk from grass-fed dairy cows on certified farms.</p>',         'milk,dairy,organic',           'Organic Whole Milk','',''),
  (14,1,'Cultured Butter (250g)',         '<p>Slow-churned cultured butter with a rich, tangy finish. Organic certified.</p>',      'butter,dairy,organic',         'Cultured Butter','',''),
  (15,1,'Fresh Orange Juice (1L)',        '<p>Cold-pressed juice from freshly harvested Valencia oranges. No added sugar.</p>',     'orange juice,fresh,pressed',   'Fresh Orange Juice','',''),
  (16,1,'Green Apple Juice (750ml)',      '<p>Naturally pressed green apple juice with zero added sugar or preservatives.</p>',     'apple juice,natural,fresh',    'Green Apple Juice','',''),
  (17,1,'Raw Wildflower Honey (500g)',    '<p>Unfiltered raw honey harvested from wildflower meadows by local beekeepers.</p>',     'honey,raw,organic,natural',    'Raw Wildflower Honey','',''),
  (18,1,'Organic Mixed Salad (200g)',     '<p>Pre-washed mixed salad leaves including rocket, spinach, and rainbow chard.</p>',     'salad,mixed,organic,leaves',   'Organic Mixed Salad','','');

INSERT INTO oc_product_to_category (product_id, category_id) VALUES
  (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),
  (9,2),(10,2),
  (11,3),(12,3),
  (13,4),(14,4),
  (15,5),(16,5),
  (17,6),(18,6);

INSERT INTO oc_product_to_store (product_id, store_id) VALUES
  (1,0),(2,0),(3,0),(4,0),(5,0),(6,0),(7,0),(8,0),
  (9,0),(10,0),(11,0),(12,0),(13,0),(14,0),(15,0),(16,0),(17,0),(18,0);

-- ---- 4. Sale prices on selected products ----
INSERT INTO oc_product_special
  (product_id, customer_group_id, priority, price, date_start, date_end)
VALUES
  ( 1,1,1, 3.49,'2020-01-01','2030-12-31'),
  ( 5,1,1, 4.99,'2020-01-01','2030-12-31'),
  ( 9,1,1,11.99,'2020-01-01','2030-12-31'),
  (17,1,1, 6.99,'2020-01-01','2030-12-31');

SET foreign_key_checks = 1;

-- Verify:
-- SELECT c.category_id, cd.name FROM oc_category c JOIN oc_category_description cd USING(category_id);
-- SELECT p.product_id, pd.name, p.price FROM oc_product p JOIN oc_product_description pd USING(product_id);
