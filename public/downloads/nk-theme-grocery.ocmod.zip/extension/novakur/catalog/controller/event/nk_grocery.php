<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkGrocery extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isGroceryThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_grocery.twig';
            if (is_file($template)) {
                $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-grocery.css';
                $data['nk_js_base']      = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_grocery_primary_color') ?: '#006b2c';
                $data['novakur_secondary_color'] = '#fd761a';
                $data['novakur_container_width'] = 1280;
                $data['novakur_base_font']       = 'Inter';
                $data['novakur_heading_font']    = 'Inter';
                $data['nk_grocery_default_view'] = (string)$this->config->get('theme_nk_grocery_default_view') ?: 'grid';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_grocery';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/footer_grocery';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_grocery';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 300);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $raw = $this->model_catalog_product->getProducts(['sort' => 'date_added', 'order' => 'DESC', 'start' => 0, 'limit' => 8]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $best_raw = $this->model_catalog_product->getProducts(['sort' => 'rating', 'order' => 'DESC', 'start' => 0, 'limit' => 4]);
            $data['best_sellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_grocery';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 20);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers / Deals ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_grocery';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 20);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_grocery';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_grocery';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_grocery';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 20),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_grocery';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_grocery';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_dashboard_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_dashboard_grocery';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_order_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_order_grocery';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_grocery';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_grocery.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_grocery';
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_grocery.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_grocery';
            }

            $this->load->model('catalog/category');
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate($p['price'], $p['tax_class_id'], $this->config->get('config_tax'));
            $products[] = [
                'product_id' => $p['product_id'],
                'name'       => $p['name'],
                'href'       => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'      => $p['image']
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'      => $this->currency->format($price, $currency),
                'special'    => $p['special']
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'], $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
            ];
        }
        return $products;
    }

    private function isGroceryThemeActive(): bool {
        return (bool)$this->config->get('theme_nk_grocery_status');
    }
}
