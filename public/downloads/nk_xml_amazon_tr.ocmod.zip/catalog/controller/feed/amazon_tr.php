<?php
namespace Opencart\Catalog\Controller\Extension\NkXmlAmazonTr\Feed;

/**
 * Amazon does not poll a feed URL. Listings are ingested through Seller Central flat file
 * uploads or the SP-API Feeds endpoints. This controller therefore produces a structured
 * export you hand to Seller Central or to your integrator: an AmazonEnvelope Product
 * document, or an Inventory Loader flat file for price and stock maintenance.
 */
class AmazonTr extends \Opencart\System\Engine\Controller {
    private const CHUNK_SIZE = 250;

    private array $product_columns = [];

    public function index(): void {
        if (!(int)$this->config->get('feed_amazon_tr_status')) {
            $this->notFound();

            return;
        }

        $token = (string)$this->config->get('feed_amazon_tr_token');
        $supplied_token = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied_token)) {
            $this->notFound();

            return;
        }

        $format = (string)$this->config->get('feed_amazon_tr_format');

        if (!in_array($format, ['xml', 'txt'], true)) {
            $format = 'xml';
        }

        $cache_file = DIR_CACHE . 'amazon_tr.' . $format;
        $content_type = $format === 'xml' ? 'application/xml; charset=utf-8' : 'text/tab-separated-values; charset=utf-8';

        $cache_hours = (int)$this->config->get('feed_amazon_tr_cache_hours');

        if (!in_array($cache_hours, [1, 6, 12, 24], true)) {
            $cache_hours = 6;
        }

        if (is_file($cache_file) && (time() - filemtime($cache_file)) < ($cache_hours * 3600)) {
            $this->response->addHeader('Content-Type: ' . $content_type);
            $this->response->setOutput((string)file_get_contents($cache_file));

            return;
        }

        $this->response->addHeader('Content-Type: ' . $content_type);
        $this->response->setOutput($this->generate($cache_file, $format));
    }

    private function notFound(): void {
        $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');
        $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
        $this->response->setOutput('Not Found');
    }

    private function generate(string $cache_file, string $format): string {
        $currency_code = (string)$this->config->get('feed_amazon_tr_currency_code');

        if ($currency_code === '' || !$this->currency->has($currency_code)) {
            $currency_code = (string)$this->config->get('config_currency');
        }

        $base_currency = (string)$this->config->get('config_currency');

        $language_id = (int)$this->config->get('feed_amazon_tr_language_id');

        if (!$language_id) {
            $language_id = (int)$this->config->get('config_language_id');
        }

        $store_id = $this->config->get('feed_amazon_tr_store_id');
        $store_id = ($store_id === null || $store_id === '') ? (int)$this->config->get('config_store_id') : (int)$store_id;

        $include_out_of_stock = (int)$this->config->get('feed_amazon_tr_include_out_of_stock');
        $include_tax = $this->config->get('feed_amazon_tr_include_tax');
        $include_tax = ($include_tax === null) ? true : (bool)(int)$include_tax;

        $max_products = max(0, (int)$this->config->get('feed_amazon_tr_max_products'));

        $merchant_id = trim((string)$this->config->get('feed_amazon_tr_merchant_id'));

        if ($merchant_id === '') {
            $merchant_id = 'MERCHANT_ID';
        }

        $condition = (string)$this->config->get('feed_amazon_tr_condition');

        if (!in_array($condition, ['11', '10', '4'], true)) {
            $condition = '11';
        }

        $fulfillment_center = (string)$this->config->get('feed_amazon_tr_fulfillment') === 'FBA' ? 'AMAZON_NA' : 'DEFAULT';

        $asin_attribute_id = (int)$this->config->get('feed_amazon_tr_asin_attribute_id');
        $bullet_attribute_id = (int)$this->config->get('feed_amazon_tr_bullet_attribute_id');

        $excluded_categories = $this->config->get('feed_amazon_tr_excluded_categories');

        if (!is_array($excluded_categories)) {
            $excluded_categories = ($excluded_categories !== null && $excluded_categories !== '') ? explode(',', (string)$excluded_categories) : [];
        }

        $excluded_categories = array_values(array_filter(array_map('intval', $excluded_categories)));

        $tmp_file = $cache_file . '.' . getmypid() . '.tmp';
        $handle = @fopen($tmp_file, 'w');
        $cacheable = ($handle !== false);

        if (!$cacheable) {
            $handle = fopen('php://temp/maxmemory:' . (2 * 1024 * 1024), 'w+');
        }

        if ($format === 'xml') {
            fwrite($handle, '<?xml version="1.0" encoding="UTF-8"?>' . "\n");
            fwrite($handle, '<AmazonEnvelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="amzn-envelope.xsd">' . "\n");
            fwrite($handle, '<Header>' . "\n");
            fwrite($handle, '<DocumentVersion>1.01</DocumentVersion>' . "\n");
            fwrite($handle, '<MerchantIdentifier>' . $this->xmlEscape($merchant_id) . '</MerchantIdentifier>' . "\n");
            fwrite($handle, '</Header>' . "\n");
            fwrite($handle, '<MessageType>Product</MessageType>' . "\n");
            fwrite($handle, '<PurgeAndReplace>false</PurgeAndReplace>' . "\n");
        } else {
            fwrite($handle, "\xEF\xBB\xBF");
            fwrite($handle, implode("\t", ['sku', 'product-id', 'product-id-type', 'price', 'item-condition', 'quantity', 'add-delete', 'fulfillment-center-id']) . "\n");
        }

        $start = 0;
        $written = 0;

        while (true) {
            $limit = self::CHUNK_SIZE;

            if ($max_products && ($written + $limit) > $max_products) {
                $limit = $max_products - $written;
            }

            if ($limit < 1) {
                break;
            }

            $products = $this->getProducts($language_id, $store_id, $include_out_of_stock, $excluded_categories, $start, $limit);

            if (!$products) {
                break;
            }

            $product_ids = [];

            foreach ($products as $product) {
                $product_ids[] = (int)$product['product_id'];
            }

            $identifiers = $this->getIdentifiers($product_ids);
            $attributes = $this->getAttributes($product_ids, $language_id, [$asin_attribute_id, $bullet_attribute_id]);

            foreach ($products as $product) {
                $product_id = (int)$product['product_id'];
                $product_identifiers = $identifiers[$product_id] ?? [];
                $product_attributes = $attributes[$product_id] ?? [];

                $sku = $this->firstIdentifier($product, $product_identifiers, ['SKU']);

                if ($sku === '') {
                    $sku = trim((string)$product['model']);
                }

                if ($sku === '') {
                    $sku = 'OC-' . $product_id;
                }

                // Amazon's own product identifier, never OpenCart's internal product_id.
                $standard_id = '';
                $standard_id_type = '';

                if ($asin_attribute_id && isset($product_attributes[$asin_attribute_id]) && trim($product_attributes[$asin_attribute_id]) !== '') {
                    $standard_id = trim($product_attributes[$asin_attribute_id]);
                    $standard_id_type = 'ASIN';
                } else {
                    foreach (['EAN' => 'EAN', 'UPC' => 'UPC', 'ISBN' => 'ISBN', 'JAN' => 'EAN'] as $code => $type) {
                        $value = $this->firstIdentifier($product, $product_identifiers, [$code]);

                        if ($value !== '') {
                            $standard_id = $value;
                            $standard_id_type = $type;

                            break;
                        }
                    }
                }

                $tax_class_id = (int)$product['tax_class_id'];
                $price = $this->convertPrice((float)$product['price'], $tax_class_id, $include_tax, $base_currency, $currency_code);

                if ($product['special'] !== null && (float)$product['special'] >= 0) {
                    $special_price = $this->convertPrice((float)$product['special'], $tax_class_id, $include_tax, $base_currency, $currency_code);

                    if ((float)$special_price < (float)$price) {
                        $price = $special_price;
                    }
                }

                if ($format === 'txt') {
                    fwrite($handle, implode("\t", [
                        $this->tabSafe($sku),
                        $this->tabSafe($standard_id),
                        $this->flatFileIdType($standard_id_type),
                        $price,
                        $condition,
                        (int)$product['quantity'],
                        'a',
                        $fulfillment_center
                    ]) . "\n");

                    $written++;

                    continue;
                }

                $title = trim(preg_replace('/\s+/', ' ', html_entity_decode((string)$product['name'], ENT_QUOTES, 'UTF-8')));
                $title = mb_substr($title, 0, 200);

                $description = trim(strip_tags(html_entity_decode((string)$product['description'], ENT_QUOTES, 'UTF-8')));
                $description = mb_substr(trim(preg_replace('/\s+/', ' ', $description)), 0, 2000);

                $brand = trim((string)($product['manufacturer'] ?? ''));
                $mpn = $this->firstIdentifier($product, $product_identifiers, ['MPN']);

                if ($mpn === '') {
                    $mpn = trim((string)$product['model']);
                }

                $bullets = [];

                if ($bullet_attribute_id && isset($product_attributes[$bullet_attribute_id])) {
                    foreach (preg_split('/\r\n|\r|\n|\|/', $product_attributes[$bullet_attribute_id]) as $bullet) {
                        $bullet = trim($bullet);

                        if ($bullet !== '') {
                            $bullets[] = mb_substr($bullet, 0, 500);
                        }

                        if (count($bullets) >= 5) {
                            break;
                        }
                    }
                }

                $item = [];
                $item[] = '<Message>';
                $item[] = '<MessageID>' . ($written + 1) . '</MessageID>';
                $item[] = '<OperationType>Update</OperationType>';
                $item[] = '<Product>';
                $item[] = '<SKU>' . $this->xmlEscape($sku) . '</SKU>';

                if ($standard_id !== '') {
                    $item[] = '<StandardProductID>';
                    $item[] = '<Type>' . $this->xmlEscape($standard_id_type) . '</Type>';
                    $item[] = '<Value>' . $this->xmlEscape($standard_id) . '</Value>';
                    $item[] = '</StandardProductID>';
                }

                $item[] = '<Condition><ConditionType>' . $this->conditionType($condition) . '</ConditionType></Condition>';
                $item[] = '<DescriptionData>';
                $item[] = '<Title>' . $this->cdata($title) . '</Title>';

                if ($brand !== '') {
                    $item[] = '<Brand>' . $this->cdata($brand) . '</Brand>';
                }

                if ($description !== '') {
                    $item[] = '<Description>' . $this->cdata($description) . '</Description>';
                }

                foreach ($bullets as $bullet) {
                    $item[] = '<BulletPoint>' . $this->cdata($bullet) . '</BulletPoint>';
                }

                if ($brand !== '') {
                    $item[] = '<Manufacturer>' . $this->cdata($brand) . '</Manufacturer>';
                }

                if ($mpn !== '') {
                    $item[] = '<MfrPartNumber>' . $this->xmlEscape($mpn) . '</MfrPartNumber>';
                }

                $item[] = '</DescriptionData>';
                $item[] = '</Product>';
                $item[] = '</Message>';

                fwrite($handle, implode("\n", $item) . "\n");

                $written++;
            }

            if (count($products) < $limit) {
                break;
            }

            $start += $limit;
        }

        if ($format === 'xml') {
            fwrite($handle, '</AmazonEnvelope>');
        }

        if ($cacheable) {
            fclose($handle);

            if (!@rename($tmp_file, $cache_file)) {
                @unlink($tmp_file);
            }

            return is_file($cache_file) ? (string)file_get_contents($cache_file) : '';
        }

        rewind($handle);
        $output = (string)stream_get_contents($handle);
        fclose($handle);

        return $output;
    }

    private function conditionType(string $condition): string {
        $map = [
            '11' => 'New',
            '10' => 'Refurbished',
            '4'  => 'UsedGood'
        ];

        return $map[$condition] ?? 'New';
    }

    private function flatFileIdType(string $type): string {
        $map = [
            'ASIN' => '1',
            'ISBN' => '2',
            'UPC'  => '3',
            'EAN'  => '4'
        ];

        return $map[$type] ?? '';
    }

    private function tabSafe(string $value): string {
        return trim(str_replace(["\t", "\r", "\n"], ' ', $value));
    }

    private function getProducts(int $language_id, int $store_id, int $include_out_of_stock, array $excluded_categories, int $start, int $limit): array {
        $sql = "SELECT `p`.`product_id`, `p`.`model`, `p`.`price`, `p`.`quantity`, `p`.`image`, `p`.`tax_class_id`";

        foreach ($this->getLegacyIdentifierColumns() as $column) {
            $sql .= ", `p`.`" . $column . "`";
        }

        $sql .= ", `pd`.`name`, `pd`.`description`, `m`.`name` AS `manufacturer`";
        $sql .= ", (SELECT MIN(`p2c`.`category_id`) FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`product_id` = `p`.`product_id`) AS `category_id`";
        $sql .= ", (SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1) AS `special`";
        $sql .= " FROM `" . DB_PREFIX . "product` `p`";
        $sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `p`.`product_id` AND `p2s`.`store_id` = '" . $store_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `p`.`product_id` AND `pd`.`language_id` = '" . $language_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "manufacturer` `m` ON (`m`.`manufacturer_id` = `p`.`manufacturer_id`)";
        $sql .= " WHERE `p`.`status` = '1' AND `p`.`date_available` <= NOW()";

        if (!$include_out_of_stock) {
            $sql .= " AND `p`.`quantity` > 0";
        }

        if ($excluded_categories) {
            $sql .= " AND `p`.`product_id` NOT IN (SELECT `product_id` FROM `" . DB_PREFIX . "product_to_category` WHERE `category_id` IN (" . implode(',', $excluded_categories) . "))";
        }

        $sql .= " ORDER BY `p`.`product_id` ASC LIMIT " . $start . "," . $limit;

        return $this->db->query($sql)->rows;
    }

    /**
     * OpenCart 4.1 keeps SKU/UPC/EAN/JAN/ISBN/MPN in `product_code`, but stores upgraded from
     * 4.0 have the legacy `product` columns dropped while fresh 4.1 installs still have them.
     * Only select the ones that actually exist so the feed query cannot fatal.
     */
    private function getLegacyIdentifierColumns(): array {
        if (!$this->product_columns) {
            foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`")->rows as $row) {
                $this->product_columns[strtolower((string)$row['Field'])] = true;
            }
        }

        $columns = [];

        foreach (['sku', 'upc', 'ean', 'jan', 'isbn', 'mpn'] as $column) {
            if (isset($this->product_columns[$column])) {
                $columns[] = $column;
            }
        }

        return $columns;
    }

    private function getIdentifiers(array $product_ids): array {
        if (!$product_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `value` != ''");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][strtoupper((string)$row['code'])] = (string)$row['value'];
        }

        return $result;
    }

    /**
     * product_code rows win over the legacy product columns when both are present.
     */
    private function firstIdentifier(array $product, array $product_identifiers, array $codes): string {
        foreach ($codes as $code) {
            if (isset($product_identifiers[$code]) && trim($product_identifiers[$code]) !== '') {
                return trim($product_identifiers[$code]);
            }

            $column = strtolower($code);

            if (isset($product[$column]) && trim((string)$product[$column]) !== '') {
                return trim((string)$product[$column]);
            }
        }

        return '';
    }

    private function getAttributes(array $product_ids, int $language_id, array $attribute_ids): array {
        $attribute_ids = array_values(array_unique(array_filter(array_map('intval', $attribute_ids))));

        if (!$product_ids || !$attribute_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `attribute_id`, `text` FROM `" . DB_PREFIX . "product_attribute` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `language_id` = '" . $language_id . "' AND `attribute_id` IN (" . implode(',', $attribute_ids) . ")");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][(int)$row['attribute_id']] = html_entity_decode((string)$row['text'], ENT_QUOTES, 'UTF-8');
        }

        return $result;
    }

    private function convertPrice(float $value, int $tax_class_id, bool $include_tax, string $from, string $to): string {
        if ($include_tax && $this->registry->has('tax')) {
            $value = (float)$this->tax->calculate($value, $tax_class_id, true);
        }

        return number_format((float)$this->currency->convert($value, $from, $to), 2, '.', '');
    }

    private function clean(string $value): string {
        if (!mb_check_encoding($value, 'UTF-8')) {
            $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }

        $value = preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $value);

        return $value === null ? '' : $value;
    }

    private function xmlEscape(string $value): string {
        return htmlspecialchars($this->clean($value), ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private function cdata(string $value): string {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $this->clean($value)) . ']]>';
    }
}
