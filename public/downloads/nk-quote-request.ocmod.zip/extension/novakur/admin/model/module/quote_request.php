<?php
namespace Opencart\Admin\Model\Extension\Novakur\Module;

/**
 * NovaKur B2B Quote Request - admin model.
 *
 * Owns the `nk_quote` / `nk_quote_item` tables. All user supplied values are
 * escaped with $this->db->escape() or cast to int/float before they reach SQL.
 */
class QuoteRequest extends \Opencart\System\Engine\Model {
    public const STATUSES = ['pending', 'quoted', 'accepted', 'expired'];

    /**
     * Create the custom tables. Called from the admin controller install().
     */
    public function createTables(): void {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_quote` (
            `quote_id` int(11) NOT NULL AUTO_INCREMENT,
            `store_id` int(11) NOT NULL DEFAULT '0',
            `customer_id` int(11) NOT NULL DEFAULT '0',
            `language_id` int(11) NOT NULL DEFAULT '0',
            `company` varchar(128) NOT NULL DEFAULT '',
            `name` varchar(96) NOT NULL DEFAULT '',
            `email` varchar(96) NOT NULL DEFAULT '',
            `telephone` varchar(32) NOT NULL DEFAULT '',
            `comment` text,
            `admin_note` text,
            `currency_code` varchar(3) NOT NULL DEFAULT '',
            `currency_value` decimal(15,8) NOT NULL DEFAULT '1.00000000',
            `status` varchar(16) NOT NULL DEFAULT 'pending',
            `token` varchar(64) NOT NULL DEFAULT '',
            `valid_days` int(11) NOT NULL DEFAULT '0',
            `ip` varchar(40) NOT NULL DEFAULT '',
            `date_added` datetime NOT NULL,
            `date_modified` datetime NOT NULL,
            `date_sent` datetime DEFAULT NULL,
            `date_expires` datetime DEFAULT NULL,
            `date_accepted` datetime DEFAULT NULL,
            PRIMARY KEY (`quote_id`),
            KEY `nk_quote_status` (`status`),
            KEY `nk_quote_token` (`token`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_quote_item` (
            `quote_item_id` int(11) NOT NULL AUTO_INCREMENT,
            `quote_id` int(11) NOT NULL DEFAULT '0',
            `product_id` int(11) NOT NULL DEFAULT '0',
            `name` varchar(255) NOT NULL DEFAULT '',
            `model` varchar(64) NOT NULL DEFAULT '',
            `quantity` int(11) NOT NULL DEFAULT '1',
            `price` decimal(15,4) NOT NULL DEFAULT '0.0000',
            `quoted_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
            `option` text,
            `subscription_plan_id` int(11) NOT NULL DEFAULT '0',
            PRIMARY KEY (`quote_item_id`),
            KEY `nk_quote_item_quote_id` (`quote_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    /**
     * Drop the custom tables. Called from the admin controller uninstall().
     */
    public function dropTables(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "nk_quote_item`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "nk_quote`");
    }

    /**
     * @return array<string, mixed>
     */
    public function getQuote(int $quote_id): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_quote` WHERE `quote_id` = '" . (int)$quote_id . "'");

        return $query->row;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getItems(int $quote_id): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_quote_item` WHERE `quote_id` = '" . (int)$quote_id . "' ORDER BY `quote_item_id` ASC");

        return $query->rows;
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<int, array<string, mixed>>
     */
    public function getQuotes(array $data = []): array {
        $sql = "SELECT * FROM `" . DB_PREFIX . "nk_quote` WHERE 1";

        $sql .= $this->buildFilter($data);

        $sort_data = ['quote_id', 'company', 'name', 'email', 'status', 'date_added'];

        if (isset($data['sort']) && in_array($data['sort'], $sort_data, true)) {
            $sql .= " ORDER BY `" . $data['sort'] . "`";
        } else {
            $sql .= " ORDER BY `quote_id`";
        }

        if (isset($data['order']) && strtoupper((string)$data['order']) === 'ASC') {
            $sql .= " ASC";
        } else {
            $sql .= " DESC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            $start = isset($data['start']) ? (int)$data['start'] : 0;
            $limit = isset($data['limit']) ? (int)$data['limit'] : 20;

            if ($start < 0) {
                $start = 0;
            }

            if ($limit < 1) {
                $limit = 20;
            }

            $sql .= " LIMIT " . $start . "," . $limit;
        }

        $query = $this->db->query($sql);

        return $query->rows;
    }

    /**
     * @param array<string, mixed> $data
     */
    public function getTotalQuotes(array $data = []): int {
        $query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_quote` WHERE 1" . $this->buildFilter($data));

        return (int)$query->row['total'];
    }

    /**
     * @param array<string, mixed> $data
     */
    private function buildFilter(array $data): string {
        $sql = '';

        if (!empty($data['filter_company'])) {
            $sql .= " AND `company` LIKE '" . $this->db->escape((string)$data['filter_company'] . '%') . "'";
        }

        if (!empty($data['filter_email'])) {
            $sql .= " AND `email` LIKE '" . $this->db->escape((string)$data['filter_email'] . '%') . "'";
        }

        if (!empty($data['filter_status']) && in_array((string)$data['filter_status'], self::STATUSES, true)) {
            $sql .= " AND `status` = '" . $this->db->escape((string)$data['filter_status']) . "'";
        }

        if (!empty($data['filter_date_from'])) {
            $sql .= " AND DATE(`date_added`) >= DATE('" . $this->db->escape((string)$data['filter_date_from']) . "')";
        }

        if (!empty($data['filter_date_to'])) {
            $sql .= " AND DATE(`date_added`) <= DATE('" . $this->db->escape((string)$data['filter_date_to']) . "')";
        }

        return $sql;
    }

    /**
     * Persist merchant edits: per line quoted price / quantity, validity and note.
     *
     * @param array<int, array<string, mixed>> $items
     */
    public function editQuote(int $quote_id, array $items, int $valid_days, string $admin_note): void {
        foreach ($items as $quote_item_id => $item) {
            $quantity = isset($item['quantity']) ? (int)$item['quantity'] : 1;

            if ($quantity < 1) {
                $quantity = 1;
            }

            $quoted_price = isset($item['quoted_price']) ? (float)$item['quoted_price'] : 0.0;

            if ($quoted_price < 0) {
                $quoted_price = 0.0;
            }

            $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote_item` SET `quantity` = '" . (int)$quantity . "', `quoted_price` = '" . (float)$quoted_price . "' WHERE `quote_item_id` = '" . (int)$quote_item_id . "' AND `quote_id` = '" . (int)$quote_id . "'");
        }

        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `valid_days` = '" . (int)$valid_days . "', `admin_note` = '" . $this->db->escape($admin_note) . "', `date_modified` = NOW() WHERE `quote_id` = '" . (int)$quote_id . "'");
    }

    /**
     * Mark the quote as sent: issue an accept token and set the expiry window.
     *
     * @return string the accept token
     */
    public function markSent(int $quote_id, int $valid_days): string {
        $quote_info = $this->getQuote($quote_id);

        if (!$quote_info) {
            return '';
        }

        $token = (string)$quote_info['token'];

        if (!$token) {
            $token = bin2hex(random_bytes(32));
        }

        if ($valid_days < 1) {
            $valid_days = 1;
        }

        // An already accepted quote keeps its status; re-sending only refreshes the copy.
        $status = ($quote_info['status'] === 'accepted') ? 'accepted' : 'quoted';

        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `status` = '" . $this->db->escape($status) . "', `token` = '" . $this->db->escape($token) . "', `valid_days` = '" . (int)$valid_days . "', `date_sent` = NOW(), `date_expires` = DATE_ADD(NOW(), INTERVAL " . (int)$valid_days . " DAY), `date_modified` = NOW() WHERE `quote_id` = '" . (int)$quote_id . "'");

        return $token;
    }

    public function editStatus(int $quote_id, string $status): void {
        if (!in_array($status, self::STATUSES, true)) {
            return;
        }

        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `status` = '" . $this->db->escape($status) . "', `date_modified` = NOW() WHERE `quote_id` = '" . (int)$quote_id . "'");
    }

    public function deleteQuote(int $quote_id): void {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nk_quote_item` WHERE `quote_id` = '" . (int)$quote_id . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "nk_quote` WHERE `quote_id` = '" . (int)$quote_id . "'");
    }

    /**
     * Number of quotes still waiting for a merchant price.
     */
    public function getTotalPending(): int {
        $query = $this->db->query("SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_quote` WHERE `status` = 'pending'");

        return (int)$query->row['total'];
    }
}
