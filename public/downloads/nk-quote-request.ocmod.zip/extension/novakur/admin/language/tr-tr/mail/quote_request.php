<?php
$_['text_subject']      = '%s - #%s numaralı teklifiniz hazır';
$_['text_greeting']     = 'Merhaba %s,';
$_['text_intro']        = '#%s numaralı talebiniz için %s teklifimiz aşağıdadır.';
$_['text_valid_until']  = 'Bu teklif %s tarihine kadar geçerlidir.';
$_['text_accept']       = 'Teklifi kabul et ve ödemeye geç';
$_['text_accept_hint']  = 'Düğme çalışmazsa bu bağlantıyı tarayıcınıza yapıştırın:';
$_['text_note']         = 'Notumuz';
$_['text_ex_tax']       = 'Fiyatlara vergi ve kargo dahil değildir; her ikisi de ödeme adımında hesaplanır.';
$_['text_thanks']       = 'İş birliğiniz için teşekkür ederiz,';
$_['text_total']        = 'Teklif Toplamı';
$_['column_product']    = 'Ürün';
$_['column_model']      = 'Model';
$_['column_quantity']   = 'Adet';
$_['column_price']      = 'Birim Fiyat';
$_['column_total']      = 'Toplam';
