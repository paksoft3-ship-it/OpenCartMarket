<?php
// Heading
$_['heading_title']           = 'NovaKur B2B Teklif Talebi';
$_['heading_quotes']          = 'Teklif Talepleri';
$_['heading_quote']           = 'Teklif #%s';

// Text
$_['text_extension']          = 'Eklentiler';
$_['text_success']            = 'Başarılı: NovaKur B2B Teklif Talebi ayarları güncellendi!';
$_['text_edit']               = 'NovaKur B2B Teklif Talebi Ayarları';
$_['text_enabled']            = 'Etkin';
$_['text_disabled']           = 'Devre Dışı';
$_['text_list']               = 'Teklif Talepleri';
$_['text_filter']             = 'Filtrele';
$_['text_quotes']             = 'Teklif Talepleri';
$_['text_quote_detail']       = 'Teklif Ayarları';
$_['text_customer']           = 'Talep Eden';
$_['text_items']              = 'Teklif Satırları';
$_['text_expire_cron']        = 'Süre Dolumu Cron Adresi';
$_['text_no_results']         = 'Teklif talebi bulunamadı!';
$_['text_not_found']          = 'Teklif talebi bulunamadı.';
$_['text_none']               = '--';
$_['text_select_status']      = '-- Tüm durumlar --';
$_['text_confirm']            = 'Seçili teklif taleplerini silmek istediğinizden emin misiniz?';
$_['text_confirm_send']       = 'Bu teklif kaydedilip müşteriye şimdi e-posta ile gönderilsin mi?';
$_['text_quote_saved']        = 'Başarılı: Teklif kaydedildi.';
$_['text_quote_sent']         = 'Başarılı: Teklif müşteriye e-posta ile gönderildi.';
$_['text_quote_deleted']      = 'Başarılı: Seçili teklif talepleri silindi.';
$_['text_pending_badge']      = 'beklemede';
$_['text_ex_tax']             = 'vergi ve kargo hariç';
$_['text_tables_missing']     = 'Uyarı: Teklif tabloları bulunamadı. Kurulum rutininin tabloları oluşturabilmesi için modülü Eklentiler > Modüller altından kaldırıp yeniden kurun.';
$_['text_pagination']         = 'Gösterilen: %d - %d / %d (%d Sayfa)';

// Status
$_['text_status_pending']     = 'Beklemede';
$_['text_status_quoted']      = 'Teklif Verildi';
$_['text_status_accepted']    = 'Kabul Edildi';
$_['text_status_expired']     = 'Süresi Doldu';

// Column
$_['column_quote_id']         = 'Teklif No';
$_['column_company']          = 'Firma';
$_['column_contact']          = 'Yetkili';
$_['column_email']            = 'E-Posta';
$_['column_product']          = 'Ürün';
$_['column_model']            = 'Model';
$_['column_quantity']         = 'Adet';
$_['column_list_price']       = 'Liste Fiyatı';
$_['column_quoted_price']     = 'Teklif Birim Fiyatı';
$_['column_line_total']       = 'Satır Toplamı';
$_['column_total']            = 'Toplam';
$_['column_status']           = 'Durum';
$_['column_date_added']       = 'Talep Tarihi';
$_['column_action']           = 'İşlem';

// Entry
$_['entry_status']            = 'Durum';
$_['entry_validity_days']     = 'Varsayılan Geçerlilik (gün)';
$_['entry_notify_email']      = 'Bildirim E-Postası';
$_['entry_cron_token']        = 'Cron Anahtarı';
$_['entry_company']           = 'Firma';
$_['entry_name']              = 'Yetkili Adı';
$_['entry_email']             = 'E-Posta';
$_['entry_telephone']         = 'Telefon';
$_['entry_comment']           = 'Müşteri Notu';
$_['entry_admin_note']        = 'Müşteriye Not';
$_['entry_date_from']         = 'Başlangıç Tarihi';
$_['entry_date_to']           = 'Bitiş Tarihi';
$_['entry_date_added']        = 'Talep Edildi';
$_['entry_date_sent']         = 'Teklif Tarihi';
$_['entry_date_expires']      = 'Son Geçerlilik';
$_['entry_accept_link']       = 'Kabul Bağlantısı';

// Help
$_['help_validity_days']      = 'Gönderilen bir teklifin kaç gün kabul edilebilir kalacağı. Her yeni teklifte başlangıç değeri olarak kullanılır; teklif bazında değiştirebilirsiniz.';
$_['help_notify_email']       = 'Yeni teklif taleplerinin bildirileceği adres. Boş bırakırsanız mağaza e-posta adresi kullanılır.';
$_['help_cron_token']         = 'Aşağıdaki süre dolumu adresinin gizli anahtarı. Bu adresi cron ile (örneğin günlük) çağırarak geçerlilik tarihi geçmiş teklifleri Süresi Doldu durumuna alın. Eski adresi iptal etmek için anahtarı değiştirin.';
$_['help_quoted_price']       = 'Teklif birim fiyatları, katalogdaki ürün fiyatları gibi mağaza varsayılan para biriminde (%s) ve vergi hariç girilir. Normal fiyattan teklif vermek için satırı liste fiyatında bırakın.';
$_['help_send']               = 'Gönderme işlemi değişiklikleri kaydeder, geçerlilik süresini damgalar ve müşteriye tek kullanımlık bir kabul bağlantısı e-postalar. Müşteri bu bağlantıyı izlediğinde sepeti burada verdiğiniz fiyatlarla yeniden oluşturulur.';

// Button
$_['button_save']             = 'Kaydet';
$_['button_back']             = 'Geri';
$_['button_quotes']           = 'Teklif Talepleri';
$_['button_filter']           = 'Filtrele';
$_['button_delete']           = 'Sil';
$_['button_view']             = 'Görüntüle';
$_['button_edit']             = 'Düzenle';
$_['button_send']             = 'Teklifi Gönder';
$_['button_copy']             = 'Kopyala';

// Error
$_['error_permission']        = 'Uyarı: Bu modülü değiştirme yetkiniz yok!';
$_['error_validity_days']     = 'Geçerlilik süresi 1 ile 365 gün arasında olmalıdır!';
$_['error_notify_email']      = 'Bildirim e-posta adresi geçerli değil!';
$_['error_quote']             = 'Uyarı: Teklif talebi bulunamadı!';
$_['error_quote_email']       = 'Uyarı: Bu teklifte gönderilecek geçerli bir e-posta adresi yok!';
$_['error_mail_engine']       = 'Uyarı: Yapılandırılmış bir e-posta motoru yok. Önce Sistem > Ayarlar > Posta bölümünden bir tane seçin.';
$_['error_mail']              = 'Uyarı: Teklif gönderilemedi (%s).';
$_['error_quantity']          = 'Adetler 1 veya daha büyük tam sayı olmalıdır!';
$_['error_price']             = 'Teklif fiyatları sıfır veya daha büyük olmalıdır!';
$_['error_admin_note']        = 'Müşteriye not 2000 karakterden kısa olmalıdır!';
$_['error_selection']         = 'Uyarı: Hiçbir teklif talebi seçilmedi!';
