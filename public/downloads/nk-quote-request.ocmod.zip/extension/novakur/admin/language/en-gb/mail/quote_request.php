<?php
$_['text_subject']      = '%s - Your quote #%s is ready';
$_['text_greeting']     = 'Hello %s,';
$_['text_intro']        = 'Here is our quote for your request #%s at %s.';
$_['text_valid_until']  = 'This quote is valid until %s.';
$_['text_accept']       = 'Accept quote and go to checkout';
$_['text_accept_hint']  = 'If the button does not work, paste this link into your browser:';
$_['text_note']         = 'Note from us';
$_['text_ex_tax']       = 'Prices exclude tax and shipping; both are calculated at checkout.';
$_['text_thanks']       = 'Thank you for your business,';
$_['text_total']        = 'Quote Total';
$_['column_product']    = 'Product';
$_['column_model']      = 'Model';
$_['column_quantity']   = 'Quantity';
$_['column_price']      = 'Unit Price';
$_['column_total']      = 'Total';
