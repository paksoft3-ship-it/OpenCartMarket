<?php
// Heading
$_['heading_title']           = 'NovaKur B2B Quote Request';
$_['heading_quotes']          = 'Quote Requests';
$_['heading_quote']           = 'Quote #%s';

// Text
$_['text_extension']          = 'Extensions';
$_['text_success']            = 'Success: You have modified NovaKur B2B Quote Request settings!';
$_['text_edit']               = 'Edit NovaKur B2B Quote Request';
$_['text_enabled']            = 'Enabled';
$_['text_disabled']           = 'Disabled';
$_['text_list']               = 'Quote Requests';
$_['text_filter']             = 'Filter';
$_['text_quotes']             = 'Quote Requests';
$_['text_quote_detail']       = 'Quote Settings';
$_['text_customer']           = 'Requester';
$_['text_items']              = 'Quote Lines';
$_['text_expire_cron']        = 'Expiry Cron URL';
$_['text_no_results']         = 'No quote requests found!';
$_['text_not_found']          = 'Quote request not found.';
$_['text_none']               = '--';
$_['text_select_status']      = '-- All statuses --';
$_['text_confirm']            = 'Are you sure you want to delete the selected quote requests?';
$_['text_confirm_send']       = 'Save this quote and e-mail it to the customer now?';
$_['text_quote_saved']        = 'Success: The quote has been saved.';
$_['text_quote_sent']         = 'Success: The quote has been e-mailed to the customer.';
$_['text_quote_deleted']      = 'Success: The selected quote requests have been deleted.';
$_['text_pending_badge']      = 'pending';
$_['text_ex_tax']             = 'excluding tax and shipping';
$_['text_tables_missing']     = 'Warning: The quote tables are missing. Uninstall and re-install this module from Extensions > Modules so its install routine can create them.';
$_['text_pagination']         = 'Showing %d to %d of %d (%d Pages)';

// Status
$_['text_status_pending']     = 'Pending';
$_['text_status_quoted']      = 'Quoted';
$_['text_status_accepted']    = 'Accepted';
$_['text_status_expired']     = 'Expired';

// Column
$_['column_quote_id']         = 'Quote ID';
$_['column_company']          = 'Company';
$_['column_contact']          = 'Contact';
$_['column_email']            = 'E-Mail';
$_['column_product']          = 'Product';
$_['column_model']            = 'Model';
$_['column_quantity']         = 'Quantity';
$_['column_list_price']       = 'List Price';
$_['column_quoted_price']     = 'Quoted Unit Price';
$_['column_line_total']       = 'Line Total';
$_['column_total']            = 'Total';
$_['column_status']           = 'Status';
$_['column_date_added']       = 'Date Added';
$_['column_action']           = 'Action';

// Entry
$_['entry_status']            = 'Status';
$_['entry_validity_days']     = 'Default Validity (days)';
$_['entry_notify_email']      = 'Notification E-Mail';
$_['entry_cron_token']        = 'Cron Token';
$_['entry_company']           = 'Company';
$_['entry_name']              = 'Contact Name';
$_['entry_email']             = 'E-Mail';
$_['entry_telephone']         = 'Telephone';
$_['entry_comment']           = 'Customer Note';
$_['entry_admin_note']        = 'Note to Customer';
$_['entry_date_from']         = 'Date From';
$_['entry_date_to']           = 'Date To';
$_['entry_date_added']        = 'Requested';
$_['entry_date_sent']         = 'Quoted On';
$_['entry_date_expires']      = 'Valid Until';
$_['entry_accept_link']       = 'Accept Link';

// Help
$_['help_validity_days']      = 'How many days a sent quote stays acceptable. Used as the starting value on every new quote; you can override it per quote.';
$_['help_notify_email']       = 'Where new quote requests are announced. Leave empty to use the store e-mail address.';
$_['help_cron_token']         = 'Secret used by the expiry URL below. Call that URL from cron (for example daily) to flip quotes past their validity date to Expired. Change the token here to revoke the old URL.';
$_['help_quoted_price']       = 'Quoted unit prices are entered in the store default currency (%s), excluding tax - exactly like product prices in the catalogue. Leave a line at its list price to quote the normal price.';
$_['help_send']               = 'Sending saves your changes, stamps the validity window and e-mails the customer a one-time accept link. Following that link rebuilds their cart at the prices you quoted here.';

// Button
$_['button_save']             = 'Save';
$_['button_back']             = 'Back';
$_['button_quotes']           = 'Quote Requests';
$_['button_filter']           = 'Filter';
$_['button_delete']           = 'Delete';
$_['button_view']             = 'View';
$_['button_edit']             = 'Edit';
$_['button_send']             = 'Send Quote';
$_['button_copy']             = 'Copy';

// Error
$_['error_permission']        = 'Warning: You do not have permission to modify this module!';
$_['error_validity_days']     = 'Validity must be between 1 and 365 days!';
$_['error_notify_email']      = 'The notification e-mail address is not valid!';
$_['error_quote']             = 'Warning: That quote request could not be found!';
$_['error_quote_email']       = 'Warning: This quote has no valid e-mail address to send to!';
$_['error_mail_engine']       = 'Warning: No mail engine is configured. Set one under System > Settings > Mail first.';
$_['error_mail']              = 'Warning: The quote could not be sent (%s).';
$_['error_quantity']          = 'Quantities must be whole numbers of 1 or more!';
$_['error_price']             = 'Quoted prices must be zero or greater!';
$_['error_admin_note']        = 'The note to the customer must be shorter than 2000 characters!';
$_['error_selection']         = 'Warning: No quote requests were selected!';
