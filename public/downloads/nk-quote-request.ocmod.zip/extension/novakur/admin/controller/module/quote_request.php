<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

/**
 * NovaKur B2B Quote Request - admin controller.
 *
 * Routes (all guarded by the `extension/novakur/module/quote_request` permission,
 * because OpenCart strips the `.method` suffix before checking permissions):
 *
 *   .index      settings form
 *   .save       settings save (ajax)
 *   .quotes     quote list page
 *   .list       quote list partial (ajax: sort / paginate / filter)
 *   .quote      quote detail form
 *   .quoteSave  save merchant prices, quantities, validity and note (ajax)
 *   .send       save + e-mail the quote with the accept link (ajax)
 *   .delete     delete selected quotes (ajax)
 */
class QuoteRequest extends \Opencart\System\Engine\Controller {
    public const STATUSES = ['pending', 'quoted', 'accepted', 'expired'];

    /**
     * Setting keys with their factory defaults.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_quote_request_status'        => '0',
            'module_quote_request_validity_days' => '14',
            'module_quote_request_notify_email'  => (string)$this->config->get('config_email'),
            'module_quote_request_cron_token'    => ''
        ];
    }

    public function index(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');

        $settings = $this->model_setting_setting->getSetting('module_quote_request', $store_id);

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        if (!$data['module_quote_request_cron_token']) {
            $data['module_quote_request_cron_token'] = bin2hex(random_bytes(16));
        }

        foreach (['heading_title', 'text_edit', 'text_enabled', 'text_disabled', 'text_quotes', 'text_expire_cron', 'entry_status', 'entry_validity_days', 'entry_notify_email', 'entry_cron_token', 'help_validity_days', 'help_notify_email', 'help_cron_token', 'button_copy', 'button_quotes', 'button_save', 'button_back'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $store_url = $this->getStoreUrl($store_id);

        $data['expire_url'] = html_entity_decode($store_url . 'index.php?route=extension/novakur/module/quote_request.expire&token=' . rawurlencode((string)$data['module_quote_request_cron_token']), ENT_QUOTES, 'UTF-8');

        // Table presence tells the merchant whether install() ran.
        $data['tables_ready'] = $this->tablesExist();
        $data['text_tables_missing'] = $this->language->get('text_tables_missing');

        if ($data['tables_ready']) {
            $this->load->model('extension/novakur/module/quote_request');

            $data['total_pending'] = $this->model_extension_novakur_module_quote_request->getTotalPending();
        } else {
            $data['total_pending'] = 0;
        }

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/novakur/module/quote_request', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/novakur/module/quote_request.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['quotes'] = $this->url->link('extension/novakur/module/quote_request.quotes', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/module/quote_request', $data));
    }

    public function save(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/novakur/module/quote_request')) {
            $json['error'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;

        $validity_days = isset($post['module_quote_request_validity_days']) ? (int)$post['module_quote_request_validity_days'] : 14;

        if ($validity_days < 1 || $validity_days > 365) {
            $json['error'] = $this->language->get('error_validity_days');
        }

        $notify_email = trim((string)($post['module_quote_request_notify_email'] ?? ''));

        if ($notify_email !== '' && !filter_var($notify_email, FILTER_VALIDATE_EMAIL)) {
            $json['error'] = $this->language->get('error_notify_email');
        }

        if (!isset($json['error'])) {
            $cron_token = preg_replace('/[^a-zA-Z0-9]/', '', (string)($post['module_quote_request_cron_token'] ?? ''));

            if (strlen((string)$cron_token) < 16) {
                $cron_token = bin2hex(random_bytes(16));
            }

            $save = [
                'module_quote_request_status'        => isset($post['module_quote_request_status']) ? (string)(int)$post['module_quote_request_status'] : '0',
                'module_quote_request_validity_days' => (string)$validity_days,
                'module_quote_request_notify_email'  => $notify_email,
                'module_quote_request_cron_token'    => (string)$cron_token
            ];

            $this->load->model('setting/setting');

            $this->model_setting_setting->editSetting('module_quote_request', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Quote list                                                          */
    /* ------------------------------------------------------------------ */

    public function quotes(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $this->document->setTitle($this->language->get('heading_quotes'));

        foreach (['heading_title', 'heading_quotes', 'text_list', 'text_filter', 'entry_company', 'entry_email', 'entry_status', 'entry_date_from', 'entry_date_to', 'button_filter', 'button_delete', 'text_confirm', 'text_select_status'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['statuses'] = $this->getStatusOptions();

        $data['filter_company'] = (string)($this->request->get['filter_company'] ?? '');
        $data['filter_email'] = (string)($this->request->get['filter_email'] ?? '');
        $data['filter_status'] = (string)($this->request->get['filter_status'] ?? '');
        $data['filter_date_from'] = (string)($this->request->get['filter_date_from'] ?? '');
        $data['filter_date_to'] = (string)($this->request->get['filter_date_to'] ?? '');

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/novakur/module/quote_request', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_quotes'),
            'href' => $this->url->link('extension/novakur/module/quote_request.quotes', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['list'] = $this->getList();

        $data['delete'] = $this->url->link('extension/novakur/module/quote_request.delete', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('extension/novakur/module/quote_request', 'user_token=' . $this->session->data['user_token']);
        $data['list_url'] = $this->url->link('extension/novakur/module/quote_request.list', 'user_token=' . $this->session->data['user_token']);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/module/quote_request_quotes', $data));
    }

    public function list(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $this->response->setOutput($this->getList());
    }

    private function getList(): string {
        $sort = (string)($this->request->get['sort'] ?? 'quote_id');
        $order = strtoupper((string)($this->request->get['order'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';
        $page = max(1, (int)($this->request->get['page'] ?? 1));

        $filters = [
            'filter_company'   => (string)($this->request->get['filter_company'] ?? ''),
            'filter_email'     => (string)($this->request->get['filter_email'] ?? ''),
            'filter_status'    => (string)($this->request->get['filter_status'] ?? ''),
            'filter_date_from' => (string)($this->request->get['filter_date_from'] ?? ''),
            'filter_date_to'   => (string)($this->request->get['filter_date_to'] ?? '')
        ];

        $url = '';

        foreach ($filters as $key => $value) {
            if ($value !== '') {
                $url .= '&' . $key . '=' . urlencode($value);
            }
        }

        foreach (['column_quote_id', 'column_company', 'column_contact', 'column_email', 'column_total', 'column_status', 'column_date_added', 'column_action', 'text_no_results', 'button_view', 'button_edit'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['status_labels'] = $this->getStatusOptions();

        $limit = (int)$this->config->get('config_pagination_admin');

        if ($limit < 1) {
            $limit = 10;
        }

        $this->load->model('extension/novakur/module/quote_request');

        if (!$this->tablesExist()) {
            $data['quotes'] = [];
            $data['pagination'] = '';
            $data['results'] = '';
            $data['sort'] = $sort;
            $data['order'] = $order;
            $data['action'] = '';
            $data['sort_quote_id'] = '';
            $data['sort_company'] = '';
            $data['sort_email'] = '';
            $data['sort_status'] = '';
            $data['sort_date_added'] = '';

            return $this->load->view('extension/novakur/module/quote_request_list', $data);
        }

        $filter_data = $filters + [
            'sort'  => $sort,
            'order' => $order,
            'start' => ($page - 1) * $limit,
            'limit' => $limit
        ];

        $results = $this->model_extension_novakur_module_quote_request->getQuotes($filter_data);

        $data['quotes'] = [];

        foreach ($results as $result) {
            $items = $this->model_extension_novakur_module_quote_request->getItems((int)$result['quote_id']);

            $total = 0.0;

            foreach ($items as $item) {
                $unit = (float)$item['quoted_price'] > 0 ? (float)$item['quoted_price'] : (float)$item['price'];

                $total += $unit * (int)$item['quantity'];
            }

            $data['quotes'][] = [
                'quote_id'   => (int)$result['quote_id'],
                'company'    => $result['company'],
                'name'       => $result['name'],
                'email'      => $result['email'],
                'status'     => $result['status'],
                'total'      => $this->currency->format($total, $this->config->get('config_currency')),
                'date_added' => date($this->language->get('date_format_short'), strtotime((string)$result['date_added'])),
                'view'       => $this->url->link('extension/novakur/module/quote_request.quote', 'user_token=' . $this->session->data['user_token'] . '&quote_id=' . (int)$result['quote_id'])
            ];
        }

        $quote_total = $this->model_extension_novakur_module_quote_request->getTotalQuotes($filters);

        $data['action'] = $this->url->link('extension/novakur/module/quote_request.list', 'user_token=' . $this->session->data['user_token'] . $url);

        $sort_url = $url . '&order=' . ($order === 'ASC' ? 'DESC' : 'ASC');

        foreach (['quote_id', 'company', 'email', 'status', 'date_added'] as $column) {
            $data['sort_' . $column] = $this->url->link('extension/novakur/module/quote_request.list', 'user_token=' . $this->session->data['user_token'] . '&sort=' . $column . $sort_url);
        }

        $data['pagination'] = $this->load->controller('common/pagination', [
            'total' => $quote_total,
            'page'  => $page,
            'limit' => $limit,
            'url'   => $this->url->link('extension/novakur/module/quote_request.list', 'user_token=' . $this->session->data['user_token'] . '&sort=' . $sort . '&order=' . $order . $url . '&page={page}')
        ]);

        $data['results'] = sprintf($this->language->get('text_pagination'), $quote_total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($quote_total - $limit)) ? $quote_total : ((($page - 1) * $limit) + $limit), $quote_total, (int)ceil($quote_total / $limit));

        $data['sort'] = $sort;
        $data['order'] = $order;

        return $this->load->view('extension/novakur/module/quote_request_list', $data);
    }

    /* ------------------------------------------------------------------ */
    /* Quote detail                                                        */
    /* ------------------------------------------------------------------ */

    public function quote(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $this->document->setTitle($this->language->get('heading_quotes'));

        $quote_id = (int)($this->request->get['quote_id'] ?? 0);

        $this->load->model('extension/novakur/module/quote_request');

        $quote_info = $this->tablesExist() ? $this->model_extension_novakur_module_quote_request->getQuote($quote_id) : [];

        foreach (['heading_quote', 'text_customer', 'text_items', 'text_quote_detail', 'text_not_found', 'text_none', 'text_ex_tax', 'entry_company', 'entry_name', 'entry_email', 'entry_telephone', 'entry_comment', 'entry_admin_note', 'entry_validity_days', 'entry_status', 'entry_date_added', 'entry_date_sent', 'entry_date_expires', 'entry_accept_link', 'column_product', 'column_model', 'column_quantity', 'column_list_price', 'column_quoted_price', 'column_line_total', 'column_total', 'button_save', 'button_send', 'button_back', 'help_quoted_price', 'help_send', 'text_confirm_send', 'text_quote_sent'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['status_labels'] = $this->getStatusOptions();
        $data['quote_id'] = $quote_id;
        $data['found'] = (bool)$quote_info;
        $data['sent'] = isset($this->request->get['sent']);

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_quotes'),
            'href' => $this->url->link('extension/novakur/module/quote_request.quotes', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => sprintf($this->language->get('heading_quote'), $quote_id),
            'href' => $this->url->link('extension/novakur/module/quote_request.quote', 'user_token=' . $this->session->data['user_token'] . '&quote_id=' . $quote_id)
        ];

        $data['back'] = $this->url->link('extension/novakur/module/quote_request.quotes', 'user_token=' . $this->session->data['user_token']);
        $data['save'] = $this->url->link('extension/novakur/module/quote_request.quoteSave', 'user_token=' . $this->session->data['user_token'] . '&quote_id=' . $quote_id);
        $data['send'] = $this->url->link('extension/novakur/module/quote_request.send', 'user_token=' . $this->session->data['user_token'] . '&quote_id=' . $quote_id);

        $data['currency_code'] = (string)$this->config->get('config_currency');

        if ($quote_info) {
            $data['company'] = $quote_info['company'];
            $data['name'] = $quote_info['name'];
            $data['email'] = $quote_info['email'];
            $data['telephone'] = $quote_info['telephone'];
            $data['comment'] = $quote_info['comment'];
            $data['admin_note'] = $quote_info['admin_note'];
            $data['status'] = $quote_info['status'];
            $data['valid_days'] = (int)$quote_info['valid_days'] > 0 ? (int)$quote_info['valid_days'] : (int)$this->config->get('module_quote_request_validity_days');

            if ($data['valid_days'] < 1) {
                $data['valid_days'] = 14;
            }

            $data['date_added'] = date($this->language->get('datetime_format'), strtotime((string)$quote_info['date_added']));
            $data['date_sent'] = $quote_info['date_sent'] ? date($this->language->get('datetime_format'), strtotime((string)$quote_info['date_sent'])) : '';
            $data['date_expires'] = $quote_info['date_expires'] ? date($this->language->get('datetime_format'), strtotime((string)$quote_info['date_expires'])) : '';

            $data['accept_link'] = $quote_info['token'] ? $this->buildAcceptLink((int)$quote_info['store_id'], $quote_id, (string)$quote_info['token']) : '';

            $data['items'] = [];

            $total = 0.0;

            foreach ($this->model_extension_novakur_module_quote_request->getItems($quote_id) as $item) {
                $quoted = (float)$item['quoted_price'] > 0 ? (float)$item['quoted_price'] : (float)$item['price'];

                $total += $quoted * (int)$item['quantity'];

                $data['items'][] = [
                    'quote_item_id' => (int)$item['quote_item_id'],
                    'product_id'    => (int)$item['product_id'],
                    'name'          => $item['name'],
                    'model'         => $item['model'],
                    'quantity'      => (int)$item['quantity'],
                    'price'         => $this->currency->format((float)$item['price'], $this->config->get('config_currency')),
                    'quoted_price'  => number_format($quoted, 4, '.', ''),
                    'line_total'    => $this->currency->format($quoted * (int)$item['quantity'], $this->config->get('config_currency')),
                    'option'        => $this->describeOptions((string)$item['option']),
                    'edit'          => $this->url->link('catalog/product.form', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . (int)$item['product_id'])
                ];
            }

            $data['total'] = $this->currency->format($total, $this->config->get('config_currency'));
        } else {
            $data['company'] = '';
            $data['name'] = '';
            $data['email'] = '';
            $data['telephone'] = '';
            $data['comment'] = '';
            $data['admin_note'] = '';
            $data['status'] = '';
            $data['valid_days'] = (int)$this->config->get('module_quote_request_validity_days');
            $data['date_added'] = '';
            $data['date_sent'] = '';
            $data['date_expires'] = '';
            $data['accept_link'] = '';
            $data['items'] = [];
            $data['total'] = '';
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/module/quote_request_quote', $data));
    }

    public function quoteSave(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $json = $this->persistQuote();

        if (!isset($json['error'])) {
            $json['success'] = $this->language->get('text_quote_saved');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Save the merchant's edits, then e-mail the quote with an accept link.
     */
    public function send(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $json = $this->persistQuote();

        if (!isset($json['error'])) {
            $quote_id = (int)($this->request->get['quote_id'] ?? 0);

            $this->load->model('extension/novakur/module/quote_request');

            $quote_info = $this->model_extension_novakur_module_quote_request->getQuote($quote_id);

            if (!$quote_info) {
                $json['error'] = $this->language->get('error_quote');
            } elseif (!filter_var($quote_info['email'], FILTER_VALIDATE_EMAIL)) {
                $json['error'] = $this->language->get('error_quote_email');
            } elseif (!$this->config->get('config_mail_engine')) {
                $json['error'] = $this->language->get('error_mail_engine');
            } else {
                $token = $this->model_extension_novakur_module_quote_request->markSent($quote_id, (int)$quote_info['valid_days']);

                if (!$token) {
                    $json['error'] = $this->language->get('error_quote');
                } else {
                    try {
                        $this->sendQuoteMail($quote_id);

                        // Reload so the merchant sees the new status, expiry and
                        // accept link straight away.
                        $json['redirect'] = $this->url->link('extension/novakur/module/quote_request.quote', 'user_token=' . $this->session->data['user_token'] . '&quote_id=' . $quote_id . '&sent=1', true);
                    } catch (\Throwable $exception) {
                        $json['error'] = sprintf($this->language->get('error_mail'), $exception->getMessage());
                    }
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Shared validation + persistence used by quoteSave() and send().
     *
     * @return array<string, mixed>
     */
    private function persistQuote(): array {
        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/novakur/module/quote_request')) {
            return ['error' => $this->language->get('error_permission')];
        }

        if (!$this->tablesExist()) {
            return ['error' => $this->language->get('text_tables_missing')];
        }

        $quote_id = (int)($this->request->get['quote_id'] ?? 0);

        $this->load->model('extension/novakur/module/quote_request');

        if (!$this->model_extension_novakur_module_quote_request->getQuote($quote_id)) {
            return ['error' => $this->language->get('error_quote')];
        }

        $valid_days = (int)($this->request->post['valid_days'] ?? 0);

        if ($valid_days < 1 || $valid_days > 365) {
            return ['error' => $this->language->get('error_validity_days')];
        }

        $admin_note = trim((string)($this->request->post['admin_note'] ?? ''));

        if (oc_strlen($admin_note) > 2000) {
            return ['error' => $this->language->get('error_admin_note')];
        }

        $posted = $this->request->post['item'] ?? [];

        $items = [];

        if (is_array($posted)) {
            foreach ($posted as $quote_item_id => $item) {
                if (!is_array($item)) {
                    continue;
                }

                $quantity = (int)($item['quantity'] ?? 1);
                $quoted_price = (float)str_replace(',', '.', (string)($item['quoted_price'] ?? '0'));

                if ($quantity < 1 || $quantity > 999999) {
                    return ['error' => $this->language->get('error_quantity')];
                }

                if ($quoted_price < 0 || $quoted_price > 99999999) {
                    return ['error' => $this->language->get('error_price')];
                }

                $items[(int)$quote_item_id] = [
                    'quantity'     => $quantity,
                    'quoted_price' => $quoted_price
                ];
            }
        }

        $this->model_extension_novakur_module_quote_request->editQuote($quote_id, $items, $valid_days, $admin_note);

        return $json;
    }

    public function delete(): void {
        $this->load->language('extension/novakur/module/quote_request');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/novakur/module/quote_request')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            $selected = $this->request->post['selected'] ?? [];

            if (!is_array($selected) || !$selected) {
                $json['error'] = $this->language->get('error_selection');
            } else {
                $this->load->model('extension/novakur/module/quote_request');

                foreach ($selected as $quote_id) {
                    $this->model_extension_novakur_module_quote_request->deleteQuote((int)$quote_id);
                }

                $json['success'] = $this->language->get('text_quote_deleted');
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Mail                                                                */
    /* ------------------------------------------------------------------ */

    /**
     * Build and send the "your quote is ready" mail. Template lives at
     * extension/novakur/admin/view/template/mail/quote_request.twig and is
     * editable by the merchant.
     */
    private function sendQuoteMail(int $quote_id): void {
        $this->load->model('extension/novakur/module/quote_request');

        $quote_info = $this->model_extension_novakur_module_quote_request->getQuote($quote_id);

        if (!$quote_info) {
            return;
        }

        $store_id = (int)$quote_info['store_id'];

        $this->load->model('setting/store');

        $store_info = $this->model_setting_store->getStore($store_id);

        if ($store_info) {
            $store_name = html_entity_decode((string)$store_info['name'], ENT_QUOTES, 'UTF-8');
        } else {
            $store_name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
        }

        $store_url = $this->getStoreUrl($store_id);

        // Use the language the quote was requested in when it is installed.
        $this->load->model('localisation/language');

        $language_info = $this->model_localisation_language->getLanguage((int)$quote_info['language_id']);

        $language_code = ($language_info && isset($language_info['code'])) ? (string)$language_info['code'] : '';

        // Fall back to the admin language when this module ships no translation
        // for the language the quote was requested in.
        if (!$language_code || !is_file(DIR_EXTENSION . 'novakur/admin/language/' . $language_code . '/mail/quote_request.php')) {
            $language_code = (string)$this->config->get('config_admin_language');
        }

        if (!is_file(DIR_EXTENSION . 'novakur/admin/language/' . $language_code . '/mail/quote_request.php')) {
            $language_code = 'en-gb';
        }

        $language = new \Opencart\System\Library\Language($language_code);
        $language->addPath(DIR_LANGUAGE);
        $language->addPath('extension/novakur', DIR_EXTENSION . 'novakur/admin/language/');
        $language->load($language_code, '', $language_code);
        $language->load('extension/novakur/mail/quote_request', '', $language_code);

        $date_format = $language->get('date_format_short');

        if ($date_format === 'date_format_short') {
            $date_format = 'd/m/Y';
        }

        $currency_code = (string)$this->config->get('config_currency');

        $items = [];

        $total = 0.0;

        foreach ($this->model_extension_novakur_module_quote_request->getItems($quote_id) as $item) {
            $quoted = (float)$item['quoted_price'] > 0 ? (float)$item['quoted_price'] : (float)$item['price'];

            $line = $quoted * (int)$item['quantity'];

            $total += $line;

            $items[] = [
                'name'       => $item['name'],
                'model'      => $item['model'],
                'option'     => $this->describeOptions((string)$item['option']),
                'quantity'   => (int)$item['quantity'],
                'price'      => $this->currency->format($quoted, $currency_code),
                'line_total' => $this->currency->format($line, $currency_code)
            ];
        }

        $data = [
            'text_greeting'     => sprintf($language->get('text_greeting'), html_entity_decode((string)$quote_info['name'], ENT_QUOTES, 'UTF-8')),
            'text_intro'        => sprintf($language->get('text_intro'), $quote_id, $store_name),
            'text_valid_until'  => $quote_info['date_expires'] ? sprintf($language->get('text_valid_until'), date($date_format, strtotime((string)$quote_info['date_expires']))) : '',
            'text_accept'       => $language->get('text_accept'),
            'text_accept_hint'  => $language->get('text_accept_hint'),
            'text_note'         => $language->get('text_note'),
            'text_ex_tax'       => $language->get('text_ex_tax'),
            'text_thanks'       => $language->get('text_thanks'),
            'column_product'    => $language->get('column_product'),
            'column_model'      => $language->get('column_model'),
            'column_quantity'   => $language->get('column_quantity'),
            'column_price'      => $language->get('column_price'),
            'column_total'      => $language->get('column_total'),
            'text_total'        => $language->get('text_total'),
            'company'           => $quote_info['company'],
            'admin_note'        => nl2br(htmlspecialchars((string)$quote_info['admin_note'], ENT_QUOTES, 'UTF-8')),
            'items'             => $items,
            'total'             => $this->currency->format($total, $currency_code),
            'accept'            => $this->buildAcceptLink($store_id, $quote_id, (string)$quote_info['token']),
            'store'             => $store_name,
            'store_url'         => $store_url
        ];

        $mail_option = [
            'parameter'     => $this->config->get('config_mail_parameter'),
            'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
            'smtp_username' => $this->config->get('config_mail_smtp_username'),
            'smtp_password' => html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
            'smtp_port'     => $this->config->get('config_mail_smtp_port'),
            'smtp_timeout'  => $this->config->get('config_mail_smtp_timeout')
        ];

        $mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_option);
        $mail->setTo((string)$quote_info['email']);
        $mail->setFrom((string)$this->config->get('config_email'));
        $mail->setSender($store_name);
        $mail->setSubject(sprintf($language->get('text_subject'), $store_name, $quote_id));
        $mail->setHtml($this->load->view('extension/novakur/mail/quote_request', $data));
        $mail->send();
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                             */
    /* ------------------------------------------------------------------ */

    private function buildAcceptLink(int $store_id, int $quote_id, string $token): string {
        return html_entity_decode($this->getStoreUrl($store_id) . 'index.php?route=extension/novakur/module/quote_request.accept&quote_id=' . $quote_id . '&token=' . rawurlencode($token), ENT_QUOTES, 'UTF-8');
    }

    private function getStoreUrl(int $store_id): string {
        if ($store_id) {
            $this->load->model('setting/store');

            $store_info = $this->model_setting_store->getStore($store_id);

            if ($store_info && !empty($store_info['url'])) {
                return rtrim((string)$store_info['url'], '/') . '/';
            }
        }

        $url = (string)$this->config->get('config_url');

        if (!$url && defined('HTTP_CATALOG')) {
            $url = (string)HTTP_CATALOG;
        }

        return rtrim($url, '/') . '/';
    }

    /**
     * Render the stored option snapshot as a short "Name: Value" list.
     *
     * The storefront stores {"raw": {...}, "display": [{name, value}, ...]} -
     * `raw` is what gets replayed into the cart, `display` is what humans read.
     */
    private function describeOptions(string $json): string {
        $decoded = json_decode($json, true);

        if (!is_array($decoded)) {
            return '';
        }

        $display = (isset($decoded['display']) && is_array($decoded['display'])) ? $decoded['display'] : $decoded;

        $parts = [];

        foreach ($display as $option) {
            if (is_array($option) && isset($option['name'], $option['value'])) {
                $parts[] = $option['name'] . ': ' . $option['value'];
            }
        }

        return implode(', ', $parts);
    }

    /**
     * @return array<string, string>
     */
    private function getStatusOptions(): array {
        $statuses = [];

        foreach (self::STATUSES as $status) {
            $statuses[$status] = $this->language->get('text_status_' . $status);
        }

        return $statuses;
    }

    private function tablesExist(): bool {
        $query = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_quote') . "'");

        return (bool)$query->num_rows;
    }

    /* ------------------------------------------------------------------ */
    /* Install / uninstall                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * Event definitions registered on install and removed on uninstall.
     *
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_quote_request_assets',
                'description' => 'NovaKur Quote Request: loads storefront assets on the product page.',
                'trigger'     => 'catalog/controller/product/product/before',
                'action'      => 'extension/novakur/event/quote_request.productAssets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_quote_request_button',
                'description' => 'NovaKur Quote Request: injects the Add to Quote button into the product page.',
                'trigger'     => 'catalog/view/product/product/after',
                'action'      => 'extension/novakur/event/quote_request.productButton',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_quote_request_cart_sync',
                'description' => 'NovaKur Quote Request: keeps accepted quote prices in sync with cart quantities.',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/novakur/event/quote_request.syncCartPrices',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_quote_request_menu',
                'description' => 'NovaKur Quote Request: adds the Quote Requests link to the admin Sales menu.',
                'trigger'     => 'admin/view/common/column_left/before',
                'action'      => 'extension/novakur/event/quote_request.columnLeft',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $this->model_setting_setting->editSetting('module_quote_request', [
            'module_quote_request_status'        => '0',
            'module_quote_request_validity_days' => '14',
            'module_quote_request_notify_email'  => (string)$this->config->get('config_email'),
            'module_quote_request_cron_token'    => bin2hex(random_bytes(16))
        ]);

        $this->load->model('extension/novakur/module/quote_request');

        $this->model_extension_novakur_module_quote_request->createTables();

        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');

        $this->model_setting_setting->deleteSetting('module_quote_request');

        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('extension/novakur/module/quote_request');

        $this->model_extension_novakur_module_quote_request->dropTables();
    }
}
