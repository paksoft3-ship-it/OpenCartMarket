<?php
// Heading
$_['heading_title']      = 'Teklif İsteyin';

// Text
$_['text_intro']         = 'Aşağıdaki ürünleri gözden geçirin, ihtiyacınız olan adetleri ayarlayın ve bilgilerinizi gönderin. Talebinizi fiyatlandırıp tek tıkla kabul edebileceğiniz bir teklifi e-posta ile ileteceğiz.';
$_['text_your_details']  = 'Bilgileriniz';
$_['text_empty']         = 'Teklif listeniz boş. Herhangi bir ürün sayfasındaki "Teklife Ekle" düğmesiyle başlayabilirsiniz.';
$_['text_total']         = 'Tahmini Toplam';
$_['text_ex_tax']        = 'Bilgi amaçlı liste fiyatları; vergi ve kargo hariçtir.';
$_['text_added']         = 'Başarılı: <a href="%s">Teklif listenize</a> eklendi.';
$_['text_updated']       = 'Başarılı: Teklif listeniz güncellendi.';
$_['text_removed']       = 'Başarılı: Ürün teklif listenizden kaldırıldı.';
$_['text_submitted']     = 'Teşekkürler. #%s numaralı teklif talebiniz gönderildi - fiyatı en kısa sürede e-posta ile ileteceğiz.';
$_['text_accepted']      = '#%s numaralı teklif kabul edildi. Sepetiniz teklif fiyatlarıyla güncellendi - siparişi tamamlamak için ödemeye geçin.';
$_['text_view_basket']   = 'Teklif listesini gör';

// Column
$_['column_product']     = 'Ürün';
$_['column_model']       = 'Model';
$_['column_quantity']    = 'Adet';
$_['column_price']       = 'Liste Fiyatı';
$_['column_total']       = 'Toplam';

// Entry
$_['entry_company']      = 'Firma';
$_['entry_name']         = 'Yetkili Adı';
$_['entry_email']        = 'E-Posta';
$_['entry_telephone']    = 'Telefon';
$_['entry_comment']      = 'Notlarınız';

// Help
$_['help_submit']        = 'Bu bilgileri yalnızca teklifinizi fiyatlandırmak ve göndermek için kullanırız.';

// Button
$_['button_add_quote']   = 'Teklife Ekle';
$_['button_submit']      = 'Teklif Talebi Gönder';
$_['button_continue']    = 'Alışverişe Devam Et';
$_['button_update']      = 'Güncelle';
$_['button_remove']      = 'Kaldır';

// Error
$_['error_disabled']       = 'Teklif talepleri şu anda kullanılamıyor.';
$_['error_product']        = 'Uyarı: Ürün bulunamadı!';
$_['error_empty']          = 'Uyarı: Teklif listeniz boş!';
$_['error_required']       = '%s zorunludur!';
$_['error_regex']          = '%s beklenen biçimde değil!';
$_['error_company']        = 'Firma adı 2 ile 128 karakter arasında olmalıdır!';
$_['error_name']           = 'Yetkili adı 2 ile 96 karakter arasında olmalıdır!';
$_['error_email']          = 'E-posta adresi geçerli görünmüyor!';
$_['error_telephone']      = 'Telefon 32 karakterden kısa olmalıdır!';
$_['error_comment']        = 'Notlar 2000 karakterden kısa olmalıdır!';
$_['error_accept_token']   = 'Bu teklif bağlantısı geçerli değil. Lütfen teklif e-postanızdaki bağlantıyı kullanın.';
$_['error_accept_used']    = 'Bu teklif zaten kabul edilmiş.';
$_['error_accept_status']  = 'Bu teklif henüz kabul edilmeye hazır değil.';
$_['error_accept_expired'] = 'Bu teklifin süresi doldu. Lütfen yeni bir talep gönderin, yeniden fiyatlandıralım.';
$_['error_accept_products'] = 'Teklif edilen ürünlerin hiçbiri artık mevcut değil. Lütfen bizimle iletişime geçin.';
