<?php
// Heading
$_['heading_title']      = 'Request a Quote';

// Text
$_['text_intro']         = 'Review the products below, adjust the quantities you need, then send us your details. We will price the request and e-mail you a quote you can accept in one click.';
$_['text_your_details']  = 'Your Details';
$_['text_empty']         = 'Your quote list is empty. Use the "Add to Quote" button on any product page to start one.';
$_['text_total']         = 'Estimated Total';
$_['text_ex_tax']        = 'Indicative list prices, excluding tax and shipping.';
$_['text_added']         = 'Success: Added to your <a href="%s">quote list</a>.';
$_['text_updated']       = 'Success: Your quote list has been updated.';
$_['text_removed']       = 'Success: The product has been removed from your quote list.';
$_['text_submitted']     = 'Thank you. Your quote request #%s has been sent - we will e-mail you a price shortly.';
$_['text_accepted']      = 'Quote #%s accepted. Your basket now holds the quoted prices - continue to checkout to place the order.';
$_['text_view_basket']   = 'View quote list';

// Column
$_['column_product']     = 'Product';
$_['column_model']       = 'Model';
$_['column_quantity']    = 'Quantity';
$_['column_price']       = 'List Price';
$_['column_total']       = 'Total';

// Entry
$_['entry_company']      = 'Company';
$_['entry_name']         = 'Contact Name';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Telephone';
$_['entry_comment']      = 'Notes for us';

// Help
$_['help_submit']        = 'We only use these details to price and send your quote.';

// Button
$_['button_add_quote']   = 'Add to Quote';
$_['button_submit']      = 'Send Quote Request';
$_['button_continue']    = 'Continue Shopping';
$_['button_update']      = 'Update';
$_['button_remove']      = 'Remove';

// Error
$_['error_disabled']       = 'Quote requests are not available at the moment.';
$_['error_product']        = 'Warning: That product could not be found!';
$_['error_empty']          = 'Warning: Your quote list is empty!';
$_['error_required']       = '%s required!';
$_['error_regex']          = '%s is not in the expected format!';
$_['error_company']        = 'Company must be between 2 and 128 characters!';
$_['error_name']           = 'Contact name must be between 2 and 96 characters!';
$_['error_email']          = 'E-Mail address does not appear to be valid!';
$_['error_telephone']      = 'Telephone must be shorter than 32 characters!';
$_['error_comment']        = 'Notes must be shorter than 2000 characters!';
$_['error_accept_token']   = 'That quote link is not valid. Please use the link from your quote e-mail.';
$_['error_accept_used']    = 'That quote has already been accepted.';
$_['error_accept_status']  = 'That quote is not ready to be accepted yet.';
$_['error_accept_expired'] = 'That quote has expired. Please send a new request and we will re-quote.';
$_['error_accept_products'] = 'None of the quoted products are available any more. Please contact us.';
