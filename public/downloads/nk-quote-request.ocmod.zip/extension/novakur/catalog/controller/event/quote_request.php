<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

/**
 * NovaKur B2B Quote Request - storefront event handlers.
 *
 * productAssets   catalog/controller/product/product/before
 * productButton   catalog/view/product/product/after
 * syncCartPrices  catalog/controller/common/header/before
 */
class QuoteRequest extends \Opencart\System\Engine\Controller {
    /**
     * Queue the module assets before the product controller renders its header,
     * so they land in the normal <head> style/script lists.
     *
     * @param array<int, mixed> $args
     */
    public function productAssets(string &$route, array &$args): void {
        if (!(int)$this->config->get('module_quote_request_status')) {
            return;
        }

        $this->document->addStyle('extension/novakur/catalog/view/assets/css/quote_request.css');
        $this->document->addScript('extension/novakur/catalog/view/assets/js/quote_request.js');
    }

    /**
     * Inject the "Add to Quote" button straight after the theme's Add to Cart
     * button. Falls back to the end of #form-product, and does nothing at all if
     * neither anchor is present, so an unusual theme can never be corrupted.
     *
     * @param array<string, mixed> $data
     */
    public function productButton(string &$route, array &$data, mixed &$output): void {
        if (!(int)$this->config->get('module_quote_request_status')) {
            return;
        }

        if (!is_string($output) || $output === '') {
            return;
        }

        $this->load->language('extension/novakur/module/quote_request');

        $html = $this->load->view('extension/novakur/module/quote_request_button', [
            'product_id'    => (int)($data['product_id'] ?? 0),
            'button_quote'  => $this->language->get('button_add_quote'),
            'text_basket'   => $this->language->get('text_view_basket'),
            'add_url'       => $this->url->link('extension/novakur/module/quote_request.add', 'language=' . $this->config->get('config_language')),
            'basket_url'    => $this->url->link('extension/novakur/module/quote_request', 'language=' . $this->config->get('config_language'))
        ]);

        $anchor = 'id="button-cart"';

        $pos = strpos($output, $anchor);

        if ($pos !== false) {
            $close = strpos($output, '</button>', $pos);

            if ($close !== false) {
                $at = $close + strlen('</button>');

                $output = substr($output, 0, $at) . $html . substr($output, $at);

                return;
            }
        }

        $pos = strpos($output, 'id="form-product"');

        if ($pos !== false) {
            $close = strpos($output, '</form>', $pos);

            if ($close !== false) {
                $output = substr($output, 0, $close) . $html . substr($output, $close);
            }
        }
    }

    /**
     * Keep quoted line totals correct when the shopper edits quantities on the
     * cart page after accepting a quote.
     *
     * Cart::getProducts() computes `total` from the catalogue price and only then
     * copies the `override` keys over it, so the stored `total` has to follow the
     * quantity. One cheap UPDATE per page, and only while the session actually
     * holds an accepted quote.
     *
     * @param array<int, mixed> $args
     */
    public function syncCartPrices(string &$route, array &$args): void {
        if (empty($this->session->data['nk_quote_cart'])) {
            return;
        }

        $query = $this->db->query("SELECT `cart_id`, `quantity`, `override` FROM `" . DB_PREFIX . "cart` WHERE `store_id` = '" . (int)$this->config->get('config_store_id') . "' AND `customer_id` = '" . (int)$this->customer->getId() . "' AND `session_id` = '" . $this->db->escape($this->session->getId()) . "' AND `override` LIKE '%nk_quote_id%'");

        if (!$query->num_rows) {
            unset($this->session->data['nk_quote_cart']);

            return;
        }

        foreach ($query->rows as $row) {
            $override = json_decode((string)$row['override'], true);

            if (!is_array($override) || !isset($override['price'], $override['nk_quote_id'])) {
                continue;
            }

            $expected = (float)$override['price'] * (int)$row['quantity'];

            if (isset($override['total']) && abs((float)$override['total'] - $expected) < 0.00005) {
                continue;
            }

            $override['total'] = $expected;

            $this->db->query("UPDATE `" . DB_PREFIX . "cart` SET `override` = '" . $this->db->escape((string)json_encode($override)) . "' WHERE `cart_id` = '" . (int)$row['cart_id'] . "'");
        }
    }
}
