/**
 * NovaKur B2B Quote Request - storefront behaviour.
 *
 * Only the "Add to Quote" button needs custom scripting: the quote basket form
 * and the submit form use OpenCart's own data-oc-toggle="ajax" handler.
 *
 * The button serialises #form-product so the shopper's selected options,
 * quantity and subscription plan travel with the request, exactly like the
 * theme's own Add to Cart button.
 */
(function () {
    'use strict';

    function alertBox(type, message) {
        var region = document.getElementById('alert');

        if (!region) {
            return;
        }

        var wrapper = document.createElement('div');

        wrapper.className = 'alert alert-' + type + ' alert-dismissible';
        wrapper.innerHTML = '<i class="fa-solid fa-circle-' + (type === 'success' ? 'check' : 'exclamation') + '"></i> ' + message + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button>';

        region.prepend(wrapper);
    }

    function clearFieldErrors(form) {
        if (!form) {
            return;
        }

        form.querySelectorAll('.is-invalid').forEach(function (node) {
            node.classList.remove('is-invalid');
        });

        form.querySelectorAll('.invalid-feedback').forEach(function (node) {
            node.classList.remove('d-block');
        });
    }

    function showFieldError(key, message) {
        var slug = key.replace(/_/g, '-');

        var input = document.getElementById('input-' + slug);
        var error = document.getElementById('error-' + slug);

        if (input) {
            input.classList.add('is-invalid');
        }

        if (error) {
            error.innerHTML = message;
            error.classList.add('d-block');
        }
    }

    document.addEventListener('click', function (event) {
        var button = event.target.closest('#nk-quote-add');

        if (!button) {
            return;
        }

        event.preventDefault();

        var container = button.closest('[data-nk-quote-add]');

        if (!container) {
            return;
        }

        var url = container.getAttribute('data-nk-quote-add').replace(/&amp;/g, '&');

        var productForm = document.getElementById('form-product');

        var body;

        if (productForm) {
            body = new FormData(productForm);
        } else {
            body = new FormData();
            body.append('product_id', button.getAttribute('data-nk-product-id') || '0');
            body.append('quantity', '1');
        }

        // The theme form has no product_id when a theme omits the hidden input.
        if (!body.get('product_id')) {
            body.set('product_id', button.getAttribute('data-nk-product-id') || '0');
        }

        clearFieldErrors(productForm);

        button.disabled = true;

        fetch(url, {
            method: 'POST',
            body: new URLSearchParams(body),
            headers: {'X-Requested-With': 'XMLHttpRequest'},
            credentials: 'same-origin'
        }).then(function (response) {
            return response.json();
        }).then(function (json) {
            document.querySelectorAll('.alert-dismissible').forEach(function (node) {
                node.remove();
            });

            if (json.error) {
                if (json.error.warning) {
                    alertBox('danger', json.error.warning);
                }

                Object.keys(json.error).forEach(function (key) {
                    if (key !== 'warning') {
                        showFieldError(key, json.error[key]);
                    }
                });
            }

            if (json.success) {
                alertBox('success', json.success);
            }
        }).catch(function () {
            alertBox('danger', 'Request failed. Please try again.');
        }).finally(function () {
            button.disabled = false;
        });
    });
}());
