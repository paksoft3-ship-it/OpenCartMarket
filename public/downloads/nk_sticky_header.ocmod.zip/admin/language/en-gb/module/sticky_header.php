<?php
// Heading
$_['heading_title']     = 'NovaKur Sticky Header';

// Text
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: You have modified NovaKur Sticky Header settings!';
$_['text_edit']         = 'Edit NovaKur Sticky Header';
$_['text_enabled']      = 'Enabled';
$_['text_disabled']     = 'Disabled';
$_['text_general']      = 'General';
$_['text_behaviour']    = 'Scroll behaviour';
$_['text_appearance']   = 'Appearance';
$_['text_mode_always']  = 'Always sticky';
$_['text_mode_offset']  = 'Sticky after scroll offset';

// Entry
$_['entry_status']      = 'Status';
$_['entry_mode']        = 'Mode';
$_['entry_offset']      = 'Scroll offset (px)';
$_['entry_compact']     = 'Compact mode';
$_['entry_hide_down']   = 'Hide on scroll down';
$_['entry_shadow']      = 'Drop shadow';
$_['entry_bg_color']    = 'Pinned background';
$_['entry_z_index']     = 'Stacking order (z-index)';
$_['entry_mobile']      = 'Enable on mobile';
$_['entry_selector']    = 'Header selector';

// Help
$_['help_mode']         = '"Always sticky" pins the header from the top of the page. "Sticky after scroll offset" leaves it in the flow until the shopper has scrolled past the distance below.';
$_['help_offset']       = 'Only used in offset mode. Between 0 and 2000.';
$_['help_compact']      = 'Once pinned, reduce the header padding and scale the logo down so it takes less of the screen.';
$_['help_hide_down']    = 'Slide the header out of view while the shopper scrolls down and bring it straight back when they scroll up.';
$_['help_shadow']       = 'Draw a soft shadow under the header while it is pinned, so it separates from the page content.';
$_['help_bg_color']     = 'Background colour applied while pinned. A transparent theme header would otherwise show page content through it.';
$_['help_z_index']      = 'Raise this if another fixed element in your theme overlaps the pinned header. Between 1 and 99999.';
$_['help_mobile']       = 'Turn off to leave the header in the normal flow on screens narrower than 768px.';
$_['help_selector']     = 'Leave blank to use the theme\'s own <header> element. Set a CSS selector (for example: #top-nav) if your theme pins something else.';

// Button
$_['button_save']       = 'Save';
$_['button_back']       = 'Back';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify this module!';
$_['error_mode']        = 'Mode must be always or offset!';
$_['error_offset']      = 'Scroll offset must be between 0 and 2000!';
$_['error_color']       = 'Colour must be a 6 digit hex value, e.g. #FFFFFF!';
$_['error_z_index']     = 'Stacking order must be between 1 and 99999!';
$_['error_selector']    = 'Selector may only contain CSS selector characters and must be under 200 characters!';
