<?php
namespace Opencart\Admin\Controller\Extension\NkStickyHeader\Module;

/**
 * NovaKur Sticky Header
 *
 * Settings namespace: module_sticky_header_*
 * Route:              extension/nk_sticky_header/module/sticky_header
 * Event codes:        nk_sticky_header_assets / nk_sticky_header_render
 */
class StickyHeader extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_sticky_header/module/sticky_header';
    private string $prefix = 'module_sticky_header';

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_sticky_header_status'    => '0',
            'module_sticky_header_mode'      => 'offset',
            'module_sticky_header_offset'    => '120',
            'module_sticky_header_compact'   => '1',
            'module_sticky_header_hide_down' => '0',
            'module_sticky_header_shadow'    => '1',
            'module_sticky_header_bg_color'  => '#FFFFFF',
            'module_sticky_header_z_index'   => '1030',
            'module_sticky_header_mobile'    => '1',
            'module_sticky_header_selector'  => ''
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_sticky_header_assets',
                'description' => 'NovaKur Sticky Header: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_sticky_header/event/sticky_header.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_sticky_header_render',
                'description' => 'NovaKur Sticky Header: configuration element injected into the footer',
                'trigger'     => 'catalog/view/common/footer/after',
                'action'      => 'extension/nk_sticky_header/event/sticky_header.render',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    /**
     * @return array<int, string>
     */
    private function modes(): array {
        return ['always', 'offset'];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_behaviour',
            'text_appearance',
            'text_mode_always',
            'text_mode_offset',
            'entry_status',
            'entry_mode',
            'entry_offset',
            'entry_compact',
            'entry_hide_down',
            'entry_shadow',
            'entry_bg_color',
            'entry_z_index',
            'entry_mobile',
            'entry_selector',
            'help_mode',
            'help_offset',
            'help_compact',
            'help_hide_down',
            'help_shadow',
            'help_bg_color',
            'help_z_index',
            'help_mobile',
            'help_selector',
            'button_save',
            'button_back',
            'error_permission',
            'error_mode',
            'error_offset',
            'error_color',
            'error_z_index',
            'error_selector'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['modes'] = $this->modes();

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        foreach (['status', 'compact', 'hide_down', 'shadow', 'mobile'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // --- Enumerations ----------------------------------------------------
        $mode = trim((string)($post[$this->prefix . '_mode'] ?? 'offset'));

        if (!in_array($mode, $this->modes(), true)) {
            $json['error'][$this->prefix . '_mode'] = $this->language->get('error_mode');
        } else {
            $save[$this->prefix . '_mode'] = $mode;
        }

        // --- Numeric ranges --------------------------------------------------
        foreach (['offset' => [0, 2000], 'z_index' => [1, 99999]] as $key => $range) {
            $value = trim((string)($post[$this->prefix . '_' . $key] ?? ''));

            if (!$this->inRange($value, $range[0], $range[1])) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_' . $key);
            } else {
                $save[$this->prefix . '_' . $key] = (string)(int)$value;
            }
        }

        // --- Colours ---------------------------------------------------------
        $color = strtoupper(trim((string)($post[$this->prefix . '_bg_color'] ?? '')));

        if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
            $json['error'][$this->prefix . '_bg_color'] = $this->language->get('error_color');
        } else {
            $save[$this->prefix . '_bg_color'] = $color;
        }

        // --- Selector override -----------------------------------------------
        $selector = trim((string)($post[$this->prefix . '_selector'] ?? ''));

        if ($selector !== '' && !preg_match('/^[A-Za-z0-9\s,.#_\-\[\]="\':()>+~*^$|]{1,200}$/', $selector)) {
            $json['error'][$this->prefix . '_selector'] = $this->language->get('error_selector');
        } else {
            $save[$this->prefix . '_selector'] = $selector;
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    private function inRange(string $value, int $min, int $max): bool {
        if (!preg_match('/^\d{1,5}$/', $value)) {
            return false;
        }

        $number = (int)$value;

        return $number >= $min && $number <= $max;
    }
}
