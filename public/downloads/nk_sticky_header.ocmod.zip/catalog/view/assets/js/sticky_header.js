/**
 * NovaKur Sticky Header
 *
 * Pins the theme's own <header> element (OpenCart 4.1's default theme renders
 * one in catalog/view/template/common/header.twig) or an admin-configured
 * selector.
 *
 * The header is never cloned. It is switched to position:fixed and a
 * placeholder div of the measured height takes its place in the flow, so the
 * page never jumps at the moment it detaches. Everything degrades to a normal
 * static header if the script does not run.
 */
(function () {
  'use strict';

  function clamp(value, min, max, fallback) {
    var number = parseInt(value, 10);

    if (isNaN(number)) {
      return fallback;
    }

    return Math.min(max, Math.max(min, number));
  }

  function findHeader(selector) {
    var candidates = [];

    if (selector) {
      candidates.push(selector);
    }

    candidates.push('header', '#header', '.header', '#top');

    for (var i = 0; i < candidates.length; i++) {
      var found;

      try {
        found = document.querySelector(candidates[i]);
      } catch (e) {
        // A hand-edited selector setting that isn't valid CSS just gets skipped.
        found = null;
      }

      if (found) {
        return found;
      }
    }

    return null;
  }

  function init() {
    var cfg = document.getElementById('nk-sh');

    if (!cfg) {
      return;
    }

    var mode = cfg.getAttribute('data-mode') === 'always' ? 'always' : 'offset';
    var offset = clamp(cfg.getAttribute('data-offset'), 0, 2000, 120);
    var compact = cfg.getAttribute('data-compact') === '1';
    var hideDown = cfg.getAttribute('data-hide-down') === '1';
    var shadow = cfg.getAttribute('data-shadow') === '1';
    var mobile = cfg.getAttribute('data-mobile') === '1';
    var bgColor = cfg.getAttribute('data-bg-color') || '';
    var zIndex = clamp(cfg.getAttribute('data-z-index'), 1, 99999, 1030);

    var header = findHeader(cfg.getAttribute('data-selector') || '');

    if (!header) {
      return;
    }

    // "always" is offset 0 with the same machinery — one code path, and the
    // placeholder is still measured so the swap is jump-free.
    var threshold = mode === 'always' ? 0 : offset;

    var reduceMotion = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    var mobileQuery = window.matchMedia ? window.matchMedia('(max-width: 767.98px)') : null;

    var placeholder = document.createElement('div');
    placeholder.className = 'nk-sh__placeholder';
    placeholder.setAttribute('aria-hidden', 'true');
    placeholder.style.display = 'none';

    if (header.parentNode) {
      header.parentNode.insertBefore(placeholder, header);
    } else {
      return;
    }

    header.classList.add('nk-sh__header');
    header.style.setProperty('--nk-sh-z', String(zIndex));

    if (bgColor) {
      header.style.setProperty('--nk-sh-bg', bgColor);
    }

    if (shadow) {
      header.classList.add('nk-sh--shadow');
    }

    var pinned = false;
    var hidden = false;
    var height = 0;
    var lastY = window.pageYOffset || document.documentElement.scrollTop || 0;
    var ticking = false;

    function motionOff() {
      return !!(reduceMotion && reduceMotion.matches);
    }

    function disabledHere() {
      // Mobile opt-out: the header stays exactly where the theme put it.
      return !mobile && mobileQuery && mobileQuery.matches;
    }

    function measure() {
      // Measured while unpinned, so the placeholder matches the header's real
      // in-flow height rather than its compact height.
      if (!pinned) {
        height = header.offsetHeight;
      }
    }

    function pin() {
      if (pinned) {
        return;
      }

      measure();

      pinned = true;
      placeholder.style.height = height + 'px';
      placeholder.style.display = 'block';
      header.classList.add('is-pinned');

      if (compact) {
        header.classList.add('is-compact');
      }

      if (motionOff()) {
        header.classList.add('nk-sh--no-motion');
      } else {
        header.classList.remove('nk-sh--no-motion');
      }
    }

    function unpin() {
      if (!pinned) {
        return;
      }

      pinned = false;
      hidden = false;
      placeholder.style.display = 'none';
      header.classList.remove('is-pinned', 'is-compact', 'is-hidden');
    }

    function update() {
      ticking = false;

      if (disabledHere()) {
        unpin();
        lastY = window.pageYOffset || document.documentElement.scrollTop || 0;

        return;
      }

      var y = window.pageYOffset || document.documentElement.scrollTop || 0;

      if (y > threshold) {
        pin();
      } else {
        unpin();
        lastY = y;

        return;
      }

      if (hideDown) {
        // A small dead zone keeps trackpad jitter from flapping the header.
        var delta = y - lastY;

        if (delta > 6 && y > threshold + height) {
          if (!hidden) {
            hidden = true;
            header.classList.add('is-hidden');
          }
        } else if (delta < -6) {
          if (hidden) {
            hidden = false;
            header.classList.remove('is-hidden');
          }
        }
      }

      lastY = y;
    }

    function onScroll() {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(update);
      }
    }

    function onResize() {
      if (pinned) {
        // Re-measure from the real flow height by briefly unpinning.
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;

        unpin();
        measure();
        lastY = y;
      }

      update();
    }

    measure();

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);

    if (mobileQuery && mobileQuery.addEventListener) {
      mobileQuery.addEventListener('change', onResize);
    }

    if (reduceMotion && reduceMotion.addEventListener) {
      reduceMotion.addEventListener('change', function () {
        header.classList.toggle('nk-sh--no-motion', motionOff());
      });
    }

    // Images inside the header (the logo) can change its height after load.
    window.addEventListener('load', onResize);

    update();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}());
