<?php
// Text
// The storefront half of this module renders no visible copy — the header it
// pins is the theme's own. This file exists so the language route resolves for
// any theme or extension that loads it.
$_['text_sticky_header'] = 'Sticky header';
