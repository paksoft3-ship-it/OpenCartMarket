<?php
namespace Opencart\Catalog\Controller\Extension\NkStickyHeader\Event;

/**
 * NovaKur Sticky Header — storefront hooks.
 *
 * assets() catalog/controller/common/header/before → queue CSS/JS
 * render() catalog/view/common/footer/after        → inject the config element
 *
 * There is no visible markup: the config element is a hidden data carrier that
 * the script reads once and then leaves alone. Both hooks fail open.
 */
class StickyHeader extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_sticky_header/catalog/view/assets/css/sticky_header.css';
    private const JS  = 'extension/nk_sticky_header/catalog/view/assets/js/sticky_header.js';

    /**
     * The config element carries an id, so only the first footer render on a
     * page gets one.
     */
    private static bool $rendered = false;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function render(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || self::$rendered || !is_string($output) || $output === '') {
            return;
        }

        self::$rendered = true;

        $html = $this->load->view('extension/nk_sticky_header/module/sticky_header', [
            'mode'      => $this->mode(),
            'offset'    => $this->number('module_sticky_header_offset', 120, 0, 2000),
            'compact'   => (bool)(int)$this->config->get('module_sticky_header_compact'),
            'hide_down' => (bool)(int)$this->config->get('module_sticky_header_hide_down'),
            'shadow'    => (bool)(int)$this->config->get('module_sticky_header_shadow'),
            'mobile'    => (bool)(int)$this->config->get('module_sticky_header_mobile'),
            'bg_color'  => $this->color('module_sticky_header_bg_color', '#FFFFFF'),
            'z_index'   => $this->number('module_sticky_header_z_index', 1030, 1, 99999),
            'selector'  => $this->selector()
        ]);

        if (!is_string($html) || $html === '') {
            return;
        }

        $position = strripos($output, '</body>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_sticky_header_status');
    }

    /**
     * @return string
     */
    private function mode(): string {
        $mode = (string)$this->config->get('module_sticky_header_mode');

        return in_array($mode, ['always', 'offset'], true) ? $mode : 'offset';
    }

    /**
     * Settings are written by a validating save(), but a hand-edited
     * `oc_setting` row must never be able to break out of a style attribute.
     *
     * @param string $key
     * @param string $fallback
     *
     * @return string
     */
    private function color(string $key, string $fallback): string {
        $color = strtoupper(trim((string)$this->config->get($key)));

        return preg_match('/^#[0-9A-F]{6}$/', $color) ? $color : $fallback;
    }

    /**
     * @return string
     */
    private function selector(): string {
        $selector = trim((string)$this->config->get('module_sticky_header_selector'));

        if ($selector === '' || !preg_match('/^[A-Za-z0-9\s,.#_\-\[\]="\':()>+~*^$|]{1,200}$/', $selector)) {
            return '';
        }

        return $selector;
    }

    /**
     * @param string $key
     * @param int    $fallback
     * @param int    $min
     * @param int    $max
     *
     * @return int
     */
    private function number(string $key, int $fallback, int $min, int $max): int {
        $value = $this->config->get($key);

        if ($value === null || $value === '' || !is_numeric($value)) {
            return $fallback;
        }

        $number = (int)$value;

        return ($number >= $min && $number <= $max) ? $number : $fallback;
    }
}
