<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkFurniture extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isFurnitureThemeActive()) {
            return;
        }

        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_furniture.twig';

            if (is_file($template)) {
                $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-furniture.css';
                $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_furniture_primary_color') ?: '#705731';
                $data['novakur_secondary_color'] = '#715b3a';
                $data['novakur_container_width'] = 1200;
                $data['novakur_heading_font'] = 'Playfair Display';
                $data['novakur_base_font'] = 'Inter';
                $data['nkf_default_view'] = (string)$this->config->get('theme_nk_furniture_default_view') ?: 'grid';
                $data['cart_quantity'] = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $categories_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];

                foreach ($categories_raw as $category) {
                    $data['categories'][] = [
                        'name'  => $category['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                        'image' => $category['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_furniture';
            }
        }

        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/common/footer_furniture';
            }
        }

        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/common/home_furniture';
            }

            $this->load->model('catalog/category');
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width') ?: 480);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);
            $categories_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);

            $data['categories'] = [];

            foreach ($categories_raw as $category) {
                $data['categories'][] = [
                    'name'  => $category['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                    'image' => $category['image'] ?? '',
                ];
            }

            $data['products'] = $this->buildProductArray(
                $this->model_catalog_product->getProducts([
                    'sort'  => 'date_added',
                    'order' => 'DESC',
                    'start' => 0,
                    'limit' => 8
                ]),
                $img_w,
                $img_h,
                $currency
            );

            $data['best_sellers'] = $this->buildProductArray(
                $this->model_catalog_product->getProducts([
                    'sort'  => 'rating',
                    'order' => 'DESC',
                    'start' => 0,
                    'limit' => 4
                ]),
                $img_w,
                $img_h,
                $currency
            );
        }

        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/category_furniture';
            }

            $this->load->model('catalog/category');
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $path = $this->request->get['path'] ?? '';
            $parts = explode('_', $path);
            $category_id = (int)end($parts);
            $page = max(1, (int)($this->request->get['page'] ?? 1));
            $limit = (int)($this->config->get('config_pagination') ?: 20);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $data['nkf_default_view'] = (string)$this->config->get('theme_nk_furniture_default_view') ?: 'grid';

            $data['products'] = $this->buildProductArray(
                $this->model_catalog_product->getProducts([
                    'filter_category_id'          => $category_id,
                    'filter_category_id_with_sub' => true,
                    'start'                       => ($page - 1) * $limit,
                    'limit'                       => $limit
                ]),
                480,
                360,
                $currency
            );

            $categories_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];

            foreach ($categories_raw as $category) {
                $data['categories'][] = [
                    'name'  => $category['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                    'image' => $category['image'] ?? '',
                ];
            }
        }

        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/product_furniture';
            }
        }

        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_furniture';
            }
        }

        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/product/search_furniture';
            }

            $this->load->model('catalog/category');
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $data['categories'] = [];
            foreach (array_slice($this->model_catalog_category->getCategories(0), 0, 8) as $category) {
                $data['categories'][] = [
                    'name'  => $category['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                    'image' => $category['image'] ?? '',
                ];
            }

            $search = $this->request->get['search'] ?? ($data['search'] ?? '');

            if ($search !== '') {
                $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
                $data['nkf_default_view'] = (string)$this->config->get('theme_nk_furniture_default_view') ?: 'grid';
                $data['products'] = $this->buildProductArray(
                    $this->model_catalog_product->getProducts([
                        'filter_name'        => $search,
                        'filter_description' => true,
                        'start'              => 0,
                        'limit'              => (int)($this->config->get('config_pagination') ?: 20)
                    ]),
                    480,
                    360,
                    $currency
                );
            } else {
                $data['nkf_default_view'] = (string)$this->config->get('theme_nk_furniture_default_view') ?: 'grid';
            }
        }

        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/login_furniture';
            }
        }

        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/register_furniture';
            }
        }

        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_dashboard_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/account_dashboard_furniture';
            }
        }

        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_order_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/account_order_furniture';
            }
        }

        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_furniture';
            }
        }

        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_furniture';
            }
        }

        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_furniture.twig';

            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_furniture';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];

        foreach ($raw as $product) {
            $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));

            $products[] = [
                'product_id' => $product['product_id'],
                'name'       => $product['name'],
                'href'       => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                'thumb'      => $product['image']
                    ? $this->model_tool_image->resize($product['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'      => $this->currency->format($price, $currency),
                'special'    => $product['special']
                    ? $this->currency->format(
                        $this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
            ];
        }

        return $products;
    }

    private function isFurnitureThemeActive(): bool {
        return (bool)$this->config->get('theme_nk_furniture_status');
    }
}
