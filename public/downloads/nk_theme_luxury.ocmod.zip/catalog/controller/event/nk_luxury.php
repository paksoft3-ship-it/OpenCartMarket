<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeLuxury\Event;

class NkLuxury extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isLuxuryThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/common/header_luxury.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_luxury/catalog/view/assets/dist/css/nk-luxury.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_luxury/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_luxury_primary_color') ?: '#141414';
                $data['novakur_secondary_color'] = '#a08b5f';
                $data['novakur_container_width'] = 1320;
                $data['novakur_base_font']       = 'Jost';
                $data['novakur_heading_font']    = 'Cormorant Garamond';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/nk_theme_luxury/common/header_luxury';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/common/footer_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/common/footer_luxury';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/common/home_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/common/home_luxury';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 600);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 750);

            // Signature section toggles (default: enabled)
            $data['show_cinematic_hero'] = $this->toggleEnabled('theme_nk_luxury_show_cinematic_hero');
            $data['show_story']          = $this->toggleEnabled('theme_nk_luxury_show_story');
            $data['show_collections']    = $this->toggleEnabled('theme_nk_luxury_show_collections');

            // Collections (categories with images) for the showcase
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 4);
            $data['collections'] = [];
            foreach ($cats_raw as $cat) {
                $data['collections'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => ($cat['image'] ?? '')
                        ? $this->model_tool_image->resize($cat['image'], 1200, 800)
                        : '',
                ];
            }
            $data['categories'] = $data['collections'];

            // Curated pieces — newest arrivals, 3-up grid with air
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 6,
            ]);
            $data['curated'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['latest']  = $data['curated'];

            // Most coveted — highest rated
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 3,
            ]);
            $data['coveted'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/product/category_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/product/category_luxury';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 600);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 750);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/product/special_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/product/special_luxury';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 600);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 750);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/product/product_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/product/product_luxury';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/checkout/cart_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/checkout/cart_luxury';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/checkout/checkout_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/checkout/checkout_luxury';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/product/search_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/product/search_luxury';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 600);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 750);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/account/login_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/account/login_luxury';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/account/register_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/account/register_luxury';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/account/account_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/account/account_luxury';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/account/order_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/account/order_luxury';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/account/wishlist_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/account/wishlist_luxury';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 600);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 750);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_luxury/catalog/view/template/error/not_found_luxury.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_luxury/error/not_found_luxury';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function toggleEnabled(string $key): bool {
        $value = $this->config->get($key);
        return $value === null || $value === '' ? true : (bool)$value;
    }

    private function isLuxuryThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_luxury', 'novakur_luxury'], true)
            && (bool)$this->config->get('theme_nk_luxury_status');
    }
}
