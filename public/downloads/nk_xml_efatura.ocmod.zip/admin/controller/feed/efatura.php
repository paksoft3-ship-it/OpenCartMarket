<?php
namespace Opencart\Admin\Controller\Extension\NkXmlEfatura\Feed;

/**
 * NovaKur e-Fatura / e-Arsiv XML
 *
 * Generates UBL-TR 1.2 invoice documents from OpenCart 4 orders.
 */
class Efatura extends \Opencart\System\Engine\Controller {
	/**
	 * Get Defaults
	 *
	 * Every setting key the extension owns, with its shipped default.
	 *
	 * @return array<string, string>
	 */
	protected function getDefaults(): array {
		return [
			'feed_efatura_status'                => '0',
			'feed_efatura_profile'               => 'TICARIFATURA',
			'feed_efatura_invoice_type'          => 'SATIS',
			'feed_efatura_currency'              => 'TRY',
			'feed_efatura_exchange_rate'         => '1.0',
			'feed_efatura_supplier_name'         => (string)$this->config->get('config_name'),
			'feed_efatura_supplier_vkn'          => '',
			'feed_efatura_supplier_tax_office'   => '',
			'feed_efatura_supplier_mersis'       => '',
			'feed_efatura_supplier_sicil'        => '',
			'feed_efatura_supplier_street'       => '',
			'feed_efatura_supplier_building'     => '',
			'feed_efatura_supplier_district'     => '',
			'feed_efatura_supplier_city'         => '',
			'feed_efatura_supplier_postcode'     => '',
			'feed_efatura_supplier_country'      => 'Türkiye',
			'feed_efatura_supplier_phone'        => (string)$this->config->get('config_telephone'),
			'feed_efatura_supplier_email'        => (string)$this->config->get('config_email'),
			'feed_efatura_supplier_website'      => (string)$this->config->get('config_url'),
			'feed_efatura_serial'                => 'EFT',
			'feed_efatura_earsiv_serial'         => 'EAR',
			'feed_efatura_start_no'              => '1',
			'feed_efatura_kdv_rate'              => '20',
			'feed_efatura_shipping_kdv_rate'     => '20',
			'feed_efatura_discount_mode'         => 'distribute',
			'feed_efatura_unit_code'             => 'C62',
			'feed_efatura_cf_vkn'                => '0',
			'feed_efatura_cf_tckn'               => '0',
			'feed_efatura_cf_tax_office'         => '0',
			'feed_efatura_use_default_tckn'      => '1',
			'feed_efatura_earsiv_send_type'      => 'ELEKTRONIK',
			'feed_efatura_earsiv_internet'       => '1',
			'feed_efatura_payment_means_code'    => '48',
			'feed_efatura_exemption_code'        => '',
			'feed_efatura_exemption_reason'      => '',
			'feed_efatura_note'                  => '',
			'feed_efatura_batch_limit'           => '500'
		];
	}

	/**
	 * Get Settings
	 *
	 * Resolves the live setting values (store setting falling back to defaults).
	 *
	 * @param int $store_id
	 *
	 * @return array<string, string>
	 */
	protected function getSettings(int $store_id = 0): array {
		$this->load->model('setting/setting');

		$setting_info = $this->model_setting_setting->getSetting('feed_efatura', $store_id);

		$settings = [];

		foreach ($this->getDefaults() as $key => $default) {
			$settings[$key] = isset($setting_info[$key]) ? (string)$setting_info[$key] : $default;
		}

		return $settings;
	}

	/**
	 * Index
	 *
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$data = [];

		$setting_info = $this->getSettings($store_id);

		foreach ($this->getDefaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = (string)$this->request->post[$key];
			} else {
				$data[$key] = $setting_info[$key];
			}
		}

		$data['store_id'] = $store_id;

		// Option lists
		$data['profiles'] = ['TICARIFATURA', 'TEMELFATURA', 'IHRACAT', 'YOLCUBERABERFATURA', 'KAMU'];
		$data['invoice_types'] = ['SATIS', 'IADE', 'TEVKIFAT', 'ISTISNA', 'OZELMATRAH', 'IHRACKAYITLI', 'SGK', 'KOMISYONCU'];
		$data['unit_codes'] = ['C62', 'NIU', 'KGM', 'GRM', 'LTR', 'MTR', 'MTK', 'MTQ', 'PR', 'SET', 'BX'];
		$data['send_types'] = ['ELEKTRONIK', 'KAGIT'];

		$data['payment_means'] = [
			['code' => '', 'name' => $this->language->get('text_none')],
			['code' => '1', 'name' => $this->language->get('text_payment_1')],
			['code' => '10', 'name' => $this->language->get('text_payment_10')],
			['code' => '42', 'name' => $this->language->get('text_payment_42')],
			['code' => '48', 'name' => $this->language->get('text_payment_48')],
			['code' => '68', 'name' => $this->language->get('text_payment_68')],
			['code' => 'ZZZ', 'name' => $this->language->get('text_payment_zzz')]
		];

		// Customer custom fields available for VKN / TCKN / tax office mapping.
		$this->load->model('customer/custom_field');

		$data['custom_fields'] = [];

		foreach ($this->model_customer_custom_field->getCustomFields() as $custom_field) {
			$data['custom_fields'][] = [
				'custom_field_id' => (int)$custom_field['custom_field_id'],
				'name'            => $custom_field['name'] . ' (' . $custom_field['location'] . ')'
			];
		}

		// Order statuses for the batch/filter panels.
		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		// Environment facts the admin should know about.
		$data['zip_available'] = class_exists('ZipArchive');
		$data['dom_available'] = class_exists('DOMDocument');

		$this->load->model('extension/nk_xml_efatura/feed/efatura');

		$data['table_available'] = $this->model_extension_nk_xml_efatura_feed_efatura->hasTable();
		$data['document_total'] = $this->model_extension_nk_xml_efatura_feed_efatura->getTotalDocuments();
		$data['last_sequence'] = $this->model_extension_nk_xml_efatura_feed_efatura->getLastSequence($data['feed_efatura_serial']);
		$data['last_sequence_earsiv'] = $this->model_extension_nk_xml_efatura_feed_efatura->getLastSequence($data['feed_efatura_earsiv_serial']);

		$data['list'] = $this->getList();

		$data['batch_date_from'] = date('Y-m-01');
		$data['batch_date_to'] = date('Y-m-d');

		$data['save'] = $this->url->link('extension/nk_xml_efatura/feed/efatura.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		// Both are consumed by JavaScript, so they must not be HTML entity encoded.
		$data['batch'] = $this->url->link('extension/nk_xml_efatura/feed/efatura.batch', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id, true);
		$data['list_url'] = $this->url->link('extension/nk_xml_efatura/feed/efatura.list', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id, true);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed');

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/nk_xml_efatura/feed/efatura', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/nk_xml_efatura/feed/efatura', $data));
	}

	/**
	 * List
	 *
	 * @return void
	 */
	public function list(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		$this->response->setOutput($this->getList());
	}

	/**
	 * Get List
	 *
	 * @return string
	 */
	protected function getList(): string {
		$filter_order_id = isset($this->request->get['filter_order_id']) ? (int)$this->request->get['filter_order_id'] : '';
		$filter_customer = isset($this->request->get['filter_customer']) ? (string)$this->request->get['filter_customer'] : '';
		$filter_order_status_id = isset($this->request->get['filter_order_status_id']) && $this->request->get['filter_order_status_id'] !== '' ? (int)$this->request->get['filter_order_status_id'] : '';
		$filter_date_from = isset($this->request->get['filter_date_from']) ? (string)$this->request->get['filter_date_from'] : '';
		$filter_date_to = isset($this->request->get['filter_date_to']) ? (string)$this->request->get['filter_date_to'] : '';
		$page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;

		$limit = (int)$this->config->get('config_pagination_admin');

		if ($limit < 1) {
			$limit = 10;
		}

		$filter_data = [
			'filter_order_id'        => $filter_order_id,
			'filter_customer'        => $filter_customer,
			'filter_order_status_id' => $filter_order_status_id,
			'filter_date_from'       => $filter_date_from,
			'filter_date_to'         => $filter_date_to,
			'sort'                   => 'o.order_id',
			'order'                  => 'DESC',
			'start'                  => ($page - 1) * $limit,
			'limit'                  => $limit
		];

		$this->load->model('sale/order');
		$this->load->model('extension/nk_xml_efatura/feed/efatura');

		$results = $this->model_sale_order->getOrders($filter_data);
		$order_total = $this->model_sale_order->getTotalOrders($filter_data);

		$order_ids = [];

		foreach ($results as $result) {
			$order_ids[] = (int)$result['order_id'];
		}

		$records = $this->model_extension_nk_xml_efatura_feed_efatura->getRecordsByOrder($order_ids);

		$data = [];
		$data['orders'] = [];

		foreach ($results as $result) {
			$order_id = (int)$result['order_id'];

			$data['orders'][] = [
				'order_id'      => $order_id,
				'customer'      => $result['customer'],
				'order_status'  => $result['order_status'],
				'total'         => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'efatura_no'    => $records[$order_id]['efatura']['invoice_no'] ?? '',
				'earsiv_no'     => $records[$order_id]['earsiv']['invoice_no'] ?? '',
				'view'          => $this->url->link('sale/order.info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id),
				'efatura'       => $this->url->link('extension/nk_xml_efatura/feed/efatura.generate', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id . '&scenario=efatura'),
				'earsiv'        => $this->url->link('extension/nk_xml_efatura/feed/efatura.generate', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id . '&scenario=earsiv'),
				'check_efatura' => $this->url->link('extension/nk_xml_efatura/feed/efatura.check', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id . '&scenario=efatura'),
				'check_earsiv'  => $this->url->link('extension/nk_xml_efatura/feed/efatura.check', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id . '&scenario=earsiv')
			];
		}

		$url = '';

		if ($filter_order_id !== '') {
			$url .= '&filter_order_id=' . $filter_order_id;
		}

		if ($filter_customer !== '') {
			$url .= '&filter_customer=' . urlencode($filter_customer);
		}

		if ($filter_order_status_id !== '') {
			$url .= '&filter_order_status_id=' . $filter_order_status_id;
		}

		if ($filter_date_from !== '') {
			$url .= '&filter_date_from=' . urlencode($filter_date_from);
		}

		if ($filter_date_to !== '') {
			$url .= '&filter_date_to=' . urlencode($filter_date_to);
		}

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $order_total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->url->link('extension/nk_xml_efatura/feed/efatura.list', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), $order_total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($order_total - $limit)) ? $order_total : ((($page - 1) * $limit) + $limit), $order_total, (int)ceil($order_total / $limit));

		return $this->load->view('extension/nk_xml_efatura/feed/efatura_order', $data);
	}

	/**
	 * Save
	 *
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/nk_xml_efatura/feed/efatura')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		// --- server side validation -------------------------------------
		$vkn = preg_replace('/[^0-9]/', '', (string)($post['feed_efatura_supplier_vkn'] ?? ''));

		if (strlen($vkn) != 10 && strlen($vkn) != 11) {
			$json['error']['supplier_vkn'] = $this->language->get('error_vkn');
		}

		if (oc_strlen(trim((string)($post['feed_efatura_supplier_name'] ?? ''))) < 3) {
			$json['error']['supplier_name'] = $this->language->get('error_supplier_name');
		}

		if (oc_strlen(trim((string)($post['feed_efatura_supplier_tax_office'] ?? ''))) < 2) {
			$json['error']['supplier_tax_office'] = $this->language->get('error_tax_office');
		}

		foreach (['feed_efatura_serial' => 'serial', 'feed_efatura_earsiv_serial' => 'earsiv_serial'] as $key => $field) {
			$serial = strtoupper(trim((string)($post[$key] ?? '')));

			if (!preg_match('/^[A-Z0-9]{3}$/', $serial)) {
				$json['error'][$field] = $this->language->get('error_serial');
			}
		}

		foreach (['feed_efatura_kdv_rate' => 'kdv_rate', 'feed_efatura_shipping_kdv_rate' => 'shipping_kdv_rate'] as $key => $field) {
			$rate = (string)($post[$key] ?? '');

			if (!is_numeric($rate) || (float)$rate < 0 || (float)$rate > 100) {
				$json['error'][$field] = $this->language->get('error_rate');
			}
		}

		$exchange_rate = (string)($post['feed_efatura_exchange_rate'] ?? '1');

		if (!is_numeric($exchange_rate) || (float)$exchange_rate <= 0) {
			$json['error']['exchange_rate'] = $this->language->get('error_exchange_rate');
		}

		$start_no = (string)($post['feed_efatura_start_no'] ?? '1');

		if (!ctype_digit($start_no) || (int)$start_no < 1 || (int)$start_no > 999999999) {
			$json['error']['start_no'] = $this->language->get('error_start_no');
		}

		if (!$json) {
			$defaults = $this->getDefaults();

			$save = [];

			foreach ($defaults as $key => $default) {
				$save[$key] = isset($post[$key]) && is_scalar($post[$key]) ? trim((string)$post[$key]) : $default;
			}

			// Normalise the values that have a strict shape.
			$save['feed_efatura_status'] = !empty($post['feed_efatura_status']) ? '1' : '0';
			$save['feed_efatura_use_default_tckn'] = !empty($post['feed_efatura_use_default_tckn']) ? '1' : '0';
			$save['feed_efatura_earsiv_internet'] = !empty($post['feed_efatura_earsiv_internet']) ? '1' : '0';
			$save['feed_efatura_supplier_vkn'] = $vkn;
			$save['feed_efatura_supplier_mersis'] = preg_replace('/[^0-9]/', '', $save['feed_efatura_supplier_mersis']);
			$save['feed_efatura_serial'] = strtoupper($save['feed_efatura_serial']);
			$save['feed_efatura_earsiv_serial'] = strtoupper($save['feed_efatura_earsiv_serial']);
			$save['feed_efatura_start_no'] = (string)(int)$save['feed_efatura_start_no'];
			$save['feed_efatura_kdv_rate'] = (string)(float)$save['feed_efatura_kdv_rate'];
			$save['feed_efatura_shipping_kdv_rate'] = (string)(float)$save['feed_efatura_shipping_kdv_rate'];
			$save['feed_efatura_exchange_rate'] = (string)(float)$save['feed_efatura_exchange_rate'];
			$save['feed_efatura_currency'] = strtoupper(substr($save['feed_efatura_currency'], 0, 3)) ?: 'TRY';
			$save['feed_efatura_cf_vkn'] = (string)(int)$save['feed_efatura_cf_vkn'];
			$save['feed_efatura_cf_tckn'] = (string)(int)$save['feed_efatura_cf_tckn'];
			$save['feed_efatura_cf_tax_office'] = (string)(int)$save['feed_efatura_cf_tax_office'];
			$save['feed_efatura_batch_limit'] = (string)min(5000, max(1, (int)$save['feed_efatura_batch_limit']));

			$save['feed_efatura_profile'] = in_array($save['feed_efatura_profile'], ['TICARIFATURA', 'TEMELFATURA', 'IHRACAT', 'YOLCUBERABERFATURA', 'KAMU'], true) ? $save['feed_efatura_profile'] : 'TICARIFATURA';
			$save['feed_efatura_invoice_type'] = in_array($save['feed_efatura_invoice_type'], ['SATIS', 'IADE', 'TEVKIFAT', 'ISTISNA', 'OZELMATRAH', 'IHRACKAYITLI', 'SGK', 'KOMISYONCU'], true) ? $save['feed_efatura_invoice_type'] : 'SATIS';
			$save['feed_efatura_unit_code'] = preg_match('/^[A-Z0-9]{2,3}$/', $save['feed_efatura_unit_code']) ? $save['feed_efatura_unit_code'] : 'C62';
			$save['feed_efatura_discount_mode'] = $save['feed_efatura_discount_mode'] == 'allowance' ? 'allowance' : 'distribute';
			$save['feed_efatura_earsiv_send_type'] = $save['feed_efatura_earsiv_send_type'] == 'KAGIT' ? 'KAGIT' : 'ELEKTRONIK';
			$save['feed_efatura_payment_means_code'] = in_array($save['feed_efatura_payment_means_code'], ['', '1', '10', '42', '48', '68', 'ZZZ'], true) ? $save['feed_efatura_payment_means_code'] : '';

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('feed_efatura', $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Generate
	 *
	 * Streams a single UBL-TR invoice document as a download.
	 *
	 * @return void
	 */
	public function generate(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		if (!$this->user->hasPermission('modify', 'extension/nk_xml_efatura/feed/efatura')) {
			$this->failure($this->language->get('error_permission'));

			return;
		}

		$order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
		$scenario = (isset($this->request->get['scenario']) && $this->request->get['scenario'] == 'earsiv') ? 'earsiv' : 'efatura';
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$order_id) {
			$this->failure($this->language->get('error_order'));

			return;
		}

		$this->load->model('extension/nk_xml_efatura/feed/efatura');

		$document = $this->model_extension_nk_xml_efatura_feed_efatura->build($order_id, $scenario, $this->getSettings($store_id));

		if (!$document['well_formed'] || $document['errors']) {
			$messages = [];

			foreach ($document['errors'] as $code) {
				$message = $this->language->get($code);

				$messages[] = ($message && $message != $code) ? $message : $code;
			}

			$this->failure(trim($this->language->get('error_generate') . ' ' . implode(' ', $messages)));

			return;
		}

		$this->response->addHeader('Pragma: public');
		$this->response->addHeader('Expires: 0');
		$this->response->addHeader('Content-Description: File Transfer');
		$this->response->addHeader('Content-Type: application/xml; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="' . $document['filename'] . '"');
		$this->response->addHeader('Content-Transfer-Encoding: binary');
		$this->response->setOutput($document['xml']);
	}

	/**
	 * Check
	 *
	 * Builds the document and reports the validation outcome as JSON without
	 * downloading anything.
	 *
	 * @return void
	 */
	public function check(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/nk_xml_efatura/feed/efatura')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
		$scenario = (isset($this->request->get['scenario']) && $this->request->get['scenario'] == 'earsiv') ? 'earsiv' : 'efatura';
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!isset($json['error']) && !$order_id) {
			$json['error'] = $this->language->get('error_order');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_xml_efatura/feed/efatura');

			// Dry run: validating an order must never consume an invoice number.
			$document = $this->model_extension_nk_xml_efatura_feed_efatura->build($order_id, $scenario, $this->getSettings($store_id), false);

			$messages = [];

			foreach (array_unique(array_merge($document['errors'], $document['warnings'])) as $code) {
				$message = $this->language->get($code);

				$messages[] = ($message && $message != $code) ? $message : $code;
			}

			$json['order_id'] = $order_id;
			$json['scenario'] = $scenario;
			$json['preview'] = (bool)$document['preview'];
			$json['profile_id'] = $document['profile_id'];
			$json['invoice_no'] = $document['invoice_no'];
			$json['uuid'] = $document['uuid'];
			$json['bytes'] = strlen($document['xml']);
			$json['payable'] = number_format((float)$document['payable'], 2, '.', '');
			$json['order_total'] = number_format((float)$document['order_total'], 2, '.', '');
			$json['well_formed'] = (bool)$document['well_formed'];
			$json['messages'] = $messages;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Batch
	 *
	 * Date range -> zip archive of UBL-TR documents.
	 *
	 * @return void
	 */
	public function batch(): void {
		$this->load->language('extension/nk_xml_efatura/feed/efatura');

		if (!$this->user->hasPermission('modify', 'extension/nk_xml_efatura/feed/efatura')) {
			$this->failure($this->language->get('error_permission'));

			return;
		}

		if (!class_exists('ZipArchive')) {
			$this->failure($this->language->get('error_zip'));

			return;
		}

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
		$scenario = (isset($this->request->get['scenario']) && $this->request->get['scenario'] == 'earsiv') ? 'earsiv' : 'efatura';

		$date_from = isset($this->request->get['date_from']) ? (string)$this->request->get['date_from'] : '';
		$date_to = isset($this->request->get['date_to']) ? (string)$this->request->get['date_to'] : '';

		foreach (['date_from' => $date_from, 'date_to' => $date_to] as $value) {
			if ($value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
				$this->failure($this->language->get('error_date'));

				return;
			}
		}

		if ($date_from === '' || $date_to === '') {
			$this->failure($this->language->get('error_date'));

			return;
		}

		if (strtotime($date_from) > strtotime($date_to)) {
			$this->failure($this->language->get('error_date_range'));

			return;
		}

		$settings = $this->getSettings($store_id);

		$limit = (int)$settings['feed_efatura_batch_limit'];

		if ($limit < 1) {
			$limit = 500;
		}

		$filter_data = [
			'filter_date_from' => $date_from,
			'filter_date_to'   => $date_to,
			'sort'             => 'o.order_id',
			'order'            => 'ASC',
			'start'            => 0,
			'limit'            => $limit
		];

		if (isset($this->request->get['order_status_id']) && $this->request->get['order_status_id'] !== '') {
			$filter_data['filter_order_status_id'] = (int)$this->request->get['order_status_id'];
		}

		$this->load->model('sale/order');
		$this->load->model('extension/nk_xml_efatura/feed/efatura');

		$orders = $this->model_sale_order->getOrders($filter_data);

		if (!$orders) {
			$this->failure($this->language->get('error_batch_empty'));

			return;
		}

		$directory = DIR_STORAGE . 'efatura/';

		if (!is_dir($directory)) {
			mkdir($directory, 0777, true);
		}

		$file = $directory . 'batch-' . $scenario . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.zip';

		$zip = new \ZipArchive();

		if ($zip->open($file, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
			$this->failure($this->language->get('error_zip_create'));

			return;
		}

		$report = [];
		$report[] = 'order_id;invoice_no;uuid;payable;order_total;well_formed;messages';

		$added = 0;

		foreach ($orders as $order) {
			$document = $this->model_extension_nk_xml_efatura_feed_efatura->build((int)$order['order_id'], $scenario, $settings);

			$messages = [];

			foreach (array_unique(array_merge($document['errors'], $document['warnings'])) as $code) {
				$message = $this->language->get($code);

				$messages[] = ($message && $message != $code) ? $message : $code;
			}

			$report[] = implode(';', [
				(int)$order['order_id'],
				str_replace(';', ',', (string)$document['invoice_no']),
				(string)$document['uuid'],
				number_format((float)$document['payable'], 2, '.', ''),
				number_format((float)$document['order_total'], 2, '.', ''),
				$document['well_formed'] ? '1' : '0',
				str_replace(';', ',', implode(' | ', $messages))
			]);

			if ($document['well_formed'] && $document['xml'] !== '') {
				$zip->addFromString($document['filename'], $document['xml']);

				$added++;
			}
		}

		$zip->addFromString('_report.csv', "\xEF\xBB\xBF" . implode("\r\n", $report));
		$zip->addFromString('_README.txt', $this->language->get('text_readme'));
		$zip->close();

		if (!$added) {
			unlink($file);

			$this->failure($this->language->get('error_batch_empty'));

			return;
		}

		$content = (string)file_get_contents($file);

		unlink($file);

		$this->response->addHeader('Pragma: public');
		$this->response->addHeader('Expires: 0');
		$this->response->addHeader('Content-Description: File Transfer');
		$this->response->addHeader('Content-Type: application/zip');
		$this->response->addHeader('Content-Disposition: attachment; filename="efatura-' . $scenario . '-' . $date_from . '_' . $date_to . '.zip"');
		$this->response->addHeader('Content-Transfer-Encoding: binary');
		$this->response->setOutput($content);
	}

	/**
	 * Failure
	 *
	 * Renders a plain, escaped error page for the direct-download routes.
	 *
	 * @param string $message
	 *
	 * @return void
	 */
	protected function failure(string $message): void {
		$this->response->addHeader('Content-Type: text/html; charset=utf-8');
		$this->response->setOutput('<!doctype html><html><head><meta charset="utf-8"><title>e-Fatura</title></head><body style="font-family:sans-serif;padding:2rem"><h3>' . htmlspecialchars($this->language->get('heading_title'), ENT_QUOTES, 'UTF-8') . '</h3><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><p><a href="javascript:history.back()">&laquo;</a></p></body></html>');
	}

	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void {
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "novakur_efatura` (
			`efatura_id` int(11) NOT NULL AUTO_INCREMENT,
			`order_id` int(11) NOT NULL DEFAULT '0',
			`scenario` varchar(16) NOT NULL DEFAULT '',
			`profile_id` varchar(32) NOT NULL DEFAULT '',
			`invoice_no` varchar(32) NOT NULL DEFAULT '',
			`uuid` varchar(36) NOT NULL DEFAULT '',
			`serial` varchar(3) NOT NULL DEFAULT '',
			`year` int(4) NOT NULL DEFAULT '0',
			`sequence_no` int(11) NOT NULL DEFAULT '0',
			`currency_code` varchar(3) NOT NULL DEFAULT 'TRY',
			`payable_amount` decimal(15,4) NOT NULL DEFAULT '0.0000',
			`date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`date_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`efatura_id`),
			UNIQUE KEY `order_scenario` (`order_id`,`scenario`),
			KEY `serial_year` (`serial`,`year`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('feed_efatura', $this->getDefaults());
	}

	/**
	 * Uninstall
	 *
	 * The issued-document ledger (`<prefix>novakur_efatura`) is deliberately
	 * preserved: it holds invoice numbers and ETTN values already handed to
	 * GIB, which must survive an uninstall/reinstall cycle. Drop the table
	 * manually only if you have a verified export.
	 *
	 * @return void
	 */
	public function uninstall(): void {

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('feed_efatura');
	}
}
