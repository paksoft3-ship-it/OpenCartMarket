<?php
// Heading
$_['heading_title']              = 'NovaKur AJAX Cart';

// Text
$_['text_extension']             = 'Extensions';
$_['text_success']               = 'Success: You have modified NovaKur AJAX Cart settings!';
$_['text_edit']                  = 'Edit NovaKur AJAX Cart';
$_['text_enabled']               = 'Enabled';
$_['text_disabled']              = 'Disabled';
$_['text_yes']                   = 'Yes';
$_['text_no']                    = 'No';

// Entry
$_['entry_status']               = 'Status';
$_['entry_open_on_add']          = 'Open drawer on add to cart';
$_['entry_free_shipping_bar']    = 'Free shipping progress bar';
$_['entry_threshold']            = 'Free shipping threshold';

// Help
$_['help_open_on_add']           = 'Slide the mini cart open every time a product is added. Turn off to only update the header count.';
$_['help_threshold']             = 'Order sub-total (in the store default currency) that qualifies for free shipping. Required when the progress bar is on.';

// Button
$_['button_save']                = 'Save';
$_['button_back']                = 'Back';

// Error
$_['error_permission']           = 'Warning: You do not have permission to modify this module!';
$_['error_threshold']            = 'Threshold must be a number between 0 and 1,000,000!';
$_['error_threshold_required']   = 'Set a threshold above zero to use the free shipping progress bar!';
