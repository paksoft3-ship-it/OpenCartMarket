<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

/**
 * NovaKur AJAX Cart - admin settings.
 */
class AjaxCart extends \Opencart\System\Engine\Controller {
	/**
	 * Storefront events registered on install / removed on uninstall.
	 *
	 * Without these the drawer is never placed on the page and the module does nothing.
	 *
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'nk_ajax_cart_header',
			'description' => 'NovaKur AJAX Cart: queue the drawer stylesheet and script in the page head.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/novakur/event/ajax_cart.header'
		],
		[
			'code'        => 'nk_ajax_cart_footer',
			'description' => 'NovaKur AJAX Cart: inject the mini cart drawer and its assets into every page.',
			'trigger'     => 'catalog/view/common/footer/after',
			'action'      => 'extension/novakur/event/ajax_cart.footer'
		]
	];

	/**
	 * Setting defaults. Also the single source of truth for which keys the module owns.
	 *
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			'module_ajax_cart_status'                  => '0',
			'module_ajax_cart_open_on_add'             => '1',
			'module_ajax_cart_show_free_shipping_bar'  => '0',
			'module_ajax_cart_free_shipping_threshold' => '0'
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/novakur/module/ajax_cart');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting('module_ajax_cart', $store_id);

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ($this->language->all() as $key => $value) {
			$data[$key] = $value;
		}

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/novakur/module/ajax_cart', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save'] = $this->url->link('extension/novakur/module/ajax_cart.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/novakur/module/ajax_cart', $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/novakur/module/ajax_cart');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/novakur/module/ajax_cart')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$threshold = isset($post['module_ajax_cart_free_shipping_threshold']) ? (float)str_replace(',', '.', (string)$post['module_ajax_cart_free_shipping_threshold']) : 0.0;

		if ($threshold < 0 || $threshold > 1000000) {
			$json['error']['free_shipping_threshold'] = $this->language->get('error_threshold');
		}

		if (!empty($post['module_ajax_cart_show_free_shipping_bar']) && $threshold <= 0 && !isset($json['error']['free_shipping_threshold'])) {
			$json['error']['free_shipping_threshold'] = $this->language->get('error_threshold_required');
		}

		if (!$json) {
			// Only the keys the module owns are written - never the raw POST body.
			$save = [
				'module_ajax_cart_status'                  => !empty($post['module_ajax_cart_status']) ? '1' : '0',
				'module_ajax_cart_open_on_add'             => !empty($post['module_ajax_cart_open_on_add']) ? '1' : '0',
				'module_ajax_cart_show_free_shipping_bar'  => !empty($post['module_ajax_cart_show_free_shipping_bar']) ? '1' : '0',
				'module_ajax_cart_free_shipping_threshold' => (string)$threshold
			];

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_ajax_cart', $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('module_ajax_cart', $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('module_ajax_cart');
	}
}
