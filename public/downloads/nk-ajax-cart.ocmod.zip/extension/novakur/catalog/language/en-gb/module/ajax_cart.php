<?php
// Heading
$_['heading_title']        = 'My Cart';

// Text
$_['text_items']           = '%d item(s)';
$_['text_empty']           = 'Your cart is empty.';
$_['text_sub_total']       = 'Sub-Total';
$_['text_free_shipping']   = 'You have earned free shipping!';
$_['text_free_remaining']  = 'Spend %s more for free shipping';

// Button
$_['button_close']         = 'Close';
$_['button_cart']          = 'View Cart';
$_['button_checkout']      = 'Checkout';
$_['button_remove']        = 'Remove';
$_['button_increase']      = 'Increase quantity';
$_['button_decrease']      = 'Decrease quantity';

// Error
$_['error_product']        = 'Warning: That item is no longer in your cart!';
