<?php
$_['heading_title'] = 'NovaKur Jewelry Theme';
$_['text_edit'] = 'Jewelry theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Jewelry theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Gold Color';
$_['entry_show_gallery_360'] = 'Show Multi-Angle 360 Gallery';
$_['entry_show_material_block'] = 'Show Metal / Stone Detail Block';
$_['entry_show_gift_packaging'] = 'Show Gift Packaging Panel';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
