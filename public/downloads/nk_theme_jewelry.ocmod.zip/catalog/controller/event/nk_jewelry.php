<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeJewelry\Event;

class NkJewelry extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isJewelryThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/common/header_jewelry.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_jewelry/catalog/view/assets/dist/css/nk-jewelry.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_jewelry/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_jewelry_primary_color') ?: '#c9a227';
                $data['novakur_secondary_color'] = '#e8cf7a';
                $data['novakur_container_width'] = 1280;
                $data['novakur_base_font']       = 'Jost';
                $data['novakur_heading_font']    = 'Playfair Display';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/nk_theme_jewelry/common/header_jewelry';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/common/footer_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/common/footer_jewelry';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/common/home_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/common/home_jewelry';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 420);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 420);

            // Collections band from OpenCart categories
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            // Featured pieces / new arrivals
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest']   = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['featured'] = $data['latest'];

            // Bestsellers row
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/product/category_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/product/category_jewelry';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 420);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 420);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/product/special_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/product/special_jewelry';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 420);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 420);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/product/product_jewelry.twig';
            if (is_file($template)) {
                $data['show_gallery_360']    = (bool)$this->config->get('theme_nk_jewelry_show_gallery_360');
                $data['show_material_block'] = (bool)$this->config->get('theme_nk_jewelry_show_material_block');
                $data['show_gift_packaging'] = (bool)$this->config->get('theme_nk_jewelry_show_gift_packaging');

                $route = 'extension/nk_theme_jewelry/product/product_jewelry';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/checkout/cart_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/checkout/cart_jewelry';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/checkout/checkout_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/checkout/checkout_jewelry';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/product/search_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/product/search_jewelry';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 420);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 420);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/account/login_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/account/login_jewelry';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/account/register_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/account/register_jewelry';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/account/account_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/account/account_jewelry';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/account/order_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/account/order_jewelry';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/account/wishlist_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/account/wishlist_jewelry';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 420);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 420);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_jewelry/catalog/view/template/error/not_found_jewelry.twig';
            if (is_file($template)) {
                $route = 'extension/nk_theme_jewelry/error/not_found_jewelry';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isJewelryThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_jewelry', 'novakur_jewelry'], true)
            && (bool)$this->config->get('theme_nk_jewelry_status');
    }
}
