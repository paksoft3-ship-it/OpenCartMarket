<?php
// Heading
$_['heading_title']            = 'NovaKur Product Labels';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified NovaKur Product Labels settings!';
$_['text_edit']                = 'Edit NovaKur Product Labels';
$_['text_enabled']             = 'Enabled';
$_['text_disabled']            = 'Disabled';
$_['text_general']             = 'General';
$_['text_new']                 = 'New label';
$_['text_sale']                = 'Sale label';
$_['text_hot']                 = 'Hot seller label';
$_['text_top_left']            = 'Top left';
$_['text_top_right']           = 'Top right';
$_['text_bottom_left']         = 'Bottom left';
$_['text_bottom_right']        = 'Bottom right';

// Entry
$_['entry_status']             = 'Status';
$_['entry_label_position']     = 'Corner';
$_['entry_max_labels']         = 'Max labels per product';
$_['entry_new_status']         = 'Show New label';
$_['entry_new_days']           = 'New for (days)';
$_['entry_sale_status']        = 'Show Sale label';
$_['entry_sale_show_percent']  = 'Show discount percentage';
$_['entry_hot_status']         = 'Show Hot Seller label';
$_['entry_hot_limit']          = 'Hot seller list size';
$_['entry_text_new']           = 'New label text';
$_['entry_text_sale']          = 'Sale label text';
$_['entry_text_sale_percent']  = 'Sale label text with %';
$_['entry_text_hot']           = 'Hot seller label text';

// Help
$_['help_max_labels']          = 'Between 1 and 3. Labels are applied in order: New, Sale, Hot Seller.';
$_['help_new_days']            = 'A product is "new" for this many days after its Date Added. Between 1 and 365.';
$_['help_sale_show_percent']   = 'Calculated from the product special (an oc_product_discount row with special = 1) against the base price.';
$_['help_hot_limit']           = 'How many top-selling products count as hot sellers. Between 1 and 100. Sales are counted from completed order lines.';
$_['help_custom_text']         = 'Leave empty to use the storefront language default.';
$_['help_sale_percent_token']  = 'Leave empty to use the storefront language default. Use {percent} where the discount number should appear, e.g. "-{percent}%".';

// Button
$_['button_save']              = 'Save';
$_['button_back']              = 'Back';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify this module!';
$_['error_label_position']     = 'Corner must be one of top-left, top-right, bottom-left or bottom-right!';
$_['error_max_labels']         = 'Max labels must be between 1 and 3!';
$_['error_new_days']           = 'New for (days) must be between 1 and 365!';
$_['error_hot_limit']          = 'Hot seller list size must be between 1 and 100!';
$_['error_text']               = 'Label text must be 24 characters or fewer!';
