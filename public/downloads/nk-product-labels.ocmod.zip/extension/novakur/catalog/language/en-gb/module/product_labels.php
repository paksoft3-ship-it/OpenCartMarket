<?php
// Text
$_['text_new']          = 'New';
$_['text_sale']         = 'Sale';
$_['text_sale_percent'] = '-{percent}%';
$_['text_hot']          = 'Hot';
