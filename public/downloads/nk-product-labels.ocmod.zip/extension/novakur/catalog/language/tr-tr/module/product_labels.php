<?php
// Text
$_['text_new']          = 'Yeni';
$_['text_sale']         = 'İndirim';
$_['text_sale_percent'] = '%{percent} İndirim';
$_['text_hot']          = 'Çok Satan';
