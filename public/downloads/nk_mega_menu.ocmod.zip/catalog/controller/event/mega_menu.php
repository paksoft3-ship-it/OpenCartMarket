<?php
namespace Opencart\Catalog\Controller\Extension\NkMegaMenu\Event;

/**
 * NovaKur Mega Menu — storefront hooks.
 *
 * assets() catalog/controller/common/header/before → register CSS/JS
 * view()   catalog/view/common/header/after        → inject the menu markup
 *
 * The stylesheet/script have to be registered on the controller/before trigger:
 * by the time the header view runs, common/header has already copied
 * $this->document->getStyles()/getScripts() into the template data, so an
 * addStyle() from a view event would never reach the page.
 */
class MegaMenu extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_mega_menu/catalog/view/assets/css/mega_menu.css';
    private const JS  = 'extension/nk_mega_menu/catalog/view/assets/js/mega_menu.js';

    private const PRODUCT_LIMIT = 6;

    private static bool $done = false;

    /**
     * Memo for getCategories() so a 3-level tree does not re-query a branch.
     *
     * @var array<int, array<int, array<string, mixed>>>
     */
    private array $branch_cache = [];

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     * @param mixed                $output
     *
     * @return void
     */
    public function view(string &$route, array &$args, mixed &$output): void {
        if (!$this->enabled() || !is_string($output) || $output === '') {
            return;
        }

        // A theme can legitimately render the header twice; only the first pass
        // gets the menu.
        if (self::$done || str_contains($output, 'nk-mega-menu__list')) {
            return;
        }

        $categories = $this->buildTree(0, '', 1, $this->depth());

        if (!$categories) {
            return;
        }

        $promo_image = $this->promoImage();

        $html = $this->inlineStyle() . $this->load->view('extension/nk_mega_menu/component/layout/mega_menu', [
            'novakur_mega_menu_categories' => $categories,
            'show_promo_column'            => $this->toggle('show_promo_column', false),
            'promo_link'                   => $this->safeLink((string)$this->config->get('module_mega_menu_promo_link')),
            'promo_image'                  => $promo_image
        ]);

        // Sit inside the theme's <header> element, just before it closes.
        $position = stripos($output, '</header>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }

        self::$done = true;
    }

    // ---------------------------------------------------------------- helpers

    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_mega_menu_status');
    }

    private function toggle(string $key, bool $default = true): bool {
        $value = $this->config->get('module_mega_menu_' . $key);

        if ($value === null || $value === '') {
            return $default;
        }

        return (bool)(int)$value;
    }

    private function depth(): int {
        $value = (int)$this->config->get('module_mega_menu_depth');

        return ($value === 2 || $value === 3) ? $value : 3;
    }

    private function columns(): int {
        $value = (int)$this->config->get('module_mega_menu_columns');

        return ($value >= 3 && $value <= 5) ? $value : 4;
    }

    private function color(string $key, string $default): string {
        $value = trim((string)$this->config->get('module_mega_menu_' . $key));

        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : $default;
    }

    /**
     * The stored promo image is a path relative to DIR_IMAGE; it has to be run
     * through the image tool to become a usable URL.
     */
    private function promoImage(): string {
        $image = trim((string)$this->config->get('module_mega_menu_promo_image'));

        // Re-check the stored path: settings can be edited outside the form.
        if ($image === '' || str_contains($image, '..') || str_starts_with($image, '/')) {
            return '';
        }

        $this->load->model('tool/image');

        return $this->model_tool_image->resize($image, 260, 340);
    }

    private function safeLink(string $link): string {
        $link = trim($link);

        if ($link === '' || preg_match('/^\s*(javascript|data|vbscript|file)\s*:/i', $link)) {
            return '';
        }

        return $link;
    }

    /**
     * Recursive category tree, depth-capped. Top-level nodes optionally carry
     * the six newest products of their branch.
     *
     * @return array<int, array<string, mixed>>
     */
    private function buildTree(int $parent_id, string $path, int $level, int $max_depth): array {
        if ($level > $max_depth) {
            return [];
        }

        $this->load->model('catalog/category');

        if (!isset($this->branch_cache[$parent_id])) {
            // OpenCart 4.x catalog model takes a plain parent id, not a filter array.
            $this->branch_cache[$parent_id] = $this->model_catalog_category->getCategories($parent_id);
        }

        $results = $this->branch_cache[$parent_id];

        if (!$results) {
            return [];
        }

        $tree = [];

        foreach ($results as $result) {
            $category_id = (int)$result['category_id'];
            $node_path   = $path === '' ? (string)$category_id : $path . '_' . $category_id;

            $tree[] = [
                'category_id' => $category_id,
                'name'        => html_entity_decode((string)$result['name'], ENT_QUOTES, 'UTF-8'),
                'href'        => $this->url->link('product/category', 'language=' . $this->config->get('config_language') . '&path=' . $node_path),
                'products'    => $level === 1 ? $this->topProducts($category_id) : [],
                'children'    => $this->buildTree($category_id, $node_path, $level + 1, $max_depth)
            ];
        }

        return $tree;
    }

    /**
     * @return array<int, array<string, string>>
     */
    private function topProducts(int $category_id): array {
        if (!$this->toggle('show_product_thumbnails', false)) {
            return [];
        }

        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $results = $this->model_catalog_product->getProducts([
            'filter_category_id'  => $category_id,
            'filter_sub_category' => true,
            'sort'                => 'p.date_added',
            'order'               => 'DESC',
            'start'               => 0,
            'limit'               => self::PRODUCT_LIMIT
        ]);

        $products = [];

        foreach ($results as $result) {
            $products[] = [
                'name'  => html_entity_decode((string)$result['name'], ENT_QUOTES, 'UTF-8'),
                'thumb' => !empty($result['image']) ? $this->model_tool_image->resize((string)$result['image'], 80, 80) : '',
                'href'  => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$result['product_id'])
            ];
        }

        return $products;
    }

    /**
     * The only per-store dynamic CSS: panel column count and the two colours.
     */
    private function inlineStyle(): string {
        $css = '.nk-mega-menu{'
            . '--nk-mm-columns:' . $this->columns() . ';'
            . '--nk-mm-background:' . $this->color('background_color', '#FFFFFF') . ';'
            . '--nk-mm-hover:' . $this->color('hover_color', '#2563EB') . ';'
            . '}';

        return '<style data-nk-mega-menu-style="1">' . $css . '</style>';
    }
}
