(function () {
  var root = document.querySelector('.nk-mega-menu');
  if (!root) return;

  var items = Array.prototype.slice.call(root.querySelectorAll('.nk-mega-menu__item'));
  if (!items.length) return;

  var closeTimer = null;

  function setOpen(item, open) {
    if (open) {
      item.classList.add('is-open');
    } else {
      item.classList.remove('is-open');
    }

    var link = item.querySelector(':scope > a');
    if (link && link.hasAttribute('aria-expanded')) {
      link.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
  }

  function closeAll() {
    items.forEach(function (item) {
      setOpen(item, false);
    });
  }

  items.forEach(function (item, index) {
    item.addEventListener('mouseenter', function () {
      if (closeTimer) clearTimeout(closeTimer);
      setOpen(item, true);
    });

    item.addEventListener('mouseleave', function () {
      if (closeTimer) clearTimeout(closeTimer);
      closeTimer = setTimeout(function () {
        setOpen(item, false);
      }, 150);
    });

    // Keyboard: opening happens on focus, so the panel links are reachable.
    item.addEventListener('focusin', function () {
      if (closeTimer) clearTimeout(closeTimer);
      setOpen(item, true);
    });

    item.addEventListener('focusout', function (e) {
      if (!item.contains(e.relatedTarget)) {
        setOpen(item, false);
      }
    });

    item.addEventListener('keydown', function (e) {
      var key = e.key;

      if (key === 'Escape') {
        setOpen(item, false);

        var link = item.querySelector(':scope > a');
        if (link) link.focus();

        return;
      }

      // Arrow keys move between top-level categories.
      if (key !== 'ArrowRight' && key !== 'ArrowLeft') return;
      if (e.target !== item.querySelector(':scope > a')) return;

      e.preventDefault();

      var next = key === 'ArrowRight' ? (index + 1) % items.length : (index - 1 + items.length) % items.length;
      var target = items[next].querySelector(':scope > a');

      if (target) {
        closeAll();
        target.focus();
      }
    });
  });

  document.addEventListener('click', function (e) {
    if (!root.contains(e.target)) closeAll();
  });
})();
