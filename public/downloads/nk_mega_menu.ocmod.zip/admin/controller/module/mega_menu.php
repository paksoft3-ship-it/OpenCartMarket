<?php
namespace Opencart\Admin\Controller\Extension\NkMegaMenu\Module;

/**
 * NovaKur Mega Menu
 *
 * Settings namespace: module_mega_menu_*
 * Route:              extension/nk_mega_menu/module/mega_menu
 * Event codes:        nk_mega_menu_assets / nk_mega_menu_view
 *
 * Kept deliberately separate from the `nk-pack-navigation` module: different
 * setting code, different route, different event codes, different file names.
 */
class MegaMenu extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_mega_menu/module/mega_menu';
    private string $prefix = 'module_mega_menu';

    /**
     * Default setting values. Every key must start with $prefix or
     * ModelSettingSetting::editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_mega_menu_status'                  => '0',
            'module_mega_menu_depth'                   => '3',
            'module_mega_menu_columns'                 => '4',
            'module_mega_menu_show_product_thumbnails' => '0',
            'module_mega_menu_show_promo_column'       => '0',
            'module_mega_menu_promo_image'             => '',
            'module_mega_menu_promo_link'              => '',
            'module_mega_menu_background_color'        => '#FFFFFF',
            'module_mega_menu_hover_color'             => '#2563EB'
        ];
    }

    /**
     * Storefront hooks. `assets` has to run on the controller/before trigger:
     * by the time the header view is rendered the document's style/script list
     * has already been copied into the template data.
     *
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_mega_menu_assets',
                'description' => 'NovaKur Mega Menu: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_mega_menu/event/mega_menu.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_mega_menu_view',
                'description' => 'NovaKur Mega Menu: menu markup injection',
                'trigger'     => 'catalog/view/common/header/after',
                'action'      => 'extension/nk_mega_menu/event/mega_menu.view',
                'status'      => 1,
                'sort_order'  => 2
            ]
        ];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_appearance',
            'text_promo',
            'entry_status',
            'entry_depth',
            'entry_columns',
            'entry_show_product_thumbnails',
            'entry_show_promo_column',
            'entry_promo_image',
            'entry_promo_link',
            'entry_background_color',
            'entry_hover_color',
            'help_depth',
            'help_columns',
            'help_show_product_thumbnails',
            'help_promo',
            'button_save',
            'button_back',
            'button_edit',
            'button_clear',
            'error_permission',
            'error_depth',
            'error_columns',
            'error_color',
            'error_promo_link'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $this->load->model('tool/image');

        $data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

        $promo_image = $this->sanitizeImage((string)$data[$this->prefix . '_promo_image']);

        $data[$this->prefix . '_promo_image'] = $promo_image;
        $data['promo_thumb'] = $promo_image !== '' ? $this->model_tool_image->resize($promo_image, 100, 100) : $data['placeholder'];

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        foreach (['status', 'show_product_thumbnails', 'show_promo_column'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        $depth = trim((string)($post[$this->prefix . '_depth'] ?? '3'));

        if (!in_array($depth, ['2', '3'], true)) {
            $json['error'][$this->prefix . '_depth'] = $this->language->get('error_depth');
        } else {
            $save[$this->prefix . '_depth'] = $depth;
        }

        $columns = trim((string)($post[$this->prefix . '_columns'] ?? '4'));

        if (!in_array($columns, ['3', '4', '5'], true)) {
            $json['error'][$this->prefix . '_columns'] = $this->language->get('error_columns');
        } else {
            $save[$this->prefix . '_columns'] = $columns;
        }

        foreach (['background_color' => '#FFFFFF', 'hover_color' => '#2563EB'] as $key => $default) {
            $color = trim((string)($post[$this->prefix . '_' . $key] ?? $default));

            if ($color === '') {
                $color = $default;
            }

            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_color');
            } else {
                $save[$this->prefix . '_' . $key] = strtoupper($color);
            }
        }

        $save[$this->prefix . '_promo_image'] = $this->sanitizeImage((string)($post[$this->prefix . '_promo_image'] ?? ''));

        $promo_link = trim((string)($post[$this->prefix . '_promo_link'] ?? ''));

        if ($promo_link !== '' && $this->sanitizeLink($promo_link) === '') {
            $json['error'][$this->prefix . '_promo_link'] = $this->language->get('error_promo_link');
        } else {
            $save[$this->prefix . '_promo_link'] = $this->sanitizeLink($promo_link);
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    /**
     * Accept only a relative path inside the store's image directory.
     */
    private function sanitizeImage(string $image): string {
        $image = trim(str_replace('\\', '/', $image));

        if ($image === '') {
            return '';
        }

        if (str_contains($image, '..') || str_starts_with($image, '/')) {
            return '';
        }

        if (!preg_match('/^[a-zA-Z0-9 _\-\/.]+\.(jpg|jpeg|png|gif|webp|svg)$/i', $image)) {
            return '';
        }

        return $image;
    }

    /**
     * Accept an empty value, a relative path, or an http(s) URL. Anything that
     * could execute (javascript:, data:, vbscript:) is discarded.
     */
    private function sanitizeLink(string $link): string {
        $link = trim(strip_tags($link));

        if ($link === '') {
            return '';
        }

        if (preg_match('/^\s*(javascript|data|vbscript|file)\s*:/i', $link)) {
            return '';
        }

        if (preg_match('/[\r\n\t<>"\']/', $link)) {
            return '';
        }

        return mb_substr($link, 0, 500);
    }
}
