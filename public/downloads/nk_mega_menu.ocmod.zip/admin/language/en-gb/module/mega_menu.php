<?php
// Heading
$_['heading_title']                 = 'NovaKur Mega Menu';

// Text
$_['text_extension']                = 'Extensions';
$_['text_success']                  = 'Success: You have modified NovaKur Mega Menu settings!';
$_['text_edit']                     = 'Edit NovaKur Mega Menu';
$_['text_enabled']                  = 'Enabled';
$_['text_disabled']                 = 'Disabled';
$_['text_general']                  = 'General';
$_['text_appearance']               = 'Appearance';
$_['text_promo']                    = 'Promo Column';

// Entry
$_['entry_status']                  = 'Status';
$_['entry_depth']                   = 'Category Depth';
$_['entry_columns']                 = 'Columns Per Panel';
$_['entry_show_product_thumbnails'] = 'Product Thumbnails';
$_['entry_show_promo_column']       = 'Show Promo Column';
$_['entry_promo_image']             = 'Promo Image';
$_['entry_promo_link']              = 'Promo Link';
$_['entry_background_color']        = 'Dropdown Background';
$_['entry_hover_color']             = 'Link Hover Colour';

// Help
$_['help_depth']                    = 'How many category levels the dropdown shows. 2 = category + subcategory, 3 = also sub-subcategories.';
$_['help_columns']                  = 'Number of subcategory columns inside a dropdown panel.';
$_['help_show_product_thumbnails']  = 'Show the six newest products of each top-level category inside its dropdown.';
$_['help_promo']                    = 'The promo column only renders when it is enabled and an image has been chosen.';

// Button
$_['button_save']                   = 'Save';
$_['button_back']                   = 'Back';

// Error
$_['error_permission']              = 'Warning: You do not have permission to modify this module!';
$_['error_depth']                   = 'Depth must be 2 or 3!';
$_['error_columns']                 = 'Columns must be 3, 4 or 5!';
$_['error_color']                   = 'Colour must be a 6 digit hex value, e.g. #2563EB!';
$_['error_promo_link']              = 'Promo link must be a plain relative path or an http(s) URL!';
