<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkPackProductPage extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if ($route !== 'product/product') {
            return;
        }

        if (!$this->isPackActive()) {
            return;
        }

        $product_id = (int)($this->request->get['product_id'] ?? 0);

        if (!$product_id) {
            return;
        }

        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $product_info = $this->model_catalog_product->getProduct($product_id);

        if (!$product_info) {
            return;
        }

        $currency  = $this->session->data['currency'] ?? $this->config->get('config_currency');
        $threshold = $this->lowStockThreshold();

        $show_badges          = $this->toggleEnabled('show_badges');
        $show_trust_row       = $this->toggleEnabled('show_trust_row');
        $show_tabs            = $this->toggleEnabled('show_tabs');
        $show_sticky_cta      = $this->toggleEnabled('show_sticky_cta');
        $show_recently_viewed = $this->toggleEnabled('show_recently_viewed');

        // ---- Raw pricing for discount percentage ----
        $tax_class_id = (int)($product_info['tax_class_id'] ?? 0);
        $price_raw    = (float)$this->tax->calculate((float)($product_info['price'] ?? 0), $tax_class_id, $this->config->get('config_tax'));

        $special_raw      = 0.0;
        $discount_percent = 0;

        if (!empty($product_info['special']) && (float)$product_info['special'] > 0) {
            $special_raw = (float)$this->tax->calculate((float)$product_info['special'], $tax_class_id, $this->config->get('config_tax'));

            if ($price_raw > 0 && $special_raw < $price_raw) {
                $discount_percent = (int)round(100 - ($special_raw / $price_raw) * 100);
            }
        }

        $price_formatted   = !empty($data['price']) ? (string)$data['price'] : $this->currency->format($price_raw, $currency);
        $special_formatted = !empty($data['special']) ? (string)$data['special'] : ($special_raw > 0.0 ? $this->currency->format($special_raw, $currency) : '');

        // ---- Product facts used by the conversion blocks ----
        $name       = (string)($data['heading_title'] ?? ($product_info['name'] ?? ''));
        $quantity   = (int)($product_info['quantity'] ?? 0);
        $date_added = (string)($product_info['date_added'] ?? '');
        $href       = $this->url->link('product/product', 'product_id=' . $product_id);

        $is_new       = $date_added !== '' && strtotime($date_added) >= strtotime('-30 days');
        $is_sale      = $special_formatted !== '';
        $is_low_stock = $threshold > 0 && $quantity > 0 && $quantity <= $threshold;

        $thumb = (string)($data['thumb'] ?? '');
        if ($thumb === '' && !empty($product_info['image'])) {
            $thumb = $this->model_tool_image->resize($product_info['image'], 100, 100);
        }

        $description = (string)($data['description'] ?? html_entity_decode((string)($product_info['description'] ?? ''), ENT_QUOTES, 'UTF-8'));

        $attribute_groups = $data['attribute_groups'] ?? [];
        if (!$attribute_groups) {
            $attribute_groups = $this->model_catalog_product->getAttributes($product_id);
        }

        // ---- Injected asset URLs + toggles (any product template can use these) ----
        $data['nk_ppp_css'] = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-product-pack.css';
        $data['nk_ppp_js']  = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/nk-product-pack.js';

        $data['nk_ppp_show_badges']          = (int)$show_badges;
        $data['nk_ppp_show_trust_row']       = (int)$show_trust_row;
        $data['nk_ppp_show_tabs']            = (int)$show_tabs;
        $data['nk_ppp_show_sticky_cta']      = (int)$show_sticky_cta;
        $data['nk_ppp_show_recently_viewed'] = (int)$show_recently_viewed;
        $data['nk_ppp_low_stock_threshold']  = $threshold;
        $data['nk_ppp_discount_percent']     = $discount_percent;

        // ---- Pre-rendered conversion blocks (echo with |raw anywhere) ----
        $data['nk_ppp_badges'] = $show_badges ? $this->load->view('extension/novakur/component/conversion/badge_row', [
            'is_new'              => $is_new,
            'is_sale'             => $is_sale,
            'is_low_stock'        => $is_low_stock,
            'quantity'            => $quantity,
            'low_stock_threshold' => $threshold,
            'date_added'          => $date_added,
            'special'             => $special_formatted,
            'discount_percent'    => $discount_percent,
        ]) : '';

        $data['nk_ppp_trust_row'] = $show_trust_row ? $this->load->view('extension/novakur/component/conversion/trust_row', []) : '';

        $data['nk_ppp_tabs'] = $show_tabs ? $this->load->view('extension/novakur/component/conversion/product_tabs', [
            'description'      => $description,
            'attribute_groups' => $attribute_groups,
            'reviews_html'     => (string)($data['review'] ?? ''),
            'review_status'    => (bool)$this->config->get('config_review_status'),
            'rating'           => (float)($product_info['rating'] ?? 0),
        ]) : '';

        $data['nk_ppp_sticky_cta'] = $show_sticky_cta ? $this->load->view('extension/novakur/component/conversion/sticky_cta', [
            'product_id' => $product_id,
            'name'       => $name,
            'thumb'      => $thumb,
            'price'      => $price_formatted,
            'special'    => $special_formatted,
        ]) : '';

        $data['nk_ppp_recently_viewed'] = $show_recently_viewed ? $this->load->view('extension/novakur/component/conversion/recently_viewed', [
            'product_id' => $product_id,
            'name'       => $name,
            'thumb'      => $thumb,
            'href'       => $href,
        ]) : '';

        // ---- Optional full template override ----
        if ($this->toggleEnabled('re_route_template', false)) {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_conversion.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_conversion';
            }
        }
    }

    private function toggleEnabled(string $key, bool $default = true): bool {
        $value = $this->config->get('theme_nk_pack_product_page_' . $key);

        if ($value === null || $value === '') {
            return $default;
        }

        return (bool)(int)$value;
    }

    private function lowStockThreshold(): int {
        $value = $this->config->get('theme_nk_pack_product_page_low_stock_threshold');

        if ($value === null || $value === '' || !is_numeric($value)) {
            return 5;
        }

        $threshold = (int)$value;

        return ($threshold >= 0 && $threshold <= 99) ? $threshold : 5;
    }

    private function isPackActive(): bool {
        if (!(bool)$this->config->get('theme_nk_pack_product_page_status')) {
            return false;
        }

        $current_theme = (string)$this->config->get('config_theme');

        return str_starts_with($current_theme, 'nk_') || str_starts_with($current_theme, 'novakur_');
    }
}
