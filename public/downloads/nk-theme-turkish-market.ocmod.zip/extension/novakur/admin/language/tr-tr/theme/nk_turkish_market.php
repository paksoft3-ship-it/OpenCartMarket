<?php
$_['heading_title'] = 'NovaKur Türk Pazaryeri Teması';
$_['text_edit'] = 'Türk pazaryeri teması ayarları';
$_['text_enabled'] = 'Etkin';
$_['text_disabled'] = 'Devre Dışı';
$_['text_home'] = 'Ana Sayfa';
$_['text_extension'] = 'Eklentiler';
$_['text_success'] = 'Başarılı: Türk Pazaryeri teması ayarları kaydedildi!';
$_['entry_status'] = 'Durum';
$_['entry_primary_color'] = 'Ana Renk';
$_['entry_show_installments'] = 'Taksit Tablosunu Göster';
$_['entry_show_trust_badges'] = 'Güven Rozetlerini Göster';
$_['entry_show_campaign_banner'] = 'Kampanya Bannerını Göster';
$_['button_save'] = 'Kaydet';
$_['button_back'] = 'Geri';
$_['error_permission'] = 'Uyarı: Bu temayı değiştirme yetkiniz bulunmuyor!';
$_['error_color'] = 'Geçerli bir hex renk değeri girin.';
