<?php
$_['heading_title'] = 'NovaKur Turkish Market Theme';
$_['text_edit'] = 'Turkish marketplace theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Turkish Market theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_installments'] = 'Show Installment Table (Taksit)';
$_['entry_show_trust_badges'] = 'Show Turkish Trust Badges';
$_['entry_show_campaign_banner'] = 'Show Campaign Banner (Kampanya)';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
