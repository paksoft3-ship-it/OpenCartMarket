<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkTurkishMarket extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isTurkishMarketThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_turkish_market.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-turkish-market.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_turkish_market_primary_color') ?: '#e8552d';
                $data['novakur_secondary_color'] = '#1b3b6f';
                $data['novakur_container_width'] = 1280;
                $data['novakur_base_font']       = 'Inter';
                $data['novakur_heading_font']    = 'Rubik';
                $data['cart_quantity']           = $this->cart->countProducts();

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_turkish_market';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_turkish_market.twig';
            if (is_file($template)) {
                $data['nk_show_trust_badges'] = (bool)$this->config->get('theme_nk_turkish_market_show_trust_badges');

                $route = 'extension/novakur/common/footer_turkish_market';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_turkish_market';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            $data['nk_show_campaign_banner'] = (bool)$this->config->get('theme_nk_turkish_market_show_campaign_banner');
            $data['nk_show_trust_badges']    = (bool)$this->config->get('theme_nk_turkish_market_show_trust_badges');

            // Category tiles
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => ($cat['image'] ?? '')
                        ? $this->model_tool_image->resize($cat['image'], $img_w, $img_h)
                        : '',
                ];
            }

            // Latest arrivals
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            // Bestsellers — "Cok Satanlar"
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_turkish_market';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers / Kampanyalar ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_turkish_market';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $data['nk_show_campaign_banner'] = (bool)$this->config->get('theme_nk_turkish_market_show_campaign_banner');

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_turkish_market';
            }

            $data['nk_show_installments'] = (bool)$this->config->get('theme_nk_turkish_market_show_installments');
            $data['nk_show_trust_badges'] = (bool)$this->config->get('theme_nk_turkish_market_show_trust_badges');

            // Raw taxed price for the display-only installment table (computed in Twig)
            $product_id = (int)($this->request->get['product_id'] ?? 0);
            if ($product_id) {
                $this->load->model('catalog/product');
                $info = $this->model_catalog_product->getProduct($product_id);
                if ($info) {
                    $base = !empty($info['special']) ? $info['special'] : ($info['price'] ?? 0);
                    $data['nk_price_raw'] = (float)$this->tax->calculate(
                        $base,
                        $info['tax_class_id'] ?? 0,
                        $this->config->get('config_tax')
                    );
                }
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_turkish_market.twig';
            if (is_file($template)) {
                $data['nk_show_trust_badges'] = (bool)$this->config->get('theme_nk_turkish_market_show_trust_badges');

                $route = 'extension/novakur/checkout/cart_turkish_market';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_turkish_market.twig';
            if (is_file($template)) {
                $data['nk_show_trust_badges'] = (bool)$this->config->get('theme_nk_turkish_market_show_trust_badges');

                $route = 'extension/novakur/checkout/checkout_turkish_market';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_turkish_market';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 10);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_turkish_market';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_turkish_market';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_turkish_market';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_turkish_market';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_turkish_market';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_turkish_market.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_turkish_market';
            }
        }
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isTurkishMarketThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_turkish_market', 'novakur_turkish_market'], true)
            && (bool)$this->config->get('theme_nk_turkish_market_status');
    }
}
