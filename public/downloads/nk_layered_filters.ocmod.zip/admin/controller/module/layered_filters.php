<?php
namespace Opencart\Admin\Controller\Extension\NkLayeredFilters\Module;

class LayeredFilters extends \Opencart\System\Engine\Controller {
    /**
     * Catalog events registered on install and removed again on uninstall.
     *
     * @var array<int, array<string, mixed>>
     */
    private array $events = [
        [
            'code'        => 'novakur_layered_filters_assets',
            'description' => 'NovaKur Advanced Layered Filters: registers the sidebar stylesheet and script before the page header is rendered.',
            'trigger'     => 'catalog/controller/product/category/before',
            'action'      => 'extension/nk_layered_filters/event/layered_filters.assets',
            'status'      => 1,
            'sort_order'  => 1
        ],
        [
            'code'        => 'novakur_layered_filters',
            'description' => 'NovaKur Advanced Layered Filters: injects the filter sidebar and the filtered product grid into the category page.',
            'trigger'     => 'catalog/view/product/category/before',
            'action'      => 'extension/nk_layered_filters/event/layered_filters.category',
            'status'      => 1,
            'sort_order'  => 1
        ],
        [
            'code'        => 'novakur_layered_filters_inject',
            'description' => 'NovaKur Advanced Layered Filters: fallback sidebar injection for themes without a left column.',
            'trigger'     => 'catalog/view/product/category/after',
            'action'      => 'extension/nk_layered_filters/event/layered_filters.inject',
            'status'      => 1,
            'sort_order'  => 1
        ]
    ];

    /**
     * Default settings. Also the single source of truth for the admin form fields.
     *
     * @var array<string, string>
     */
    private array $defaults = [
        'module_layered_filters_status'       => '0',
        'module_layered_filters_price'        => '1',
        'module_layered_filters_filter'       => '1',
        'module_layered_filters_attribute'    => '1',
        'module_layered_filters_option'       => '1',
        'module_layered_filters_manufacturer' => '1',
        'module_layered_filters_stock'        => '1',
        'module_layered_filters_price_step'   => '1',
        'module_layered_filters_show_counts'  => '1',
        'module_layered_filters_ajax'         => '1'
    ];

    public function index(): void {
        $this->load->language('extension/nk_layered_filters/module/layered_filters');
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting('module_layered_filters', $store_id);

        $data = [];

        foreach ($this->defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_general'] = $this->language->get('text_general');
        $data['text_types'] = $this->language->get('text_types');
        $data['text_usage'] = $this->language->get('text_usage');

        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_price'] = $this->language->get('entry_price');
        $data['entry_filter'] = $this->language->get('entry_filter');
        $data['entry_attribute'] = $this->language->get('entry_attribute');
        $data['entry_option'] = $this->language->get('entry_option');
        $data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
        $data['entry_stock'] = $this->language->get('entry_stock');
        $data['entry_price_step'] = $this->language->get('entry_price_step');
        $data['entry_show_counts'] = $this->language->get('entry_show_counts');
        $data['entry_ajax'] = $this->language->get('entry_ajax');

        $data['help_price'] = $this->language->get('help_price');
        $data['help_filter'] = $this->language->get('help_filter');
        $data['help_attribute'] = $this->language->get('help_attribute');
        $data['help_option'] = $this->language->get('help_option');
        $data['help_manufacturer'] = $this->language->get('help_manufacturer');
        $data['help_stock'] = $this->language->get('help_stock');
        $data['help_price_step'] = $this->language->get('help_price_step');
        $data['help_show_counts'] = $this->language->get('help_show_counts');
        $data['help_ajax'] = $this->language->get('help_ajax');
        $data['help_usage'] = $this->language->get('help_usage');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_back'] = $this->language->get('button_back');

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_layered_filters/module/layered_filters', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/nk_layered_filters/module/layered_filters.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_layered_filters/module/layered_filters', $data));
    }

    public function save(): void {
        $this->load->language('extension/nk_layered_filters/module/layered_filters');
        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_layered_filters/module/layered_filters')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $step = isset($this->request->post['module_layered_filters_price_step']) ? (float)str_replace(',', '.', (string)$this->request->post['module_layered_filters_price_step']) : 1;

        if ($step <= 0 || $step > 10000) {
            $json['error']['warning'] = $this->language->get('error_form');
            $json['error']['price_step'] = $this->language->get('error_price_step');
        }

        if (!isset($json['error'])) {
            $save = [];

            foreach ($this->defaults as $key => $default) {
                if ($key == 'module_layered_filters_price_step') {
                    $save[$key] = (string)$step;
                } else {
                    $save[$key] = isset($this->request->post[$key]) ? (string)(int)$this->request->post[$key] : '0';
                }
            }

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_layered_filters', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_layered_filters', $this->defaults);

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_layered_filters');

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }
    }
}
