<?php
namespace Opencart\Catalog\Controller\Extension\NkLayeredFilters\Event;
/**
 * Class LayeredFilters
 *
 * Hooks the category page without touching a single core file.
 *
 * category() runs on catalog/view/product/category/before: it builds the sidebar, drops it into
 * the left column and, when filters are active, swaps the product grid, pagination and result
 * counter for the filtered set.
 *
 * inject() runs on catalog/view/product/category/after and is only a safety net for themes whose
 * category template does not output {{ column_left }}.
 *
 * @package Opencart\Catalog\Controller\Extension\NkLayeredFilters\Event
 */
class LayeredFilters extends \Opencart\System\Engine\Controller {
	/**
	 * Sidebar HTML kept between the before and after events.
	 *
	 * @var string
	 */
	protected static string $sidebar = '';

	/**
	 * Assets
	 *
	 * Runs on catalog/controller/product/category/before. The stylesheet and script have to be
	 * registered here because common/header is rendered before the category view event fires.
	 *
	 * @param string              $route
	 * @param array<int, mixed>   $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_layered_filters_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_layered_filters/catalog/view/assets/css/layered_filters.css');
		$this->document->addScript('extension/nk_layered_filters/catalog/view/assets/js/layered_filters.js');
	}

	/**
	 * Category
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param string               $code
	 * @param string               $output
	 *
	 * @return void
	 */
	public function category(string &$route, array &$data, string &$code, string &$output): void {
		if (!(int)$this->config->get('module_layered_filters_status')) {
			return;
		}

		$result = $this->load->controller('extension/nk_layered_filters/module/layered_filters.build');

		if (!is_array($result)) {
			return;
		}

		if (!empty($result['sidebar'])) {
			self::$sidebar = (string)$result['sidebar'];

			if (!empty($data['column_left']) && str_contains((string)$data['column_left'], '</aside>')) {
				// Slot it in underneath whatever modules the merchant already placed there.
				$position = strrpos((string)$data['column_left'], '</aside>');

				$data['column_left'] = substr((string)$data['column_left'], 0, $position) . self::$sidebar . substr((string)$data['column_left'], $position);
			} else {
				$data['column_left'] = '<aside id="column-left" class="col-12 col-lg-3">' . self::$sidebar . '</aside>' . (string)($data['column_left'] ?? '');
			}
		}

		if (!empty($result['filtered'])) {
			$data['products'] = $result['products'];
			$data['pagination'] = $result['pagination'];
			$data['results'] = $result['results'];

			// Keep the active filters when the shopper changes the sort order or page size.
			$data['sorts'] = $result['sorts'];
			$data['limits'] = $result['limits'];
			$data['sort'] = $result['sort'];
			$data['order'] = $result['order'];
			$data['limit'] = $result['limit'];

			// The core template hides the whole toolbar when there are no products, so keep the
			// "no results" copy meaningful when a filter combination matches nothing.
			if (!$result['products']) {
				$this->load->language('extension/nk_layered_filters/module/layered_filters');

				$data['text_no_results'] = $this->language->get('text_empty');
			}
		}
	}

	/**
	 * Inject
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param string               $output
	 *
	 * @return void
	 */
	public function inject(string &$route, array &$data, string &$output): void {
		if (!(int)$this->config->get('module_layered_filters_status')) {
			return;
		}

		if (self::$sidebar === '' || !is_string($output) || str_contains($output, 'id="novakur-lf"')) {
			return;
		}

		$position = strpos($output, '<div id="content"');

		if ($position !== false) {
			$output = substr($output, 0, $position) . '<aside id="column-left" class="col-12 col-lg-3">' . self::$sidebar . '</aside>' . substr($output, $position);
		}

		self::$sidebar = '';
	}
}
