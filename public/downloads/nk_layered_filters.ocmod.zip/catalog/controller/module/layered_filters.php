<?php
namespace Opencart\Catalog\Controller\Extension\NkLayeredFilters\Module;
/**
 * Class LayeredFilters
 *
 * Storefront side of NovaKur Advanced Layered Filters.
 *
 * index()   renders the filter sidebar (so it can also be dropped into a layout position).
 * build()   is called by the category event and returns the sidebar plus the re-filtered
 *           product grid, pagination and result counter.
 * results() is the AJAX endpoint (extension/nk_layered_filters/module/layered_filters.results) that
 *           returns the rendered product grid fragment as JSON.
 *
 * @package Opencart\Catalog\Controller\Extension\NkLayeredFilters\Module
 */
class LayeredFilters extends \Opencart\System\Engine\Controller {
	/**
	 * Set once the sidebar has been rendered in this request so it is never output twice.
	 *
	 * @var bool
	 */
	protected static bool $rendered = false;

	/**
	 * Index
	 *
	 * Renders the sidebar on its own. Useful when the merchant prefers to place the module in a
	 * layout position instead of relying on the automatic injection.
	 *
	 * @return string
	 */
	public function index(): string {
		if (!$this->enabled()) {
			return '';
		}

		$request = $this->collect($this->request->get);

		if (!$request['category_id']) {
			return '';
		}

		return $this->sidebar($request);
	}

	/**
	 * Build
	 *
	 * Called from the catalog event. Returns everything the category page needs.
	 *
	 * @return array<string, mixed>
	 */
	public function build(): array {
		$result = [
			'sidebar'    => '',
			'filtered'   => false,
			'products'   => [],
			'pagination' => '',
			'results'    => '',
			'total'      => 0,
			'sorts'      => [],
			'limits'     => [],
			'sort'       => 'p.sort_order',
			'order'      => 'ASC',
			'limit'      => (int)$this->config->get('config_pagination')
		];

		if (!$this->enabled()) {
			return $result;
		}

		$request = $this->collect($this->request->get);

		if (!$request['category_id']) {
			return $result;
		}

		if (!self::$rendered) {
			$result['sidebar'] = $this->sidebar($request);
		}

		if ($request['active']) {
			$grid = $this->grid($request);
			$toolbar = $this->toolbar($request);

			$result['filtered'] = true;
			$result['products'] = $grid['products'];
			$result['pagination'] = $grid['pagination'];
			$result['results'] = $grid['results'];
			$result['total'] = $grid['total'];
			$result['sorts'] = $toolbar['sorts'];
			$result['limits'] = $toolbar['limits'];
			$result['sort'] = $request['sort'];
			$result['order'] = $request['order'];
			$result['limit'] = $request['limit'];
		}

		return $result;
	}

	/**
	 * Results
	 *
	 * AJAX endpoint. Returns the rendered product grid fragment plus the refreshed facet counts.
	 *
	 * @return void
	 */
	public function results(): void {
		$this->load->language('extension/nk_layered_filters/module/layered_filters');

		$json = [];

		if (!$this->enabled()) {
			$json['error'] = $this->language->get('error_disabled');
		}

		if (!isset($json['error'])) {
			$request = $this->collect($this->request->get);

			if (!$request['category_id']) {
				$json['error'] = $this->language->get('error_category');
			} else {
				$grid = $this->grid($request);
				$toolbar = $this->toolbar($request, true);

				$json['list'] = implode('', array_map(static function (string $product): string {
					return '<div class="col mb-3">' . $product . '</div>';
				}, $grid['products']));

				$json['pagination'] = $grid['pagination'];
				$json['results'] = $grid['results'];
				$json['total'] = $grid['total'];
				$json['url'] = $this->categoryLink($request, ['page' => $request['page']]);
				$json['counts'] = $this->counts($request);
				$json['text_empty'] = $this->language->get('text_empty');

				// So that changing the sort order or page size afterwards keeps the filters.
				$json['sorts'] = array_column($toolbar['sorts'], 'href');
				$json['limits'] = array_column($toolbar['limits'], 'href');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Enabled
	 *
	 * @return bool
	 */
	protected function enabled(): bool {
		return (bool)(int)$this->config->get('module_layered_filters_status');
	}

	/**
	 * Types
	 *
	 * Which facet types the merchant switched on.
	 *
	 * @return array<string, bool>
	 */
	protected function types(): array {
		$types = [];

		foreach (['price', 'filter', 'attribute', 'option', 'manufacturer', 'stock'] as $type) {
			$setting = $this->config->get('module_layered_filters_' . $type);

			// Default to on when the setting has never been written.
			$types[$type] = $setting === null ? true : (bool)(int)$setting;
		}

		return $types;
	}

	/**
	 * Collect
	 *
	 * Normalises the request into a canonical filter set. Every value accepts both the compact
	 * comma separated form used by the shareable URLs (filter_manufacturer=1,3) and the array
	 * form produced by a plain GET form submission (filter_manufacturer[]=1&filter_manufacturer[]=3).
	 *
	 * @param array<string, mixed> $get
	 *
	 * @return array<string, mixed>
	 */
	protected function collect(array $get): array {
		$types = $this->types();

		$path = isset($get['path']) ? preg_replace('/[^0-9_]/', '', (string)$get['path']) : '';

		if ($path !== '') {
			$parts = explode('_', $path);
			$category_id = (int)array_pop($parts);
		} else {
			$category_id = isset($get['category_id']) ? (int)$get['category_id'] : 0;
		}

		$filters = ['filter_category_id' => $category_id];

		$selected = [];

		// Manufacturers
		if ($types['manufacturer']) {
			$values = array_values(array_unique(array_filter(array_map('intval', $this->listed($get, 'filter_manufacturer')))));

			if ($values) {
				$filters['filter_manufacturer'] = $values;

				foreach ($values as $value) {
					$selected['filter_manufacturer'][] = (string)$value;
				}
			}
		}

		// Stock OpenCart filters
		if ($types['filter']) {
			$values = $this->listed($get, 'filter_filter');

			// Honour the core "filter" parameter too so existing filter links keep working.
			if (isset($get['filter']) && is_string($get['filter'])) {
				$values = array_merge($values, explode(',', (string)$get['filter']));
			}

			$values = array_values(array_unique(array_filter(array_map('intval', $values))));

			if ($values) {
				$filters['filter_filter'] = $values;

				foreach ($values as $value) {
					$selected['filter_filter'][] = (string)$value;
				}
			}
		}

		// Availability. Selecting both or neither means "no restriction".
		if ($types['stock']) {
			$values = array_values(array_intersect(['in', 'out'], array_map('strval', $this->listed($get, 'filter_stock'))));

			if (count($values) == 1) {
				$filters['filter_stock'] = $values[0];
				$selected['filter_stock'][] = $values[0];
			}
		}

		// Attributes: attribute_id:text
		if ($types['attribute']) {
			foreach ($this->listed($get, 'filter_attribute') as $value) {
				$pair = explode(':', (string)$value, 2);

				if (count($pair) != 2 || !(int)$pair[0] || $pair[1] === '') {
					continue;
				}

				// The request library html encodes GET data, the DB copy is encoded once only.
				$text = html_entity_decode($pair[1], ENT_COMPAT, 'UTF-8');

				$filters['filter_attribute'][(int)$pair[0]][] = $text;
				$selected['filter_attribute'][] = (int)$pair[0] . ':' . $text;
			}
		}

		// Option values: option_id:option_value_id
		if ($types['option']) {
			foreach ($this->listed($get, 'filter_option') as $value) {
				$pair = explode(':', (string)$value, 2);

				if (count($pair) != 2 || !(int)$pair[0] || !(int)$pair[1]) {
					continue;
				}

				$filters['filter_option'][(int)$pair[0]][] = (int)$pair[1];
				$selected['filter_option'][] = (int)$pair[0] . ':' . (int)$pair[1];
			}
		}

		// Price. Values arrive in the shopper's display currency.
		$price_min = '';
		$price_max = '';

		if ($types['price']) {
			if (isset($get['filter_price']) && is_string($get['filter_price']) && str_contains($get['filter_price'], '-')) {
				[$price_min, $price_max] = explode('-', (string)$get['filter_price'], 2);
			}

			if (isset($get['filter_price_min']) && $get['filter_price_min'] !== '') {
				$price_min = (string)$get['filter_price_min'];
			}

			if (isset($get['filter_price_max']) && $get['filter_price_max'] !== '') {
				$price_max = (string)$get['filter_price_max'];
			}

			$price_min = is_numeric($price_min) ? (float)$price_min : '';
			$price_max = is_numeric($price_max) ? (float)$price_max : '';

			if ($price_min !== '' && $price_max !== '' && $price_min > $price_max) {
				[$price_min, $price_max] = [$price_max, $price_min];
			}

			$currency = $this->session->data['currency'] ?? (string)$this->config->get('config_currency');

			if ($price_min !== '') {
				$filters['filter_price_min'] = $this->currency->convert((float)$price_min, $currency, (string)$this->config->get('config_currency'));
			}

			if ($price_max !== '') {
				$filters['filter_price_max'] = $this->currency->convert((float)$price_max, $currency, (string)$this->config->get('config_currency'));
			}
		}

		$sort_data = ['pd.name', 'p.model', 'p.quantity', 'p.price', 'rating', 'p.sort_order', 'p.date_added'];

		$sort = isset($get['sort']) && in_array($get['sort'], $sort_data) ? (string)$get['sort'] : 'p.sort_order';
		$order = isset($get['order']) && strtoupper((string)$get['order']) == 'DESC' ? 'DESC' : 'ASC';
		$page = isset($get['page']) && (int)$get['page'] > 0 ? (int)$get['page'] : 1;
		$limit = isset($get['limit']) && (int)$get['limit'] > 0 ? (int)$get['limit'] : (int)$this->config->get('config_pagination');

		if ($limit < 1) {
			$limit = 20;
		}

		return [
			'category_id' => $category_id,
			'path'        => $path,
			'types'       => $types,
			'filters'     => $filters,
			'selected'    => $selected,
			'price_min'   => $price_min,
			'price_max'   => $price_max,
			'sort'        => $sort,
			'order'       => $order,
			'page'        => $page,
			'limit'       => $limit,
			'active'      => (bool)$selected || $price_min !== '' || $price_max !== ''
		];
	}

	/**
	 * Listed
	 *
	 * Reads one filter parameter as a flat list, accepting both "a,b" and ['a', 'b'].
	 *
	 * @param array<string, mixed> $get
	 * @param string               $key
	 *
	 * @return array<int, string>
	 */
	protected function listed(array $get, string $key): array {
		if (!isset($get[$key])) {
			return [];
		}

		$value = $get[$key];

		if (is_array($value)) {
			$list = [];

			foreach ($value as $item) {
				if (is_scalar($item)) {
					$list[] = (string)$item;
				}
			}
		} elseif (is_scalar($value)) {
			$list = explode(',', (string)$value);
		} else {
			return [];
		}

		return array_values(array_filter(array_map('trim', $list), static fn(string $item): bool => $item !== ''));
	}

	/**
	 * Grid
	 *
	 * Runs the filtered query and renders the product thumbs, pagination and counter.
	 *
	 * @param array<string, mixed> $request
	 *
	 * @return array<string, mixed>
	 */
	protected function grid(array $request): array {
		$this->load->language('product/category');
		$this->load->model('extension/nk_layered_filters/module/layered_filters');
		$this->load->model('tool/image');

		$page = (int)$request['page'];
		$limit = (int)$request['limit'];

		$data = $request['filters'] + [
			'sort'  => $request['sort'],
			'order' => $request['order'],
			'start' => ($page - 1) * $limit,
			'limit' => $limit
		];

		$results = $this->model_extension_nk_layered_filters_module_layered_filters->getProducts($data);
		$total = $this->model_extension_nk_layered_filters_module_layered_filters->getTotalProducts($request['filters']);

		$products = [];

		foreach ($results as $result) {
			$description = trim(strip_tags(html_entity_decode((string)$result['description'], ENT_QUOTES, 'UTF-8')));

			if (oc_strlen($description) > (int)$this->config->get('config_product_description_length')) {
				$description = oc_substr($description, 0, (int)$this->config->get('config_product_description_length')) . '..';
			}

			if ($result['image'] && is_file(DIR_IMAGE . html_entity_decode((string)$result['image'], ENT_QUOTES, 'UTF-8'))) {
				$image = $result['image'];
			} else {
				$image = 'placeholder.png';
			}

			if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
				$price = $this->currency->format($this->tax->calculate((float)$result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
			} else {
				$price = false;
			}

			if ((float)$result['special']) {
				$special = $this->currency->format($this->tax->calculate((float)$result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
			} else {
				$special = false;
			}

			if ($this->config->get('config_tax')) {
				$tax = $this->currency->format((float)$result['special'] ? (float)$result['special'] : (float)$result['price'], $this->session->data['currency']);
			} else {
				$tax = false;
			}

			$product_data = [
				'description' => $description,
				'thumb'       => $this->model_tool_image->resize($image, $this->config->get('config_image_product_width'), $this->config->get('config_image_product_height')),
				'price'       => $price,
				'special'     => $special,
				'tax'         => $tax,
				'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
				'rating'      => (int)$result['rating'],
				'reviews'     => (int)$result['reviews'],
				'href'        => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$result['product_id'])
			] + $result;

			$products[] = $this->load->controller('product/thumb', $product_data);
		}

		$pagination = $this->load->controller('common/pagination', [
			'total' => $total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->categoryLink($request, ['page_token' => '{page}'])
		]);

		$results_text = sprintf($this->language->get('text_pagination'), $total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($total - $limit)) ? $total : ((($page - 1) * $limit) + $limit), $total, $limit ? ceil($total / $limit) : 0);

		return [
			'products'   => $products,
			'pagination' => $pagination,
			'results'    => $results_text,
			'total'      => $total
		];
	}

	/**
	 * Counts
	 *
	 * Facet counts keyed by "<parameter>|<value>" so the JS can refresh the badges in place.
	 *
	 * @param array<string, mixed> $request
	 *
	 * @return array<string, int>
	 */
	protected function counts(array $request): array {
		$this->load->model('extension/nk_layered_filters/module/layered_filters');

		$model = $this->model_extension_nk_layered_filters_module_layered_filters;
		$types = $request['types'];
		$filters = $request['filters'];

		$counts = [];

		if ($types['manufacturer']) {
			foreach ($model->getManufacturers($filters) as $row) {
				$counts['filter_manufacturer|' . (int)$row['manufacturer_id']] = (int)$row['total'];
			}
		}

		if ($types['filter']) {
			foreach ($model->getFilters($filters) as $row) {
				$counts['filter_filter|' . (int)$row['filter_id']] = (int)$row['total'];
			}
		}

		if ($types['attribute']) {
			foreach ($model->getAttributes($filters) as $row) {
				$counts['filter_attribute|' . (int)$row['attribute_id'] . ':' . $row['name']] = (int)$row['total'];
			}
		}

		if ($types['option']) {
			foreach ($model->getOptions($filters) as $row) {
				$counts['filter_option|' . (int)$row['option_id'] . ':' . (int)$row['option_value_id']] = (int)$row['total'];
			}
		}

		if ($types['stock']) {
			$stock = $model->getStock($filters);

			$counts['filter_stock|in'] = $stock['in'];
			$counts['filter_stock|out'] = $stock['out'];
		}

		return $counts;
	}

	/**
	 * Sidebar
	 *
	 * @param array<string, mixed> $request
	 *
	 * @return string
	 */
	protected function sidebar(array $request): string {
		$this->load->language('extension/nk_layered_filters/module/layered_filters');
		$this->load->model('extension/nk_layered_filters/module/layered_filters');

		$model = $this->model_extension_nk_layered_filters_module_layered_filters;
		$types = $request['types'];
		$filters = $request['filters'];
		$selected = $request['selected'];

		$this->document->addStyle('extension/nk_layered_filters/catalog/view/assets/css/layered_filters.css');
		$this->document->addScript('extension/nk_layered_filters/catalog/view/assets/js/layered_filters.js');

		$data = [];

		$data['groups'] = [];
		$data['price'] = [];

		// Price slider
		if ($types['price']) {
			$range = $model->getPriceRange($filters);

			$currency = $this->session->data['currency'] ?? (string)$this->config->get('config_currency');
			$from = (string)$this->config->get('config_currency');

			$min = floor($this->currency->convert($range['min'], $from, $currency));
			$max = ceil($this->currency->convert($range['max'], $from, $currency));

			if ($max > $min) {
				$step = (float)$this->config->get('module_layered_filters_price_step');

				if ($step <= 0) {
					$step = 1;
				}

				$data['price'] = [
					'name'         => $this->language->get('text_price'),
					'min'          => $min,
					'max'          => $max,
					'step'         => $step,
					'value_min'    => $request['price_min'] !== '' ? (float)$request['price_min'] : $min,
					'value_max'    => $request['price_max'] !== '' ? (float)$request['price_max'] : $max,
					'symbol_left'  => $this->escape($this->currency->getSymbolLeft($currency)),
					'symbol_right' => $this->escape($this->currency->getSymbolRight($currency))
				];
			}
		}

		// Manufacturers
		if ($types['manufacturer']) {
			$values = [];

			foreach ($model->getManufacturers($filters) as $row) {
				$values[] = $this->value('filter_manufacturer', (string)(int)$row['manufacturer_id'], (string)$row['name'], (int)$row['total'], $selected);
			}

			if ($values) {
				$data['groups'][] = [
					'code'   => 'manufacturer',
					'key'    => 'filter_manufacturer',
					'name'   => $this->escape($this->language->get('text_manufacturer')),
					'swatch' => false,
					'values' => $values
				];
			}
		}

		// OpenCart filter groups
		if ($types['filter']) {
			$groups = [];

			foreach ($model->getFilters($filters) as $row) {
				$group_id = (int)$row['filter_group_id'];

				if (!isset($groups[$group_id])) {
					$groups[$group_id] = [
						'code'   => 'filter-' . $group_id,
						'key'    => 'filter_filter',
						'name'   => $this->escape((string)$row['group_name']),
						'swatch' => false,
						'values' => []
					];
				}

				$groups[$group_id]['values'][] = $this->value('filter_filter', (string)(int)$row['filter_id'], (string)$row['name'], (int)$row['total'], $selected);
			}

			$data['groups'] = array_merge($data['groups'], array_values($groups));
		}

		// Attributes
		if ($types['attribute']) {
			$groups = [];

			foreach ($model->getAttributes($filters) as $row) {
				$attribute_id = (int)$row['attribute_id'];

				if (!isset($groups[$attribute_id])) {
					$groups[$attribute_id] = [
						'code'   => 'attribute-' . $attribute_id,
						'key'    => 'filter_attribute',
						'name'   => $this->escape((string)$row['group_name']),
						'swatch' => false,
						'values' => []
					];
				}

				$groups[$attribute_id]['values'][] = $this->value('filter_attribute', $attribute_id . ':' . $row['name'], (string)$row['name'], (int)$row['total'], $selected);
			}

			$data['groups'] = array_merge($data['groups'], array_values($groups));
		}

		// Option values
		if ($types['option']) {
			$groups = [];

			foreach ($model->getOptions($filters) as $row) {
				$option_id = (int)$row['option_id'];

				if (!isset($groups[$option_id])) {
					$groups[$option_id] = [
						'code'   => 'option-' . $option_id,
						'key'    => 'filter_option',
						'name'   => $this->escape((string)$row['group_name']),
						'swatch' => in_array($row['type'], ['image', 'radio', 'checkbox', 'select']) && !empty($row['image']),
						'values' => []
					];
				}

				$value = $this->value('filter_option', $option_id . ':' . (int)$row['option_value_id'], (string)$row['name'], (int)$row['total'], $selected);

				if (!empty($row['image']) && is_file(DIR_IMAGE . html_entity_decode((string)$row['image'], ENT_QUOTES, 'UTF-8'))) {
					$this->load->model('tool/image');

					$value['image'] = $this->model_tool_image->resize((string)$row['image'], 30, 30);

					$groups[$option_id]['swatch'] = true;
				}

				$groups[$option_id]['values'][] = $value;
			}

			$data['groups'] = array_merge($data['groups'], array_values($groups));
		}

		// Availability
		if ($types['stock']) {
			$stock = $model->getStock($filters);

			$values = [];

			if ($stock['in']) {
				$values[] = $this->value('filter_stock', 'in', $this->language->get('text_in_stock'), $stock['in'], $selected);
			}

			if ($stock['out']) {
				$values[] = $this->value('filter_stock', 'out', $this->language->get('text_out_of_stock'), $stock['out'], $selected);
			}

			if ($values) {
				$data['groups'][] = [
					'code'   => 'stock',
					'key'    => 'filter_stock',
					'name'   => $this->escape($this->language->get('text_availability')),
					'swatch' => false,
					'values' => $values
				];
			}
		}

		if (!$data['groups'] && !$data['price']) {
			return '';
		}

		// Values that must survive a plain GET submission.
		$data['hidden'] = [];

		// With SEO URLs switched on the pretty path already carries the route and the category,
		// so only the plain index.php form needs those two fields.
		if (!isset($this->request->get['_route_'])) {
			$data['hidden'][] = ['name' => 'route', 'value' => 'product/category'];

			if ($request['path'] !== '') {
				$data['hidden'][] = ['name' => 'path', 'value' => $this->escape($request['path'])];
			}
		}

		$data['hidden'][] = ['name' => 'language', 'value' => $this->escape((string)$this->config->get('config_language'))];

		foreach (['sort', 'order', 'limit'] as $key) {
			if (isset($this->request->get[$key]) && is_scalar($this->request->get[$key])) {
				$data['hidden'][] = ['name' => $key, 'value' => $this->escape((string)$this->request->get[$key])];
			}
		}

		$data['action'] = $this->escape($this->requestUri());
		$data['results_url'] = $this->escape($this->url->link('extension/nk_layered_filters/module/layered_filters.results', 'language=' . $this->config->get('config_language'), true));
		$data['category_id'] = (int)$request['category_id'];
		$data['path'] = $this->escape($request['path']);
		$data['clear'] = $this->escape($this->url->link('product/category', 'language=' . $this->config->get('config_language') . ($request['path'] !== '' ? '&path=' . $request['path'] : '')));
		$data['ajax'] = $this->config->get('module_layered_filters_ajax') === null ? 1 : (int)$this->config->get('module_layered_filters_ajax');
		$data['show_counts'] = $this->config->get('module_layered_filters_show_counts') === null ? 1 : (int)$this->config->get('module_layered_filters_show_counts');
		$data['active'] = (bool)$request['active'];

		$data['heading_title'] = $this->escape($this->language->get('heading_title'));
		$data['text_price'] = $this->escape($this->language->get('text_price'));
		$data['text_apply'] = $this->escape($this->language->get('text_apply'));
		$data['text_clear'] = $this->escape($this->language->get('text_clear'));
		$data['text_loading'] = $this->escape($this->language->get('text_loading'));
		$data['text_min'] = $this->escape($this->language->get('text_min'));
		$data['text_max'] = $this->escape($this->language->get('text_max'));

		self::$rendered = true;

		return $this->load->view('extension/nk_layered_filters/module/layered_filters', $data);
	}

	/**
	 * Value
	 *
	 * Builds one checkbox row.
	 *
	 * The raw value is kept exactly as it is stored so the SQL comparison matches, while the
	 * label is decoded and re-escaped for display.
	 *
	 * @param string                $key
	 * @param string                $value
	 * @param string                $label
	 * @param int                   $total
	 * @param array<string, mixed>  $selected
	 *
	 * @return array<string, mixed>
	 */
	protected function value(string $key, string $value, string $label, int $total, array $selected): array {
		return [
			'value'    => htmlspecialchars($value, ENT_QUOTES, 'UTF-8'),
			'label'    => $this->escape($label),
			'total'    => $total,
			'image'    => '',
			'selected' => isset($selected[$key]) && in_array($value, $selected[$key], true)
		];
	}

	/**
	 * Escape
	 *
	 * Normalises a stored value to a single, safe HTML encoding.
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	protected function escape(string $value): string {
		return htmlspecialchars(html_entity_decode($value, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8');
	}

	/**
	 * Request Uri
	 *
	 * The current category URL without a query string, used as the no-JS form action.
	 *
	 * @return string
	 */
	protected function requestUri(): string {
		$uri = (string)($this->request->server['REQUEST_URI'] ?? '');

		$position = strpos($uri, '?');

		if ($position !== false) {
			$uri = substr($uri, 0, $position);
		}

		return $uri !== '' ? html_entity_decode($uri, ENT_QUOTES, 'UTF-8') : $this->url->link('product/category', 'language=' . $this->config->get('config_language'), true);
	}

	/**
	 * Category Link
	 *
	 * Rebuilds the category URL carrying every active filter. SEO friendly and shareable.
	 *
	 * @param array<string, mixed> $request
	 * @param array<string, mixed> $override sort, order, limit, page, page_token or js
	 *
	 * @return string
	 */
	protected function categoryLink(array $request, array $override = []): string {
		$sort = (string)($override['sort'] ?? $request['sort']);
		$order = (string)($override['order'] ?? $request['order']);
		$limit = (int)($override['limit'] ?? $request['limit']);
		$page = (int)($override['page'] ?? 0);
		$token = (string)($override['page_token'] ?? '');

		$args = 'language=' . $this->config->get('config_language');

		if ($request['path'] !== '') {
			$args .= '&path=' . $request['path'];
		}

		$args .= $this->queryString($request);

		if ($sort != 'p.sort_order') {
			$args .= '&sort=' . rawurlencode($sort);
		}

		if ($order != 'ASC') {
			$args .= '&order=DESC';
		}

		if ($limit != (int)$this->config->get('config_pagination')) {
			$args .= '&limit=' . $limit;
		}

		if ($token !== '') {
			$args .= '&page=' . $token;
		} elseif ($page > 1) {
			$args .= '&page=' . $page;
		}

		// $js = true leaves the ampersands raw, which is what JavaScript needs. Anything that
		// ends up inside an HTML attribute must keep them encoded.
		$js = array_key_exists('js', $override) ? (bool)$override['js'] : ($token === '');

		return $this->url->link('product/category', $args, $js);
	}

	/**
	 * Toolbar
	 *
	 * The sort and limit dropdowns rebuilt so that changing either one keeps the active filters.
	 *
	 * @param array<string, mixed> $request
	 * @param bool                 $js      true when the hrefs are handed to JavaScript
	 *
	 * @return array<string, mixed>
	 */
	protected function toolbar(array $request, bool $js = false): array {
		$this->load->language('product/category');

		$sorts = [
			['text_default', 'p.sort_order', 'ASC'],
			['text_name_asc', 'pd.name', 'ASC'],
			['text_name_desc', 'pd.name', 'DESC'],
			['text_price_asc', 'p.price', 'ASC'],
			['text_price_desc', 'p.price', 'DESC']
		];

		if ($this->config->get('config_review_status')) {
			$sorts[] = ['text_rating_desc', 'rating', 'DESC'];
			$sorts[] = ['text_rating_asc', 'rating', 'ASC'];
		}

		$sorts[] = ['text_model_asc', 'p.model', 'ASC'];
		$sorts[] = ['text_model_desc', 'p.model', 'DESC'];

		$data = ['sorts' => [], 'limits' => []];

		foreach ($sorts as $sort) {
			$data['sorts'][] = [
				'text'  => $this->language->get($sort[0]),
				'value' => $sort[1] . '-' . $sort[2],
				'href'  => $this->categoryLink($request, ['sort' => $sort[1], 'order' => $sort[2], 'js' => $js])
			];
		}

		$limits = array_unique([(int)$this->config->get('config_pagination'), 25, 50, 75, 100]);

		sort($limits);

		foreach ($limits as $value) {
			$data['limits'][] = [
				'text'  => $value,
				'value' => $value,
				'href'  => $this->categoryLink($request, ['limit' => (int)$value, 'js' => $js])
			];
		}

		return $data;
	}

	/**
	 * Query String
	 *
	 * The canonical, human readable filter query fragment.
	 *
	 * @param array<string, mixed> $request
	 *
	 * @return string
	 */
	protected function queryString(array $request): string {
		$args = '';

		$selected = $request['selected'];

		if (!empty($selected['filter_manufacturer'])) {
			$args .= '&filter_manufacturer=' . implode(',', array_map('intval', $selected['filter_manufacturer']));
		}

		if (!empty($selected['filter_filter'])) {
			$args .= '&filter_filter=' . implode(',', array_map('intval', $selected['filter_filter']));
		}

		if (!empty($selected['filter_stock'])) {
			$args .= '&filter_stock=' . rawurlencode((string)$selected['filter_stock'][0]);
		}

		if (!empty($selected['filter_attribute'])) {
			$parts = [];

			foreach ($selected['filter_attribute'] as $value) {
				$pair = explode(':', (string)$value, 2);

				// The value is kept exactly as stored so that it survives the round trip
				// through Request::clean() and still matches the database copy.
				$parts[] = (int)$pair[0] . ':' . rawurlencode($pair[1] ?? '');
			}

			$args .= '&filter_attribute=' . implode(',', $parts);
		}

		if (!empty($selected['filter_option'])) {
			$parts = [];

			foreach ($selected['filter_option'] as $value) {
				$pair = explode(':', (string)$value, 2);
				$parts[] = (int)$pair[0] . ':' . (int)($pair[1] ?? 0);
			}

			$args .= '&filter_option=' . implode(',', $parts);
		}

		if ($request['price_min'] !== '' || $request['price_max'] !== '') {
			$args .= '&filter_price=' . ($request['price_min'] !== '' ? (float)$request['price_min'] : '') . '-' . ($request['price_max'] !== '' ? (float)$request['price_max'] : '');
		}

		return $args;
	}
}
