<?php
namespace Opencart\Catalog\Model\Extension\NkLayeredFilters\Module;
/**
 * Class LayeredFilters
 *
 * Can be called from $this->load->model('extension/nk_layered_filters/module/layered_filters');
 *
 * Builds the facet lists (price bounds, OpenCart filters, attributes, option values,
 * manufacturers, stock availability) for the products of a single category and runs the
 * filtered product query.
 *
 * All facet counts are calculated with the *other* active facets applied but with the facet's
 * own selection excluded, which is the standard "layered navigation" behaviour.
 *
 * @package Opencart\Catalog\Model\Extension\NkLayeredFilters\Module
 */
class LayeredFilters extends \Opencart\System\Engine\Model {
	/**
	 * Cached price scalar sub queries.
	 *
	 * @var array<string, string>
	 */
	protected array $statement = [];

	/**
	 * Constructor
	 *
	 * @param \Opencart\System\Engine\Registry $registry
	 */
	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);

		$customer_group_id = (int)$this->config->get('config_customer_group_id');

		$this->statement['discount'] = "(SELECT (CASE WHEN `pd2`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`pd2`.`price` / 100))) WHEN `pd2`.`type` = 'S' THEN (`p`.`price` - `pd2`.`price`) ELSE `pd2`.`price` END) FROM `" . DB_PREFIX . "product_discount` `pd2` WHERE `pd2`.`product_id` = `p`.`product_id` AND `pd2`.`customer_group_id` = '" . $customer_group_id . "' AND `pd2`.`quantity` = '1' AND `pd2`.`special` = '0' AND ((`pd2`.`date_start` = '0000-00-00' OR `pd2`.`date_start` < NOW()) AND (`pd2`.`date_end` = '0000-00-00' OR `pd2`.`date_end` > NOW())) ORDER BY `pd2`.`priority` ASC, `pd2`.`price` ASC LIMIT 1)";
		$this->statement['special'] = "(SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . $customer_group_id . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1)";
		$this->statement['reward'] = "(SELECT `pr`.`points` FROM `" . DB_PREFIX . "product_reward` `pr` WHERE `pr`.`product_id` = `p`.`product_id` AND `pr`.`customer_group_id` = '" . $customer_group_id . "')";
		$this->statement['review'] = "(SELECT COUNT(*) FROM `" . DB_PREFIX . "review` `r` WHERE `r`.`product_id` = `p`.`product_id` AND `r`.`status` = '1' GROUP BY `r`.`product_id`)";

		// Effective price = special, else discount, else base price.
		$this->statement['effective'] = "COALESCE(" . $this->statement['special'] . ", " . $this->statement['discount'] . ", `p`.`price`)";
	}

	/**
	 * From
	 *
	 * The shared FROM clause. Mirrors the joins the core catalog/product model uses for a
	 * non recursive category listing so that our result set matches the storefront listing.
	 *
	 * @return string
	 */
	protected function from(): string {
		return " FROM `" . DB_PREFIX . "product_to_category` `p2c`"
			. " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `p2c`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `p2c`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `p`.`product_id`)";
	}

	/**
	 * Where
	 *
	 * Builds the WHERE clause for a set of active filters.
	 *
	 * @param array<string, mixed> $data    active filters
	 * @param string               $exclude facet key whose own selection must be ignored
	 *
	 * @return string
	 */
	protected function where(array $data, string $exclude = ''): string {
		$sql = " WHERE `p2c`.`category_id` = '" . (int)($data['filter_category_id'] ?? 0) . "'"
			. " AND `p2s`.`store_id` = '" . (int)$this->config->get('config_store_id') . "'"
			. " AND `pd`.`language_id` = '" . (int)$this->config->get('config_language_id') . "'"
			. " AND `p`.`status` = '1' AND `p`.`date_available` <= NOW()";

		// Manufacturers
		if ($exclude != 'manufacturer' && !empty($data['filter_manufacturer'])) {
			$sql .= " AND `p`.`manufacturer_id` IN (" . implode(',', array_map('intval', (array)$data['filter_manufacturer'])) . ")";
		}

		// Stock availability
		if ($exclude != 'stock' && !empty($data['filter_stock'])) {
			if ($data['filter_stock'] == 'in') {
				$sql .= " AND `p`.`quantity` > '0'";
			} elseif ($data['filter_stock'] == 'out') {
				$sql .= " AND `p`.`quantity` < '1'";
			}
		}

		// OpenCart filters (oc_filter / oc_product_filter)
		if ($exclude != 'filter' && !empty($data['filter_filter'])) {
			$sql .= " AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "product_filter` `pf` WHERE `pf`.`product_id` = `p`.`product_id` AND `pf`.`filter_id` IN (" . implode(',', array_map('intval', (array)$data['filter_filter'])) . "))";
		}

		// Attributes. AND between attributes, OR between the values of one attribute.
		if ($exclude != 'attribute' && !empty($data['filter_attribute'])) {
			foreach ((array)$data['filter_attribute'] as $attribute_id => $values) {
				$implode = [];

				foreach ((array)$values as $value) {
					$implode[] = "'" . $this->db->escape((string)$value) . "'";
				}

				if ($implode) {
					// TRIM matches the way the facet list is built.
					$sql .= " AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "product_attribute` `pa` WHERE `pa`.`product_id` = `p`.`product_id` AND `pa`.`language_id` = '" . (int)$this->config->get('config_language_id') . "' AND `pa`.`attribute_id` = '" . (int)$attribute_id . "' AND TRIM(`pa`.`text`) IN (" . implode(',', $implode) . "))";
				}
			}
		}

		// Option values. AND between options, OR between the values of one option.
		if ($exclude != 'option' && !empty($data['filter_option'])) {
			foreach ((array)$data['filter_option'] as $option_id => $values) {
				$implode = array_map('intval', (array)$values);

				if ($implode) {
					$sql .= " AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "product_option_value` `pov` WHERE `pov`.`product_id` = `p`.`product_id` AND `pov`.`option_id` = '" . (int)$option_id . "' AND `pov`.`option_value_id` IN (" . implode(',', $implode) . "))";
				}
			}
		}

		return $sql;
	}

	/**
	 * Price
	 *
	 * The price bounds as conditions against an already computed price column, so the very
	 * expensive special/discount sub queries only have to appear once per statement.
	 *
	 * @param array<string, mixed> $data    active filters
	 * @param string               $column  the column holding the effective price
	 * @param string               $exclude facet key whose own selection must be ignored
	 *
	 * @return string
	 */
	protected function price(array $data, string $column, string $exclude = ''): string {
		if ($exclude == 'price') {
			return '';
		}

		$sql = [];

		if (isset($data['filter_price_min']) && $data['filter_price_min'] !== '') {
			$sql[] = $column . " >= '" . (float)$data['filter_price_min'] . "'";
		}

		if (isset($data['filter_price_max']) && $data['filter_price_max'] !== '') {
			$sql[] = $column . " <= '" . (float)$data['filter_price_max'] . "'";
		}

		return implode(' AND ', $sql);
	}

	/**
	 * Id Query
	 *
	 * Returns a sub query that yields the product IDs matching the active filters.
	 *
	 * @param array<string, mixed> $data    active filters
	 * @param string               $exclude facet key whose own selection must be ignored
	 *
	 * @return string
	 */
	protected function idQuery(array $data, string $exclude = ''): string {
		$sql = "SELECT `p`.`product_id`" . $this->from() . $this->where($data, $exclude) . " GROUP BY `p`.`product_id`";

		$price = $this->price($data, '`nk`.`nk_price`', $exclude);

		if (!$price) {
			return $sql;
		}

		// Wrap so the effective price is only calculated once per product.
		return "SELECT `nk`.`product_id` FROM (SELECT `p`.`product_id`, " . $this->statement['effective'] . " AS `nk_price`" . $this->from() . $this->where($data, $exclude) . " GROUP BY `p`.`product_id`) `nk` WHERE " . $price;
	}

	/**
	 * Get Products
	 *
	 * Runs the filtered product query. The returned rows carry the same columns the core
	 * catalog/product model returns so they can be handed straight to product/thumb.
	 *
	 * @param array<string, mixed> $data active filters plus sort, order, start and limit
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getProducts(array $data = []): array {
		$sql = "SELECT `p`.*, `pd`.`name`, `pd`.`description`, `pd`.`tag`, `pd`.`meta_title`,"
			. " " . $this->statement['discount'] . " AS `discount`,"
			. " " . $this->statement['special'] . " AS `special`,"
			. " " . $this->statement['reward'] . " AS `reward`,"
			. " " . $this->statement['review'] . " AS `reviews`"
			. $this->from() . $this->where($data) . " GROUP BY `p`.`product_id`";

		// The aliases selected above let MySQL reuse the sub query results here.
		$price = $this->price($data, "COALESCE(`special`, `discount`, `p`.`price`)");

		if ($price) {
			$sql .= " HAVING " . $price;
		}

		$sort_data = [
			'pd.name',
			'p.model',
			'p.quantity',
			'p.price',
			'rating',
			'p.sort_order',
			'p.date_added'
		];

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			if ($data['sort'] == 'pd.name' || $data['sort'] == 'p.model') {
				$sql .= " ORDER BY LCASE(`" . str_replace('.', '`.`', $data['sort']) . "`)";
			} elseif ($data['sort'] == 'p.price') {
				$sql .= " ORDER BY (CASE WHEN `special` IS NOT NULL THEN `special` WHEN `discount` IS NOT NULL THEN `discount` ELSE `p`.`price` END)";
			} elseif ($data['sort'] == 'rating') {
				$sql .= " ORDER BY `p`.`rating`";
			} else {
				$sql .= " ORDER BY `" . str_replace('.', '`.`', $data['sort']) . "`";
			}
		} else {
			$sql .= " ORDER BY `p`.`sort_order`";
		}

		if (isset($data['order']) && strtoupper((string)$data['order']) == 'DESC') {
			$sql .= " DESC, LCASE(`pd`.`name`) DESC";
		} else {
			$sql .= " ASC, LCASE(`pd`.`name`) ASC";
		}

		$start = isset($data['start']) ? (int)$data['start'] : 0;
		$limit = isset($data['limit']) ? (int)$data['limit'] : 20;

		if ($start < 0) {
			$start = 0;
		}

		if ($limit < 1) {
			$limit = 20;
		}

		$sql .= " LIMIT " . $start . "," . $limit;

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * Get Total Products
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return int
	 */
	public function getTotalProducts(array $data = []): int {
		$query = $this->db->query("SELECT COUNT(*) AS `total` FROM (" . $this->idQuery($data) . ") `t`");

		return (int)($query->row['total'] ?? 0);
	}

	/**
	 * Get Price Range
	 *
	 * Lowest and highest effective price in the category, ignoring any active price filter so
	 * that the slider bounds stay stable while the shopper drags it.
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<string, float>
	 */
	public function getPriceRange(array $data = []): array {
		$sql = "SELECT MIN(`t`.`nk_price`) AS `min`, MAX(`t`.`nk_price`) AS `max` FROM (SELECT " . $this->statement['effective'] . " AS `nk_price`" . $this->from() . $this->where($data, 'price') . " GROUP BY `p`.`product_id`) `t`";

		$query = $this->db->query($sql);

		return [
			'min' => (float)($query->row['min'] ?? 0),
			'max' => (float)($query->row['max'] ?? 0)
		];
	}

	/**
	 * Get Manufacturers
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getManufacturers(array $data = []): array {
		$sql = "SELECT `m`.`manufacturer_id`, `m`.`name`, COUNT(DISTINCT `t`.`product_id`) AS `total`"
			. " FROM (" . $this->idQuery($data, 'manufacturer') . ") `t`"
			. " INNER JOIN `" . DB_PREFIX . "product` `p2` ON (`p2`.`product_id` = `t`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "manufacturer` `m` ON (`m`.`manufacturer_id` = `p2`.`manufacturer_id`)"
			. " INNER JOIN `" . DB_PREFIX . "manufacturer_to_store` `m2s` ON (`m2s`.`manufacturer_id` = `m`.`manufacturer_id` AND `m2s`.`store_id` = '" . (int)$this->config->get('config_store_id') . "')"
			. " GROUP BY `m`.`manufacturer_id`, `m`.`name` ORDER BY `m`.`sort_order` ASC, LCASE(`m`.`name`) ASC";

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * Get Filters
	 *
	 * The stock OpenCart filter groups (oc_filter_group / oc_filter).
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getFilters(array $data = []): array {
		$language_id = (int)$this->config->get('config_language_id');

		$sql = "SELECT `f`.`filter_group_id`, `fgd`.`name` AS `group_name`, `f`.`filter_id`, `fd`.`name` AS `name`, COUNT(DISTINCT `pf`.`product_id`) AS `total`"
			. " FROM `" . DB_PREFIX . "product_filter` `pf`"
			. " INNER JOIN (" . $this->idQuery($data, 'filter') . ") `t` ON (`t`.`product_id` = `pf`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "filter` `f` ON (`f`.`filter_id` = `pf`.`filter_id`)"
			. " INNER JOIN `" . DB_PREFIX . "filter_description` `fd` ON (`fd`.`filter_id` = `f`.`filter_id` AND `fd`.`language_id` = '" . $language_id . "')"
			. " INNER JOIN `" . DB_PREFIX . "filter_group_description` `fgd` ON (`fgd`.`filter_group_id` = `f`.`filter_group_id` AND `fgd`.`language_id` = '" . $language_id . "')"
			. " GROUP BY `f`.`filter_id`, `f`.`filter_group_id`, `fgd`.`name`, `fd`.`name`"
			. " ORDER BY LCASE(`fgd`.`name`) ASC, `f`.`sort_order` ASC, LCASE(`fd`.`name`) ASC";

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * Get Attributes
	 *
	 * Distinct attribute values of the products in the category. Values longer than 64
	 * characters are skipped: those are description style attributes, not facets.
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getAttributes(array $data = []): array {
		$language_id = (int)$this->config->get('config_language_id');

		$sql = "SELECT `pa`.`attribute_id`, `ad`.`name` AS `group_name`, TRIM(`pa`.`text`) AS `name`, COUNT(DISTINCT `pa`.`product_id`) AS `total`"
			. " FROM `" . DB_PREFIX . "product_attribute` `pa`"
			. " INNER JOIN (" . $this->idQuery($data, 'attribute') . ") `t` ON (`t`.`product_id` = `pa`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "attribute` `a` ON (`a`.`attribute_id` = `pa`.`attribute_id`)"
			. " INNER JOIN `" . DB_PREFIX . "attribute_description` `ad` ON (`ad`.`attribute_id` = `a`.`attribute_id` AND `ad`.`language_id` = '" . $language_id . "')"
			. " WHERE `pa`.`language_id` = '" . $language_id . "' AND TRIM(`pa`.`text`) <> '' AND CHAR_LENGTH(TRIM(`pa`.`text`)) <= 64"
			. " GROUP BY `pa`.`attribute_id`, `ad`.`name`, TRIM(`pa`.`text`)"
			. " ORDER BY `a`.`sort_order` ASC, LCASE(`ad`.`name`) ASC, LCASE(TRIM(`pa`.`text`)) ASC";

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * Get Options
	 *
	 * Distinct option values (colour, size, ...) of the products in the category.
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getOptions(array $data = []): array {
		$language_id = (int)$this->config->get('config_language_id');

		$sql = "SELECT `pov`.`option_id`, `od`.`name` AS `group_name`, `o`.`type`, `pov`.`option_value_id`, `ovd`.`name` AS `name`, `ov`.`image`, COUNT(DISTINCT `pov`.`product_id`) AS `total`"
			. " FROM `" . DB_PREFIX . "product_option_value` `pov`"
			. " INNER JOIN (" . $this->idQuery($data, 'option') . ") `t` ON (`t`.`product_id` = `pov`.`product_id`)"
			. " INNER JOIN `" . DB_PREFIX . "option` `o` ON (`o`.`option_id` = `pov`.`option_id`)"
			. " INNER JOIN `" . DB_PREFIX . "option_description` `od` ON (`od`.`option_id` = `o`.`option_id` AND `od`.`language_id` = '" . $language_id . "')"
			. " INNER JOIN `" . DB_PREFIX . "option_value` `ov` ON (`ov`.`option_value_id` = `pov`.`option_value_id`)"
			. " INNER JOIN `" . DB_PREFIX . "option_value_description` `ovd` ON (`ovd`.`option_value_id` = `ov`.`option_value_id` AND `ovd`.`language_id` = '" . $language_id . "')"
			. " GROUP BY `pov`.`option_id`, `od`.`name`, `o`.`type`, `pov`.`option_value_id`, `ovd`.`name`, `ov`.`image`"
			. " ORDER BY `o`.`sort_order` ASC, LCASE(`od`.`name`) ASC, `ov`.`sort_order` ASC, LCASE(`ovd`.`name`) ASC";

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * Get Stock
	 *
	 * In stock / out of stock counts.
	 *
	 * @param array<string, mixed> $data active filters
	 *
	 * @return array<string, int>
	 */
	public function getStock(array $data = []): array {
		$sql = "SELECT SUM(CASE WHEN `p2`.`quantity` > 0 THEN 1 ELSE 0 END) AS `in_stock`, SUM(CASE WHEN `p2`.`quantity` < 1 THEN 1 ELSE 0 END) AS `out_stock`"
			. " FROM (" . $this->idQuery($data, 'stock') . ") `t`"
			. " INNER JOIN `" . DB_PREFIX . "product` `p2` ON (`p2`.`product_id` = `t`.`product_id`)";

		$query = $this->db->query($sql);

		return [
			'in'  => (int)($query->row['in_stock'] ?? 0),
			'out' => (int)($query->row['out_stock'] ?? 0)
		];
	}
}
