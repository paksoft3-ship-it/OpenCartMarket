<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class NkRtl extends \Opencart\System\Engine\Controller {

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isRtlThemeActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/header_rtl.twig';
            if (is_file($template)) {
                $data['novakur_main_css']        = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/css/nk-rtl.css';
                $data['nk_js_base']              = rtrim(HTTP_SERVER, '/') . '/extension/novakur/catalog/view/assets/dist/js/';
                $data['novakur_primary_color']   = (string)$this->config->get('theme_nk_rtl_primary_color') ?: '#0f7a5a';
                $data['novakur_secondary_color'] = '#1f2a44';
                $data['novakur_accent_color']    = '#c8a24b';
                $data['novakur_container_width'] = 1200;
                $data['novakur_base_font']       = 'Cairo';
                $data['novakur_heading_font']    = 'Cairo';
                $data['cart_quantity']           = $this->cart->countProducts();
                $data['direction']               = $this->resolveDirection();
                $data['nk_show_direction_toggle'] = (bool)$this->config->get('theme_nk_rtl_show_direction_toggle');
                $data['nk_arabic_numerals']       = (bool)$this->config->get('theme_nk_rtl_arabic_numerals');

                $this->load->model('catalog/category');
                $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
                $data['categories'] = [];
                foreach ($cats_raw as $cat) {
                    $data['categories'][] = [
                        'name'  => $cat['name'],
                        'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                        'image' => $cat['image'] ?? '',
                    ];
                }

                $route = 'extension/novakur/common/header_rtl';
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/footer_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/footer_rtl';
            }
        }

        // ---- Homepage ----
        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/common/home_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/common/home_rtl';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h = (int)($this->config->get('config_image_product_height') ?: 360);

            // Category tiles
            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            // Latest arrivals
            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['latest']   = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            $data['featured'] = $data['latest'];

            // Bestsellers
            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8,
            ]);
            $data['bestsellers'] = $this->buildProductArray($best_raw, $img_w, $img_h, $currency);
        }

        // ---- Category ----
        if ($route === 'product/category') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/category_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/category_rtl';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $path     = $this->request->get['path'] ?? '';
            $parts    = explode('_', $path);
            $cat_id   = (int)end($parts);
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'          => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                       => ($page - 1) * $limit,
                'limit'                       => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Special Offers ----
        if ($route === 'product/special') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/special_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/special_rtl';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);
            $page     = max(1, (int)($this->request->get['page'] ?? 1));
            $limit    = (int)($this->config->get('config_pagination') ?: 24);

            $raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => ($page - 1) * $limit,
                'limit' => $limit,
            ]);
            $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }

        // ---- Product Detail ----
        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/product_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/product_rtl';
            }
        }

        // ---- Cart ----
        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/cart_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/cart_rtl';
            }
        }

        // ---- Checkout ----
        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/checkout/checkout_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/checkout/checkout_rtl';
            }
        }

        // ---- Search ----
        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/product/search_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/product/search_rtl';
            }

            $this->load->model('catalog/product');
            $this->load->model('catalog/category');
            $this->load->model('tool/image');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }

            $search   = $this->request->get['search'] ?? ($data['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'        => $search,
                    'filter_description' => true,
                    'start'              => 0,
                    'limit'              => (int)($this->config->get('config_pagination') ?: 24),
                ]);
                $data['products'] = $this->buildProductArray($raw, $img_w, $img_h, $currency);
            }
        }

        // ---- Login ----
        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/login_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/login_rtl';
            }
        }

        // ---- Register ----
        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/register_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/register_rtl';
            }
        }

        // ---- Account Dashboard ----
        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/account_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/account_rtl';
            }
        }

        // ---- Order History ----
        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/order_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/order_rtl';
            }
        }

        // ---- Wishlist ----
        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/account/wishlist_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/account/wishlist_rtl';
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 360);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 360);

            // Build rich product data for wishlist items already provided by OC
            if (!empty($data['products'])) {
                $data['products'] = $this->buildProductArray($data['products'], $img_w, $img_h, $currency);
            }
        }

        // ---- 404 ----
        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'novakur/catalog/view/template/error/not_found_rtl.twig';
            if (is_file($template)) {
                $route = 'extension/novakur/error/not_found_rtl';
            }

            $this->load->model('catalog/category');

            $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];
            foreach ($cats_raw as $cat) {
                $data['categories'][] = [
                    'name'  => $cat['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                    'image' => $cat['image'] ?? '',
                ];
            }
        }
    }

    private function resolveDirection(): string {
        if ((bool)$this->config->get('theme_nk_rtl_force_rtl')) {
            return 'rtl';
        }

        $direction = (string)($this->language->get('direction') ?? '');

        return in_array($direction, ['ltr', 'rtl'], true) ? $direction : 'ltr';
    }

    private function buildProductArray(array $raw, int $img_w, int $img_h, string $currency): array {
        $products = [];
        foreach ($raw as $p) {
            $price = $this->tax->calculate(
                $p['price'] ?? 0,
                $p['tax_class_id'] ?? 0,
                $this->config->get('config_tax')
            );
            $products[] = [
                'product_id'   => $p['product_id'],
                'name'         => $p['name'],
                'href'         => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                'thumb'        => ($p['image'] ?? '')
                    ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                    : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                'price'        => $this->currency->format($price, $currency),
                'special'      => ($p['special'] ?? false)
                    ? $this->currency->format(
                        $this->tax->calculate($p['special'], $p['tax_class_id'] ?? 0, $this->config->get('config_tax')),
                        $currency
                    )
                    : false,
                'manufacturer' => $p['manufacturer'] ?? '',
                'rating'       => (float)($p['rating'] ?? 0),
                'reviews'      => (int)($p['reviews'] ?? 0),
            ];
        }
        return $products;
    }

    private function isRtlThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');
        return in_array($current_theme, ['nk_rtl', 'novakur_rtl'], true)
            && (bool)$this->config->get('theme_nk_rtl_status');
    }
}
