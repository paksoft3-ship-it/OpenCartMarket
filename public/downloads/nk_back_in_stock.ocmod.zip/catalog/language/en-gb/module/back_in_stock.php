<?php
$_['text_bis_heading'] = 'Out of stock — get an e-mail when it is back';
$_['text_bis_button'] = 'Notify me';
$_['text_bis_placeholder'] = 'Your e-mail address';
$_['text_bis_sending'] = 'Sending...';
$_['text_bis_subscribed'] = 'Thanks! We will e-mail you as soon as this product is available again.';
$_['text_bis_already'] = 'You are already on the waiting list for this product.';
$_['text_bis_privacy'] = 'We only use this address for this one notification.';
$_['text_bis_default_subject'] = '{product} is back in stock';
$_['text_bis_default_body'] = '<p>Good news - {product} is available again.</p><p><a href="{link}">Order it here</a></p><p>{store}</p>';

$_['error_bis_disabled'] = 'Stock notifications are not available right now.';
$_['error_bis_email'] = 'Please enter a valid e-mail address.';
$_['error_bis_product'] = 'This product is no longer available.';
$_['error_bis_in_stock'] = 'Good news - this product is in stock, you can order it right away.';
$_['error_bis_throttle'] = 'Too many requests. Please try again later.';
