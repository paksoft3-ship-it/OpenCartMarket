/* NovaKur Back in Stock Alerts */
(function () {
  function init() {
    var root = document.getElementById('nk-bis');

    if (!root) {
      return;
    }

    var url = root.getAttribute('data-url') || '';
    var productId = root.getAttribute('data-product-id') || '';
    var button = document.getElementById('nk-bis-submit');
    var input = document.getElementById('nk-bis-email');
    var message = document.getElementById('nk-bis-message');

    if (!url || !button || !input) {
      return;
    }

    var text = {
      button: root.getAttribute('data-text-button') || button.textContent,
      sending: root.getAttribute('data-text-sending') || 'Sending...',
      email: root.getAttribute('data-text-email') || 'Please enter a valid e-mail address.'
    };

    function show(content, state) {
      if (!message) {
        return;
      }

      message.textContent = content;
      message.className = 'nk-bis__message' + (state ? ' is-' + state : '');
    }

    function submit() {
      var email = (input.value || '').trim();

      // Cheap client side gate only; the server validates properly.
      if (email.length < 6 || email.length > 96 || email.indexOf('@') < 1) {
        show(text.email, 'error');
        input.focus();

        return;
      }

      button.disabled = true;
      button.textContent = text.sending;
      show('', '');

      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: 'product_id=' + encodeURIComponent(productId) + '&email=' + encodeURIComponent(email),
        credentials: 'same-origin'
      }).then(function (response) {
        return response.json();
      }).then(function (json) {
        button.disabled = false;
        button.textContent = text.button;

        if (!json || typeof json !== 'object') {
          show(text.email, 'error');

          return;
        }

        if (json.error) {
          show(String(json.error), 'error');

          return;
        }

        if (json.success) {
          show(String(json.success), 'success');

          root.classList.add('nk-bis--done');
        }
      }).catch(function () {
        button.disabled = false;
        button.textContent = text.button;

        show(text.email, 'error');
      });
    }

    button.addEventListener('click', submit);

    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();

        submit();
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
