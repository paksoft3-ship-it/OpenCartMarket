<?php
namespace Opencart\Catalog\Controller\Extension\NkBackInStock\Event;

/**
 * NovaKur Back in Stock Alerts - storefront event handlers.
 *
 *   assets  catalog/controller/product/product/before
 *   form    catalog/view/product/product/after
 */
class BackInStock extends \Opencart\System\Engine\Controller {
	/**
	 * @param string            $route
	 * @param array<int, mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_back_in_stock_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_back_in_stock/catalog/view/assets/css/back_in_stock.css');
		$this->document->addScript('extension/nk_back_in_stock/catalog/view/assets/js/back_in_stock.js');
	}

	/**
	 * Inject the notify form immediately after the add to cart form, which on an
	 * unavailable product is the button the shopper just found useless. Falls back
	 * to the description tabs, and does nothing when neither anchor is present.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function form(string &$route, array &$data, mixed &$output): void {
		if (!(int)$this->config->get('module_back_in_stock_status') || !is_string($output) || $output === '') {
			return;
		}

		if (str_contains($output, 'id="nk-bis"')) {
			return;
		}

		$product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

		if ($product_id < 1) {
			return;
		}

		$html = $this->load->controller('extension/nk_back_in_stock/module/back_in_stock.render', $product_id);

		if (!is_string($html) || $html === '') {
			return;
		}

		$position = strpos($output, 'id="form-product"');

		if ($position !== false) {
			$close = strpos($output, '</form>', $position);

			if ($close !== false) {
				$at = $close + strlen('</form>');

				$output = substr($output, 0, $at) . $html . substr($output, $at);

				return;
			}
		}

		$anchor = '<ul class="nav nav-tabs">';

		$position = strpos($output, $anchor);

		if ($position !== false) {
			$output = substr($output, 0, $position) . $html . substr($output, $position);
		}
	}
}
