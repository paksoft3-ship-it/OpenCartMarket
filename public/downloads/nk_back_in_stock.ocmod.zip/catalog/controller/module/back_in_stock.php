<?php
namespace Opencart\Catalog\Controller\Extension\NkBackInStock\Module;

/**
 * NovaKur Back in Stock Alerts - storefront endpoints.
 *
 *   extension/nk_back_in_stock/module/back_in_stock.render     notify form markup (product page event)
 *   extension/nk_back_in_stock/module/back_in_stock.subscribe  POST product_id + email
 *   extension/nk_back_in_stock/module/back_in_stock.cron       token guarded mail run
 */
class BackInStock extends \Opencart\System\Engine\Controller {
	private const THROTTLE_WINDOW = 3600;
	private const THROTTLE_MAX = 5;
	private const MAIL_CHUNK = 50;

	/**
	 * Layout placeholder. The form is injected by the product page event.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * @param int $product_id
	 *
	 * @return string
	 */
	public function render(int $product_id = 0): string {
		if (!(int)$this->config->get('module_back_in_stock_status')) {
			return '';
		}

		if ($product_id < 1) {
			$product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
		}

		if ($product_id < 1) {
			return '';
		}

		$this->load->model('catalog/product');

		$product_info = $this->model_catalog_product->getProduct($product_id);

		if (!$product_info || !$this->isUnavailable($product_info)) {
			return '';
		}

		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$data = [
			'product_id'    => $product_id,
			'heading'       => $this->text('module_back_in_stock_heading', 'text_bis_heading'),
			'button_text'   => $this->text('module_back_in_stock_button_text', 'text_bis_button'),
			'subscribe_url' => $this->url->link('extension/nk_back_in_stock/module/back_in_stock.subscribe', 'language=' . $this->config->get('config_language'), true),
			'email'         => $this->customer->isLogged() ? (string)$this->customer->getEmail() : ''
		];

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_back_in_stock/module/back_in_stock_form', $data);
	}

	/**
	 * Store one subscription.
	 *
	 * Deliberately CSRF-tolerant: like checkout/cart.add and account/newsletter in
	 * core this is an unauthenticated storefront POST that only ever adds the
	 * caller's own address to a waiting list. It is throttled per session instead.
	 *
	 * @return void
	 */
	public function subscribe(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$json = [];

		if (!(int)$this->config->get('module_back_in_stock_status')) {
			$json['error'] = $this->language->get('error_bis_disabled');
		}

		$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;
		$email = isset($this->request->post['email']) ? trim((string)$this->request->post['email']) : '';

		// Column is varchar(96); validate before the database has to.
		if (!isset($json['error']) && (oc_strlen($email) > 96 || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
			$json['error'] = $this->language->get('error_bis_email');
		}

		$product_info = [];

		if (!isset($json['error'])) {
			$this->load->model('catalog/product');

			$product_info = $product_id ? $this->model_catalog_product->getProduct($product_id) : [];

			if (!$product_info) {
				$json['error'] = $this->language->get('error_bis_product');
			} elseif (!$this->isUnavailable($product_info)) {
				$json['error'] = $this->language->get('error_bis_in_stock');
			}
		}

		// An open endpoint must not become a free mail spool.
		if (!isset($json['error']) && isset($this->session->data['nk_bis_time']) && (time() - (int)$this->session->data['nk_bis_time']) < self::THROTTLE_WINDOW && (int)($this->session->data['nk_bis_count'] ?? 0) >= self::THROTTLE_MAX) {
			$json['error'] = $this->language->get('error_bis_throttle');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_back_in_stock/module/back_in_stock');

			if (!$this->model_extension_nk_back_in_stock_module_back_in_stock->tableExists()) {
				$json['error'] = $this->language->get('error_bis_disabled');
			} else {
				$added = $this->model_extension_nk_back_in_stock_module_back_in_stock->addSubscriber([
					'product_id'  => $product_id,
					'store_id'    => (int)$this->config->get('config_store_id'),
					'language_id' => (int)$this->config->get('config_language_id'),
					'customer_id' => (int)$this->customer->getId(),
					'email'       => $email,
					'ip'          => (string)($this->request->server['REMOTE_ADDR'] ?? '')
				]);

				if (!isset($this->session->data['nk_bis_time']) || (time() - (int)$this->session->data['nk_bis_time']) >= self::THROTTLE_WINDOW) {
					$this->session->data['nk_bis_time'] = time();
					$this->session->data['nk_bis_count'] = 0;
				}

				$this->session->data['nk_bis_count'] = (int)($this->session->data['nk_bis_count'] ?? 0) + 1;

				$json['success'] = $added ? $this->language->get('text_bis_subscribed') : $this->language->get('text_bis_already');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Token guarded mail run: everybody waiting for a product that is purchasable
	 * again gets one e-mail, and the row is marked so it never goes out twice.
	 *
	 * @return void
	 */
	public function cron(): void {
		$this->response->addHeader('Content-Type: text/plain; charset=utf-8');

		$configured = (string)$this->config->get('module_back_in_stock_cron_token');
		$supplied = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

		if ($configured === '' || strlen($supplied) !== strlen($configured) || !hash_equals($configured, $supplied)) {
			$this->response->addHeader(((string)($this->request->server['SERVER_PROTOCOL'] ?? 'HTTP/1.1')) . ' 403 Forbidden');
			$this->response->setOutput("Forbidden\n");

			return;
		}

		$this->load->model('extension/nk_back_in_stock/module/back_in_stock');

		if (!$this->model_extension_nk_back_in_stock_module_back_in_stock->tableExists()) {
			$this->response->setOutput("The nk_stock_alert table is not installed.\n");

			return;
		}

		if (!$this->config->get('config_mail_engine')) {
			$this->response->setOutput("No mail engine is configured; nothing was sent.\n");

			return;
		}

		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$store_id = (int)$this->config->get('config_store_id');
		$language_id = (int)$this->config->get('config_language_id');

		$batch = (int)$this->config->get('module_back_in_stock_batch');

		if ($batch < 1 || $batch > 5000) {
			$batch = 200;
		}

		$store_name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
		$store_url = rtrim(html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8'), '/') . '/';

		$subject_template = trim((string)$this->config->get('module_back_in_stock_subject'));

		if ($subject_template === '') {
			$subject_template = $this->language->get('text_bis_default_subject');
		}

		$body_template = (string)$this->config->get('module_back_in_stock_body');

		if (trim($body_template) === '') {
			$body_template = $this->language->get('text_bis_default_body');
		}

		$mail_option = [
			'parameter'     => $this->config->get('config_mail_parameter'),
			'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
			'smtp_username' => $this->config->get('config_mail_smtp_username'),
			'smtp_password' => html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
			'smtp_port'     => $this->config->get('config_mail_smtp_port'),
			'smtp_timeout'  => $this->config->get('config_mail_smtp_timeout')
		];

		$sent = 0;
		$failed = 0;

		// Chunked: rows are marked as they go, so the next read never returns them.
		while ($sent + $failed < $batch) {
			$limit = min(self::MAIL_CHUNK, $batch - ($sent + $failed));

			$rows = $this->model_extension_nk_back_in_stock_module_back_in_stock->getPending($store_id, $language_id, $limit);

			if (!$rows) {
				break;
			}

			foreach ($rows as $row) {
				$product_id = (int)$row['product_id'];
				$email = (string)$row['email'];

				// A row can only be mailed once, whatever the mail library does next.
				$this->model_extension_nk_back_in_stock_module_back_in_stock->markSent((int)$row['stock_alert_id']);

				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$failed++;

					continue;
				}

				$name = html_entity_decode((string)$row['name'], ENT_QUOTES, 'UTF-8');
				$link = $store_url . 'index.php?route=product/product&product_id=' . $product_id;

				$subject = $this->replace($subject_template, $name, $link, $store_name, false);

				$body = $this->load->view('extension/nk_back_in_stock/mail/back_in_stock', [
					'body'      => $this->replace($body_template, $name, $link, $store_name, true),
					'store'     => htmlspecialchars($store_name, ENT_QUOTES, 'UTF-8'),
					'store_url' => htmlspecialchars($store_url, ENT_QUOTES, 'UTF-8')
				]);

				try {
					$mail = new \Opencart\System\Library\Mail((string)$this->config->get('config_mail_engine'), $mail_option);
					$mail->setTo($email);
					$mail->setFrom((string)$this->config->get('config_email'));
					$mail->setSender($store_name);
					$mail->setSubject($subject);
					$mail->setHtml($body);
					$mail->send();

					$sent++;
				} catch (\Throwable $e) {
					// One dead address must not abort the whole run.
					$failed++;
				}
			}

			if (count($rows) < $limit) {
				break;
			}
		}

		$this->response->setOutput('Notifications sent: ' . $sent . "\n" . 'Failed: ' . $failed . "\n");
	}

	/**
	 * Fill {product} / {link} / {store}.
	 *
	 * @param string $template
	 * @param string $name
	 * @param string $link
	 * @param string $store
	 * @param bool   $html     escape the values for an HTML body
	 *
	 * @return string
	 */
	private function replace(string $template, string $name, string $link, string $store, bool $html): string {
		if ($html) {
			$name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
			$link = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');
			$store = htmlspecialchars($store, ENT_QUOTES, 'UTF-8');
		} else {
			// Subject lines are plain text; a stray newline would let a crafted
			// product name inject its own mail headers.
			$name = trim(str_replace(["\r", "\n"], ' ', $name));
			$link = trim(str_replace(["\r", "\n"], ' ', $link));
			$store = trim(str_replace(["\r", "\n"], ' ', $store));
		}

		return str_replace(['{product}', '{link}', '{store}'], [$name, $link, $store], $template);
	}

	/**
	 * Out of stock by quantity, or by one of the merchant's nominated statuses.
	 *
	 * @param array<string, mixed> $product_info
	 *
	 * @return bool
	 */
	private function isUnavailable(array $product_info): bool {
		if ((int)($product_info['quantity'] ?? 0) <= 0) {
			return true;
		}

		$stock_status_ids = $this->config->get('module_back_in_stock_stock_status_ids');

		if (!is_array($stock_status_ids)) {
			$stock_status_ids = ($stock_status_ids !== null && $stock_status_ids !== '') ? explode(',', (string)$stock_status_ids) : [];
		}

		$stock_status_ids = array_map('intval', $stock_status_ids);

		return in_array((int)($product_info['stock_status_id'] ?? 0), $stock_status_ids, true);
	}

	/**
	 * Configured copy, or the language default when the merchant left it empty.
	 *
	 * @param string $key
	 * @param string $fallback
	 *
	 * @return string
	 */
	private function text(string $key, string $fallback): string {
		$value = trim((string)$this->config->get($key));

		return $value !== '' ? $value : $this->language->get($fallback);
	}
}
