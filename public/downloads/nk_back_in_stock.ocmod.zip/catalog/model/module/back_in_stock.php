<?php
namespace Opencart\Catalog\Model\Extension\NkBackInStock\Module;

/**
 * NovaKur Back in Stock Alerts - storefront model.
 *
 * Every value reaching SQL is int cast or escaped; the e-mail has already been
 * validated by the controller.
 */
class BackInStock extends \Opencart\System\Engine\Model {
	/**
	 * @return bool
	 */
	public function tableExists(): bool {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_stock_alert') . "'")->num_rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return bool true when this is a new subscription, false when it already existed
	 */
	public function addSubscriber(array $data): bool {
		$email = oc_strtolower(trim((string)($data['email'] ?? '')));
		$product_id = (int)($data['product_id'] ?? 0);
		$store_id = (int)($data['store_id'] ?? 0);

		$query = $this->db->query("SELECT `stock_alert_id` FROM `" . DB_PREFIX . "nk_stock_alert` WHERE `product_id` = '" . $product_id . "' AND `email` = '" . $this->db->escape($email) . "' AND `store_id` = '" . $store_id . "' LIMIT 1");

		if ($query->num_rows) {
			return false;
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_stock_alert` SET `product_id` = '" . $product_id . "', `store_id` = '" . $store_id . "', `language_id` = '" . (int)($data['language_id'] ?? 0) . "', `customer_id` = '" . (int)($data['customer_id'] ?? 0) . "', `email` = '" . $this->db->escape($email) . "', `ip` = '" . $this->db->escape(substr((string)($data['ip'] ?? ''), 0, 40)) . "', `status` = '1', `date_added` = NOW()");

		return true;
	}

	/**
	 * Waiting subscriptions whose product is purchasable again.
	 *
	 * The product must still exist, be enabled, be released and belong to this
	 * store - a restocked but hidden product is not worth an e-mail.
	 *
	 * @param int $store_id
	 * @param int $language_id fallback language for the product name
	 * @param int $limit
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getPending(int $store_id, int $language_id, int $limit): array {
		$limit = max(1, min(500, $limit));

		$sql = "SELECT `a`.`stock_alert_id`, `a`.`product_id`, `a`.`email`, `a`.`language_id`, COALESCE(NULLIF(`pd`.`name`, ''), `pdd`.`name`, '') AS `name`";
		$sql .= " FROM `" . DB_PREFIX . "nk_stock_alert` `a`";
		$sql .= " INNER JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `a`.`product_id`)";
		$sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `a`.`product_id` AND `p2s`.`store_id` = `a`.`store_id`)";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `a`.`product_id` AND `pd`.`language_id` = `a`.`language_id`)";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pdd` ON (`pdd`.`product_id` = `a`.`product_id` AND `pdd`.`language_id` = '" . (int)$language_id . "')";
		$sql .= " WHERE `a`.`status` = '1' AND `a`.`store_id` = '" . (int)$store_id . "'";
		$sql .= " AND `p`.`quantity` > 0 AND `p`.`status` = '1' AND `p`.`date_available` <= NOW()";
		$sql .= " ORDER BY `a`.`stock_alert_id` ASC LIMIT " . $limit;

		return $this->db->query($sql)->rows;
	}

	/**
	 * @param int $stock_alert_id
	 *
	 * @return void
	 */
	public function markSent(int $stock_alert_id): void {
		$this->db->query("UPDATE `" . DB_PREFIX . "nk_stock_alert` SET `status` = '0', `date_sent` = NOW() WHERE `stock_alert_id` = '" . (int)$stock_alert_id . "'");
	}
}
