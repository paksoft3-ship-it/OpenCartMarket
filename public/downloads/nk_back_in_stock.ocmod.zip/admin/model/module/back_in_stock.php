<?php
namespace Opencart\Admin\Model\Extension\NkBackInStock\Module;

/**
 * NovaKur Back in Stock Alerts - admin model.
 *
 * Owns `<prefix>nk_stock_alert`. status 1 = still waiting, 0 = already mailed.
 */
class BackInStock extends \Opencart\System\Engine\Model {
	/**
	 * @return void
	 */
	public function createTable(): void {
		// varchar(96) matches oc_customer.email, so the composite unique key stays
		// well inside the InnoDB index limit on utf8mb4.
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_stock_alert` (
			`stock_alert_id` int(11) NOT NULL AUTO_INCREMENT,
			`product_id` int(11) NOT NULL DEFAULT '0',
			`store_id` int(11) NOT NULL DEFAULT '0',
			`language_id` int(11) NOT NULL DEFAULT '0',
			`customer_id` int(11) NOT NULL DEFAULT '0',
			`email` varchar(96) NOT NULL DEFAULT '',
			`ip` varchar(40) NOT NULL DEFAULT '',
			`status` tinyint(1) NOT NULL DEFAULT '1',
			`date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`date_sent` datetime DEFAULT NULL,
			PRIMARY KEY (`stock_alert_id`),
			UNIQUE KEY `product_email_store` (`product_id`,`email`,`store_id`),
			KEY `waiting` (`status`,`store_id`,`product_id`),
			KEY `date_added` (`date_added`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * @return bool
	 */
	public function tableExists(): bool {
		return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_stock_alert') . "'")->num_rows;
	}

	/**
	 * Shared WHERE for the list, the total and the export.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return string
	 */
	private function where(array $data): string {
		$sql = " WHERE `a`.`store_id` = '" . (int)($data['store_id'] ?? 0) . "'";

		if (!empty($data['filter_product_id'])) {
			$sql .= " AND `a`.`product_id` = '" . (int)$data['filter_product_id'] . "'";
		}

		if (isset($data['filter_status']) && $data['filter_status'] !== '') {
			$sql .= " AND `a`.`status` = '" . ((int)$data['filter_status'] ? 1 : 0) . "'";
		}

		if (!empty($data['filter_email'])) {
			$sql .= " AND `a`.`email` LIKE '" . $this->db->escape((string)$data['filter_email'] . '%') . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND `pd`.`name` LIKE '" . $this->db->escape((string)$data['filter_name'] . '%') . "'";
		}

		return $sql;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return string
	 */
	private function from(array $data): string {
		$sql = " FROM `" . DB_PREFIX . "nk_stock_alert` `a`";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `a`.`product_id` AND `pd`.`language_id` = '" . (int)($data['language_id'] ?? 0) . "')";
		$sql .= " LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `a`.`product_id`)";

		return $sql;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getSubscribers(array $data = []): array {
		$sql = "SELECT `a`.*, COALESCE(`pd`.`name`, '') AS `name`, COALESCE(`p`.`quantity`, 0) AS `quantity`";
		$sql .= $this->from($data) . $this->where($data);
		$sql .= " ORDER BY `a`.`date_added` DESC, `a`.`stock_alert_id` DESC";

		if (isset($data['start']) || isset($data['limit'])) {
			$start = max(0, (int)($data['start'] ?? 0));
			$limit = (int)($data['limit'] ?? 20);

			if ($limit < 1) {
				$limit = 20;
			}

			$sql .= " LIMIT " . $start . "," . $limit;
		}

		return $this->db->query($sql)->rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function getTotalSubscribers(array $data = []): int {
		$sql = "SELECT COUNT(*) AS `total`" . $this->from($data) . $this->where($data);

		return (int)($this->db->query($sql)->row['total'] ?? 0);
	}

	/**
	 * Waiting / sent counts per product.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getProductSummary(array $data = []): array {
		$sql = "SELECT `a`.`product_id`, COALESCE(`pd`.`name`, '') AS `name`, COALESCE(`p`.`model`, '') AS `model`, COALESCE(`p`.`quantity`, 0) AS `quantity`";
		$sql .= ", SUM(CASE WHEN `a`.`status` = '1' THEN 1 ELSE 0 END) AS `waiting`";
		$sql .= ", SUM(CASE WHEN `a`.`status` = '0' THEN 1 ELSE 0 END) AS `sent`";
		$sql .= ", MAX(`a`.`date_added`) AS `date_added`";
		$sql .= $this->from($data) . $this->where($data);
		$sql .= " GROUP BY `a`.`product_id`, `pd`.`name`, `p`.`model`, `p`.`quantity`";
		$sql .= " ORDER BY `waiting` DESC, `date_added` DESC";

		$start = max(0, (int)($data['start'] ?? 0));
		$limit = (int)($data['limit'] ?? 10);

		if ($limit < 1) {
			$limit = 10;
		}

		$sql .= " LIMIT " . $start . "," . $limit;

		return $this->db->query($sql)->rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function getTotalProducts(array $data = []): int {
		$sql = "SELECT COUNT(DISTINCT `a`.`product_id`) AS `total`" . $this->from($data) . $this->where($data);

		return (int)($this->db->query($sql)->row['total'] ?? 0);
	}

	/**
	 * @param int $stock_alert_id
	 *
	 * @return void
	 */
	public function deleteSubscriber(int $stock_alert_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_stock_alert` WHERE `stock_alert_id` = '" . (int)$stock_alert_id . "'");
	}

	/**
	 * @param int $product_id
	 * @param int $store_id
	 *
	 * @return int
	 */
	public function deleteByProduct(int $product_id, int $store_id): int {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_stock_alert` WHERE `product_id` = '" . (int)$product_id . "' AND `store_id` = '" . (int)$store_id . "'");

		return (int)$this->db->countAffected();
	}
}
