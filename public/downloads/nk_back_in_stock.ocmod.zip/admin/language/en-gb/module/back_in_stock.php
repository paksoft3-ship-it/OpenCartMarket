<?php
// Heading
$_['heading_title'] = 'NovaKur Back in Stock Alerts';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified NovaKur Back in Stock Alerts settings!';
$_['text_edit'] = 'Edit NovaKur Back in Stock Alerts';
$_['text_delete_success'] = 'Success: The selected subscribers have been removed!';
$_['text_mail'] = 'Notification E-mail';
$_['text_cron'] = 'Notification Cron';
$_['text_summary'] = 'Waiting Lists Per Product';
$_['text_subscribers'] = 'Subscribers';
$_['text_waiting'] = 'Waiting';
$_['text_sent'] = 'Sent';
$_['text_guest'] = 'Guest';
$_['text_all_status'] = 'Waiting and sent';
$_['text_in_stock'] = 'In stock';
$_['text_out_of_stock'] = 'Out of stock';
$_['text_missing_product'] = '(deleted product #%d)';
$_['text_no_results'] = 'Nobody is waiting for a restock yet.';
$_['text_placeholders'] = 'Placeholders: {product} product name, {link} product page URL, {store} store name.';

// Column
$_['column_product'] = 'Product';
$_['column_model'] = 'Model';
$_['column_email'] = 'E-Mail';
$_['column_customer'] = 'Customer';
$_['column_ip'] = 'IP';
$_['column_stock'] = 'Stock';
$_['column_waiting'] = 'Waiting';
$_['column_sent'] = 'Sent';
$_['column_status'] = 'Status';
$_['column_date_added'] = 'Added';
$_['column_date_sent'] = 'Notified';
$_['column_action'] = 'Action';

// Entry
$_['entry_status'] = 'Status';
$_['entry_stock_status'] = 'Out Of Stock Statuses';
$_['entry_heading'] = 'Form Heading';
$_['entry_button_text'] = 'Button Text';
$_['entry_subject'] = 'E-Mail Subject';
$_['entry_body'] = 'E-Mail Body';
$_['entry_batch'] = 'E-Mails Per Run';
$_['entry_cron_token'] = 'Cron Token';
$_['entry_filter_name'] = 'Product Name';
$_['entry_filter_email'] = 'E-Mail';
$_['entry_filter_status'] = 'Status';

// Help
$_['help_status'] = 'Shows the notify form on out of stock product pages.';
$_['help_stock_status'] = 'Products carrying one of these stock statuses count as unavailable even when the quantity is above zero. Quantity at or below zero always counts.';
$_['help_heading'] = 'Leave blank to use the built in wording.';
$_['help_button_text'] = 'Leave blank to use the built in wording.';
$_['help_subject'] = 'Subject line of the restock e-mail.';
$_['help_body'] = 'HTML is allowed. {link} is required so the customer can reach the product.';
$_['help_batch'] = 'Upper bound on how many e-mails one cron run sends. The rest go out on the next run.';
$_['help_cron_token'] = '16-64 letters and digits. The notification URL below is refused without it.';
$_['help_cron'] = 'Call this URL from cron (for example every 15 minutes). It mails everyone waiting for a product whose quantity is back above zero, then marks those rows sent. It answers 403 without the token.';
$_['help_export'] = 'The export follows the filters above.';

// Button
$_['button_export'] = 'Export CSV';
$_['button_filter'] = 'Filter';
$_['button_delete_product'] = 'Delete list';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify NovaKur Back in Stock Alerts!';
$_['error_subject'] = 'The subject must be between 1 and 255 characters!';
$_['error_body'] = 'The body must be between 1 and 8000 characters!';
$_['error_body_link'] = 'The body must contain the {link} placeholder!';
$_['error_length'] = 'This field must be 255 characters or fewer!';
$_['error_batch'] = 'The e-mails per run must be between 1 and 5000!';
$_['error_cron_token'] = 'The cron token must be 16 to 64 letters and digits!';
