<?php
namespace Opencart\Admin\Controller\Extension\NkBackInStock\Module;

/**
 * NovaKur Back in Stock Alerts - admin settings and waiting list.
 *
 * Settings namespace: module_back_in_stock_*
 * Route:              extension/nk_back_in_stock/module/back_in_stock
 * Table:              <prefix>nk_stock_alert (kept on uninstall - merchant data)
 */
class BackInStock extends \Opencart\System\Engine\Controller {
	private string $route = 'extension/nk_back_in_stock/module/back_in_stock';
	private string $prefix = 'module_back_in_stock';

	private const TEXT_MAX = 255;
	private const BODY_MAX = 8000;

	/**
	 * Every key must start with $prefix or editSetting() silently drops it.
	 *
	 * @return array<string, mixed>
	 */
	private function defaults(): array {
		return [
			'module_back_in_stock_status'           => '0',
			'module_back_in_stock_stock_status_ids' => [],
			'module_back_in_stock_heading'          => '',
			'module_back_in_stock_button_text'      => '',
			'module_back_in_stock_subject'          => '{product} is back in stock',
			'module_back_in_stock_body'             => "<p>Good news - {product} is available again.</p>\n<p><a href=\"{link}\">Order it here</a></p>\n<p>{store}</p>",
			'module_back_in_stock_batch'            => '200',
			'module_back_in_stock_cron_token'       => oc_token(32)
		];
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private function events(): array {
		return [
			[
				'code'        => 'nk_back_in_stock_assets',
				'description' => 'NovaKur Back in Stock Alerts: queue the notify form stylesheet and script on the product page.',
				'trigger'     => 'catalog/controller/product/product/before',
				'action'      => 'extension/nk_back_in_stock/event/back_in_stock.assets',
				'status'      => 1,
				'sort_order'  => 1
			],
			[
				'code'        => 'nk_back_in_stock_form',
				'description' => 'NovaKur Back in Stock Alerts: inject the notify form beside the unavailable add to cart button.',
				'trigger'     => 'catalog/view/product/product/after',
				'action'      => 'extension/nk_back_in_stock/event/back_in_stock.form',
				'status'      => 1,
				'sort_order'  => 1
			]
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

		$data = [];

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		// A cron route without a token would let anyone trigger a mail run.
		if (trim((string)$data['module_back_in_stock_cron_token']) === '' && $this->user->hasPermission('modify', $this->route)) {
			$data['module_back_in_stock_cron_token'] = oc_token(32);

			$settings['module_back_in_stock_cron_token'] = $data['module_back_in_stock_cron_token'];

			$this->model_setting_setting->editSetting($this->prefix, $settings, $store_id);
		}

		if (!is_array($data['module_back_in_stock_stock_status_ids'])) {
			$raw = (string)$data['module_back_in_stock_stock_status_ids'];

			$data['module_back_in_stock_stock_status_ids'] = $raw !== '' ? explode(',', $raw) : [];
		}

		$data['module_back_in_stock_stock_status_ids'] = array_map('intval', $data['module_back_in_stock_stock_status_ids']);

		$this->load->model('localisation/stock_status');

		$data['stock_statuses'] = $this->model_localisation_stock_status->getStockStatuses();

		$token = 'user_token=' . $this->session->data['user_token'];

		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', $token)
			],
			[
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('marketplace/extension', $token . '&type=module')
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link($this->route, $token . '&store_id=' . $store_id)
			]
		];

		$data['store_id'] = $store_id;
		$data['user_token'] = $this->session->data['user_token'];

		$data['save'] = $this->url->link($this->route . '.save', $token . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', $token . '&type=module');
		$data['cron_url'] = $this->cronUrl($store_id, (string)$data['module_back_in_stock_cron_token']);

		$data['list'] = $this->getList();

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/nk_back_in_stock/module/back_in_stock', $data));
	}

	/**
	 * @return void
	 */
	public function list(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$this->response->setOutput($this->getList());
	}

	/**
	 * Filters shared by the list and the CSV export.
	 *
	 * @return array<string, mixed>
	 */
	private function filters(): array {
		$status = '';

		if (isset($this->request->get['filter_status']) && $this->request->get['filter_status'] !== '') {
			$status = (string)(int)(bool)$this->request->get['filter_status'];
		}

		return [
			'store_id'          => isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0,
			'language_id'       => (int)$this->config->get('config_language_id'),
			'filter_product_id' => isset($this->request->get['filter_product_id']) ? (int)$this->request->get['filter_product_id'] : 0,
			'filter_email'      => isset($this->request->get['filter_email']) ? trim((string)$this->request->get['filter_email']) : '',
			'filter_name'       => isset($this->request->get['filter_name']) ? trim((string)$this->request->get['filter_name']) : '',
			'filter_status'     => $status
		];
	}

	/**
	 * @return string
	 */
	private function getList(): string {
		$filters = $this->filters();

		$page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;

		$limit = (int)$this->config->get('config_pagination_admin');

		if ($limit < 1) {
			$limit = 10;
		}

		$data = [];

		$data['subscribers'] = [];
		$data['products'] = [];
		$total = 0;

		$this->load->model('extension/nk_back_in_stock/module/back_in_stock');

		if ($this->model_extension_nk_back_in_stock_module_back_in_stock->tableExists()) {
			$filter_data = $filters + [
				'start' => ($page - 1) * $limit,
				'limit' => $limit
			];

			$total = $this->model_extension_nk_back_in_stock_module_back_in_stock->getTotalSubscribers($filter_data);

			foreach ($this->model_extension_nk_back_in_stock_module_back_in_stock->getSubscribers($filter_data) as $row) {
				$name = (string)$row['name'];

				$data['subscribers'][] = [
					'stock_alert_id' => (int)$row['stock_alert_id'],
					'product_id'     => (int)$row['product_id'],
					'name'           => $name !== '' ? $name : sprintf($this->language->get('text_missing_product'), (int)$row['product_id']),
					'email'          => (string)$row['email'],
					'customer_id'    => (int)$row['customer_id'],
					'ip'             => (string)$row['ip'],
					'quantity'       => (int)$row['quantity'],
					'status'         => (int)$row['status'] ? $this->language->get('text_waiting') : $this->language->get('text_sent'),
					'sent'           => !(int)$row['status'],
					'date_added'     => date($this->language->get('date_format_short'), strtotime((string)$row['date_added'])),
					'date_sent'      => $row['date_sent'] ? date($this->language->get('date_format_short'), strtotime((string)$row['date_sent'])) : ''
				];
			}

			// The per product counts ignore the status filter on purpose: the point
			// of the panel is to compare waiting against already mailed.
			$summary_data = $filters;

			$summary_data['filter_status'] = '';
			$summary_data['start'] = 0;
			$summary_data['limit'] = 10;

			foreach ($this->model_extension_nk_back_in_stock_module_back_in_stock->getProductSummary($summary_data) as $row) {
				$name = (string)$row['name'];

				$data['products'][] = [
					'product_id' => (int)$row['product_id'],
					'name'       => $name !== '' ? $name : sprintf($this->language->get('text_missing_product'), (int)$row['product_id']),
					'model'      => (string)$row['model'],
					'quantity'   => (int)$row['quantity'],
					'waiting'    => (int)$row['waiting'],
					'sent'       => (int)$row['sent'],
					'date_added' => $row['date_added'] ? date($this->language->get('date_format_short'), strtotime((string)$row['date_added'])) : ''
				];
			}
		}

		$url = '&store_id=' . $filters['store_id'];

		if ($filters['filter_product_id']) {
			$url .= '&filter_product_id=' . $filters['filter_product_id'];
		}

		if ($filters['filter_email'] !== '') {
			$url .= '&filter_email=' . urlencode($filters['filter_email']);
		}

		if ($filters['filter_name'] !== '') {
			$url .= '&filter_name=' . urlencode($filters['filter_name']);
		}

		if ($filters['filter_status'] !== '') {
			$url .= '&filter_status=' . $filters['filter_status'];
		}

		$user_token = 'user_token=' . $this->session->data['user_token'];

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->url->link($this->route . '.list', $user_token . $url . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), $total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($total - $limit)) ? $total : ((($page - 1) * $limit) + $limit), $total, (int)ceil($total / $limit));

		$data['delete'] = $this->url->link($this->route . '.delete', $user_token . $url);
		$data['export'] = $this->url->link($this->route . '.export', $user_token . $url);
		$data['action'] = $this->url->link($this->route . '.list', $user_token . $url);

		$data['filter_product_id'] = $filters['filter_product_id'];
		$data['filter_email'] = $filters['filter_email'];
		$data['filter_name'] = $filters['filter_name'];
		$data['filter_status'] = $filters['filter_status'];
		$data['total'] = $total;

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/nk_back_in_stock/module/back_in_stock_list', $data);
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$subject = isset($post['module_back_in_stock_subject']) ? trim((string)$post['module_back_in_stock_subject']) : '';

		if ($subject === '' || oc_strlen($subject) > self::TEXT_MAX) {
			$json['error']['subject'] = $this->language->get('error_subject');
		}

		$body = isset($post['module_back_in_stock_body']) ? trim((string)$post['module_back_in_stock_body']) : '';

		if ($body === '' || oc_strlen($body) > self::BODY_MAX) {
			$json['error']['body'] = $this->language->get('error_body');
		}

		// The customer has to be able to reach the product, or the mail is noise.
		if ($body !== '' && !str_contains($body, '{link}')) {
			$json['error']['body'] = $this->language->get('error_body_link');
		}

		foreach (['heading', 'button_text'] as $field) {
			if (isset($post['module_back_in_stock_' . $field]) && oc_strlen((string)$post['module_back_in_stock_' . $field]) > self::TEXT_MAX) {
				$json['error'][$field] = $this->language->get('error_length');
			}
		}

		$batch = isset($post['module_back_in_stock_batch']) ? (int)$post['module_back_in_stock_batch'] : 200;

		if ($batch < 1 || $batch > 5000) {
			$json['error']['batch'] = $this->language->get('error_batch');
		}

		$cron_token = isset($post['module_back_in_stock_cron_token']) ? trim((string)$post['module_back_in_stock_cron_token']) : '';

		if (!preg_match('/^[A-Za-z0-9]{16,64}$/', $cron_token)) {
			$json['error']['cron_token'] = $this->language->get('error_cron_token');
		}

		$stock_status_ids = [];

		if (isset($post['module_back_in_stock_stock_status_ids']) && is_array($post['module_back_in_stock_stock_status_ids'])) {
			$this->load->model('localisation/stock_status');

			$allowed = array_map(static function (array $row): int {
				return (int)$row['stock_status_id'];
			}, $this->model_localisation_stock_status->getStockStatuses());

			foreach ($post['module_back_in_stock_stock_status_ids'] as $value) {
				$stock_status_id = (int)$value;

				if ($stock_status_id > 0 && in_array($stock_status_id, $allowed, true) && !in_array($stock_status_id, $stock_status_ids, true)) {
					$stock_status_ids[] = $stock_status_id;
				}
			}
		}

		if (!isset($json['error'])) {
			$save = [
				'module_back_in_stock_status'           => !empty($post['module_back_in_stock_status']) ? '1' : '0',
				'module_back_in_stock_stock_status_ids' => $stock_status_ids,
				'module_back_in_stock_subject'          => $subject,
				'module_back_in_stock_body'             => $body,
				'module_back_in_stock_batch'            => (string)$batch,
				'module_back_in_stock_cron_token'       => $cron_token
			];

			// Merchant copy is stored raw and escaped at render time, matching core.
			foreach (['heading', 'button_text'] as $field) {
				$save['module_back_in_stock_' . $field] = isset($post['module_back_in_stock_' . $field]) ? trim((string)$post['module_back_in_stock_' . $field]) : '';
			}

			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Remove selected subscribers, or every subscriber of one product.
	 *
	 * @return void
	 */
	public function delete(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', $this->route)) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/nk_back_in_stock/module/back_in_stock');

			if ($this->model_extension_nk_back_in_stock_module_back_in_stock->tableExists()) {
				$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

				if ($product_id > 0) {
					$this->model_extension_nk_back_in_stock_module_back_in_stock->deleteByProduct($product_id, $store_id);
				}

				$selected = (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) ? $this->request->post['selected'] : [];

				foreach ($selected as $stock_alert_id) {
					$this->model_extension_nk_back_in_stock_module_back_in_stock->deleteSubscriber((int)$stock_alert_id);
				}
			}

			$json['success'] = $this->language->get('text_delete_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Download the waiting list as CSV.
	 *
	 * @return void
	 */
	public function export(): void {
		$this->load->language('extension/nk_back_in_stock/module/back_in_stock');

		if (!$this->user->hasPermission('access', $this->route)) {
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput((string)json_encode(['error' => $this->language->get('error_permission')]));

			return;
		}

		$this->load->model('extension/nk_back_in_stock/module/back_in_stock');

		$rows = $this->model_extension_nk_back_in_stock_module_back_in_stock->tableExists() ? $this->model_extension_nk_back_in_stock_module_back_in_stock->getSubscribers($this->filters()) : [];

		$handle = fopen('php://temp', 'w+');

		fputcsv($handle, ['product_id', 'product', 'email', 'customer_id', 'ip', 'status', 'date_added', 'date_sent']);

		foreach ($rows as $row) {
			fputcsv($handle, [
				(int)$row['product_id'],
				$this->csv((string)$row['name']),
				$this->csv((string)$row['email']),
				(int)$row['customer_id'],
				$this->csv((string)$row['ip']),
				(int)$row['status'] ? 'waiting' : 'sent',
				(string)$row['date_added'],
				(string)($row['date_sent'] ?? '')
			]);
		}

		rewind($handle);

		$csv = (string)stream_get_contents($handle);

		fclose($handle);

		$this->response->addHeader('Content-Type: text/csv; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="nk-back-in-stock-' . date('Y-m-d') . '.csv"');
		$this->response->setOutput($csv);
	}

	/**
	 * Neutralise spreadsheet formula injection from shopper supplied values.
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	private function csv(string $value): string {
		if ($value !== '' && str_contains("=+-@\t\r", $value[0])) {
			return "'" . $value;
		}

		return $value;
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/nk_back_in_stock/module/back_in_stock');
		$this->model_extension_nk_back_in_stock_module_back_in_stock->createTable();

		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->prefix, $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
			$this->model_setting_event->addEvent($event);
		}

		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
	}

	/**
	 * The subscriber table is deliberately left in place - uninstalling a module
	 * must not throw away a waiting list the merchant still owes an e-mail to.
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events() as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting($this->prefix);
	}

	/**
	 * @param int    $store_id
	 * @param string $cron_token
	 *
	 * @return string
	 */
	private function cronUrl(int $store_id, string $cron_token): string {
		$store_url = (string)$this->config->get('config_url');

		if ($store_id) {
			$this->load->model('setting/store');

			$store_info = $this->model_setting_store->getStore($store_id);

			if ($store_info && !empty($store_info['url'])) {
				$store_url = (string)$store_info['url'];
			}
		}

		$store_url = rtrim(html_entity_decode($store_url, ENT_QUOTES, 'UTF-8'), '/') . '/';

		return $store_url . 'index.php?route=extension/nk_back_in_stock/module/back_in_stock.cron&token=' . rawurlencode($cron_token);
	}
}
