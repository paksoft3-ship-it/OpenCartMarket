<?php
$_['heading_title']                 = 'NovaKur Akakçe Feed';

$_['text_extension']                = 'Extensions';
$_['text_success']                  = 'Success: You have modified Akakçe feed settings!';
$_['text_edit']                     = 'Edit Akakçe Feed';
$_['text_enabled']                  = 'Enabled';
$_['text_disabled']                 = 'Disabled';
$_['text_default_store']            = 'Default Store';
$_['text_cache_cleared']            = 'Feed cache has been cleared.';
$_['text_feed_url']                 = 'Feed URL';
$_['text_feed_status']              = 'Feed Status';
$_['text_last_generated']           = 'Last Generated';
$_['text_not_generated']            = 'Not generated yet';

$_['text_field_notice']             = 'This extension generates the feed URL for Akakçe to poll, or for you to upload. It does not connect to Akakçe and does not create or update listings by itself. The field set (id, code, barcode, name, brand, category, price, currency, stock, stockQuantity, url, image, cargo) follows Akakçe\'s public feed conventions; check it against the integration documentation in your own Akakçe merchant account before go-live, because required fields, tag names and the shipping-day format are agreed per merchant.';

$_['entry_status']                  = 'Status';
$_['entry_store']                   = 'Store';
$_['entry_currency']                = 'Currency';
$_['entry_language']                = 'Language';
$_['entry_include_out_of_stock']    = 'Include Out Of Stock';
$_['entry_include_tax']             = 'Prices Include Tax';
$_['entry_brand_attribute']         = 'Brand Attribute';
$_['entry_cargo_days']              = 'Shipping Days (Cargo)';
$_['entry_max_products']            = 'Maximum Products';
$_['entry_cache_hours']             = 'Cache Duration (Hours)';
$_['entry_excluded_categories']     = 'Excluded Categories';
$_['entry_token']                   = 'Feed Token';

$_['help_feed_url']                 = 'Give this URL to Akakçe, or fetch it yourself for upload. It contains the feed token, so treat it as a secret.';
$_['help_token']                    = 'Required. The feed URL only answers when this token is supplied, otherwise the route returns 404.';
$_['help_currency']                 = 'Akakçe lists Turkish stores in TRY. Prices are converted from your store currency using the exchange rate OpenCart holds for the selected currency.';
$_['help_include_tax']              = 'Akakçe expects the gross price a shopper pays. Leave enabled unless your stored product prices already include VAT.';
$_['help_brand_attribute']          = 'Optional. Read the brand from this product attribute instead of the manufacturer. Falls back to the manufacturer when the attribute is empty.';
$_['help_cargo_days']               = 'Shipping day count written into the &lt;cargo&gt; element of every product. 0 to 90. This is a single store-wide value, not a per product one.';
$_['help_excluded_categories']      = 'Products in the selected categories, and in every category below them, are excluded from the feed.';
$_['help_max_products']             = 'Hard cap on the number of items written to the feed. 0 means no limit. Products are read from the database in batches of 250 either way.';

$_['button_copy']                   = 'Copy';
$_['button_clear_cache']            = 'Clear Cache';
$_['button_regenerate_token']       = 'Regenerate Token';

$_['error_permission']              = 'Warning: You do not have permission to modify the Akakçe feed!';
$_['error_currency']                = 'Select a currency that exists in your store!';
$_['error_token']                   = 'The feed token must be 16 to 64 letters or digits!';
$_['error_cargo_days']              = 'Shipping days must be between 0 and 90!';
