<?php
namespace Opencart\Admin\Controller\Extension\NkXmlAkakce\Feed;

class Akakce extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/nk_xml_akakce/feed/akakce');

        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $data = [];

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_xml_akakce/feed/akakce', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/nk_xml_akakce/feed/akakce.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['clear_cache'] = $this->url->link('extension/nk_xml_akakce/feed/akakce.clearCache', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed');

        $this->load->model('setting/setting');
        $setting_info = $this->model_setting_setting->getSetting('feed_akakce', $store_id);

        $defaults = $this->getDefaults($store_id);

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($setting_info[$key]) && $setting_info[$key] !== '') {
                $data[$key] = $setting_info[$key];
            } else {
                $data[$key] = $default;
            }
        }

        // A feed without a token would expose the whole catalogue to anyone who
        // guesses the route, so one is minted on first view.
        if (trim((string)$data['feed_akakce_token']) === '' && $this->user->hasPermission('modify', 'extension/nk_xml_akakce/feed/akakce')) {
            $data['feed_akakce_token'] = oc_token(32);

            $setting_info['feed_akakce_token'] = $data['feed_akakce_token'];

            $this->model_setting_setting->editSetting('feed_akakce', $setting_info, $store_id);
        }

        if (!is_array($data['feed_akakce_excluded_categories'])) {
            $data['feed_akakce_excluded_categories'] = $data['feed_akakce_excluded_categories'] !== '' ? explode(',', (string)$data['feed_akakce_excluded_categories']) : [];
        }

        $data['feed_akakce_excluded_categories'] = array_map('intval', $data['feed_akakce_excluded_categories']);

        $data['feed_url'] = html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8') . 'index.php?route=extension/nk_xml_akakce/feed/akakce&token=' . rawurlencode((string)$data['feed_akakce_token']);

        $this->load->model('setting/store');
        $data['stores'] = [
            [
                'store_id' => 0,
                'name'     => $this->language->get('text_default_store')
            ]
        ];

        foreach ($this->model_setting_store->getStores() as $store) {
            $data['stores'][] = [
                'store_id' => (int)$store['store_id'],
                'name'     => $store['name']
            ];
        }

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $this->load->model('localisation/currency');
        $data['currencies'] = array_values(array_filter(
            $this->model_localisation_currency->getCurrencies(),
            static function (array $currency): bool {
                return !isset($currency['status']) || (int)$currency['status'] === 1;
            }
        ));

        $this->load->model('catalog/attribute');
        $data['attributes'] = $this->model_catalog_attribute->getAttributes();

        // The admin category model already returns the full "Parent > Child" path in `name`.
        $this->load->model('catalog/category');
        $data['categories'] = $this->model_catalog_category->getCategories(['sort' => 'name']);

        $cache_file = $this->cacheFile($store_id);

        if (is_file($cache_file)) {
            $data['last_generated'] = date('Y-m-d H:i:s', filemtime($cache_file));
        } else {
            $data['last_generated'] = $this->language->get('text_not_generated');
        }

        $language_keys = [
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'text_default_store',
            'text_feed_url',
            'text_feed_status',
            'text_last_generated',
            'text_not_generated',
            'text_field_notice',
            'entry_status',
            'entry_store',
            'entry_currency',
            'entry_language',
            'entry_include_out_of_stock',
            'entry_include_tax',
            'entry_brand_attribute',
            'entry_cargo_days',
            'entry_max_products',
            'entry_cache_hours',
            'entry_excluded_categories',
            'entry_token',
            'help_brand_attribute',
            'help_cargo_days',
            'help_currency',
            'help_excluded_categories',
            'help_feed_url',
            'help_include_tax',
            'help_max_products',
            'help_token',
            'button_save',
            'button_back',
            'button_copy',
            'button_clear_cache',
            'button_regenerate_token'
        ];

        foreach ($language_keys as $language_key) {
            $data[$language_key] = $this->language->get($language_key);
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_xml_akakce/feed/akakce', $data));
    }

    public function save(): void {
        $this->load->language('extension/nk_xml_akakce/feed/akakce');

        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_xml_akakce/feed/akakce')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $post = $this->request->post;

            // Only the known keys are stored, so nothing else can be written
            // into the feed_akakce setting group.
            $save = [];

            $save['feed_akakce_status'] = !empty($post['feed_akakce_status']) ? '1' : '0';
            $save['feed_akakce_store_id'] = isset($post['feed_akakce_store_id']) ? (string)(int)$post['feed_akakce_store_id'] : '0';
            $save['feed_akakce_include_out_of_stock'] = !empty($post['feed_akakce_include_out_of_stock']) ? '1' : '0';
            $save['feed_akakce_include_tax'] = !empty($post['feed_akakce_include_tax']) ? '1' : '0';
            $save['feed_akakce_brand_attribute_id'] = isset($post['feed_akakce_brand_attribute_id']) ? (string)max(0, (int)$post['feed_akakce_brand_attribute_id']) : '0';
            $save['feed_akakce_max_products'] = (string)max(0, (int)($post['feed_akakce_max_products'] ?? 0));
            $save['feed_akakce_cache_hours'] = in_array((string)($post['feed_akakce_cache_hours'] ?? '6'), ['1', '6', '12', '24'], true) ? (string)$post['feed_akakce_cache_hours'] : '6';

            $cargo_days = (int)($post['feed_akakce_cargo_days'] ?? 0);

            if ($cargo_days < 0 || $cargo_days > 90) {
                $json['error']['cargo_days'] = $this->language->get('error_cargo_days');
            }

            $save['feed_akakce_cargo_days'] = (string)$cargo_days;

            $this->load->model('localisation/language');
            $language_id = isset($post['feed_akakce_language_id']) ? (int)$post['feed_akakce_language_id'] : 0;

            if (!$language_id || !$this->model_localisation_language->getLanguage($language_id)) {
                $language_id = (int)$this->config->get('config_language_id');
            }

            $save['feed_akakce_language_id'] = (string)$language_id;

            $currency_code = strtoupper(trim((string)($post['feed_akakce_currency_code'] ?? '')));

            $this->load->model('localisation/currency');

            if ($currency_code === '' || !$this->model_localisation_currency->getCurrencyByCode($currency_code)) {
                $json['error']['currency_code'] = $this->language->get('error_currency');
            }

            $save['feed_akakce_currency_code'] = $currency_code;

            $token = trim((string)($post['feed_akakce_token'] ?? ''));

            if ($token === '' || !preg_match('/^[A-Za-z0-9]{16,64}$/', $token)) {
                $json['error']['token'] = $this->language->get('error_token');
            }

            $save['feed_akakce_token'] = $token;

            $save['feed_akakce_excluded_categories'] = [];

            if (isset($post['feed_akakce_excluded_categories']) && is_array($post['feed_akakce_excluded_categories'])) {
                foreach ($post['feed_akakce_excluded_categories'] as $category_id) {
                    $category_id = (int)$category_id;

                    if ($category_id > 0 && !in_array($category_id, $save['feed_akakce_excluded_categories'], true)) {
                        $save['feed_akakce_excluded_categories'][] = $category_id;
                    }
                }
            }

            if (!$json) {
                $this->load->model('setting/setting');
                $this->model_setting_setting->editSetting('feed_akakce', $save, $store_id);

                // Settings changed, so the cached feed is stale.
                $this->deleteCache($store_id);

                $json['success'] = $this->language->get('text_success');
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function clearCache(): void {
        $this->load->language('extension/nk_xml_akakce/feed/akakce');

        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_xml_akakce/feed/akakce')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $this->deleteCache($store_id);

            $json['success'] = $this->language->get('text_cache_cleared');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $setting_info = $this->model_setting_setting->getSetting('feed_akakce');

        $defaults = $this->getDefaults(0);

        // A re-install keeps whatever was configured before.
        foreach ($defaults as $key => $value) {
            if (isset($setting_info[$key]) && $setting_info[$key] !== '') {
                $defaults[$key] = $setting_info[$key];
            }
        }

        $this->model_setting_setting->editSetting('feed_akakce', $defaults);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('feed_akakce');

        foreach ((array)glob(DIR_CACHE . 'nk_feed_akakce_*.xml') as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function getDefaults(int $store_id): array {
        return [
            'feed_akakce_status'               => '0',
            'feed_akakce_token'                => oc_token(32),
            'feed_akakce_store_id'             => (string)$store_id,
            'feed_akakce_currency_code'        => (string)$this->config->get('config_currency'),
            'feed_akakce_language_id'          => (string)$this->config->get('config_language_id'),
            'feed_akakce_include_out_of_stock' => '0',
            'feed_akakce_include_tax'          => '1',
            'feed_akakce_brand_attribute_id'   => '0',
            'feed_akakce_cargo_days'           => '2',
            'feed_akakce_max_products'         => '0',
            'feed_akakce_cache_hours'          => '6',
            'feed_akakce_excluded_categories'  => []
        ];
    }

    private function cacheFile(int $store_id): string {
        return DIR_CACHE . 'nk_feed_akakce_' . $store_id . '.xml';
    }

    private function deleteCache(int $store_id): void {
        $cache_file = $this->cacheFile($store_id);

        if (is_file($cache_file)) {
            unlink($cache_file);
        }
    }
}
