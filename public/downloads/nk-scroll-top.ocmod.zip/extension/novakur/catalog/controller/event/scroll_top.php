<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

/**
 * NovaKur Scroll To Top — storefront hooks.
 *
 * assets() catalog/controller/common/header/before → register CSS/JS
 * render() catalog/view/common/footer/after        → inject the button markup
 *
 * Both hooks fail open: on unexpected input the storefront output is returned
 * untouched.
 */
class ScrollTop extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/novakur/catalog/view/assets/css/scroll_top.css';
    private const JS  = 'extension/novakur/catalog/view/assets/js/scroll_top.js';

    /**
     * The footer partial is rendered once per page, but a theme is free to
     * render it again (print views, AJAX fragments). Only the first one gets
     * the button so we never emit duplicate ids.
     */
    private static bool $rendered = false;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!(int)$this->config->get('module_scroll_top_status')) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function render(string &$route, array &$data, mixed &$output): void {
        if (!(int)$this->config->get('module_scroll_top_status')) {
            return;
        }

        if (self::$rendered || !is_string($output) || $output === '') {
            return;
        }

        self::$rendered = true;

        $this->load->language('extension/novakur/module/scroll_top');

        $html = $this->load->view('extension/novakur/module/scroll_top', [
            'text_scroll_top' => $this->language->get('text_scroll_top'),
            'position'        => $this->position(),
            'icon'            => $this->icon(),
            'show_progress'   => (bool)$this->config->get('module_scroll_top_show_progress'),
            'bg_color'        => $this->color('module_scroll_top_bg_color', '#2563EB'),
            'icon_color'      => $this->color('module_scroll_top_icon_color', '#FFFFFF'),
            'size'            => $this->number('module_scroll_top_size', 52, 32, 96),
            'show_after_px'   => $this->number('module_scroll_top_show_after_px', 300, 0, 5000),
            'offset_bottom'   => $this->number('module_scroll_top_offset_bottom', 24, 0, 400)
        ]);

        if ($html === '') {
            return;
        }

        // The button is absolutely positioned, so it only has to live somewhere
        // inside <body>. Prefer just before </footer>, fall back to appending.
        $position = strripos($output, '</footer>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }
    }

    private function position(): string {
        $position = (string)$this->config->get('module_scroll_top_position');

        return in_array($position, ['bottom-right', 'bottom-left'], true) ? $position : 'bottom-right';
    }

    private function icon(): string {
        $icon = (string)$this->config->get('module_scroll_top_icon');

        return in_array($icon, ['arrow', 'chevron', 'caret'], true) ? $icon : 'arrow';
    }

    /**
     * Settings are written by a validating save(), but a hand-edited
     * `oc_setting` row must never be able to break out of a style attribute.
     */
    private function color(string $key, string $fallback): string {
        $color = strtoupper(trim((string)$this->config->get($key)));

        return preg_match('/^#[0-9A-F]{6}$/', $color) ? $color : $fallback;
    }

    private function number(string $key, int $fallback, int $min, int $max): int {
        $value = $this->config->get($key);

        if ($value === null || $value === '' || !is_numeric($value)) {
            return $fallback;
        }

        $number = (int)$value;

        return ($number >= $min && $number <= $max) ? $number : $fallback;
    }
}
