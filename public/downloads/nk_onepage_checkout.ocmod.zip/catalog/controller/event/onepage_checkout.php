<?php
namespace Opencart\Catalog\Controller\Extension\NkOnepageCheckout\Event;

/**
 * NovaKur One-Page Checkout
 *
 * Re-skins the stock OpenCart 4.1 checkout into a single accordion page. The individual
 * checkout sections are still rendered by OpenCart's own controllers (checkout/register,
 * checkout/payment_address, checkout/shipping_address, checkout/shipping_method,
 * checkout/payment_method, checkout/confirm) and still post to OpenCart's own AJAX
 * endpoints, so every payment / shipping extension keeps working untouched.
 */
class OnepageCheckout extends \Opencart\System\Engine\Controller {
    /**
     * catalog/controller/checkout/checkout/before
     *
     * Runs before checkout/checkout builds its output, which is the last point at which
     * the header and footer can still pick up our stylesheet and script.
     *
     * @param string            $route
     * @param array<int, mixed> $args
     *
     * @return void
     */
    public function before(string &$route, array &$args): void {
        if (!$this->config->get('module_onepage_checkout_status')) {
            return;
        }

        $this->document->addStyle('extension/nk_onepage_checkout/catalog/view/assets/css/onepage_checkout.css');
        // Footer position: our script must run after bootstrap.bundle.js and after the
        // inline section scripts that OpenCart prints inside the page body.
        $this->document->addScript('extension/nk_onepage_checkout/catalog/view/assets/js/onepage_checkout.js', 'footer');
    }

    /**
     * catalog/view/checkout/checkout/before
     *
     * Swaps the checkout template for the one-page accordion and injects the extra data
     * the accordion needs. The stock section markup arrives in $data untouched.
     *
     * @param string               $route
     * @param array<string, mixed> $data
     * @param string               $code
     * @param mixed                $output
     *
     * @return void
     */
    public function view(string &$route, array &$data, string &$code = '', mixed &$output = null): void {
        if (!$this->config->get('module_onepage_checkout_status')) {
            return;
        }

        $this->load->language('extension/nk_onepage_checkout/checkout/onepage');

        $language = (string)$this->config->get('config_language');

        foreach (['nk_step_cart', 'nk_step_customer', 'nk_step_payment_address', 'nk_step_shipping_address', 'nk_step_shipping_method', 'nk_step_payment_method', 'nk_step_confirm', 'nk_text_logged_in_as', 'nk_text_not_you', 'nk_text_guest_badge', 'nk_text_confirm_hint'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['nk_guest_highlight'] = (bool)$this->config->get('module_onepage_checkout_guest_highlight');
        $data['nk_show_comments'] = (bool)$this->config->get('module_onepage_checkout_show_comments');

        // Endpoints the accordion script talks to. All of them are stock OpenCart routes
        // except the summary partial, which belongs to this module.
        $data['nk_summary_url'] = $this->url->link('extension/nk_onepage_checkout/module/onepage_checkout.summary', 'language=' . $language);
        $data['nk_logout_url'] = $this->url->link('account/logout', 'language=' . $language, true);

        // Customer
        $data['nk_customer_name'] = trim(html_entity_decode($this->customer->getFirstName() . ' ' . $this->customer->getLastName(), ENT_QUOTES, 'UTF-8'));
        $data['nk_customer_email'] = html_entity_decode($this->customer->getEmail(), ENT_QUOTES, 'UTF-8');

        // Which steps the session already considers finished, so the accordion can open
        // the first outstanding one instead of always starting at the top.
        $data['nk_done_customer'] = isset($this->session->data['customer']);
        $data['nk_done_payment_address'] = isset($this->session->data['payment_address']);
        $data['nk_done_shipping_address'] = isset($this->session->data['shipping_address']['address_id']);
        $data['nk_done_shipping_method'] = isset($this->session->data['shipping_method']);
        $data['nk_done_payment_method'] = isset($this->session->data['payment_method']);

        // Cart summary partial (module controller so the script can reload it over AJAX).
        $data['nk_summary'] = $this->load->controller('extension/nk_onepage_checkout/module/onepage_checkout');

        $route = 'extension/nk_onepage_checkout/checkout/onepage';
    }
}
