<?php
// Every key is prefixed nk_ so it can never collide with the checkout/* language keys
// that OpenCart dumps into the same template scope.

// Step titles
$_['nk_step_cart'] = 'Your cart';
$_['nk_step_customer'] = 'Your details';
$_['nk_step_payment_address'] = 'Billing address';
$_['nk_step_shipping_address'] = 'Delivery address';
$_['nk_step_shipping_method'] = 'Delivery method';
$_['nk_step_payment_method'] = 'Payment method';
$_['nk_step_confirm'] = 'Review &amp; confirm';

// Text
$_['nk_text_items'] = '%s item(s) in your cart';
$_['nk_text_edit_cart'] = 'Edit cart';
$_['nk_text_empty'] = 'Your cart is empty.';
$_['nk_text_logged_in_as'] = 'You are signed in as';
$_['nk_text_not_you'] = 'Not you? Sign out';
$_['nk_text_guest_badge'] = 'Fastest';
$_['nk_text_confirm_hint'] = 'Check your order below, then press the confirm button from your chosen payment provider to place it.';
$_['nk_text_model'] = 'Model';
