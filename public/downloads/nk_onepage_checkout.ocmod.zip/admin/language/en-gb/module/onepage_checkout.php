<?php
// Heading
$_['heading_title'] = 'NovaKur One-Page Checkout';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified NovaKur One-Page Checkout settings!';
$_['text_edit'] = 'Edit NovaKur One-Page Checkout';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_section_order'] = 'Section order';
$_['text_section_cart'] = 'Cart summary';
$_['text_section_customer'] = 'Customer details (guest or login)';
$_['text_section_shipping_address'] = 'Shipping address';
$_['text_section_shipping_method'] = 'Delivery method';
$_['text_section_payment_method'] = 'Payment method';
$_['text_section_confirm'] = 'Confirm order';
$_['text_payment_note'] = 'The final confirm step is rendered by whichever payment extension the shopper selects. One-Page Checkout does not replace payment logic — it calls OpenCart\'s own <code>checkout/confirm.confirm</code> endpoint and displays the result. Always place one live test order per enabled payment method after switching this module on.';

// Entry
$_['entry_status'] = 'Status';
$_['entry_guest_highlight'] = 'Highlight guest checkout';
$_['entry_show_comments'] = 'Show order comments';
$_['entry_sections'] = 'Sections';

// Help
$_['help_guest_highlight'] = 'Pre-selects the "Guest Checkout" option and gives it a recommended badge. Only takes effect when guest checkout is enabled under System &gt; Settings &gt; Option and the cart has no downloadable or subscription products.';
$_['help_show_comments'] = 'Shows the "Add comments about your order" textarea inside the payment step. Turn off for a shorter form.';
$_['help_sections'] = 'The section order is fixed and cannot be reordered. Sections that do not apply to the cart (for example the shipping steps for a downloads-only order) are hidden automatically.';

// Button
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';
