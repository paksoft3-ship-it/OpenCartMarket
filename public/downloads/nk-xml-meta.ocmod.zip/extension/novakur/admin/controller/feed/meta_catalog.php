<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Feed;

class MetaCatalog extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/novakur/feed/meta_catalog');

        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $data = [];

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/novakur/feed/meta_catalog', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/novakur/feed/meta_catalog.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['clear_cache'] = $this->url->link('extension/novakur/feed/meta_catalog.clearCache', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed');

        $data['commerce_manager_url'] = 'https://business.facebook.com/commerce/';

        $this->load->model('setting/setting');
        $setting_info = $this->model_setting_setting->getSetting('feed_meta_catalog', $store_id);

        $defaults = $this->getDefaults($store_id);

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($setting_info[$key])) {
                $data[$key] = $setting_info[$key];
            } else {
                $data[$key] = $default;
            }
        }

        // A feed without a token would expose the whole catalogue to anyone who guesses the route.
        if (trim((string)$data['feed_meta_catalog_token']) === '' && $this->user->hasPermission('modify', 'extension/novakur/feed/meta_catalog')) {
            $data['feed_meta_catalog_token'] = oc_token(32);

            $setting_info['feed_meta_catalog_token'] = $data['feed_meta_catalog_token'];

            $this->model_setting_setting->editSetting('feed_meta_catalog', $setting_info, $store_id);
        }

        if (!is_array($data['feed_meta_catalog_excluded_categories'])) {
            $data['feed_meta_catalog_excluded_categories'] = $data['feed_meta_catalog_excluded_categories'] !== '' ? explode(',', (string)$data['feed_meta_catalog_excluded_categories']) : [];
        }

        $data['feed_meta_catalog_excluded_categories'] = array_map('intval', $data['feed_meta_catalog_excluded_categories']);

        $data['feed_url'] = html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8') . 'index.php?route=extension/novakur/feed/meta_catalog&token=' . rawurlencode((string)$data['feed_meta_catalog_token']);

        $this->load->model('setting/store');
        $data['stores'] = [
            [
                'store_id' => 0,
                'name'     => $this->language->get('text_default_store')
            ]
        ];

        foreach ($this->model_setting_store->getStores() as $store) {
            $data['stores'][] = [
                'store_id' => (int)$store['store_id'],
                'name'     => $store['name']
            ];
        }

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $this->load->model('localisation/currency');
        $data['currencies'] = array_values(array_filter(
            $this->model_localisation_currency->getCurrencies(),
            static function (array $currency): bool {
                return !isset($currency['status']) || (int)$currency['status'] === 1;
            }
        ));

        $this->load->model('catalog/attribute');
        $data['attributes'] = $this->model_catalog_attribute->getAttributes();

        // The admin category model already returns the full "Parent > Child" path in `name`.
        $this->load->model('catalog/category');
        $data['categories'] = $this->model_catalog_category->getCategories(['sort' => 'name']);

        $cache_file = DIR_CACHE . 'meta_catalog.xml';

        if (is_file($cache_file)) {
            $data['last_generated'] = date('Y-m-d H:i:s', filemtime($cache_file));
        } else {
            $data['last_generated'] = $this->language->get('text_not_generated');
        }

        $language_keys = [
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'text_new',
            'text_used',
            'text_refurbished',
            'text_default_store',
            'text_feed_url',
            'text_feed_status',
            'text_last_generated',
            'text_not_generated',
            'entry_status',
            'entry_store',
            'entry_currency',
            'entry_language',
            'entry_include_out_of_stock',
            'entry_include_tax',
            'entry_brand_attribute',
            'entry_gtin_attribute',
            'entry_mpn_attribute',
            'entry_condition',
            'entry_google_product_category',
            'entry_max_products',
            'entry_cache_hours',
            'entry_excluded_categories',
            'entry_token',
            'help_excluded_categories',
            'help_feed_url',
            'help_include_tax',
            'help_google_product_category',
            'help_max_products',
            'help_token',
            'button_save',
            'button_back',
            'button_copy',
            'button_clear_cache',
            'button_regenerate_token',
            'button_open_commerce_manager'
        ];

        foreach ($language_keys as $language_key) {
            $data[$language_key] = $this->language->get($language_key);
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/feed/meta_catalog', $data));
    }

    public function save(): void {
        $this->load->language('extension/novakur/feed/meta_catalog');

        $json = [];
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/novakur/feed/meta_catalog')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $post = $this->request->post;
            $save = [];

            $save['feed_meta_catalog_status'] = isset($post['feed_meta_catalog_status']) ? (string)(int)(bool)$post['feed_meta_catalog_status'] : '0';
            $save['feed_meta_catalog_store_id'] = isset($post['feed_meta_catalog_store_id']) ? (string)(int)$post['feed_meta_catalog_store_id'] : '0';
            $save['feed_meta_catalog_language_id'] = isset($post['feed_meta_catalog_language_id']) ? (string)(int)$post['feed_meta_catalog_language_id'] : (string)$this->config->get('config_language_id');
            $save['feed_meta_catalog_include_out_of_stock'] = isset($post['feed_meta_catalog_include_out_of_stock']) ? (string)(int)(bool)$post['feed_meta_catalog_include_out_of_stock'] : '0';
            $save['feed_meta_catalog_include_tax'] = isset($post['feed_meta_catalog_include_tax']) ? (string)(int)(bool)$post['feed_meta_catalog_include_tax'] : '0';
            $save['feed_meta_catalog_brand_attribute_id'] = isset($post['feed_meta_catalog_brand_attribute_id']) ? (string)(int)$post['feed_meta_catalog_brand_attribute_id'] : '0';
            $save['feed_meta_catalog_gtin_attribute_id'] = isset($post['feed_meta_catalog_gtin_attribute_id']) ? (string)(int)$post['feed_meta_catalog_gtin_attribute_id'] : '0';
            $save['feed_meta_catalog_mpn_attribute_id'] = isset($post['feed_meta_catalog_mpn_attribute_id']) ? (string)(int)$post['feed_meta_catalog_mpn_attribute_id'] : '0';
            $save['feed_meta_catalog_condition'] = in_array($post['feed_meta_catalog_condition'] ?? '', ['new', 'used', 'refurbished'], true) ? (string)$post['feed_meta_catalog_condition'] : 'new';
            $save['feed_meta_catalog_cache_hours'] = in_array((string)($post['feed_meta_catalog_cache_hours'] ?? '6'), ['1', '6', '12', '24'], true) ? (string)$post['feed_meta_catalog_cache_hours'] : '6';
            $save['feed_meta_catalog_max_products'] = (string)max(0, (int)($post['feed_meta_catalog_max_products'] ?? 0));
            $save['feed_meta_catalog_google_product_category'] = mb_substr(trim((string)($post['feed_meta_catalog_google_product_category'] ?? '')), 0, 255);

            $currency_code = strtoupper(trim((string)($post['feed_meta_catalog_currency_code'] ?? '')));

            $this->load->model('localisation/currency');

            if ($currency_code === '' || !$this->model_localisation_currency->getCurrencyByCode($currency_code)) {
                $json['error']['currency_code'] = $this->language->get('error_currency');
            }

            $save['feed_meta_catalog_currency_code'] = $currency_code;

            $token = trim((string)($post['feed_meta_catalog_token'] ?? ''));

            if ($token === '' || !preg_match('/^[A-Za-z0-9]{16,64}$/', $token)) {
                $json['error']['token'] = $this->language->get('error_token');
            }

            $save['feed_meta_catalog_token'] = $token;

            if (isset($post['feed_meta_catalog_excluded_categories']) && is_array($post['feed_meta_catalog_excluded_categories'])) {
                $save['feed_meta_catalog_excluded_categories'] = array_values(array_filter(array_map('intval', $post['feed_meta_catalog_excluded_categories'])));
            } else {
                $save['feed_meta_catalog_excluded_categories'] = [];
            }

            if (!$json) {
                $this->load->model('setting/setting');
                $this->model_setting_setting->editSetting('feed_meta_catalog', $save, $store_id);

                $json['success'] = $this->language->get('text_success');
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function clearCache(): void {
        $this->load->language('extension/novakur/feed/meta_catalog');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/novakur/feed/meta_catalog')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $cache_file = DIR_CACHE . 'meta_catalog.xml';

            if (is_file($cache_file)) {
                unlink($cache_file);
            }

            $json['success'] = $this->language->get('text_cache_cleared');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $this->model_setting_setting->editSetting('feed_meta_catalog', $this->getDefaults(0));
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('feed_meta_catalog');
    }

    private function getDefaults(int $store_id): array {
        return [
            'feed_meta_catalog_status'                  => '0',
            'feed_meta_catalog_token'                   => oc_token(32),
            'feed_meta_catalog_store_id'                => (string)$store_id,
            'feed_meta_catalog_currency_code'           => (string)$this->config->get('config_currency'),
            'feed_meta_catalog_language_id'             => (string)$this->config->get('config_language_id'),
            'feed_meta_catalog_include_out_of_stock'    => '0',
            'feed_meta_catalog_include_tax'             => '1',
            'feed_meta_catalog_brand_attribute_id'      => '0',
            'feed_meta_catalog_gtin_attribute_id'       => '0',
            'feed_meta_catalog_mpn_attribute_id'        => '0',
            'feed_meta_catalog_condition'               => 'new',
            'feed_meta_catalog_google_product_category' => '',
            'feed_meta_catalog_max_products'            => '0',
            'feed_meta_catalog_cache_hours'             => '6',
            'feed_meta_catalog_excluded_categories'     => []
        ];
    }
}
