<?php
$_['heading_title']                  = 'NovaKur Meta Catalog Feed';

$_['text_extension']                 = 'Extensions';
$_['text_success']                   = 'Success: You have modified Meta catalog feed settings!';
$_['text_edit']                      = 'Edit Meta Catalog Feed';
$_['text_enabled']                   = 'Enabled';
$_['text_disabled']                  = 'Disabled';
$_['text_new']                       = 'New';
$_['text_used']                      = 'Used';
$_['text_refurbished']               = 'Refurbished';
$_['text_default_store']             = 'Default Store';
$_['text_cache_cleared']             = 'Feed cache has been cleared.';
$_['text_feed_url']                  = 'Feed URL';
$_['text_feed_status']               = 'Feed Status';
$_['text_last_generated']            = 'Last Generated';
$_['text_not_generated']             = 'Not generated yet';

$_['entry_status']                   = 'Status';
$_['entry_store']                    = 'Store';
$_['entry_currency']                 = 'Currency';
$_['entry_language']                 = 'Language';
$_['entry_include_out_of_stock']     = 'Include Out Of Stock';
$_['entry_include_tax']              = 'Prices Include Tax';
$_['entry_brand_attribute']          = 'Brand Attribute';
$_['entry_gtin_attribute']           = 'GTIN Attribute';
$_['entry_mpn_attribute']            = 'MPN Attribute';
$_['entry_condition']                = 'Condition';
$_['entry_google_product_category']  = 'Google Product Category';
$_['entry_max_products']             = 'Maximum Products';
$_['entry_cache_hours']              = 'Cache Duration (Hours)';
$_['entry_excluded_categories']      = 'Excluded Categories';
$_['entry_token']                    = 'Feed Token';

$_['help_feed_url']                  = 'Add this URL as a scheduled data feed in Meta Commerce Manager. It contains the feed token, so treat it as a secret.';
$_['help_excluded_categories']       = 'Products in the selected categories will be excluded from the feed.';
$_['help_include_tax']               = 'Meta expects prices that include tax. Leave enabled unless your store prices are already tax inclusive.';
$_['help_google_product_category']   = 'Optional. A single Google product taxonomy value applied to every item, for example "Health &amp; Beauty &gt; Health Care". Leave blank to omit the field.';
$_['help_max_products']              = 'Hard cap on the number of items written to the feed. 0 means no limit. Products are read from the database in batches of 250 either way.';
$_['help_token']                     = 'Required. The feed URL only answers when this token is supplied, otherwise the route returns 404.';

$_['button_copy']                    = 'Copy';
$_['button_clear_cache']             = 'Clear Cache';
$_['button_regenerate_token']        = 'Regenerate Token';
$_['button_open_commerce_manager']    = 'Open Commerce Manager';

$_['error_permission']               = 'Warning: You do not have permission to modify Meta catalog feed!';
$_['error_currency']                 = 'Select a currency that exists in your store!';
$_['error_token']                    = 'The feed token must be 16 to 64 letters or digits!';
