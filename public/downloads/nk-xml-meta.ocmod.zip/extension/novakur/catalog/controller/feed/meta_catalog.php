<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Feed;

class MetaCatalog extends \Opencart\System\Engine\Controller {
    private const CHUNK_SIZE = 250;

    private array $product_columns = [];

    public function index(): void {
        if (!(int)$this->config->get('feed_meta_catalog_status')) {
            $this->notFound();

            return;
        }

        $token = (string)$this->config->get('feed_meta_catalog_token');
        $supplied_token = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied_token)) {
            $this->notFound();

            return;
        }

        $cache_file = DIR_CACHE . 'meta_catalog.xml';
        $cache_hours = (int)$this->config->get('feed_meta_catalog_cache_hours');

        if (!in_array($cache_hours, [1, 6, 12, 24], true)) {
            $cache_hours = 6;
        }

        if (is_file($cache_file) && (time() - filemtime($cache_file)) < ($cache_hours * 3600)) {
            $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
            $this->response->setOutput((string)file_get_contents($cache_file));

            return;
        }

        $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
        $this->response->setOutput($this->generate($cache_file));
    }

    private function notFound(): void {
        $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');
        $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
        $this->response->setOutput('Not Found');
    }

    private function generate(string $cache_file): string {
        $currency_code = (string)$this->config->get('feed_meta_catalog_currency_code');

        if ($currency_code === '' || !$this->currency->has($currency_code)) {
            $currency_code = (string)$this->config->get('config_currency');
        }

        $base_currency = (string)$this->config->get('config_currency');

        $language_id = (int)$this->config->get('feed_meta_catalog_language_id');

        if (!$language_id) {
            $language_id = (int)$this->config->get('config_language_id');
        }

        $store_id = $this->config->get('feed_meta_catalog_store_id');
        $store_id = ($store_id === null || $store_id === '') ? (int)$this->config->get('config_store_id') : (int)$store_id;

        $include_out_of_stock = (int)$this->config->get('feed_meta_catalog_include_out_of_stock');
        $include_tax = $this->config->get('feed_meta_catalog_include_tax');
        $include_tax = ($include_tax === null) ? true : (bool)(int)$include_tax;

        $condition = (string)$this->config->get('feed_meta_catalog_condition');

        if (!in_array($condition, ['new', 'used', 'refurbished'], true)) {
            $condition = 'new';
        }

        $google_product_category = trim((string)$this->config->get('feed_meta_catalog_google_product_category'));

        $max_products = (int)$this->config->get('feed_meta_catalog_max_products');

        if ($max_products < 0) {
            $max_products = 0;
        }

        $brand_attribute_id = (int)$this->config->get('feed_meta_catalog_brand_attribute_id');
        $gtin_attribute_id = (int)$this->config->get('feed_meta_catalog_gtin_attribute_id');
        $mpn_attribute_id = (int)$this->config->get('feed_meta_catalog_mpn_attribute_id');

        $excluded_categories = $this->config->get('feed_meta_catalog_excluded_categories');

        if (!is_array($excluded_categories)) {
            $excluded_categories = ($excluded_categories !== null && $excluded_categories !== '') ? explode(',', (string)$excluded_categories) : [];
        }

        $excluded_categories = array_values(array_filter(array_map('intval', $excluded_categories)));

        $store_url = $this->getStoreUrl($store_id);
        $local_store = ($store_id === (int)$this->config->get('config_store_id'));

        $store_name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
        $store_description = html_entity_decode((string)$this->config->get('config_meta_description'), ENT_QUOTES, 'UTF-8');

        $tmp_file = $cache_file . '.' . getmypid() . '.tmp';
        $handle = @fopen($tmp_file, 'w');
        $cacheable = ($handle !== false);

        if (!$cacheable) {
            $handle = fopen('php://temp/maxmemory:' . (2 * 1024 * 1024), 'w+');
        }

        fwrite($handle, '<?xml version="1.0" encoding="UTF-8"?>' . "\n");
        fwrite($handle, '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">' . "\n");
        fwrite($handle, '<channel>' . "\n");
        fwrite($handle, '<title>' . $this->xmlEscape($store_name) . '</title>' . "\n");
        fwrite($handle, '<link>' . $this->xmlEscape($store_url) . '</link>' . "\n");
        fwrite($handle, '<description>' . $this->xmlEscape($store_description) . '</description>' . "\n");

        $start = 0;
        $written = 0;

        while (true) {
            $limit = self::CHUNK_SIZE;

            if ($max_products && ($written + $limit) > $max_products) {
                $limit = $max_products - $written;
            }

            if ($limit < 1) {
                break;
            }

            $products = $this->getProducts($language_id, $store_id, $include_out_of_stock, $excluded_categories, $start, $limit);

            if (!$products) {
                break;
            }

            $product_ids = [];

            foreach ($products as $product) {
                $product_ids[] = (int)$product['product_id'];
            }

            $identifiers = $this->getIdentifiers($product_ids);
            $extra_images = $this->getImages($product_ids);
            $attributes = $this->getAttributes($product_ids, $language_id, [$brand_attribute_id, $gtin_attribute_id, $mpn_attribute_id]);

            foreach ($products as $product) {
                $product_id = (int)$product['product_id'];
                $product_identifiers = $identifiers[$product_id] ?? [];
                $product_attributes = $attributes[$product_id] ?? [];

                $brand = '';

                if ($brand_attribute_id && isset($product_attributes[$brand_attribute_id])) {
                    $brand = trim($product_attributes[$brand_attribute_id]);
                }

                if ($brand === '') {
                    $brand = trim((string)($product['manufacturer'] ?? ''));
                }

                $gtin = '';

                if ($gtin_attribute_id && isset($product_attributes[$gtin_attribute_id])) {
                    $gtin = trim($product_attributes[$gtin_attribute_id]);
                }

                if ($gtin === '') {
                    $gtin = $this->firstIdentifier($product, $product_identifiers, ['EAN', 'UPC', 'JAN', 'ISBN']);
                }

                $mpn = '';

                if ($mpn_attribute_id && isset($product_attributes[$mpn_attribute_id])) {
                    $mpn = trim($product_attributes[$mpn_attribute_id]);
                }

                if ($mpn === '') {
                    $mpn = $this->firstIdentifier($product, $product_identifiers, ['MPN']);
                }

                if ($mpn === '') {
                    $mpn = trim((string)$product['model']);
                }

                $offer_id = $this->firstIdentifier($product, $product_identifiers, ['SKU']);

                if ($offer_id === '') {
                    $offer_id = (string)$product_id;
                }

                $tax_class_id = (int)$product['tax_class_id'];

                $price = $this->convertPrice((float)$product['price'], $tax_class_id, $include_tax, $base_currency, $currency_code);
                $price_text = $price . ' ' . $currency_code;

                $sale_price_text = '';

                if ($product['special'] !== null && (float)$product['special'] >= 0) {
                    $sale_price = $this->convertPrice((float)$product['special'], $tax_class_id, $include_tax, $base_currency, $currency_code);

                    if ((float)$sale_price < (float)$price) {
                        $sale_price_text = $sale_price . ' ' . $currency_code;
                    }
                }

                // Meta's catalog spec uses space separated availability values, unlike Google.
                $availability = (int)$product['quantity'] > 0 ? 'in stock' : 'out of stock';

                $title = trim(html_entity_decode((string)$product['name'], ENT_QUOTES, 'UTF-8'));
                $title = mb_substr(preg_replace('/\s+/', ' ', $title), 0, 150);

                $description = trim(strip_tags(html_entity_decode((string)$product['description'], ENT_QUOTES, 'UTF-8')));
                $description = mb_substr(trim(preg_replace('/\s+/', ' ', $description)), 0, 5000);

                if ($description === '') {
                    $description = $title;
                }

                $product_link = $this->getProductLink($product_id, $local_store, $store_url);
                $image_link = $product['image'] ? $store_url . '/image/' . $this->encodeImagePath((string)$product['image']) : '';

                $category_path = $this->getCategoryPath((int)$product['category_id'], $language_id);

                $item = [];
                $item[] = '<item>';
                $item[] = '<g:id>' . $this->xmlEscape($offer_id) . '</g:id>';
                $item[] = '<g:title>' . $this->cdata($title) . '</g:title>';
                $item[] = '<g:description>' . $this->cdata($description) . '</g:description>';
                $item[] = '<g:link>' . $this->xmlEscape($product_link) . '</g:link>';

                if ($image_link !== '') {
                    $item[] = '<g:image_link>' . $this->xmlEscape($image_link) . '</g:image_link>';
                }

                foreach (array_slice($extra_images[$product_id] ?? [], 0, 10) as $extra_image) {
                    $item[] = '<g:additional_image_link>' . $this->xmlEscape($store_url . '/image/' . $this->encodeImagePath($extra_image)) . '</g:additional_image_link>';
                }

                $item[] = '<g:price>' . $this->xmlEscape($price_text) . '</g:price>';

                if ($sale_price_text !== '') {
                    $item[] = '<g:sale_price>' . $this->xmlEscape($sale_price_text) . '</g:sale_price>';
                }

                $item[] = '<g:availability>' . $availability . '</g:availability>';
                $item[] = '<g:condition>' . $condition . '</g:condition>';

                if ($brand !== '') {
                    $item[] = '<g:brand>' . $this->cdata($brand) . '</g:brand>';
                }

                if ($gtin !== '') {
                    $item[] = '<g:gtin>' . $this->xmlEscape($gtin) . '</g:gtin>';
                }

                if ($mpn !== '') {
                    $item[] = '<g:mpn>' . $this->xmlEscape($mpn) . '</g:mpn>';
                }

                if ($category_path !== '') {
                    $item[] = '<g:product_type>' . $this->cdata($category_path) . '</g:product_type>';
                }

                if ($google_product_category !== '') {
                    $item[] = '<g:google_product_category>' . $this->cdata($google_product_category) . '</g:google_product_category>';
                }

                $item[] = '</item>';

                fwrite($handle, implode("\n", $item) . "\n");

                $written++;
            }

            if (count($products) < $limit) {
                break;
            }

            $start += $limit;
        }

        fwrite($handle, '</channel>' . "\n");
        fwrite($handle, '</rss>');

        if ($cacheable) {
            fclose($handle);

            if (!@rename($tmp_file, $cache_file)) {
                @unlink($tmp_file);
            }

            return is_file($cache_file) ? (string)file_get_contents($cache_file) : '';
        }

        rewind($handle);
        $output = (string)stream_get_contents($handle);
        fclose($handle);

        return $output;
    }

    private function getProducts(int $language_id, int $store_id, int $include_out_of_stock, array $excluded_categories, int $start, int $limit): array {
        $sql = "SELECT `p`.`product_id`, `p`.`model`, `p`.`price`, `p`.`quantity`, `p`.`image`, `p`.`tax_class_id`";

        foreach ($this->getLegacyIdentifierColumns() as $column) {
            $sql .= ", `p`.`" . $column . "`";
        }

        $sql .= ", `pd`.`name`, `pd`.`description`, `m`.`name` AS `manufacturer`";
        $sql .= ", (SELECT MIN(`p2c`.`category_id`) FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`product_id` = `p`.`product_id`) AS `category_id`";
        $sql .= ", (SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1) AS `special`";
        $sql .= " FROM `" . DB_PREFIX . "product` `p`";
        $sql .= " INNER JOIN `" . DB_PREFIX . "product_to_store` `p2s` ON (`p2s`.`product_id` = `p`.`product_id` AND `p2s`.`store_id` = '" . $store_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`pd`.`product_id` = `p`.`product_id` AND `pd`.`language_id` = '" . $language_id . "')";
        $sql .= " LEFT JOIN `" . DB_PREFIX . "manufacturer` `m` ON (`m`.`manufacturer_id` = `p`.`manufacturer_id`)";
        $sql .= " WHERE `p`.`status` = '1' AND `p`.`date_available` <= NOW()";

        if (!$include_out_of_stock) {
            $sql .= " AND `p`.`quantity` > 0";
        }

        if ($excluded_categories) {
            $sql .= " AND `p`.`product_id` NOT IN (SELECT `product_id` FROM `" . DB_PREFIX . "product_to_category` WHERE `category_id` IN (" . implode(',', $excluded_categories) . "))";
        }

        $sql .= " ORDER BY `p`.`product_id` ASC LIMIT " . $start . "," . $limit;

        return $this->db->query($sql)->rows;
    }

    /**
     * OpenCart 4.1 keeps SKU/UPC/EAN/JAN/ISBN/MPN in `product_code`, but stores upgraded from
     * 4.0 have the legacy `product` columns dropped while fresh 4.1 installs still have them.
     * Only select the ones that actually exist so the feed query cannot fatal.
     */
    private function getLegacyIdentifierColumns(): array {
        if (!$this->product_columns) {
            foreach ($this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product`")->rows as $row) {
                $this->product_columns[strtolower((string)$row['Field'])] = true;
            }
        }

        $columns = [];

        foreach (['sku', 'upc', 'ean', 'jan', 'isbn', 'mpn'] as $column) {
            if (isset($this->product_columns[$column])) {
                $columns[] = $column;
            }
        }

        return $columns;
    }

    private function getIdentifiers(array $product_ids): array {
        if (!$product_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `value` != ''");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][strtoupper((string)$row['code'])] = (string)$row['value'];
        }

        return $result;
    }

    /**
     * product_code rows win over the legacy product columns when both are present.
     */
    private function firstIdentifier(array $product, array $product_identifiers, array $codes): string {
        foreach ($codes as $code) {
            if (isset($product_identifiers[$code]) && trim($product_identifiers[$code]) !== '') {
                return trim($product_identifiers[$code]);
            }

            $column = strtolower($code);

            if (isset($product[$column]) && trim((string)$product[$column]) !== '') {
                return trim((string)$product[$column]);
            }
        }

        return '';
    }

    private function getImages(array $product_ids): array {
        if (!$product_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `image` FROM `" . DB_PREFIX . "product_image` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `image` != '' ORDER BY `product_id` ASC, `sort_order` ASC");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][] = (string)$row['image'];
        }

        return $result;
    }

    private function getAttributes(array $product_ids, int $language_id, array $attribute_ids): array {
        $attribute_ids = array_values(array_unique(array_filter(array_map('intval', $attribute_ids))));

        if (!$product_ids || !$attribute_ids) {
            return [];
        }

        $query = $this->db->query("SELECT `product_id`, `attribute_id`, `text` FROM `" . DB_PREFIX . "product_attribute` WHERE `product_id` IN (" . implode(',', array_map('intval', $product_ids)) . ") AND `language_id` = '" . $language_id . "' AND `attribute_id` IN (" . implode(',', $attribute_ids) . ")");

        $result = [];

        foreach ($query->rows as $row) {
            $result[(int)$row['product_id']][(int)$row['attribute_id']] = (string)$row['text'];
        }

        return $result;
    }

    private function getCategoryPath(int $category_id, int $language_id): string {
        static $cache = [];

        if ($category_id <= 0) {
            return '';
        }

        if (isset($cache[$category_id])) {
            return $cache[$category_id];
        }

        $query = $this->db->query("SELECT GROUP_CONCAT(`cd`.`name` ORDER BY `cp`.`level` SEPARATOR ' > ') AS `path` FROM `" . DB_PREFIX . "category_path` `cp` LEFT JOIN `" . DB_PREFIX . "category_description` `cd` ON (`cd`.`category_id` = `cp`.`path_id` AND `cd`.`language_id` = '" . $language_id . "') WHERE `cp`.`category_id` = '" . $category_id . "'");

        $path = $query->num_rows ? trim(html_entity_decode((string)$query->row['path'], ENT_QUOTES, 'UTF-8')) : '';

        $cache[$category_id] = $path;

        return $path;
    }

    private function getStoreUrl(int $store_id): string {
        if ($store_id) {
            $query = $this->db->query("SELECT `url` FROM `" . DB_PREFIX . "store` WHERE `store_id` = '" . $store_id . "'");

            if ($query->num_rows && $query->row['url']) {
                return rtrim(html_entity_decode((string)$query->row['url'], ENT_QUOTES, 'UTF-8'), '/');
            }
        } else {
            $query = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = 'config' AND `key` = 'config_url'");

            if ($query->num_rows && $query->row['value']) {
                return rtrim(html_entity_decode((string)$query->row['value'], ENT_QUOTES, 'UTF-8'), '/');
            }
        }

        return rtrim(html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8'), '/');
    }

    private function getProductLink(int $product_id, bool $local_store, string $store_url): string {
        if ($local_store) {
            return html_entity_decode($this->url->link('product/product', 'product_id=' . $product_id), ENT_QUOTES, 'UTF-8');
        }

        return $store_url . '/index.php?route=product/product&product_id=' . $product_id;
    }

    private function encodeImagePath(string $image): string {
        $parts = explode('/', ltrim($image, '/'));

        return implode('/', array_map('rawurlencode', $parts));
    }

    private function convertPrice(float $value, int $tax_class_id, bool $include_tax, string $from, string $to): string {
        if ($include_tax && $this->registry->has('tax')) {
            $value = (float)$this->tax->calculate($value, $tax_class_id, true);
        }

        return number_format((float)$this->currency->convert($value, $from, $to), 2, '.', '');
    }

    private function clean(string $value): string {
        if (!mb_check_encoding($value, 'UTF-8')) {
            $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }

        $value = preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $value);

        return $value === null ? '' : $value;
    }

    private function xmlEscape(string $value): string {
        return htmlspecialchars($this->clean($value), ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private function cdata(string $value): string {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $this->clean($value)) . ']]>';
    }
}
