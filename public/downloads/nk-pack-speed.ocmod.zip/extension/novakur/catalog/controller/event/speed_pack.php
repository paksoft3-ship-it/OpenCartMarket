<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

/**
 * NovaKur Speed Optimization Pack - storefront event hooks.
 *
 * Every public hook in this class is defensive: it is wrapped in a try/catch and
 * only ever assigns back to $output when a complete, non-empty replacement was
 * produced. On any error, unexpected input or unwritable cache directory the
 * original storefront output passes through completely untouched (fail open).
 */
class SpeedPack extends \Opencart\System\Engine\Controller {
	/**
	 * Number of <img> tags seen so far in this request. Shared across every
	 * lazy-load hook so the "skip the first N images" setting counts per page,
	 * not per template.
	 *
	 * @var int
	 */
	private static int $image_index = 0;

	/**
	 * Cache sub-directory (inside DIR_CACHE) holding the generated bundles.
	 */
	private const CACHE_SUBDIR = 'nk_speed';

	/**
	 * Hard ceiling on a single source file we are willing to read into memory.
	 */
	private const MAX_ASSET_BYTES = 2097152;

	/* ------------------------------------------------------------------ */
	/* Hook: catalog/controller/common/header/before                       */
	/* ------------------------------------------------------------------ */

	/**
	 * Registers the infinite-scroll assets before the header template renders.
	 *
	 * @param string       $route
	 * @param array<mixed> $args
	 *
	 * @return void
	 */
	public function assets(string &$route, array &$args): void {
		try {
			if (!$this->enabled()) {
				return;
			}

			if (!(int)$this->config->get('module_speed_pack_infinite_status')) {
				return;
			}

			if ($this->currentRoute() !== 'product/category') {
				return;
			}

			$selector = (string)$this->config->get('module_speed_pack_infinite_selector');

			if ($selector === '') {
				$selector = '#product-list';
			}

			$max_pages = (int)$this->config->get('module_speed_pack_infinite_max_pages');

			if ($max_pages < 0 || $max_pages > 100) {
				$max_pages = 0;
			}

			// One parameter, so the emitted src never contains a raw "&" and
			// never needs HTML entity encoding. The "?" also keeps this file
			// out of the JS bundle, which it must be: it reads currentScript.
			$query = 'nk=' . rawurlencode($selector . '|' . $max_pages);

			$this->document->addStyle('extension/novakur/catalog/view/assets/css/speed_pack.css');
			$this->document->addScript('extension/novakur/catalog/view/assets/js/speed_pack.js?' . $query);
		} catch (\Throwable $e) {
			// Fail open - the page renders exactly as it would without us.
		}
	}

	/* ------------------------------------------------------------------ */
	/* Hook: catalog/view/common/header/after                              */
	/* ------------------------------------------------------------------ */

	/**
	 * Rewrites the rendered <head> markup, replacing local stylesheet/script
	 * tags with a single concatenated + minified bundle per asset type.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function bundle(string &$route, array &$data, mixed &$output): void {
		try {
			if (!$this->enabled() || !is_string($output) || $output === '') {
				return;
			}

			$html = $output;

			if ((int)$this->config->get('module_speed_pack_bundle_css')) {
				$css = $this->bundleTags($html, 'css');

				if ($css !== null && $css !== '') {
					$html = $css;
				}
			}

			if ((int)$this->config->get('module_speed_pack_bundle_js')) {
				$js = $this->bundleTags($html, 'js');

				if ($js !== null && $js !== '') {
					$html = $js;
				}
			}

			if ($html !== '' && $html !== $output) {
				$output = $html;
			}
		} catch (\Throwable $e) {
			// Fail open.
		}
	}

	/* ------------------------------------------------------------------ */
	/* Hook: catalog/view/product/{category,search,...}/after              */
	/* ------------------------------------------------------------------ */

	/**
	 * Adds loading="lazy" decoding="async" to below-the-fold <img> tags.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function lazy(string &$route, array &$data, mixed &$output): void {
		try {
			if (!$this->enabled() || !is_string($output) || $output === '') {
				return;
			}

			if (!(int)$this->config->get('module_speed_pack_lazy_status')) {
				return;
			}

			$skip = (int)$this->config->get('module_speed_pack_lazy_skip');

			if ($skip < 0) {
				$skip = 0;
			}

			if ($skip > 50) {
				$skip = 50;
			}

			// Quotes are consumed as whole units so a ">" inside an attribute
			// value can never truncate the match.
			$pattern = '/<img\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>/i';

			$result = preg_replace_callback($pattern, function (array $match) use ($skip): string {
				return $this->lazyTag($match[0], $skip);
			}, $output);

			if (is_string($result) && $result !== '') {
				$output = $result;
			}
		} catch (\Throwable $e) {
			// Fail open.
		}
	}

	/* ------------------------------------------------------------------ */
	/* Lazy-load helpers                                                   */
	/* ------------------------------------------------------------------ */

	/**
	 * @param string $tag
	 * @param int    $skip
	 *
	 * @return string
	 */
	private function lazyTag(string $tag, int $skip): string {
		// Never touch a tag the theme already made a decision about.
		if (preg_match('/\sloading\s*=/i', $tag)) {
			return $tag;
		}

		// Opt-out hooks for theme authors.
		if (preg_match('/\sdata-nk-eager\b/i', $tag)) {
			return $tag;
		}

		if (preg_match('/\sclass\s*=\s*(?:"[^"]*\bnk-no-lazy\b|\'[^\']*\bnk-no-lazy\b)/i', $tag)) {
			return $tag;
		}

		self::$image_index++;

		if (self::$image_index <= $skip) {
			return $tag;
		}

		$add = ' loading="lazy"';

		if (!preg_match('/\sdecoding\s*=/i', $tag)) {
			$add .= ' decoding="async"';
		}

		if (substr($tag, -2) === '/>') {
			return substr($tag, 0, -2) . $add . '/>';
		}

		return substr($tag, 0, -1) . $add . '>';
	}

	/* ------------------------------------------------------------------ */
	/* Bundling                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Replaces every eligible local asset tag with one bundle tag.
	 *
	 * Returns null (caller keeps the original markup) whenever the rewrite
	 * cannot be proven safe.
	 *
	 * @param string $html
	 * @param string $type "css" or "js"
	 *
	 * @return string|null
	 */
	private function bundleTags(string $html, string $type): ?string {
		$head_end = stripos($html, '</head>');

		if ($head_end === false) {
			return null;
		}

		$head = substr($html, 0, $head_end);

		if ($type === 'css') {
			$pattern = '/<link\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>/i';
		} else {
			// Both <script src=".."></script> and self-closed variants, plus
			// inline blocks (which are detected and used as a safety abort).
			$pattern = '/<script\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>(.*?)<\/script\s*>/is';
		}

		if (!preg_match_all($pattern, $head, $matches, PREG_OFFSET_CAPTURE)) {
			return null;
		}

		$eligible = [];
		$blocked  = [];

		foreach ($matches[0] as $index => $match) {
			$tag    = (string)$match[0];
			$offset = (int)$match[1];

			if ($type === 'css') {
				$rel = $this->attr($tag, 'rel');

				// Anything that is not a stylesheet (icon, canonical, preload,
				// manifest...) is irrelevant to CSS cascade order.
				if ($rel === null || stripos($rel, 'stylesheet') === false) {
					continue;
				}

				$media = $this->attr($tag, 'media');

				if ($media !== null && !in_array(strtolower(trim($media)), ['', 'screen', 'all'], true)) {
					// print / device-specific sheets must keep their media attr.
					$blocked[] = $offset;
					continue;
				}

				$href = $this->attr($tag, 'href');
			} else {
				$inline = isset($matches[1][$index][0]) ? trim((string)$matches[1][$index][0]) : '';

				if ($inline !== '') {
					// An inline block between externals defines execution order.
					$blocked[] = $offset;
					continue;
				}

				$tag_type = $this->attr($tag, 'type');

				if ($tag_type !== null && !in_array(strtolower(trim($tag_type)), ['', 'text/javascript', 'application/javascript'], true)) {
					$blocked[] = $offset;
					continue;
				}

				if (preg_match('/\s(?:async|defer|nomodule)\b/i', $tag)) {
					$blocked[] = $offset;
					continue;
				}

				$href = $this->attr($tag, 'src');
			}

			if ($href === null) {
				$blocked[] = $offset;
				continue;
			}

			$local = $this->localAsset($href, $type);

			if ($local === null) {
				$blocked[] = $offset;
				continue;
			}

			$eligible[] = [
				'offset' => $offset,
				'length' => strlen($tag),
				'file'   => $local['file'],
				'href'   => $local['href']
			];
		}

		if (count($eligible) < 2) {
			// Nothing worth bundling - leave the page alone.
			return null;
		}

		$first = $eligible[0]['offset'];
		$last  = $eligible[count($eligible) - 1]['offset'];

		// Refuse to reorder around an asset we cannot bundle.
		foreach ($blocked as $offset) {
			if ($offset > $first && $offset < $last) {
				return null;
			}
		}

		$key = $this->bundleKey($eligible, $type);

		if ($key === null) {
			return null;
		}

		$name = $this->buildBundle($eligible, $type, $key);

		if ($name === null) {
			return null;
		}

		$url = $this->url->link('extension/novakur/module/speed_pack.asset', 'f=' . rawurlencode($name));

		if ($type === 'css') {
			$tag = '<link href="' . $url . '" type="text/css" rel="stylesheet"/>';
		} else {
			$tag = '<script src="' . $url . '" type="text/javascript"></script>';
		}

		// Replace back-to-front so earlier offsets stay valid.
		for ($i = count($eligible) - 1; $i >= 0; $i--) {
			$replacement = ($i === 0) ? $tag : '';

			$html = substr_replace($html, $replacement, $eligible[$i]['offset'], $eligible[$i]['length']);
		}

		return $html;
	}

	/**
	 * Cache-busting key: changes whenever any source file, the minifier
	 * settings or the admin "clear cache" counter changes.
	 *
	 * @param array<int, array<string, mixed>> $files
	 * @param string                           $type
	 *
	 * @return string|null
	 */
	private function bundleKey(array $files, string $type): ?string {
		$parts = ['v1', $type, (string)(int)$this->config->get('module_speed_pack_cache_version')];

		foreach ($files as $file) {
			$size = @filesize((string)$file['file']);
			$time = @filemtime((string)$file['file']);

			if ($size === false || $time === false) {
				return null;
			}

			if ($size > self::MAX_ASSET_BYTES) {
				return null;
			}

			$parts[] = $file['href'] . ':' . $size . ':' . $time;
		}

		return md5(implode('|', $parts));
	}

	/**
	 * Generates (once) and returns the bundle filename.
	 *
	 * @param array<int, array<string, mixed>> $files
	 * @param string                           $type
	 * @param string                           $key
	 *
	 * @return string|null
	 */
	private function buildBundle(array $files, string $type, string $key): ?string {
		$dir = $this->cacheDir();

		if ($dir === null) {
			return null;
		}

		$name = 'nk-speed.' . $key . '.' . $type;
		$path = $dir . $name;

		if (is_file($path) && filesize($path) > 0) {
			return $name;
		}

		$web_path = $this->webPath();

		if ($type === 'css' && $web_path === null) {
			return null;
		}

		$parts = [];

		foreach ($files as $file) {
			$source = @file_get_contents((string)$file['file']);

			if ($source === false || $source === '') {
				return null;
			}

			$href = (string)$file['href'];

			if ($this->isPreMinified($href)) {
				// Rule: never re-minify an already-minified file.
				$code = $source;
			} elseif ($type === 'css') {
				$code = $this->minifyCss($source);
			} else {
				$code = $this->minifyJs($source);
			}

			if ($code === null || $code === '') {
				// Minifier was not confident - ship the untouched source.
				$code = $source;
			}

			if ($type === 'css') {
				if (stripos($code, '@import') !== false) {
					// @import only works at the top of a sheet; merging would
					// silently drop rules.
					return null;
				}

				$rewritten = $this->rewriteCssUrls($code, $href, (string)$web_path);

				if ($rewritten === null) {
					return null;
				}

				$code = $rewritten;
			} else {
				if (preg_match('/^\s*(?:[\'"]use strict[\'"]\s*;)/', $code)) {
					// A file-level "use strict" would leak into every following
					// file once concatenated.
					return null;
				}
			}

			$parts[] = '/* ' . str_replace('*/', '*\/', $href) . ' */' . "\n" . $code;
		}

		// A leading ";" is a harmless empty statement and protects against
		// automatic-semicolon-insertion surprises between JS files.
		$glue    = ($type === 'js') ? "\n;\n" : "\n";
		$content = implode($glue, $parts) . "\n";

		return $this->writeAtomic($path, $content) ? $name : null;
	}

	/**
	 * @param string $path
	 * @param string $content
	 *
	 * @return bool
	 */
	private function writeAtomic(string $path, string $content): bool {
		$temp = $path . '.' . getmypid() . '.tmp';

		if (@file_put_contents($temp, $content, LOCK_EX) === false) {
			return false;
		}

		if (!@rename($temp, $path)) {
			@unlink($temp);

			return false;
		}

		@chmod($path, 0644);

		return true;
	}

	/* ------------------------------------------------------------------ */
	/* Minifiers - conservative whitespace/comment stripping only          */
	/* ------------------------------------------------------------------ */

	/**
	 * CSS minifier. Scans character by character so string literals are never
	 * touched. Returns null if the sheet looks malformed.
	 *
	 * @param string $css
	 *
	 * @return string|null
	 */
	private function minifyCss(string $css): ?string {
		$length  = strlen($css);
		$out     = '';
		$i       = 0;
		$pending = false;

		// Characters that can never be part of an identifier, so an adjacent
		// space is always safe to drop.
		$tight = '{};,';

		while ($i < $length) {
			$char = $css[$i];

			// Comment - acts as a token separator.
			if ($char === '/' && $i + 1 < $length && $css[$i + 1] === '*') {
				$end = strpos($css, '*/', $i + 2);

				if ($end === false) {
					return null;
				}

				$i       = $end + 2;
				$pending = true;

				continue;
			}

			// Whitespace run collapses to at most one space.
			if ($char === ' ' || $char === "\t" || $char === "\n" || $char === "\r" || $char === "\f") {
				$i++;
				$pending = true;

				continue;
			}

			if ($pending) {
				$pending = false;

				$last = ($out === '') ? '' : substr($out, -1);

				if ($last !== '' && strpos($tight, $last) === false && strpos($tight, $char) === false) {
					$out .= ' ';
				}
			}

			// String literal - copied verbatim, never re-spaced.
			if ($char === '"' || $char === '\'') {
				$literal = $this->readString($css, $i, $char);

				if ($literal === null || strpos($literal, "\n") !== false) {
					return null;
				}

				$out .= $literal;

				continue;
			}

			$out .= $char;
			$i++;
		}

		return trim($out);
	}

	/**
	 * JS minifier. Strips comments and per-line indentation but deliberately
	 * KEEPS newlines, so automatic semicolon insertion behaves identically to
	 * the original file. Strings, template literals and regex literals are
	 * copied verbatim. Returns null if anything is unterminated.
	 *
	 * @param string $js
	 *
	 * @return string|null
	 */
	private function minifyJs(string $js): ?string {
		$length    = strlen($js);
		$out       = '';
		$i         = 0;
		$multiline = false;

		while ($i < $length) {
			$char = $js[$i];

			// Block comment
			if ($char === '/' && $i + 1 < $length && $js[$i + 1] === '*') {
				$end = strpos($js, '*/', $i + 2);

				if ($end === false) {
					return null;
				}

				$newlines = substr_count(substr($js, $i, $end + 2 - $i), "\n");

				// Preserve the line structure the comment spanned; a same-line
				// comment still has to separate the tokens around it.
				if ($newlines > 0) {
					$out .= str_repeat("\n", $newlines);
				} elseif ($out === '' || substr($out, -1) !== ' ') {
					$out .= ' ';
				}

				$i = $end + 2;

				continue;
			}

			// Line comment
			if ($char === '/' && $i + 1 < $length && $js[$i + 1] === '/') {
				$end = strpos($js, "\n", $i);

				$i = ($end === false) ? $length : $end;

				continue;
			}

			// Regex literal vs division
			if ($char === '/' && $this->regexAllowed($out)) {
				$literal = $this->readRegex($js, $i);

				if ($literal === null) {
					return null;
				}

				$out .= $literal;

				continue;
			}

			// String / template literal
			if ($char === '"' || $char === '\'' || $char === '`') {
				$literal = $this->readString($js, $i, $char);

				if ($literal === null) {
					return null;
				}

				if (strpos($literal, "\n") !== false) {
					// A multi-line template literal carries its own whitespace
					// as data - stop trimming lines for this file.
					$multiline = true;
				}

				$out .= $literal;

				continue;
			}

			// Collapse runs of horizontal whitespace outside literals.
			if ($char === ' ' || $char === "\t") {
				if ($out === '' || substr($out, -1) !== ' ') {
					$out .= ' ';
				}

				$i++;

				continue;
			}

			$out .= $char;
			$i++;
		}

		if ($multiline) {
			return $out;
		}

		// Trim each line, drop the blank ones, keep the newlines so automatic
		// semicolon insertion behaves exactly as in the original file.
		$lines = explode("\n", str_replace("\r\n", "\n", $out));
		$kept  = [];

		foreach ($lines as $line) {
			$line = trim($line);

			if ($line === '') {
				continue;
			}

			$kept[] = $line;
		}

		return implode("\n", $kept);
	}

	/**
	 * Reads a quoted string (or template literal) starting at $i, advancing $i
	 * past the closing quote.
	 *
	 * @param string $code
	 * @param int    $i
	 * @param string $quote
	 *
	 * @return string|null
	 */
	private function readString(string $code, int &$i, string $quote): ?string {
		$length = strlen($code);
		$start  = $i;
		$i++;

		while ($i < $length) {
			$char = $code[$i];

			if ($char === '\\') {
				$i += 2;

				continue;
			}

			if ($char === $quote) {
				$i++;

				return substr($code, $start, $i - $start);
			}

			$i++;
		}

		return null;
	}

	/**
	 * Reads a JS regex literal starting at $i, advancing $i past the flags.
	 *
	 * @param string $code
	 * @param int    $i
	 *
	 * @return string|null
	 */
	private function readRegex(string $code, int &$i): ?string {
		$length  = strlen($code);
		$start   = $i;
		$i++;
		$in_class = false;

		while ($i < $length) {
			$char = $code[$i];

			if ($char === "\n") {
				return null;
			}

			if ($char === '\\') {
				$i += 2;

				continue;
			}

			if ($char === '[') {
				$in_class = true;
			} elseif ($char === ']') {
				$in_class = false;
			} elseif ($char === '/' && !$in_class) {
				$i++;

				while ($i < $length && preg_match('/[a-z]/i', $code[$i])) {
					$i++;
				}

				return substr($code, $start, $i - $start);
			}

			$i++;
		}

		return null;
	}

	/**
	 * Standard heuristic: a "/" opens a regex literal when the previous
	 * significant token cannot end an expression.
	 *
	 * @param string $before
	 *
	 * @return bool
	 */
	private function regexAllowed(string $before): bool {
		$trimmed = rtrim($before);

		if ($trimmed === '') {
			return true;
		}

		$last = substr($trimmed, -1);

		if (strpos('(,=:[!&|?{};+-*%~^<>', $last) !== false) {
			return true;
		}

		if (preg_match('/(?:^|[^\w$.])(return|typeof|instanceof|in|of|new|delete|do|else|case|void|throw|yield|await)$/', $trimmed)) {
			return true;
		}

		return false;
	}

	/* ------------------------------------------------------------------ */
	/* Path helpers                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * Resolves a document-relative asset href to a readable file inside the
	 * OpenCart root, or null when it is not safe to bundle.
	 *
	 * @param string $href
	 * @param string $type
	 *
	 * @return array<string, string>|null
	 */
	private function localAsset(string $href, string $type): ?array {
		$href = trim(html_entity_decode($href, ENT_QUOTES, 'UTF-8'));

		if ($href === '') {
			return null;
		}

		// Absolute, protocol-relative, query-stringed or fragment URLs.
		if (preg_match('#^(?:[a-z][a-z0-9+.\-]*:|//|/|\#)#i', $href)) {
			return null;
		}

		if (strpos($href, '?') !== false || strpos($href, '#') !== false || strpos($href, '..') !== false) {
			return null;
		}

		if (!preg_match('/\.' . preg_quote($type, '/') . '$/i', $href)) {
			return null;
		}

		$root = realpath($this->rootDir());

		if ($root === false) {
			return null;
		}

		$file = realpath($root . '/' . $href);

		if ($file === false || !is_file($file) || !is_readable($file)) {
			return null;
		}

		if (strncmp($file, $root . DIRECTORY_SEPARATOR, strlen($root) + 1) !== 0) {
			return null;
		}

		return ['file' => $file, 'href' => $href];
	}

	/**
	 * @param string $href
	 *
	 * @return bool
	 */
	private function isPreMinified(string $href): bool {
		return (bool)preg_match('/[.\-]min\.(?:css|js)$/i', $href);
	}

	/**
	 * Rewrites relative url(...) references so they still resolve once the
	 * sheet is served from a different URL.
	 *
	 * @param string $css
	 * @param string $href
	 * @param string $web_path
	 *
	 * @return string|null
	 */
	private function rewriteCssUrls(string $css, string $href, string $web_path): ?string {
		$base = trim(dirname($href), '/.');

		$result = preg_replace_callback('/url\(\s*(\'[^\')]*\'|"[^")]*"|[^)\'"]*)\s*\)/i', function (array $match) use ($base, $web_path): string {
			$raw   = trim($match[1]);
			$quote = '';

			if (strlen($raw) >= 2 && ($raw[0] === '"' || $raw[0] === '\'')) {
				$quote = $raw[0];
				$raw   = trim(substr($raw, 1, -1));
			}

			if ($raw === '') {
				return $match[0];
			}

			// data:, http:, //cdn, /root-relative and #fragment stay as-is.
			if (preg_match('#^(?:[a-z][a-z0-9+.\-]*:|//|/|\#)#i', $raw)) {
				return $match[0];
			}

			$absolute = $web_path . ($base !== '' ? $base . '/' : '') . $raw;

			return 'url(' . $quote . $this->normalizePath($absolute) . $quote . ')';
		}, $css);

		return is_string($result) ? $result : null;
	}

	/**
	 * Collapses "." and ".." segments in a URL path.
	 *
	 * @param string $path
	 *
	 * @return string
	 */
	private function normalizePath(string $path): string {
		$leading = (strncmp($path, '/', 1) === 0) ? '/' : '';
		$out     = [];

		foreach (explode('/', trim($path, '/')) as $segment) {
			if ($segment === '' || $segment === '.') {
				continue;
			}

			if ($segment === '..') {
				array_pop($out);

				continue;
			}

			$out[] = $segment;
		}

		return $leading . implode('/', $out);
	}

	/**
	 * Absolute filesystem path of the OpenCart web root, with trailing slash.
	 *
	 * @return string
	 */
	private function rootDir(): string {
		if (defined('DIR_OPENCART')) {
			return rtrim((string)DIR_OPENCART, '/\\') . '/';
		}

		// DIR_APPLICATION is <root>/catalog/ on the storefront.
		return rtrim(dirname(rtrim(DIR_APPLICATION, '/\\')), '/\\') . '/';
	}

	/**
	 * URL path of the OpenCart web root, e.g. "/" or "/shop/".
	 *
	 * @return string|null
	 */
	private function webPath(): ?string {
		$url = '';

		if (defined('HTTP_SERVER')) {
			$url = (string)HTTP_SERVER;
		}

		if ($url === '') {
			$url = (string)$this->config->get('config_url');
		}

		if ($url === '') {
			return null;
		}

		$path = parse_url($url, PHP_URL_PATH);

		if (!is_string($path) || $path === '') {
			return '/';
		}

		return '/' . trim($path, '/') . (trim($path, '/') === '' ? '' : '/');
	}

	/**
	 * Bundle cache directory, created on demand. Null when unusable.
	 *
	 * @return string|null
	 */
	private function cacheDir(): ?string {
		if (!defined('DIR_CACHE')) {
			return null;
		}

		$dir = rtrim((string)DIR_CACHE, '/\\') . '/' . self::CACHE_SUBDIR . '/';

		if (!is_dir($dir) && !@mkdir($dir, 0777, true) && !is_dir($dir)) {
			return null;
		}

		return is_writable($dir) ? $dir : null;
	}

	/* ------------------------------------------------------------------ */
	/* Misc helpers                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * @return bool
	 */
	private function enabled(): bool {
		return (bool)(int)$this->config->get('module_speed_pack_status');
	}

	/**
	 * @return string
	 */
	private function currentRoute(): string {
		return isset($this->request->get['route']) ? (string)$this->request->get['route'] : 'common/home';
	}

	/**
	 * Reads a single attribute value out of a raw HTML tag.
	 *
	 * @param string $tag
	 * @param string $name
	 *
	 * @return string|null
	 */
	private function attr(string $tag, string $name): ?string {
		$pattern = '/\s' . preg_quote($name, '/') . '\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s"\'>]+))/i';

		if (!preg_match($pattern, $tag, $match)) {
			return null;
		}

		if (isset($match[2]) && $match[2] !== '') {
			return $match[2];
		}

		if (isset($match[3]) && $match[3] !== '') {
			return $match[3];
		}

		if (isset($match[4]) && $match[4] !== '') {
			return $match[4];
		}

		return '';
	}
}
