<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Module;

/**
 * NovaKur Speed Optimization Pack - storefront bundle delivery.
 *
 * Bundles live in the OpenCart storage cache directory, which is normally
 * outside the web root, so they are streamed through this route. Filenames
 * contain a content hash, which lets us answer with immutable far-future cache
 * headers plus ETag/304 revalidation - after the first hit the browser never
 * asks for the file again.
 */
class SpeedPack extends \Opencart\System\Engine\Controller {
	/**
	 * Cache sub-directory (inside DIR_CACHE) holding the generated bundles.
	 */
	private const CACHE_SUBDIR = 'nk_speed';

	/**
	 * This module has no layout placement - it exists for the asset route.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * Streams a generated bundle.
	 *
	 * @return void
	 */
	public function asset(): void {
		$file = isset($this->request->get['f']) ? (string)$this->request->get['f'] : '';

		// The name is fully machine generated: nk-speed.<md5>.css|js
		if (!preg_match('/^nk\-speed\.[a-f0-9]{32}\.(css|js)$/', $file, $match)) {
			$this->notFound();

			return;
		}

		if (!defined('DIR_CACHE')) {
			$this->notFound();

			return;
		}

		$path = rtrim((string)DIR_CACHE, '/\\') . '/' . self::CACHE_SUBDIR . '/' . $file;

		if (!is_file($path) || !is_readable($path)) {
			$this->notFound();

			return;
		}

		$type = ($match[1] === 'css') ? 'text/css' : 'application/javascript';
		$etag = '"' . substr($file, 9, 32) . '"';

		$this->response->addHeader('Content-Type: ' . $type . '; charset=utf-8');
		$this->response->addHeader('Cache-Control: public, max-age=31536000, immutable');
		$this->response->addHeader('ETag: ' . $etag);
		$this->response->addHeader('X-Content-Type-Options: nosniff');

		$match_header = isset($this->request->server['HTTP_IF_NONE_MATCH']) ? trim((string)$this->request->server['HTTP_IF_NONE_MATCH']) : '';

		if ($match_header !== '' && ($match_header === $etag || $match_header === 'W/' . $etag)) {
			$this->response->addHeader($this->protocol() . ' 304 Not Modified');
			$this->response->setOutput('');

			return;
		}

		$content = @file_get_contents($path);

		if ($content === false) {
			$this->notFound();

			return;
		}

		$this->response->setOutput($content);
	}

	/**
	 * @return void
	 */
	private function notFound(): void {
		$this->response->addHeader($this->protocol() . ' 404 Not Found');
		$this->response->addHeader('Content-Type: text/plain; charset=utf-8');
		$this->response->setOutput('Not Found');
	}

	/**
	 * @return string
	 */
	private function protocol(): string {
		$protocol = isset($this->request->server['SERVER_PROTOCOL']) ? (string)$this->request->server['SERVER_PROTOCOL'] : '';

		return in_array($protocol, ['HTTP/1.0', 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0', 'HTTP/3'], true) ? $protocol : 'HTTP/1.1';
	}
}
