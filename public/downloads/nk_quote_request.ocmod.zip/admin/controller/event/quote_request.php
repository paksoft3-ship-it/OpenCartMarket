<?php
namespace Opencart\Admin\Controller\Extension\NkQuoteRequest\Event;

/**
 * NovaKur B2B Quote Request - admin event handler.
 *
 * Adds a "Quote Requests" entry under Sales in the admin sidebar so the merchant
 * does not have to go through Extensions > Modules to reach the quote list.
 */
class QuoteRequest extends \Opencart\System\Engine\Controller {
    /**
     * Trigger: admin/view/common/column_left/before
     *
     * @param array<string, mixed> $data
     */
    public function columnLeft(string &$route, array &$data, string &$code, mixed &$output): void {
        if (!isset($data['menus']) || !is_array($data['menus'])) {
            return;
        }

        if (!$this->user->hasPermission('access', 'extension/nk_quote_request/module/quote_request')) {
            return;
        }

        if (!isset($this->session->data['user_token'])) {
            return;
        }

        $this->load->language('extension/nk_quote_request/module/quote_request');

        $item = [
            'name'     => $this->language->get('heading_quotes'),
            'href'     => $this->url->link('extension/nk_quote_request/module/quote_request.quotes', 'user_token=' . $this->session->data['user_token']),
            'children' => []
        ];

        foreach ($data['menus'] as &$menu) {
            if (isset($menu['id']) && $menu['id'] === 'menu-sale') {
                $menu['children'][] = $item;

                unset($menu);

                return;
            }
        }

        unset($menu);

        // No Sales menu (permissions) - surface it as its own top level entry.
        $data['menus'][] = [
            'id'       => 'menu-nk-quote-request',
            'icon'     => 'fa-solid fa-file-invoice-dollar',
            'name'     => $this->language->get('heading_title'),
            'href'     => $item['href'],
            'children' => []
        ];
    }
}
