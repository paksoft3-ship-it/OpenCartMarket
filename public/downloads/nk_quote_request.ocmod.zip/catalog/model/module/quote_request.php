<?php
namespace Opencart\Catalog\Model\Extension\NkQuoteRequest\Module;

/**
 * NovaKur B2B Quote Request - storefront model.
 *
 * Reads and writes the `nk_quote` / `nk_quote_item` tables created by the admin
 * controller's install(). Every value that originates from the request is either
 * cast to int/float or escaped with $this->db->escape().
 */
class QuoteRequest extends \Opencart\System\Engine\Model {
    /**
     * Insert a quote and its lines.
     *
     * @param array<string, mixed>             $data
     * @param array<int, array<string, mixed>> $items
     */
    public function addQuote(array $data, array $items): int {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "nk_quote` SET
            `store_id` = '" . (int)$data['store_id'] . "',
            `customer_id` = '" . (int)$data['customer_id'] . "',
            `language_id` = '" . (int)$data['language_id'] . "',
            `company` = '" . $this->db->escape((string)$data['company']) . "',
            `name` = '" . $this->db->escape((string)$data['name']) . "',
            `email` = '" . $this->db->escape((string)$data['email']) . "',
            `telephone` = '" . $this->db->escape((string)$data['telephone']) . "',
            `comment` = '" . $this->db->escape((string)$data['comment']) . "',
            `admin_note` = '',
            `currency_code` = '" . $this->db->escape((string)$data['currency_code']) . "',
            `currency_value` = '" . (float)$data['currency_value'] . "',
            `status` = 'pending',
            `token` = '',
            `valid_days` = '" . (int)$data['valid_days'] . "',
            `ip` = '" . $this->db->escape((string)$data['ip']) . "',
            `date_added` = NOW(),
            `date_modified` = NOW()");

        $quote_id = (int)$this->db->getLastId();

        foreach ($items as $item) {
            $this->db->query("INSERT INTO `" . DB_PREFIX . "nk_quote_item` SET
                `quote_id` = '" . (int)$quote_id . "',
                `product_id` = '" . (int)$item['product_id'] . "',
                `name` = '" . $this->db->escape((string)$item['name']) . "',
                `model` = '" . $this->db->escape((string)$item['model']) . "',
                `quantity` = '" . (int)$item['quantity'] . "',
                `price` = '" . (float)$item['price'] . "',
                `quoted_price` = '" . (float)$item['price'] . "',
                `option` = '" . $this->db->escape((string)json_encode($item['option'])) . "',
                `subscription_plan_id` = '" . (int)$item['subscription_plan_id'] . "'");
        }

        return $quote_id;
    }

    /**
     * @return array<string, mixed>
     */
    public function getQuote(int $quote_id): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_quote` WHERE `quote_id` = '" . (int)$quote_id . "'");

        return $query->row;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getItems(int $quote_id): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_quote_item` WHERE `quote_id` = '" . (int)$quote_id . "' ORDER BY `quote_item_id` ASC");

        return $query->rows;
    }

    public function markAccepted(int $quote_id): void {
        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `status` = 'accepted', `date_accepted` = NOW(), `date_modified` = NOW() WHERE `quote_id` = '" . (int)$quote_id . "'");
    }

    public function markExpired(int $quote_id): void {
        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `status` = 'expired', `date_modified` = NOW() WHERE `quote_id` = '" . (int)$quote_id . "'");
    }

    /**
     * Sweep quotes whose validity window has passed. Used by the token guarded
     * cron route.
     *
     * @return int number of quotes expired
     */
    public function expireOverdue(): int {
        $this->db->query("UPDATE `" . DB_PREFIX . "nk_quote` SET `status` = 'expired', `date_modified` = NOW() WHERE `status` = 'quoted' AND `date_expires` IS NOT NULL AND `date_expires` < NOW()");

        return (int)$this->db->countAffected();
    }

    public function tablesExist(): bool {
        $query = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . 'nk_quote') . "'");

        return (bool)$query->num_rows;
    }
}
