<?php
namespace Opencart\Catalog\Controller\Extension\NkQuoteRequest\Module;

/**
 * NovaKur B2B Quote Request - storefront controller.
 *
 * Routes:
 *   .index    quote basket page
 *   .list     quote basket list partial (ajax)
 *   .add      add a product to the session quote basket (ajax POST)
 *   .edit     change a line quantity (ajax POST)
 *   .remove   drop a line (ajax POST)
 *   .submit   turn the basket into an `nk_quote` row (ajax POST)
 *   .accept   token guarded accept link -> rebuilds the cart at quoted prices
 *   .expire   token guarded cron sweep that expires overdue quotes
 */
class QuoteRequest extends \Opencart\System\Engine\Controller {
    private const SESSION_KEY = 'nk_quote_basket';

    /* ------------------------------------------------------------------ */
    /* Quote basket page                                                   */
    /* ------------------------------------------------------------------ */

    public function index(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        if (!$this->isEnabled()) {
            $this->response->redirect($this->url->link('common/home', 'language=' . $this->config->get('config_language')));

            return;
        }

        $this->document->setTitle($this->language->get('heading_title'));

        $this->document->addStyle('extension/nk_quote_request/catalog/view/assets/css/quote_request.css');
        $this->document->addScript('extension/nk_quote_request/catalog/view/assets/js/quote_request.js');

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'language=' . $this->config->get('config_language'))
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_quote_request/module/quote_request', 'language=' . $this->config->get('config_language'))
        ];

        foreach (['heading_title', 'text_intro', 'text_empty', 'text_your_details', 'text_ex_tax', 'entry_company', 'entry_name', 'entry_email', 'entry_telephone', 'entry_comment', 'button_submit', 'button_continue', 'help_submit'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        if (isset($this->session->data['nk_quote_success'])) {
            $data['success'] = $this->session->data['nk_quote_success'];

            unset($this->session->data['nk_quote_success']);
        } else {
            $data['success'] = '';
        }

        if (isset($this->session->data['nk_quote_error'])) {
            $data['error_warning'] = $this->session->data['nk_quote_error'];

            unset($this->session->data['nk_quote_error']);
        } else {
            $data['error_warning'] = '';
        }

        $data['list'] = $this->getList();

        $data['action_submit'] = $this->url->link('extension/nk_quote_request/module/quote_request.submit', 'language=' . $this->config->get('config_language'));
        $data['action_list'] = $this->url->link('extension/nk_quote_request/module/quote_request.list', 'language=' . $this->config->get('config_language'));
        $data['continue'] = $this->url->link('common/home', 'language=' . $this->config->get('config_language'));

        // Pre-fill from the logged in customer where we can.
        $data['company'] = '';
        $data['name'] = '';
        $data['email'] = '';
        $data['telephone'] = '';

        if ($this->customer->isLogged()) {
            $data['name'] = trim($this->customer->getFirstName() . ' ' . $this->customer->getLastName());
            $data['email'] = $this->customer->getEmail();
            $data['telephone'] = $this->customer->getTelephone();
        }

        $data['language'] = $this->config->get('config_language');

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('extension/nk_quote_request/module/quote_request_basket', $data));
    }

    public function list(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $this->response->setOutput($this->getList());
    }

    private function getList(): string {
        foreach (['column_product', 'column_model', 'column_quantity', 'column_price', 'column_total', 'text_empty', 'text_total', 'text_ex_tax', 'button_update', 'button_remove'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['action_edit'] = $this->url->link('extension/nk_quote_request/module/quote_request.edit', 'language=' . $this->config->get('config_language'));
        $data['action_list'] = $this->url->link('extension/nk_quote_request/module/quote_request.list', 'language=' . $this->config->get('config_language'));

        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $data['products'] = [];

        $total = 0.0;

        foreach ($this->getBasket() as $key => $line) {
            $product_info = $this->model_catalog_product->getProduct((int)$line['product_id']);

            if (!$product_info) {
                continue;
            }

            $priced = $this->priceProduct($product_info, (array)$line['option']);

            $total += $priced['price'] * (int)$line['quantity'];

            $data['products'][] = [
                'key'        => $key,
                'product_id' => (int)$line['product_id'],
                'name'       => $product_info['name'],
                'model'      => $product_info['model'],
                'option'     => $priced['display'],
                'quantity'   => (int)$line['quantity'],
                'thumb'      => $product_info['image'] ? $this->model_tool_image->resize((string)$product_info['image'], 60, 60) : $this->model_tool_image->resize('placeholder.png', 60, 60),
                'price'      => $this->currency->format($priced['price'], $this->session->data['currency']),
                'total'      => $this->currency->format($priced['price'] * (int)$line['quantity'], $this->session->data['currency']),
                'href'       => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$line['product_id']),
                'remove'     => $this->url->link('extension/nk_quote_request/module/quote_request.remove', 'language=' . $this->config->get('config_language') . '&key=' . rawurlencode($key))
            ];
        }

        $data['total'] = $this->currency->format($total, $this->session->data['currency']);

        return $this->load->view('extension/nk_quote_request/module/quote_request_list', $data);
    }

    /* ------------------------------------------------------------------ */
    /* Basket mutations                                                    */
    /* ------------------------------------------------------------------ */

    public function add(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $json = [];

        if (!$this->isEnabled()) {
            $json['error']['warning'] = $this->language->get('error_disabled');
        }

        $product_id = (int)($this->request->post['product_id'] ?? 0);
        $quantity = (int)($this->request->post['quantity'] ?? 1);

        if ($quantity < 1) {
            $quantity = 1;
        }

        if ($quantity > 999999) {
            $quantity = 999999;
        }

        $option = isset($this->request->post['option']) && is_array($this->request->post['option']) ? array_filter($this->request->post['option']) : [];
        $subscription_plan_id = (int)($this->request->post['subscription_plan_id'] ?? 0);

        if (!isset($json['error'])) {
            $this->load->model('catalog/product');

            $product_info = $this->model_catalog_product->getProduct($product_id);

            if (!$product_info) {
                $json['error']['warning'] = $this->language->get('error_product');
            } else {
                // Variants resolve to their master product and fold their fixed
                // option values into the submitted set - same as checkout/cart.add().
                if (!empty($product_info['master_id'])) {
                    $product_id = (int)$product_info['master_id'];

                    $overridden = (isset($product_info['override']['variant']) && is_array($product_info['override']['variant'])) ? $product_info['override']['variant'] : [];

                    foreach ((array)$product_info['variant'] as $variant_key => $variant_value) {
                        if (array_key_exists($variant_key, $overridden)) {
                            $option[$variant_key] = $variant_value;
                        }
                    }
                }

                foreach ($this->model_catalog_product->getOptions($product_id) as $product_option) {
                    $value = $option[$product_option['product_option_id']] ?? '';

                    if ($product_option['required'] && empty($value)) {
                        $json['error']['option_' . $product_option['product_option_id']] = sprintf($this->language->get('error_required'), $product_option['name']);
                    } elseif ($product_option['type'] === 'text' && !empty($product_option['validation']) && !oc_validate_regex((string)$value, (string)$product_option['validation'])) {
                        $json['error']['option_' . $product_option['product_option_id']] = sprintf($this->language->get('error_regex'), $product_option['name']);
                    }
                }
            }
        }

        if (!$json) {
            $basket = $this->getBasket();

            $key = $this->lineKey($product_id, $option, $subscription_plan_id);

            if (isset($basket[$key])) {
                $basket[$key]['quantity'] = min(999999, (int)$basket[$key]['quantity'] + $quantity);
            } else {
                $basket[$key] = [
                    'product_id'           => $product_id,
                    'quantity'             => $quantity,
                    'option'               => $option,
                    'subscription_plan_id' => $subscription_plan_id
                ];
            }

            $this->setBasket($basket);

            $json['success'] = sprintf($this->language->get('text_added'), $this->url->link('extension/nk_quote_request/module/quote_request', 'language=' . $this->config->get('config_language')));
            $json['total'] = $this->countBasket();
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function edit(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $json = [];

        $basket = $this->getBasket();

        $posted = $this->request->post['quantity'] ?? [];

        if (is_array($posted)) {
            foreach ($posted as $key => $quantity) {
                $key = (string)$key;

                if (!isset($basket[$key])) {
                    continue;
                }

                $quantity = (int)$quantity;

                if ($quantity < 1) {
                    unset($basket[$key]);
                } else {
                    $basket[$key]['quantity'] = min(999999, $quantity);
                }
            }
        }

        $this->setBasket($basket);

        $json['success'] = $this->language->get('text_updated');
        $json['total'] = $this->countBasket();

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function remove(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $json = [];

        $key = (string)($this->request->get['key'] ?? $this->request->post['key'] ?? '');

        $basket = $this->getBasket();

        if (isset($basket[$key])) {
            unset($basket[$key]);

            $this->setBasket($basket);
        }

        $json['success'] = $this->language->get('text_removed');
        $json['total'] = $this->countBasket();

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Submit                                                              */
    /* ------------------------------------------------------------------ */

    public function submit(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $json = [];

        if (!$this->isEnabled()) {
            $json['error']['warning'] = $this->language->get('error_disabled');
        }

        $this->load->model('extension/nk_quote_request/module/quote_request');

        if (!isset($json['error']) && !$this->model_extension_nk_quote_request_module_quote_request->tablesExist()) {
            $json['error']['warning'] = $this->language->get('error_disabled');
        }

        $basket = $this->getBasket();

        if (!isset($json['error']) && !$basket) {
            $json['error']['warning'] = $this->language->get('error_empty');
        }

        $company = trim((string)($this->request->post['company'] ?? ''));
        $name = trim((string)($this->request->post['name'] ?? ''));
        $email = trim((string)($this->request->post['email'] ?? ''));
        $telephone = trim((string)($this->request->post['telephone'] ?? ''));
        $comment = trim((string)($this->request->post['comment'] ?? ''));

        if (oc_strlen($company) < 2 || oc_strlen($company) > 128) {
            $json['error']['company'] = $this->language->get('error_company');
        }

        if (oc_strlen($name) < 2 || oc_strlen($name) > 96) {
            $json['error']['name'] = $this->language->get('error_name');
        }

        if (oc_strlen($email) > 96 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $json['error']['email'] = $this->language->get('error_email');
        }

        if (oc_strlen($telephone) > 32) {
            $json['error']['telephone'] = $this->language->get('error_telephone');
        }

        if (oc_strlen($comment) > 2000) {
            $json['error']['comment'] = $this->language->get('error_comment');
        }

        if (!$json) {
            $this->load->model('catalog/product');

            $items = [];

            foreach ($basket as $line) {
                $product_info = $this->model_catalog_product->getProduct((int)$line['product_id']);

                if (!$product_info) {
                    continue;
                }

                $priced = $this->priceProduct($product_info, (array)$line['option']);

                $items[] = [
                    'product_id'           => (int)$line['product_id'],
                    'name'                 => (string)$product_info['name'],
                    'model'                => (string)$product_info['model'],
                    'quantity'             => (int)$line['quantity'],
                    'price'                => $priced['price'],
                    'option'               => [
                        'raw'     => (array)$line['option'],
                        'display' => $priced['display']
                    ],
                    'subscription_plan_id' => (int)$line['subscription_plan_id']
                ];
            }

            if (!$items) {
                $json['error']['warning'] = $this->language->get('error_empty');
            } else {
                $validity_days = (int)$this->config->get('module_quote_request_validity_days');

                if ($validity_days < 1 || $validity_days > 365) {
                    $validity_days = 14;
                }

                $quote_id = $this->model_extension_nk_quote_request_module_quote_request->addQuote([
                    'store_id'       => (int)$this->config->get('config_store_id'),
                    'customer_id'    => (int)$this->customer->getId(),
                    'language_id'    => (int)$this->config->get('config_language_id'),
                    'company'        => $company,
                    'name'           => $name,
                    'email'          => $email,
                    'telephone'      => $telephone,
                    'comment'        => $comment,
                    'currency_code'  => (string)$this->session->data['currency'],
                    'currency_value' => (float)$this->currency->getValue((string)$this->session->data['currency']),
                    'valid_days'     => $validity_days,
                    'ip'             => oc_get_ip()
                ], $items);

                $this->setBasket([]);

                try {
                    $this->notify($quote_id);
                } catch (\Throwable $exception) {
                    // A mail transport failure must not lose the quote itself.
                    $this->log->write('nk-quote-request: mail failed for quote ' . $quote_id . ' - ' . $exception->getMessage());
                }

                $this->session->data['nk_quote_success'] = sprintf($this->language->get('text_submitted'), $quote_id);

                $json['success'] = sprintf($this->language->get('text_submitted'), $quote_id);
                $json['redirect'] = $this->url->link('extension/nk_quote_request/module/quote_request', 'language=' . $this->config->get('config_language'), true);
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Accept link                                                         */
    /* ------------------------------------------------------------------ */

    /**
     * Token guarded accept link. Converts the quote into a real cart whose lines
     * carry the merchant's quoted unit prices.
     *
     * PRICE OVERRIDE MECHANISM - why `oc_cart`.`override` and not an order total:
     *
     * Cart::add() accepts a fifth $override argument which it json-encodes into
     * `oc_cart`.`override`. Cart::getProducts() builds each line from the
     * catalogue price and then copies every override key over the finished row
     * ("Use with order editor and subscriptions" in the core source). Setting
     * `price` and `total` therefore feeds getSubTotal(), getTotal() and
     * getTaxes() with the quoted figures for free.
     *
     * An order-total extension was rejected: totals are store-wide, cannot
     * attribute a price to one cart line, run for every cart whether quoted or
     * not, and collide with coupons and vouchers. The override column is
     * per-line, needs no extra extension registration, and is the only price
     * override the OpenCart 4.1 core actually supports.
     *
     * `total` is a stored snapshot, so the header event syncCartPrices() keeps
     * it in step if the shopper edits the quantity afterwards.
     */
    public function accept(): void {
        $this->load->language('extension/nk_quote_request/module/quote_request');

        $quote_id = (int)($this->request->get['quote_id'] ?? 0);
        $token = (string)($this->request->get['token'] ?? '');

        $this->load->model('extension/nk_quote_request/module/quote_request');

        $quote_info = $this->model_extension_nk_quote_request_module_quote_request->tablesExist() ? $this->model_extension_nk_quote_request_module_quote_request->getQuote($quote_id) : [];

        $error = '';

        if (!$quote_info || !$quote_info['token'] || strlen($token) !== strlen((string)$quote_info['token']) || !hash_equals((string)$quote_info['token'], $token)) {
            $error = $this->language->get('error_accept_token');
        } elseif ($quote_info['status'] === 'accepted') {
            $error = $this->language->get('error_accept_used');
        } elseif ($quote_info['status'] !== 'quoted') {
            $error = $this->language->get('error_accept_status');
        } elseif ($quote_info['date_expires'] && strtotime((string)$quote_info['date_expires']) < time()) {
            $this->model_extension_nk_quote_request_module_quote_request->markExpired($quote_id);

            $error = $this->language->get('error_accept_expired');
        }

        if ($error) {
            $this->session->data['nk_quote_error'] = $error;

            $this->response->redirect($this->url->link('extension/nk_quote_request/module/quote_request', 'language=' . $this->config->get('config_language'), true));

            return;
        }

        $items = $this->model_extension_nk_quote_request_module_quote_request->getItems($quote_id);

        $this->cart->clear();

        $added = 0;

        foreach ($items as $item) {
            $decoded = json_decode((string)$item['option'], true);

            $option = (is_array($decoded) && isset($decoded['raw']) && is_array($decoded['raw'])) ? $decoded['raw'] : [];

            $quantity = (int)$item['quantity'];

            if ($quantity < 1) {
                continue;
            }

            $price = (float)$item['quoted_price'] > 0 ? (float)$item['quoted_price'] : (float)$item['price'];

            $this->cart->add((int)$item['product_id'], $quantity, $option, (int)$item['subscription_plan_id'], [
                'price'       => $price,
                'total'       => $price * $quantity,
                'nk_quote_id' => $quote_id
            ]);

            $added++;
        }

        if (!$added) {
            $this->session->data['nk_quote_error'] = $this->language->get('error_accept_products');

            $this->response->redirect($this->url->link('extension/nk_quote_request/module/quote_request', 'language=' . $this->config->get('config_language'), true));

            return;
        }

        $this->model_extension_nk_quote_request_module_quote_request->markAccepted($quote_id);

        // Marker used by the header event to keep overridden totals in step with
        // quantity edits made on the cart page.
        $this->session->data['nk_quote_cart'] = $quote_id;

        // Quoted prices invalidate any previously chosen shipping/payment method.
        unset($this->session->data['shipping_method'], $this->session->data['shipping_methods'], $this->session->data['payment_method'], $this->session->data['payment_methods']);

        $this->session->data['success'] = sprintf($this->language->get('text_accepted'), $quote_id);

        $this->response->redirect($this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'), true));
    }

    /* ------------------------------------------------------------------ */
    /* Cron sweep                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * Token guarded cron entry point:
     *   index.php?route=extension/nk_quote_request/module/quote_request.expire&token=<cron token>
     *
     * Flips `quoted` quotes whose validity window has passed to `expired`.
     */
    public function expire(): void {
        $this->response->addHeader('Content-Type: text/plain; charset=utf-8');

        $configured = (string)$this->config->get('module_quote_request_cron_token');
        $token = (string)($this->request->get['token'] ?? '');

        if (!$configured || strlen($token) !== strlen($configured) || !hash_equals($configured, $token)) {
            $this->response->addHeader(((string)($this->request->server['SERVER_PROTOCOL'] ?? 'HTTP/1.1')) . ' 403 Forbidden');
            $this->response->setOutput("Forbidden\n");

            return;
        }

        $this->load->model('extension/nk_quote_request/module/quote_request');

        if (!$this->model_extension_nk_quote_request_module_quote_request->tablesExist()) {
            $this->response->setOutput("Quote tables are not installed.\n");

            return;
        }

        $this->response->setOutput('Expired quotes: ' . $this->model_extension_nk_quote_request_module_quote_request->expireOverdue() . "\n");
    }

    /* ------------------------------------------------------------------ */
    /* Mail                                                                */
    /* ------------------------------------------------------------------ */

    /**
     * Confirmation to the requester + alert to the shop.
     */
    private function notify(int $quote_id): void {
        if (!$this->config->get('config_mail_engine')) {
            return;
        }

        $this->load->language('extension/nk_quote_request/mail/quote_request');

        $quote_info = $this->model_extension_nk_quote_request_module_quote_request->getQuote($quote_id);

        if (!$quote_info) {
            return;
        }

        $store_name = html_entity_decode((string)$this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
        $store_url = (string)$this->config->get('config_url');

        $items = [];

        $total = 0.0;

        foreach ($this->model_extension_nk_quote_request_module_quote_request->getItems($quote_id) as $item) {
            $line = (float)$item['price'] * (int)$item['quantity'];

            $total += $line;

            $decoded = json_decode((string)$item['option'], true);

            $display = [];

            if (is_array($decoded) && isset($decoded['display']) && is_array($decoded['display'])) {
                foreach ($decoded['display'] as $entry) {
                    if (isset($entry['name'], $entry['value'])) {
                        $display[] = $entry['name'] . ': ' . $entry['value'];
                    }
                }
            }

            $items[] = [
                'name'       => htmlspecialchars((string)$item['name'], ENT_QUOTES, 'UTF-8'),
                'model'      => htmlspecialchars((string)$item['model'], ENT_QUOTES, 'UTF-8'),
                'option'     => htmlspecialchars(implode(', ', $display), ENT_QUOTES, 'UTF-8'),
                'quantity'   => (int)$item['quantity'],
                'price'      => $this->currency->format((float)$item['price'], (string)$quote_info['currency_code'], (float)$quote_info['currency_value']),
                'line_total' => $this->currency->format($line, (string)$quote_info['currency_code'], (float)$quote_info['currency_value'])
            ];
        }

        $shared = [
            'quote_id'        => $quote_id,
            'company'         => htmlspecialchars((string)$quote_info['company'], ENT_QUOTES, 'UTF-8'),
            'name'            => htmlspecialchars((string)$quote_info['name'], ENT_QUOTES, 'UTF-8'),
            'email'           => htmlspecialchars((string)$quote_info['email'], ENT_QUOTES, 'UTF-8'),
            'telephone'       => htmlspecialchars((string)$quote_info['telephone'], ENT_QUOTES, 'UTF-8'),
            'comment'         => nl2br(htmlspecialchars((string)$quote_info['comment'], ENT_QUOTES, 'UTF-8')),
            'items'           => $items,
            'total'           => $this->currency->format($total, (string)$quote_info['currency_code'], (float)$quote_info['currency_value']),
            'store'           => $store_name,
            'store_url'       => $store_url,
            'column_product'  => $this->language->get('column_product'),
            'column_model'    => $this->language->get('column_model'),
            'column_quantity' => $this->language->get('column_quantity'),
            'column_price'    => $this->language->get('column_price'),
            'column_total'    => $this->language->get('column_total'),
            'text_total'      => $this->language->get('text_total'),
            'text_ex_tax'     => $this->language->get('text_ex_tax'),
            'text_comment'    => $this->language->get('text_comment'),
            'text_thanks'     => $this->language->get('text_thanks')
        ];

        $mail_option = [
            'parameter'     => $this->config->get('config_mail_parameter'),
            'smtp_hostname' => $this->config->get('config_mail_smtp_hostname'),
            'smtp_username' => $this->config->get('config_mail_smtp_username'),
            'smtp_password' => html_entity_decode((string)$this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8'),
            'smtp_port'     => $this->config->get('config_mail_smtp_port'),
            'smtp_timeout'  => $this->config->get('config_mail_smtp_timeout')
        ];

        // 1. Confirmation to the requester.
        $customer_data = $shared + [
            'text_greeting' => sprintf($this->language->get('text_received_greeting'), $shared['name']),
            'text_intro'    => sprintf($this->language->get('text_received_intro'), $quote_id, $store_name)
        ];

        $mail = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_option);
        $mail->setTo((string)$quote_info['email']);
        $mail->setFrom((string)$this->config->get('config_email'));
        $mail->setSender($store_name);
        $mail->setSubject(sprintf($this->language->get('text_received_subject'), $store_name, $quote_id));
        $mail->setHtml($this->load->view('extension/nk_quote_request/mail/quote_request_received', $customer_data));
        $mail->send();

        // 2. Alert to the shop.
        $notify = trim((string)$this->config->get('module_quote_request_notify_email'));

        if ($notify === '' || !filter_var($notify, FILTER_VALIDATE_EMAIL)) {
            $notify = (string)$this->config->get('config_email');
        }

        if (!filter_var($notify, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        $alert_data = $shared + [
            'text_intro'      => sprintf($this->language->get('text_alert_intro'), $quote_id),
            'text_customer'   => $this->language->get('text_customer'),
            'entry_company'   => $this->language->get('entry_company'),
            'entry_name'      => $this->language->get('entry_name'),
            'entry_email'     => $this->language->get('entry_email'),
            'entry_telephone' => $this->language->get('entry_telephone')
        ];

        $alert = new \Opencart\System\Library\Mail($this->config->get('config_mail_engine'), $mail_option);
        $alert->setTo($notify);
        $alert->setFrom((string)$this->config->get('config_email'));
        $alert->setSender($store_name);
        $alert->setReplyTo((string)$quote_info['email']);
        $alert->setSubject(sprintf($this->language->get('text_alert_subject'), $store_name, $quote_id));
        $alert->setHtml($this->load->view('extension/nk_quote_request/mail/quote_request_alert', $alert_data));
        $alert->send();
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                             */
    /* ------------------------------------------------------------------ */

    private function isEnabled(): bool {
        return (bool)(int)$this->config->get('module_quote_request_status');
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function getBasket(): array {
        $basket = $this->session->data[self::SESSION_KEY] ?? [];

        return is_array($basket) ? $basket : [];
    }

    /**
     * @param array<string, array<string, mixed>> $basket
     */
    private function setBasket(array $basket): void {
        $this->session->data[self::SESSION_KEY] = $basket;
    }

    private function countBasket(): int {
        $total = 0;

        foreach ($this->getBasket() as $line) {
            $total += (int)$line['quantity'];
        }

        return $total;
    }

    /**
     * Stable identity for a basket line: same product + same options + same plan.
     *
     * @param array<mixed> $option
     */
    private function lineKey(int $product_id, array $option, int $subscription_plan_id): string {
        ksort($option);

        return md5($product_id . '|' . json_encode($option) . '|' . $subscription_plan_id);
    }

    /**
     * Snapshot the current unit price (special aware) plus option surcharges, and
     * build a human readable option list for the quote line.
     *
     * @param array<string, mixed> $product_info
     * @param array<mixed>         $option
     *
     * @return array{price: float, display: array<int, array<string, string>>}
     */
    private function priceProduct(array $product_info, array $option): array {
        $price = ($product_info['special'] !== false && $product_info['special'] !== null && $product_info['special'] !== '') ? (float)$product_info['special'] : (float)$product_info['price'];

        $display = [];

        $product_id = !empty($product_info['master_id']) ? (int)$product_info['master_id'] : (int)$product_info['product_id'];

        foreach ($this->model_catalog_product->getOptions($product_id) as $product_option) {
            $product_option_id = (int)$product_option['product_option_id'];

            if (!isset($option[$product_option_id])) {
                continue;
            }

            $value = $option[$product_option_id];

            if (in_array($product_option['type'], ['select', 'radio'], true)) {
                foreach ($product_option['product_option_value'] as $option_value) {
                    if ((int)$option_value['product_option_value_id'] === (int)$value) {
                        $price += ($option_value['price_prefix'] === '-') ? -(float)$option_value['price'] : (float)$option_value['price'];

                        $display[] = ['name' => (string)$product_option['name'], 'value' => (string)$option_value['name']];
                    }
                }
            } elseif ($product_option['type'] === 'checkbox' && is_array($value)) {
                foreach ($product_option['product_option_value'] as $option_value) {
                    if (in_array((string)$option_value['product_option_value_id'], array_map('strval', $value), true)) {
                        $price += ($option_value['price_prefix'] === '-') ? -(float)$option_value['price'] : (float)$option_value['price'];

                        $display[] = ['name' => (string)$product_option['name'], 'value' => (string)$option_value['name']];
                    }
                }
            } else {
                $display[] = ['name' => (string)$product_option['name'], 'value' => oc_substr((string)$value, 0, 120)];
            }
        }

        if ($price < 0) {
            $price = 0.0;
        }

        return ['price' => $price, 'display' => $display];
    }
}
