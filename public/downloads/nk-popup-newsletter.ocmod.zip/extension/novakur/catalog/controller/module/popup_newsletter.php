<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Module;

/**
 * NovaKur Popup Newsletter - storefront endpoints.
 *
 *   extension/novakur/module/popup_newsletter.render     popup markup (used by the footer event)
 *   extension/novakur/module/popup_newsletter.subscribe  POST email - stores the subscriber
 *
 * The popup is injected into every page by extension/novakur/event/popup_newsletter.footer,
 * which the admin controller registers on install.
 */
class PopupNewsletter extends \Opencart\System\Engine\Controller {
	/**
	 * Layout placeholder. The popup is injected sitewide by the footer event.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * @return string
	 */
	public function render(): string {
		if (!(int)$this->config->get('module_popup_newsletter_status')) {
			return '';
		}

		$this->load->language('extension/novakur/module/popup_newsletter');

		$data = $this->language->all();

		// Merchant supplied copy - fall back to the language file when a field is blank.
		$data['heading'] = $this->text('module_popup_newsletter_heading', 'text_default_heading');
		$data['subheading'] = $this->text('module_popup_newsletter_subheading', 'text_default_subheading');
		$data['button_text'] = $this->text('module_popup_newsletter_button_text', 'button_default_subscribe');
		$data['discount_text'] = $this->text('module_popup_newsletter_discount_text', 'text_default_discount');

		$data['show_discount'] = (bool)$this->config->get('module_popup_newsletter_show_discount');

		// Only ever a hex colour: it lands inside a style attribute.
		$bg_color = (string)$this->config->get('module_popup_newsletter_bg_color');

		$data['bg_color'] = preg_match('/^#[0-9A-Fa-f]{3,8}$/', $bg_color) ? $bg_color : '#1E3A8A';

		$data['bg_image'] = '';

		$bg_image = (string)$this->config->get('module_popup_newsletter_bg_image');

		if ($bg_image && is_file(DIR_IMAGE . html_entity_decode($bg_image, ENT_QUOTES, 'UTF-8'))) {
			$this->load->model('tool/image');

			// resize() returns a store URL, so nothing merchant-typed reaches the CSS url().
			// Belt and braces: the value lands inside a style attribute, so refuse anything
			// carrying a quote, parenthesis or semicolon that could break out of url().
			$url = $this->model_tool_image->resize($bg_image, 800, 600);

			if (preg_match('#^[A-Za-z0-9:/._~%?=&+\-]+$#', $url)) {
				$data['bg_image'] = $url;
			}
		}

		$data['subscribe'] = $this->url->link('extension/novakur/module/popup_newsletter.subscribe', 'language=' . $this->config->get('config_language'));

		return $this->load->view('extension/novakur/module/popup_newsletter', $data);
	}

	/**
	 * Store a subscriber and hand back the reward code.
	 *
	 * Deliberately CSRF-tolerant: like checkout/cart.add and account/newsletter in core,
	 * this is an unauthenticated storefront POST that only ever adds the caller's own
	 * address to a mailing list - there is no session-scoped state to forge.
	 *
	 * @return void
	 */
	public function subscribe(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		$json = [];

		if (!(int)$this->config->get('module_popup_newsletter_status')) {
			$json['error'] = $this->language->get('error_disabled');
		}

		$email = isset($this->request->post['email']) ? trim((string)$this->request->post['email']) : '';

		// Column is varchar(96); validate before the database has to.
		if (!isset($json['error']) && (oc_strlen($email) > 96 || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
			$json['error'] = $this->language->get('error_email');
		}

		// One address per session per hour - an open endpoint should not be a free mail spool.
		if (!isset($json['error']) && isset($this->session->data['nk_newsletter_time']) && (time() - (int)$this->session->data['nk_newsletter_time']) < 3600 && (int)($this->session->data['nk_newsletter_count'] ?? 0) >= 5) {
			$json['error'] = $this->language->get('error_throttle');
		}

		if (!isset($json['error'])) {
			$this->load->model('extension/novakur/module/popup_newsletter');

			$this->model_extension_novakur_module_popup_newsletter->addSubscriber([
				'store_id'    => (int)$this->config->get('config_store_id'),
				'customer_id' => (int)$this->customer->getId(),
				'language_id' => (int)$this->config->get('config_language_id'),
				'email'       => $email,
				'ip'          => (string)($this->request->server['REMOTE_ADDR'] ?? '')
			]);

			if (!isset($this->session->data['nk_newsletter_time']) || (time() - (int)$this->session->data['nk_newsletter_time']) >= 3600) {
				$this->session->data['nk_newsletter_time'] = time();
				$this->session->data['nk_newsletter_count'] = 0;
			}

			$this->session->data['nk_newsletter_count'] = (int)($this->session->data['nk_newsletter_count'] ?? 0) + 1;

			$json['success'] = $this->language->get('text_subscribed');

			if ((bool)$this->config->get('module_popup_newsletter_show_discount')) {
				$json['code'] = (string)$this->config->get('module_popup_newsletter_discount_code');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Configured copy, or the language default when the merchant left the field empty.
	 *
	 * @param string $key
	 * @param string $fallback
	 *
	 * @return string
	 */
	private function text(string $key, string $fallback): string {
		$value = trim((string)$this->config->get($key));

		return $value !== '' ? $value : $this->language->get($fallback);
	}
}
