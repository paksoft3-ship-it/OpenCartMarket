<?php
// Text
$_['text_default_heading']     = 'Get 10% off your first order';
$_['text_default_subheading']  = 'Join our newsletter for early access to new arrivals and offers.';
$_['text_default_discount']    = 'Your discount code arrives the moment you subscribe.';
$_['text_subscribed']          = 'Thank you for subscribing!';
$_['text_code']                = 'Your code:';
$_['text_dismiss']             = 'No thanks';
$_['text_placeholder']         = 'Your e-mail address';

// Button
$_['button_default_subscribe'] = 'Subscribe';
$_['button_close']             = 'Close';

// Error
$_['error_email']              = 'Please enter a valid e-mail address!';
$_['error_disabled']           = 'Newsletter sign up is not available right now.';
$_['error_throttle']           = 'Too many sign ups from this session. Please try again later.';
