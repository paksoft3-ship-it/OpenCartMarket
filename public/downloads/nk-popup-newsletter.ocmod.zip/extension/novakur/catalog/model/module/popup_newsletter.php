<?php
namespace Opencart\Catalog\Model\Extension\Novakur\Module;

/**
 * NovaKur Popup Newsletter - storefront model.
 */
class PopupNewsletter extends \Opencart\System\Engine\Model {
	/**
	 * Store a subscriber.
	 *
	 * Every value is escaped or int cast on the way in; the e-mail has already been
	 * validated by the controller.
	 *
	 * @param array<string, mixed> $data
	 *
	 * @return bool true when this is a new subscriber, false when it was already on the list
	 */
	public function addSubscriber(array $data): bool {
		$email = oc_strtolower(trim((string)($data['email'] ?? '')));
		$store_id = (int)($data['store_id'] ?? 0);

		$query = $this->db->query("SELECT `subscriber_id` FROM `" . DB_PREFIX . "nk_newsletter_subscriber` WHERE `email` = '" . $this->db->escape($email) . "' AND `store_id` = '" . $store_id . "' LIMIT 1");

		if ($query->num_rows) {
			return false;
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "nk_newsletter_subscriber` SET `store_id` = '" . $store_id . "', `customer_id` = '" . (int)($data['customer_id'] ?? 0) . "', `language_id` = '" . (int)($data['language_id'] ?? 0) . "', `email` = '" . $this->db->escape($email) . "', `ip` = '" . $this->db->escape(substr((string)($data['ip'] ?? ''), 0, 40)) . "', `status` = '1', `date_added` = NOW()");

		return true;
	}
}
