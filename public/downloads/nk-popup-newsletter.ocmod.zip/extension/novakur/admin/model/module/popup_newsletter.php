<?php
namespace Opencart\Admin\Model\Extension\Novakur\Module;

/**
 * NovaKur Popup Newsletter - admin model.
 *
 * Owns the subscriber table: `<prefix>nk_newsletter_subscriber`.
 */
class PopupNewsletter extends \Opencart\System\Engine\Model {
	/**
	 * @return void
	 */
	public function createTable(): void {
		// varchar(96) matches oc_customer.email, so the composite unique key stays well
		// inside the InnoDB index limit on utf8mb4.
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_newsletter_subscriber` (
			`subscriber_id` int(11) NOT NULL AUTO_INCREMENT,
			`store_id` int(11) NOT NULL DEFAULT '0',
			`customer_id` int(11) NOT NULL DEFAULT '0',
			`language_id` int(11) NOT NULL DEFAULT '0',
			`email` varchar(96) NOT NULL DEFAULT '',
			`ip` varchar(40) NOT NULL DEFAULT '',
			`status` tinyint(1) NOT NULL DEFAULT '1',
			`date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`subscriber_id`),
			UNIQUE KEY `email_store` (`email`,`store_id`),
			KEY `date_added` (`date_added`)
		) ENGINE=InnoDB CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
	}

	/**
	 * @return void
	 */
	public function dropTable(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "nk_newsletter_subscriber`");
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function getSubscribers(array $data = []): array {
		$sql = "SELECT * FROM `" . DB_PREFIX . "nk_newsletter_subscriber` WHERE `store_id` = '" . (int)($data['filter_store_id'] ?? 0) . "'";

		if (!empty($data['filter_email'])) {
			$sql .= " AND `email` LIKE '" . $this->db->escape((string)$data['filter_email'] . '%') . "'";
		}

		$sql .= " ORDER BY `date_added` DESC";

		if (isset($data['start']) || isset($data['limit'])) {
			$start = max(0, (int)($data['start'] ?? 0));
			$limit = (int)($data['limit'] ?? 20);

			if ($limit < 1) {
				$limit = 20;
			}

			$sql .= " LIMIT " . $start . "," . $limit;
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * @param array<string, mixed> $data
	 *
	 * @return int
	 */
	public function getTotalSubscribers(array $data = []): int {
		$sql = "SELECT COUNT(*) AS `total` FROM `" . DB_PREFIX . "nk_newsletter_subscriber` WHERE `store_id` = '" . (int)($data['filter_store_id'] ?? 0) . "'";

		if (!empty($data['filter_email'])) {
			$sql .= " AND `email` LIKE '" . $this->db->escape((string)$data['filter_email'] . '%') . "'";
		}

		$query = $this->db->query($sql);

		return (int)($query->row['total'] ?? 0);
	}

	/**
	 * @param int $subscriber_id
	 *
	 * @return void
	 */
	public function deleteSubscriber(int $subscriber_id): void {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "nk_newsletter_subscriber` WHERE `subscriber_id` = '" . (int)$subscriber_id . "'");
	}
}
