<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

/**
 * NovaKur Popup Newsletter - admin settings and subscriber list.
 */
class PopupNewsletter extends \Opencart\System\Engine\Controller {
	/**
	 * Storefront events registered on install / removed on uninstall.
	 *
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'nk_popup_newsletter_header',
			'description' => 'NovaKur Popup Newsletter: queue the popup stylesheet and script in the page head.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/novakur/event/popup_newsletter.header'
		],
		[
			'code'        => 'nk_popup_newsletter_footer',
			'description' => 'NovaKur Popup Newsletter: inject the popup and its trigger config into every page.',
			'trigger'     => 'catalog/view/common/footer/after',
			'action'      => 'extension/novakur/event/popup_newsletter.footer'
		]
	];

	/**
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			'module_popup_newsletter_status'        => '0',
			'module_popup_newsletter_trigger'       => 'delay',
			'module_popup_newsletter_delay'         => '5',
			'module_popup_newsletter_scroll'        => '50',
			'module_popup_newsletter_cookie_days'   => '7',
			'module_popup_newsletter_heading'       => '',
			'module_popup_newsletter_subheading'    => '',
			'module_popup_newsletter_button_text'   => '',
			'module_popup_newsletter_show_discount' => '1',
			'module_popup_newsletter_discount_text' => '',
			'module_popup_newsletter_discount_code' => '',
			'module_popup_newsletter_bg_color'      => '#1E3A8A',
			'module_popup_newsletter_bg_image'      => ''
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting('module_popup_newsletter', $store_id);

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ($this->language->all() as $key => $value) {
			$data[$key] = $value;
		}

		$this->load->model('tool/image');

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 200, 150);

		if ($data['module_popup_newsletter_bg_image'] && is_file(DIR_IMAGE . html_entity_decode((string)$data['module_popup_newsletter_bg_image'], ENT_QUOTES, 'UTF-8'))) {
			$data['thumb'] = $this->model_tool_image->resize((string)$data['module_popup_newsletter_bg_image'], 200, 150);
		} else {
			$data['thumb'] = $data['placeholder'];
		}

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/novakur/module/popup_newsletter', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['store_id'] = $store_id;

		$data['save'] = $this->url->link('extension/novakur/module/popup_newsletter.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');
		$data['export'] = $this->url->link('extension/novakur/module/popup_newsletter.export', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);

		$data['list'] = $this->getList();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/novakur/module/popup_newsletter', $data));
	}

	/**
	 * Subscriber list (its own ajax-refreshable block).
	 *
	 * @return void
	 */
	public function list(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		$this->response->setOutput($this->getList());
	}

	/**
	 * @return string
	 */
	private function getList(): string {
		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;
		$page = isset($this->request->get['page']) ? max(1, (int)$this->request->get['page']) : 1;

		$limit = (int)$this->config->get('config_pagination_admin');

		if ($limit < 1) {
			$limit = 10;
		}

		$this->load->model('extension/novakur/module/popup_newsletter');

		$filter_data = [
			'filter_store_id' => $store_id,
			'start'           => ($page - 1) * $limit,
			'limit'           => $limit
		];

		$total = $this->model_extension_novakur_module_popup_newsletter->getTotalSubscribers($filter_data);

		$data['subscribers'] = [];

		foreach ($this->model_extension_novakur_module_popup_newsletter->getSubscribers($filter_data) as $result) {
			$data['subscribers'][] = [
				'subscriber_id' => (int)$result['subscriber_id'],
				'email'         => (string)$result['email'],
				'ip'            => (string)$result['ip'],
				'customer_id'   => (int)$result['customer_id'],
				'date_added'    => date($this->language->get('date_format_short'), strtotime((string)$result['date_added']))
			];
		}

		$url = '&store_id=' . $store_id;

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $total,
			'page'  => $page,
			'limit' => $limit,
			'url'   => $this->url->link('extension/novakur/module/popup_newsletter.list', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), $total ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($total - $limit)) ? $total : ((($page - 1) * $limit) + $limit), $total, (int)ceil($total / $limit));

		$data['total'] = $total;
		$data['delete'] = $this->url->link('extension/novakur/module/popup_newsletter.delete', 'user_token=' . $this->session->data['user_token'] . $url);
		$data['action'] = $this->url->link('extension/novakur/module/popup_newsletter.list', 'user_token=' . $this->session->data['user_token'] . $url);

		foreach ($this->language->all() as $key => $value) {
			if (!isset($data[$key])) {
				$data[$key] = $value;
			}
		}

		return $this->load->view('extension/novakur/module/popup_newsletter_list', $data);
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/novakur/module/popup_newsletter')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$trigger = isset($post['module_popup_newsletter_trigger']) ? (string)$post['module_popup_newsletter_trigger'] : 'delay';

		if (!in_array($trigger, ['delay', 'scroll', 'exit'], true)) {
			$json['error']['trigger'] = $this->language->get('error_trigger');
		}

		$delay = isset($post['module_popup_newsletter_delay']) ? (int)$post['module_popup_newsletter_delay'] : 5;

		if ($delay < 0 || $delay > 600) {
			$json['error']['delay'] = $this->language->get('error_delay');
		}

		$scroll = isset($post['module_popup_newsletter_scroll']) ? (int)$post['module_popup_newsletter_scroll'] : 50;

		if ($scroll < 1 || $scroll > 100) {
			$json['error']['scroll'] = $this->language->get('error_scroll');
		}

		$cookie_days = isset($post['module_popup_newsletter_cookie_days']) ? (int)$post['module_popup_newsletter_cookie_days'] : 7;

		if ($cookie_days < 1 || $cookie_days > 365) {
			$json['error']['cookie_days'] = $this->language->get('error_cookie_days');
		}

		$bg_color = isset($post['module_popup_newsletter_bg_color']) ? trim((string)$post['module_popup_newsletter_bg_color']) : '';

		// This value ends up inside a style attribute, so nothing but a hex colour is allowed.
		if ($bg_color !== '' && !preg_match('/^#[0-9A-Fa-f]{3,8}$/', $bg_color)) {
			$json['error']['bg_color'] = $this->language->get('error_bg_color');
		}

		$discount_code = isset($post['module_popup_newsletter_discount_code']) ? trim((string)$post['module_popup_newsletter_discount_code']) : '';

		if ($discount_code !== '' && (oc_strlen($discount_code) > 20 || !preg_match('/^[A-Za-z0-9_-]+$/', $discount_code))) {
			$json['error']['discount_code'] = $this->language->get('error_discount_code');
		}

		if (!empty($post['module_popup_newsletter_show_discount']) && $discount_code === '' && !isset($json['error']['discount_code'])) {
			$json['error']['discount_code'] = $this->language->get('error_discount_required');
		}

		foreach (['heading', 'subheading', 'button_text', 'discount_text'] as $field) {
			if (isset($post['module_popup_newsletter_' . $field]) && oc_strlen((string)$post['module_popup_newsletter_' . $field]) > 255) {
				$json['error'][$field] = $this->language->get('error_length');
			}
		}

		if (!$json) {
			$save = [
				'module_popup_newsletter_status'        => !empty($post['module_popup_newsletter_status']) ? '1' : '0',
				'module_popup_newsletter_trigger'       => $trigger,
				'module_popup_newsletter_delay'         => (string)$delay,
				'module_popup_newsletter_scroll'        => (string)$scroll,
				'module_popup_newsletter_cookie_days'   => (string)$cookie_days,
				'module_popup_newsletter_show_discount' => !empty($post['module_popup_newsletter_show_discount']) ? '1' : '0',
				'module_popup_newsletter_discount_code' => $discount_code,
				'module_popup_newsletter_bg_color'      => $bg_color !== '' ? $bg_color : '#1E3A8A',
				'module_popup_newsletter_bg_image'      => isset($post['module_popup_newsletter_bg_image']) ? (string)$post['module_popup_newsletter_bg_image'] : ''
			];

			// Merchant copy is stored raw and escaped at render time, matching core.
			foreach (['heading', 'subheading', 'button_text', 'discount_text'] as $field) {
				$save['module_popup_newsletter_' . $field] = isset($post['module_popup_newsletter_' . $field]) ? trim((string)$post['module_popup_newsletter_' . $field]) : '';
			}

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_popup_newsletter', $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Remove selected subscribers.
	 *
	 * @return void
	 */
	public function delete(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/novakur/module/popup_newsletter')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$selected = (isset($this->request->post['selected']) && is_array($this->request->post['selected'])) ? $this->request->post['selected'] : [];

		if (!isset($json['error'])) {
			$this->load->model('extension/novakur/module/popup_newsletter');

			foreach ($selected as $subscriber_id) {
				$this->model_extension_novakur_module_popup_newsletter->deleteSubscriber((int)$subscriber_id);
			}

			$json['success'] = $this->language->get('text_delete_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * Download the subscriber list as CSV.
	 *
	 * @return void
	 */
	public function export(): void {
		$this->load->language('extension/novakur/module/popup_newsletter');

		if (!$this->user->hasPermission('access', 'extension/novakur/module/popup_newsletter')) {
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput((string)json_encode(['error' => $this->language->get('error_permission')]));

			return;
		}

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('extension/novakur/module/popup_newsletter');

		$rows = $this->model_extension_novakur_module_popup_newsletter->getSubscribers(['filter_store_id' => $store_id]);

		$handle = fopen('php://temp', 'w+');

		fputcsv($handle, ['email', 'customer_id', 'ip', 'date_added']);

		foreach ($rows as $row) {
			// Neutralise spreadsheet formula injection from a shopper supplied address.
			$email = (string)$row['email'];

			if ($email !== '' && str_contains("=+-@\t\r", $email[0])) {
				$email = "'" . $email;
			}

			fputcsv($handle, [$email, (int)$row['customer_id'], (string)$row['ip'], (string)$row['date_added']]);
		}

		rewind($handle);

		$csv = (string)stream_get_contents($handle);

		fclose($handle);

		$this->response->addHeader('Content-Type: text/csv; charset=utf-8');
		$this->response->addHeader('Content-Disposition: attachment; filename="nk-newsletter-subscribers-' . date('Y-m-d') . '.csv"');
		$this->response->setOutput($csv);
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('extension/novakur/module/popup_newsletter');

		$this->model_extension_novakur_module_popup_newsletter->createTable();

		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('module_popup_newsletter', $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}
	}

	/**
	 * The subscriber table is deliberately left in place - uninstalling a module must not
	 * throw away a mailing list the merchant may still need.
	 *
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('module_popup_newsletter');
	}
}
