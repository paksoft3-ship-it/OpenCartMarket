<?php
// Heading
$_['heading_title']            = 'NovaKur Popup Newsletter';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified NovaKur Popup Newsletter settings!';
$_['text_delete_success']      = 'Success: You have deleted the selected subscribers!';
$_['text_edit']                = 'Edit NovaKur Popup Newsletter';
$_['text_settings']            = 'Settings';
$_['text_appearance']          = 'Appearance';
$_['text_subscribers']         = 'Subscribers';
$_['text_enabled']             = 'Enabled';
$_['text_disabled']            = 'Disabled';
$_['text_yes']                 = 'Yes';
$_['text_no']                  = 'No';
$_['text_none']                = 'No subscribers yet.';
$_['text_guest']               = 'Guest';
$_['text_trigger_delay']       = 'After a delay';
$_['text_trigger_scroll']      = 'After scrolling';
$_['text_trigger_exit']        = 'On exit intent';
$_['text_pagination']          = 'Showing %d to %d of %d (%d Pages)';
$_['text_confirm']             = 'Are you sure?';

// Column
$_['column_email']             = 'E-Mail';
$_['column_customer']          = 'Customer';
$_['column_ip']                = 'IP';
$_['column_date_added']        = 'Date Added';

// Entry
$_['entry_status']             = 'Status';
$_['entry_trigger']            = 'Trigger';
$_['entry_delay']              = 'Delay (seconds)';
$_['entry_scroll']             = 'Scroll depth (%)';
$_['entry_cookie_days']        = 'Suppress for (days)';
$_['entry_heading']            = 'Heading';
$_['entry_subheading']         = 'Sub heading';
$_['entry_button_text']        = 'Button text';
$_['entry_show_discount']      = 'Reward with a discount code';
$_['entry_discount_text']      = 'Discount text';
$_['entry_discount_code']      = 'Discount code';
$_['entry_bg_color']           = 'Background colour';
$_['entry_bg_image']           = 'Background image';

// Help
$_['help_trigger']             = 'When the popup should appear. Exit intent falls back to the delay on touch devices.';
$_['help_delay']               = 'Used by the delay trigger, and as the fallback for exit intent on touch devices.';
$_['help_scroll']              = 'Percentage of the page the visitor must scroll before the popup opens.';
$_['help_cookie_days']         = 'How long a visitor who dismissed or completed the popup is left alone.';
$_['help_copy']                = 'Leave blank to use the built in wording from the language file.';
$_['help_discount_code']       = 'The coupon code shown after a successful subscribe. Letters, digits, - and _ only.';
$_['help_bg_color']            = 'Hex colour, e.g. #1E3A8A.';
$_['help_export']              = 'Download every subscriber for this store as CSV.';

// Button
$_['button_save']              = 'Save';
$_['button_back']              = 'Back';
$_['button_edit']              = 'Edit';
$_['button_clear']             = 'Clear';
$_['button_delete']            = 'Delete';
$_['button_export']            = 'Export CSV';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify this module!';
$_['error_trigger']            = 'Choose one of the supported triggers!';
$_['error_delay']              = 'Delay must be between 0 and 600 seconds!';
$_['error_scroll']             = 'Scroll depth must be between 1 and 100!';
$_['error_cookie_days']        = 'Suppression must be between 1 and 365 days!';
$_['error_bg_color']           = 'Background colour must be a hex value such as #1E3A8A!';
$_['error_discount_code']      = 'Discount code must be up to 20 letters, digits, - or _!';
$_['error_discount_required']  = 'Set a discount code, or turn the reward off!';
$_['error_length']             = 'Must be shorter than 255 characters!';
