<?php
namespace Opencart\Admin\Controller\Extension\NkMobileNav\Module;

/**
 * NovaKur Mobile Bottom Nav
 *
 * Settings namespace: module_mobile_nav_*
 * Route:              extension/nk_mobile_nav/module/mobile_nav
 * Event codes:        nk_mobile_nav_assets / nk_mobile_nav_render
 */
class MobileNav extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_mobile_nav/module/mobile_nav';
    private string $prefix = 'module_mobile_nav';

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_mobile_nav_status'         => '0',
            'module_mobile_nav_item_home'       => '1',
            'module_mobile_nav_item_categories' => '1',
            'module_mobile_nav_item_search'     => '1',
            'module_mobile_nav_item_cart'       => '1',
            'module_mobile_nav_item_account'    => '1',
            'module_mobile_nav_show_labels'     => '1',
            'module_mobile_nav_category_limit'  => '10',
            'module_mobile_nav_breakpoint'      => '768',
            'module_mobile_nav_bg_color'        => '#FFFFFF',
            'module_mobile_nav_icon_color'      => '#4B5563',
            'module_mobile_nav_active_color'    => '#2563EB',
            'module_mobile_nav_badge_color'     => '#DC2626'
        ];
    }

    /**
     * The five toggleable destinations, in the order they are rendered.
     *
     * @return array<int, string>
     */
    private function items(): array {
        return ['home', 'categories', 'search', 'cart', 'account'];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_mobile_nav_assets',
                'description' => 'NovaKur Mobile Bottom Nav: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_mobile_nav/event/mobile_nav.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_mobile_nav_render',
                'description' => 'NovaKur Mobile Bottom Nav: bar markup injected before </body>',
                'trigger'     => 'catalog/view/common/footer/after',
                'action'      => 'extension/nk_mobile_nav/event/mobile_nav.render',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_items',
            'text_appearance',
            'entry_status',
            'entry_item_home',
            'entry_item_categories',
            'entry_item_search',
            'entry_item_cart',
            'entry_item_account',
            'entry_show_labels',
            'entry_category_limit',
            'entry_breakpoint',
            'entry_bg_color',
            'entry_icon_color',
            'entry_active_color',
            'entry_badge_color',
            'help_items',
            'help_item_categories',
            'help_item_cart',
            'help_show_labels',
            'help_category_limit',
            'help_breakpoint',
            'help_bg_color',
            'help_icon_color',
            'help_active_color',
            'help_badge_color',
            'button_save',
            'button_back',
            'error_permission',
            'error_category_limit',
            'error_breakpoint',
            'error_color'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        $toggles = ['status', 'show_labels'];

        foreach ($this->items() as $item) {
            $toggles[] = 'item_' . $item;
        }

        foreach ($toggles as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // --- Numeric ranges --------------------------------------------------
        foreach (['category_limit' => [1, 20], 'breakpoint' => [320, 1200]] as $key => $range) {
            $value = trim((string)($post[$this->prefix . '_' . $key] ?? ''));

            if (!$this->inRange($value, $range[0], $range[1])) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_' . $key);
            } else {
                $save[$this->prefix . '_' . $key] = (string)(int)$value;
            }
        }

        // --- Colours ---------------------------------------------------------
        foreach (['bg_color', 'icon_color', 'active_color', 'badge_color'] as $key) {
            $color = strtoupper(trim((string)($post[$this->prefix . '_' . $key] ?? '')));

            if (!preg_match('/^#[0-9A-F]{6}$/', $color)) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_color');
            } else {
                $save[$this->prefix . '_' . $key] = $color;
            }
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    private function inRange(string $value, int $min, int $max): bool {
        if (!preg_match('/^\d{1,5}$/', $value)) {
            return false;
        }

        $number = (int)$value;

        return $number >= $min && $number <= $max;
    }
}
