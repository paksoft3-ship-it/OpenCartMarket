<?php
// Heading
$_['heading_title']         = 'NovaKur Mobile Bottom Nav';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified NovaKur Mobile Bottom Nav settings!';
$_['text_edit']             = 'Edit NovaKur Mobile Bottom Nav';
$_['text_enabled']          = 'Enabled';
$_['text_disabled']         = 'Disabled';
$_['text_general']          = 'General';
$_['text_items']            = 'Navigation items';
$_['text_appearance']       = 'Appearance';

// Entry
$_['entry_status']          = 'Status';
$_['entry_item_home']       = 'Home';
$_['entry_item_categories'] = 'Categories';
$_['entry_item_search']     = 'Search';
$_['entry_item_cart']       = 'Cart';
$_['entry_item_account']    = 'Account';
$_['entry_show_labels']     = 'Show labels';
$_['entry_category_limit']  = 'Categories in sheet';
$_['entry_breakpoint']      = 'Hide above (px)';
$_['entry_bg_color']        = 'Bar background';
$_['entry_icon_color']      = 'Icon colour';
$_['entry_active_color']    = 'Active colour';
$_['entry_badge_color']     = 'Cart badge colour';

// Help
$_['help_items']            = 'Switch off any item you do not want. The bar divides the width evenly between whatever is left, and hides itself entirely if you switch off all five.';
$_['help_item_categories']  = 'Tapping this opens a slide-up sheet listing your top-level categories.';
$_['help_item_cart']        = 'Carries a live count badge that refreshes whenever a product is added to the cart.';
$_['help_show_labels']      = 'Show a text label under each icon. Turn off for an icon-only bar.';
$_['help_category_limit']   = 'How many top-level categories the slide-up sheet lists. Between 1 and 20.';
$_['help_breakpoint']       = 'The bar is shown on screens up to this width and hidden above it. Between 320 and 1200.';
$_['help_bg_color']         = 'Background colour of the bar and the category sheet.';
$_['help_icon_color']       = 'Colour of the icons and labels at rest.';
$_['help_active_color']     = 'Colour of the item matching the page the shopper is on.';
$_['help_badge_color']      = 'Background colour of the cart count badge.';

// Button
$_['button_save']           = 'Save';
$_['button_back']           = 'Back';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify this module!';
$_['error_category_limit']  = 'Categories in sheet must be between 1 and 20!';
$_['error_breakpoint']      = 'Hide above must be between 320 and 1200 pixels!';
$_['error_color']           = 'Colour must be a 6 digit hex value, e.g. #2563EB!';
