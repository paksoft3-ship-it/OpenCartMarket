<?php
namespace Opencart\Catalog\Controller\Extension\NkMobileNav\Event;

/**
 * NovaKur Mobile Bottom Nav — storefront hooks.
 *
 * assets() catalog/controller/common/header/before → queue CSS/JS
 * render() catalog/view/common/footer/after        → inject the bar before
 *                                                    </body>
 *
 * Both hooks fail open: on unexpected input the storefront output is returned
 * untouched.
 */
class MobileNav extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_mobile_nav/catalog/view/assets/css/mobile_nav.css';
    private const JS  = 'extension/nk_mobile_nav/catalog/view/assets/js/mobile_nav.js';

    /**
     * The bar carries an id, so only the first footer render on a page gets one.
     */
    private static bool $rendered = false;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function render(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || self::$rendered || !is_string($output) || $output === '') {
            return;
        }

        // The module can also be dropped into a layout position; never emit a
        // second bar (duplicate element id).
        if (str_contains($output, 'id="nk-mn"')) {
            return;
        }

        $html = $this->load->controller('extension/nk_mobile_nav/module/mobile_nav');

        if (!is_string($html) || $html === '') {
            return;
        }

        self::$rendered = true;

        // The bar is fixed to the viewport, so it only has to live somewhere
        // inside <body>.
        $position = strripos($output, '</body>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_mobile_nav_status');
    }
}
