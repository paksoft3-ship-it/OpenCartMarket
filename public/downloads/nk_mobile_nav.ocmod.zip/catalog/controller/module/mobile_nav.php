<?php
namespace Opencart\Catalog\Controller\Extension\NkMobileNav\Module;

/**
 * NovaKur Mobile Bottom Nav — storefront module + cart count endpoint.
 *
 * index() renders the bar; count() answers the badge refresh the script fires
 * after it sees an add-to-cart request go past.
 */
class MobileNav extends \Opencart\System\Engine\Controller {
    /**
     * The five destinations, in render order. Each one is individually
     * switchable in the admin.
     *
     * @var array<int, string>
     */
    private const ITEMS = ['home', 'categories', 'search', 'cart', 'account'];

    /**
     * @return string
     */
    public function index(): string {
        if (!$this->enabled()) {
            return '';
        }

        $this->load->language('extension/nk_mobile_nav/module/mobile_nav');

        $language = (string)$this->config->get('config_language');

        $enabled = [];

        foreach (self::ITEMS as $item) {
            if ((int)$this->config->get('module_mobile_nav_item_' . $item)) {
                $enabled[] = $item;
            }
        }

        // Every item switched off means there is nothing to render; emitting an
        // empty fixed bar would still eat screen space.
        if (!$enabled) {
            return '';
        }

        $route = isset($this->request->get['route']) ? (string)$this->request->get['route'] : 'common/home';

        $items = [];

        foreach ($enabled as $item) {
            $items[] = [
                'code'   => $item,
                'label'  => $this->language->get('text_' . $item),
                'href'   => $this->href($item, $language),
                'sheet'  => $item === 'categories',
                'badge'  => $item === 'cart',
                'active' => $this->isActive($item, $route)
            ];
        }

        return $this->load->view('extension/nk_mobile_nav/module/mobile_nav', [
            'items'            => $items,
            'categories'       => in_array('categories', $enabled, true) ? $this->categories($language) : [],
            'show_labels'      => (bool)(int)$this->config->get('module_mobile_nav_show_labels'),
            'breakpoint'       => $this->number('module_mobile_nav_breakpoint', 768, 320, 1200),
            'bg_color'         => $this->color('module_mobile_nav_bg_color', '#FFFFFF'),
            'icon_color'       => $this->color('module_mobile_nav_icon_color', '#4B5563'),
            'active_color'     => $this->color('module_mobile_nav_active_color', '#2563EB'),
            'badge_color'      => $this->color('module_mobile_nav_badge_color', '#DC2626'),
            'cart_count'       => $this->cartCount(),
            'count_url'        => $this->url->link('extension/nk_mobile_nav/module/mobile_nav.count', 'language=' . $language, true),
            'text_categories'  => $this->language->get('text_categories'),
            'text_close'       => $this->language->get('text_close'),
            'text_navigation'  => $this->language->get('text_navigation'),
            'text_cart_items'  => $this->language->get('text_cart_items'),
            'text_no_category' => $this->language->get('text_no_category')
        ]);
    }

    /**
     * Badge refresh endpoint. Deliberately tiny — it is called on every add to
     * cart, so it does no more work than counting the session cart.
     *
     * @return void
     */
    public function count(): void {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->addHeader('X-Robots-Tag: noindex');

        if (!$this->enabled()) {
            $this->response->setOutput(json_encode(['count' => 0]));

            return;
        }

        $this->response->setOutput(json_encode(['count' => $this->cartCount()]));
    }

    /**
     * @return int
     */
    private function cartCount(): int {
        return (int)$this->cart->countProducts();
    }

    /**
     * @param string $item
     * @param string $language
     *
     * @return string
     */
    private function href(string $item, string $language): string {
        switch ($item) {
            case 'home':
                return $this->url->link('common/home', 'language=' . $language);

            case 'search':
                return $this->url->link('product/search', 'language=' . $language);

            case 'cart':
                return $this->url->link('checkout/cart', 'language=' . $language);

            case 'account':
                // Same split the stock header uses: logged-in shoppers land on
                // their account page, guests on the login form.
                return $this->customer->isLogged()
                    ? $this->url->link('account/account', 'language=' . $language, true)
                    : $this->url->link('account/login', 'language=' . $language, true);

            default:
                // "categories" opens the sheet; the href is only a no-JS
                // fallback to a page that lists everything.
                return $this->url->link('product/search', 'language=' . $language);
        }
    }

    /**
     * @param string $item
     * @param string $route
     *
     * @return bool
     */
    private function isActive(string $item, string $route): bool {
        switch ($item) {
            case 'home':
                return $route === 'common/home';

            case 'search':
                return $route === 'product/search';

            case 'cart':
                return $route === 'checkout/cart';

            case 'account':
                return str_starts_with($route, 'account/');

            case 'categories':
                return str_starts_with($route, 'product/category');

            default:
                return false;
        }
    }

    /**
     * Top-level, store-visible, enabled categories for the slide-up sheet.
     * `getCategories(int)` takes an int parent id in 4.1.
     *
     * @param string $language
     *
     * @return array<int, array<string, mixed>>
     */
    private function categories(string $language): array {
        $this->load->model('catalog/category');

        $limit = $this->number('module_mobile_nav_category_limit', 10, 1, 20);
        $show_count = (bool)$this->config->get('config_product_count');

        if ($show_count) {
            $this->load->model('catalog/product');
        }

        $categories = [];

        foreach ($this->model_catalog_category->getCategories(0) as $category) {
            if (count($categories) >= $limit) {
                break;
            }

            $category_id = (int)$category['category_id'];
            $total = '';

            if ($show_count) {
                $total = (string)(int)$this->model_catalog_product->getTotalProducts([
                    'filter_category_id'  => $category_id,
                    'filter_sub_category' => true
                ]);
            }

            $categories[] = [
                'name'  => html_entity_decode((string)$category['name'], ENT_QUOTES, 'UTF-8'),
                'total' => $total,
                'href'  => $this->url->link('product/category', 'language=' . $language . '&path=' . $category_id)
            ];
        }

        return $categories;
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_mobile_nav_status');
    }

    /**
     * Settings are written by a validating save(), but a hand-edited
     * `oc_setting` row must never be able to break out of a style attribute.
     *
     * @param string $key
     * @param string $fallback
     *
     * @return string
     */
    private function color(string $key, string $fallback): string {
        $color = strtoupper(trim((string)$this->config->get($key)));

        return preg_match('/^#[0-9A-F]{6}$/', $color) ? $color : $fallback;
    }

    /**
     * @param string $key
     * @param int    $fallback
     * @param int    $min
     * @param int    $max
     *
     * @return int
     */
    private function number(string $key, int $fallback, int $min, int $max): int {
        $value = $this->config->get($key);

        if ($value === null || $value === '' || !is_numeric($value)) {
            return $fallback;
        }

        $number = (int)$value;

        return ($number >= $min && $number <= $max) ? $number : $fallback;
    }
}
