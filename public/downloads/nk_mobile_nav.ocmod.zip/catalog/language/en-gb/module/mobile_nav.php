<?php
// Item labels
$_['text_home']        = 'Home';
$_['text_categories']  = 'Categories';
$_['text_search']      = 'Search';
$_['text_cart']        = 'Cart';
$_['text_account']     = 'Account';

// Text
$_['text_navigation']  = 'Quick navigation';
$_['text_close']       = 'Close';
$_['text_cart_items']  = 'items in cart';
$_['text_no_category'] = 'No categories yet';
