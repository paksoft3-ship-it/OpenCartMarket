/**
 * NovaKur Mobile Bottom Nav
 *
 * Three jobs:
 *   1. Apply the admin-configured breakpoint (a CSS custom property cannot
 *      drive a media query, so the rules are injected once at runtime).
 *   2. Drive the slide-up category sheet, including focus handling and Escape.
 *   3. Keep the cart badge live by watching OpenCart's own add-to-cart request
 *      rather than any particular theme's markup — the same XHR/fetch hook the
 *      NovaKur Meta Ads pack uses, so it survives custom themes.
 *
 * Everything here is enhancement: with JS off the bar still renders and every
 * item except "categories" is a plain working link.
 */
(function () {
  'use strict';

  var CART_ROUTES = ['checkout/cart.add', 'checkout/cart.remove', 'checkout/cart.edit'];

  function clamp(value, min, max, fallback) {
    var number = parseInt(value, 10);

    if (isNaN(number)) {
      return fallback;
    }

    return Math.min(max, Math.max(min, number));
  }

  /**
   * True when the URL is one of OpenCart's cart mutations. Our own count
   * endpoint is excluded so the hook can never feed itself.
   */
  function isCartChange(url) {
    if (!url || typeof url !== 'string') {
      return false;
    }

    if (url.indexOf('nk_mobile_nav') !== -1) {
      return false;
    }

    for (var i = 0; i < CART_ROUTES.length; i++) {
      if (url.indexOf('route=' + CART_ROUTES[i]) !== -1) {
        return true;
      }
    }

    return false;
  }

  function init() {
    var nav = document.getElementById('nk-mn');

    if (!nav) {
      return;
    }

    applyBreakpoint(nav);

    if (document.body) {
      document.body.classList.add('nk-mn-active');
    }

    setupSheet(nav);
    setupBadge(nav);
  }

  /**
   * The stylesheet ships the 768px default so the bar is right on first paint;
   * this overrides it when the merchant chose something else. Appended to
   * <head> last, so it wins on equal specificity.
   */
  function applyBreakpoint(nav) {
    var raw = window.getComputedStyle(nav).getPropertyValue('--nk-mn-bp');
    var bp = clamp(String(raw).replace('px', '').trim(), 320, 1200, 768);

    if (bp === 768) {
      return;
    }

    var style = document.createElement('style');

    style.textContent =
      '@media (max-width:' + (bp - 0.02) + 'px){' +
      '.nk-mn{display:block}' +
      'body.nk-mn-active{padding-bottom:calc(56px + env(safe-area-inset-bottom,0px))}' +
      '}' +
      '@media (min-width:' + bp + 'px){' +
      '.nk-mn{display:none}' +
      'body.nk-mn-active{padding-bottom:0}' +
      '.nk-mn-sheet{display:none !important}' +
      '}';

    document.head.appendChild(style);
  }

  function setupSheet(nav) {
    var sheet = document.getElementById('nk-mn-sheet');
    var trigger = nav.querySelector('[data-nk-mn-sheet]');

    if (!sheet || !trigger) {
      return;
    }

    var lastFocus = null;

    function open() {
      lastFocus = document.activeElement;
      sheet.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');

      // One frame between unhiding and adding the class, so the panel actually
      // animates in instead of appearing already-open.
      window.requestAnimationFrame(function () {
        sheet.classList.add('is-open');
      });

      var close = sheet.querySelector('.nk-mn-sheet__close');

      if (close) {
        close.focus();
      }
    }

    function close() {
      sheet.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');

      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      window.setTimeout(function () {
        sheet.hidden = true;
      }, reduce ? 0 : 250);

      if (lastFocus && lastFocus.focus) {
        lastFocus.focus();
      }
    }

    trigger.addEventListener('click', function (event) {
      event.preventDefault();

      if (sheet.hidden) {
        open();
      } else {
        close();
      }
    });

    sheet.addEventListener('click', function (event) {
      if (event.target.closest && event.target.closest('[data-nk-mn-close]')) {
        event.preventDefault();
        close();
      }
    });

    document.addEventListener('keydown', function (event) {
      if ((event.key === 'Escape' || event.key === 'Esc') && !sheet.hidden) {
        event.preventDefault();
        close();
      }
    });
  }

  function setupBadge(nav) {
    var badge = document.getElementById('nk-mn-badge');
    var countUrl = nav.getAttribute('data-count-url') || '';

    if (!badge || !countUrl) {
      return;
    }

    var label = nav.getAttribute('data-text-cart-items') || 'items in cart';
    var pending = null;

    function paint(count) {
      var value = parseInt(count, 10);

      if (isNaN(value) || value < 0) {
        value = 0;
      }

      badge.setAttribute('data-count', String(value));
      // 99+ keeps the badge from stretching the icon out of the column.
      badge.textContent = value > 99 ? '99+' : String(value);
      badge.hidden = value < 1;
      badge.setAttribute('aria-label', value + ' ' + label);
    }

    function refresh() {
      if (pending) {
        window.clearTimeout(pending);
      }

      // OpenCart's own header cart refresh fires on the same event; a short
      // delay coalesces a burst of adds into one request.
      pending = window.setTimeout(function () {
        fetch(countUrl, {
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
          .then(function (response) { return response.json(); })
          .then(function (data) { paint(data && data.count); })
          .catch(function () { /* the badge just stays at its last value */ });
      }, 350);
    }

    paint(badge.getAttribute('data-count'));

    // XMLHttpRequest hook — also covers jQuery $.ajax, which is what the stock
    // 4.1 product form and most themes use.
    (function () {
      var open = window.XMLHttpRequest.prototype.open;
      var send = window.XMLHttpRequest.prototype.send;

      window.XMLHttpRequest.prototype.open = function (method, url) {
        this.__nkMnUrl = url;

        return open.apply(this, arguments);
      };

      window.XMLHttpRequest.prototype.send = function () {
        var xhr = this;

        if (isCartChange(xhr.__nkMnUrl)) {
          xhr.addEventListener('load', refresh);
        }

        return send.apply(this, arguments);
      };
    }());

    // fetch hook — for themes that skipped jQuery.
    if (typeof window.fetch === 'function') {
      var originalFetch = window.fetch;

      window.fetch = function (input) {
        var url = (typeof input === 'string') ? input : (input && input.url);
        var promise = originalFetch.apply(this, arguments);

        if (isCartChange(url)) {
          promise.then(refresh).catch(function () { /* the store's own error handling owns this */ });
        }

        return promise;
      };
    }

    // Returning via the back/forward cache would otherwise show a stale count.
    window.addEventListener('pageshow', function (event) {
      if (event.persisted) {
        refresh();
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}());
