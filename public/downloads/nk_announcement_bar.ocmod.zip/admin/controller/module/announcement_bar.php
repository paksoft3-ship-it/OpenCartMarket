<?php
namespace Opencart\Admin\Controller\Extension\NkAnnouncementBar\Module;

class AnnouncementBar extends \Opencart\System\Engine\Controller {
    /**
     * Setting key => default value. Also drives index() and save().
     *
     * @var array<string, string>
     */
    private array $defaults = [
        'module_announcement_bar_status'          => '0',
        'module_announcement_bar_bg_color'        => '#1E3A8A',
        'module_announcement_bar_text_color'      => '#FFFFFF',
        'module_announcement_bar_dismissible'     => '1',
        'module_announcement_bar_rotate'          => '1',
        'module_announcement_bar_rotate_interval' => '4',
        'module_announcement_bar_cookie_hours'    => '24',
        'module_announcement_bar_messages_json'   => '[{"text":"Free shipping on all orders over 50!","link":"","link_text":"","show_countdown":false,"countdown_end":""}]'
    ];

    /**
     * Events registered on install, removed on uninstall.
     *
     * The assets have to be registered before common/header runs, otherwise the
     * <link>/<script> tags are already rendered by the time we get the output.
     *
     * @var array<int, array<string, string>>
     */
    private array $events = [
        [
            'code'        => 'novakur_announcement_bar_assets',
            'description' => 'NovaKur Announcement Bar: registers the storefront CSS/JS.',
            'trigger'     => 'catalog/controller/common/header/before',
            'action'      => 'extension/nk_announcement_bar/event/announcement_bar.assets'
        ],
        [
            'code'        => 'novakur_announcement_bar_render',
            'description' => 'NovaKur Announcement Bar: injects the bar above the storefront header.',
            'trigger'     => 'catalog/view/common/header/after',
            'action'      => 'extension/nk_announcement_bar/event/announcement_bar.view'
        ]
    ];

    public function index(): void {
        $this->load->language('extension/nk_announcement_bar/module/announcement_bar');
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting('module_announcement_bar', $store_id);

        $data = [];

        foreach ($this->defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_messages',
            'entry_status',
            'entry_bg_color',
            'entry_text_color',
            'entry_dismissible',
            'entry_rotate',
            'entry_rotate_interval',
            'entry_cookie_hours',
            'entry_messages',
            'help_bg_color',
            'help_text_color',
            'help_dismissible',
            'help_rotate',
            'help_rotate_interval',
            'help_cookie_hours',
            'help_messages',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_announcement_bar/module/announcement_bar', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/nk_announcement_bar/module/announcement_bar.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_announcement_bar/module/announcement_bar', $data));
    }

    public function save(): void {
        $this->load->language('extension/nk_announcement_bar/module/announcement_bar');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_announcement_bar/module/announcement_bar')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;

        $bg_color = isset($post['module_announcement_bar_bg_color']) ? trim((string)$post['module_announcement_bar_bg_color']) : '';
        $text_color = isset($post['module_announcement_bar_text_color']) ? trim((string)$post['module_announcement_bar_text_color']) : '';

        if (!static::isHexColor($bg_color)) {
            $json['error']['bg-color'] = $this->language->get('error_bg_color');
        }

        if (!static::isHexColor($text_color)) {
            $json['error']['text-color'] = $this->language->get('error_text_color');
        }

        $rotate_interval = isset($post['module_announcement_bar_rotate_interval']) ? (int)$post['module_announcement_bar_rotate_interval'] : 0;

        if ($rotate_interval < 2 || $rotate_interval > 120) {
            $json['error']['rotate-interval'] = $this->language->get('error_rotate_interval');
        }

        $cookie_hours = isset($post['module_announcement_bar_cookie_hours']) ? (int)$post['module_announcement_bar_cookie_hours'] : 0;

        if ($cookie_hours < 1 || $cookie_hours > 8760) {
            $json['error']['cookie-hours'] = $this->language->get('error_cookie_hours');
        }

        $messages_raw = isset($post['module_announcement_bar_messages_json']) ? trim((string)$post['module_announcement_bar_messages_json']) : '';

        if ($messages_raw === '') {
            $messages_raw = $this->defaults['module_announcement_bar_messages_json'];
        }

        $decoded = json_decode($messages_raw, true);

        if (!is_array($decoded) || !$decoded || array_keys($decoded) !== range(0, count($decoded) - 1)) {
            $json['error']['messages'] = $this->language->get('error_messages');

            $messages = [];
        } else {
            $messages = static::sanitizeMessages($decoded);

            if (!$messages) {
                $json['error']['messages'] = $this->language->get('error_messages');
            }
        }

        if (!isset($json['error'])) {
            $save = [
                'module_announcement_bar_status'          => !empty($post['module_announcement_bar_status']) ? '1' : '0',
                'module_announcement_bar_bg_color'        => strtoupper($bg_color),
                'module_announcement_bar_text_color'      => strtoupper($text_color),
                'module_announcement_bar_dismissible'     => !empty($post['module_announcement_bar_dismissible']) ? '1' : '0',
                'module_announcement_bar_rotate'          => !empty($post['module_announcement_bar_rotate']) ? '1' : '0',
                'module_announcement_bar_rotate_interval' => (string)$rotate_interval,
                'module_announcement_bar_cookie_hours'    => (string)$cookie_hours,
                'module_announcement_bar_messages_json'   => (string)json_encode($messages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            ];

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_announcement_bar', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_announcement_bar', $this->defaults);

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);

            $this->model_setting_event->addEvent([
                'code'        => $event['code'],
                'description' => $event['description'],
                'trigger'     => $event['trigger'],
                'action'      => $event['action'],
                'status'      => 1,
                'sort_order'  => 1
            ]);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_announcement_bar');

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }
    }

    /**
     * @param string $value
     *
     * @return bool
     */
    public static function isHexColor(string $value): bool {
        return (bool)preg_match('/^#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/', $value);
    }

    /**
     * Normalises the message list: drops unknown keys, empty rows and unsafe
     * links, and caps the list so a bad paste cannot blow up every page.
     *
     * The catalog event controller carries its own copy of this (the admin
     * namespace is not autoloadable from the storefront) because the settings
     * row can also be edited straight in the database.
     *
     * @param array<int, mixed> $messages
     *
     * @return array<int, array<string, mixed>>
     */
    public static function sanitizeMessages(array $messages): array {
        $clean = [];

        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $text = isset($message['text']) && is_scalar($message['text']) ? trim((string)$message['text']) : '';

            if ($text === '') {
                continue;
            }

            $link = isset($message['link']) && is_scalar($message['link']) ? trim((string)$message['link']) : '';

            // Only same-document paths and http(s) links - blocks javascript:/data: URIs.
            if ($link !== '' && !preg_match('~^(?:https?://[^\s"\'<>]+|/[^\s"\'<>]*|index\.php\?[^\s"\'<>]*)$~i', $link)) {
                $link = '';
            }

            $link_text = isset($message['link_text']) && is_scalar($message['link_text']) ? trim((string)$message['link_text']) : '';

            $countdown_end = isset($message['countdown_end']) && is_scalar($message['countdown_end']) ? trim((string)$message['countdown_end']) : '';

            // Anything Date.parse() can read, restricted to the ISO shape the form emits.
            if ($countdown_end !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2})?)?$/', $countdown_end)) {
                $countdown_end = '';
            }

            $clean[] = [
                'text'           => mb_substr($text, 0, 255),
                'link'           => $link,
                'link_text'      => mb_substr($link_text, 0, 64),
                'show_countdown' => !empty($message['show_countdown']) && $countdown_end !== '',
                'countdown_end'  => $countdown_end
            ];

            if (count($clean) >= 10) {
                break;
            }
        }

        return $clean;
    }
}
