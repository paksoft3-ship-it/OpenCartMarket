<?php
namespace Opencart\Catalog\Controller\Extension\NkAnnouncementBar\Event;

class AnnouncementBar extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_announcement_bar/catalog/view/assets/css/announcement_bar.css';
    private const JS  = 'extension/nk_announcement_bar/catalog/view/assets/js/announcement_bar.js';

    private const DEFAULT_BG    = '#1E3A8A';
    private const DEFAULT_COLOR = '#FFFFFF';

    /**
     * catalog/controller/common/header/before
     *
     * The assets have to be queued before common/header renders, otherwise the
     * <link>/<script> loops in header.twig have already been written out.
     *
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * catalog/view/common/header/after
     *
     * @param string               $route
     * @param array<string, mixed> $args
     * @param mixed                $output
     *
     * @return void
     */
    public function view(string &$route, array &$args, mixed &$output): void {
        if (!$this->enabled() || !is_string($output) || $output === '') {
            return;
        }

        // A theme can legitimately render the header twice (e.g. a print view);
        // only the first copy gets the bar.
        if (str_contains($output, 'id="nk-announcement-bar"')) {
            return;
        }

        $messages = $this->messages();

        if (!$messages) {
            return;
        }

        $this->load->language('extension/nk_announcement_bar/module/announcement_bar');

        $html = $this->load->view('extension/nk_announcement_bar/module/announcement_bar', [
            'bg_color'        => $this->color((string)$this->config->get('module_announcement_bar_bg_color'), self::DEFAULT_BG),
            'text_color'      => $this->color((string)$this->config->get('module_announcement_bar_text_color'), self::DEFAULT_COLOR),
            'dismissible'     => (bool)$this->config->get('module_announcement_bar_dismissible'),
            'messages'        => $messages,
            'rotate'          => (bool)$this->config->get('module_announcement_bar_rotate'),
            'rotate_interval' => $this->clamp((int)$this->config->get('module_announcement_bar_rotate_interval'), 2, 120, 4),
            'cookie_hours'    => $this->clamp((int)$this->config->get('module_announcement_bar_cookie_hours'), 1, 8760, 24),
            'text_link'       => $this->language->get('text_link'),
            'text_close'      => $this->language->get('text_close')
        ]);

        if (str_contains($output, '<header')) {
            // preg_replace() would read $1/\1 inside the rendered bar as
            // backreferences, so the replacement is built in a callback.
            $output = preg_replace_callback('/<header[^>]*>/', static function (array $match) use ($html): string {
                return $html . $match[0];
            }, $output, 1);
        } else {
            $output = $html . $output;
        }
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_announcement_bar_status');
    }

    /**
     * The stored JSON is re-validated here: the settings row can be edited
     * straight in the database, bypassing the admin form's checks.
     *
     * @return array<int, array<string, mixed>>
     */
    private function messages(): array {
        $decoded = json_decode((string)$this->config->get('module_announcement_bar_messages_json'), true);

        if (!is_array($decoded)) {
            return [];
        }

        $clean = [];

        foreach ($decoded as $message) {
            if (!is_array($message)) {
                continue;
            }

            $text = isset($message['text']) && is_scalar($message['text']) ? trim((string)$message['text']) : '';

            if ($text === '') {
                continue;
            }

            $link = isset($message['link']) && is_scalar($message['link']) ? trim((string)$message['link']) : '';

            // Only same-document paths and http(s) links - blocks javascript:/data: URIs.
            if ($link !== '' && !preg_match('~^(?:https?://[^\s"\'<>]+|/[^\s"\'<>]*|index\.php\?[^\s"\'<>]*)$~i', $link)) {
                $link = '';
            }

            $link_text = isset($message['link_text']) && is_scalar($message['link_text']) ? trim((string)$message['link_text']) : '';

            $countdown_end = isset($message['countdown_end']) && is_scalar($message['countdown_end']) ? trim((string)$message['countdown_end']) : '';

            if ($countdown_end !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2})?)?$/', $countdown_end)) {
                $countdown_end = '';
            }

            $clean[] = [
                'text'           => mb_substr($text, 0, 255),
                'link'           => $link,
                'link_text'      => mb_substr($link_text, 0, 64),
                'show_countdown' => !empty($message['show_countdown']) && $countdown_end !== '',
                'countdown_end'  => $countdown_end
            ];

            if (count($clean) >= 10) {
                break;
            }
        }

        return $clean;
    }

    /**
     * @param string $value
     * @param string $fallback
     *
     * @return string
     */
    private function color(string $value, string $fallback): string {
        return preg_match('/^#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/', $value) ? $value : $fallback;
    }

    /**
     * @param int $value
     * @param int $min
     * @param int $max
     * @param int $fallback
     *
     * @return int
     */
    private function clamp(int $value, int $min, int $max, int $fallback): int {
        if ($value < $min || $value > $max) {
            return $fallback;
        }

        return $value;
    }
}
