(function () {
  var CM_PER_INCH = 2.54;

  function init() {
    var root = document.querySelector('[data-nk-sg]');
    if (!root) return;

    var modal = root.querySelector('[data-nk-sg-modal]');
    var backdrop = root.querySelector('[data-nk-sg-backdrop]');
    var opener = root.querySelector('[data-nk-sg-open]');
    var baseUnit = root.getAttribute('data-nk-sg-unit') === 'inch' ? 'inch' : 'cm';
    var unit = baseUnit;
    var lastFocus = null;

    if (!modal || !opener) return;

    /* ---------------------------------------------------------------- modal */

    function open() {
      lastFocus = document.activeElement;
      modal.hidden = false;
      if (backdrop) backdrop.hidden = false;
      opener.setAttribute('aria-expanded', 'true');
      document.addEventListener('keydown', onKeydown);

      var focusable = modal.querySelector('[data-nk-sg-close]');
      if (focusable) focusable.focus();
    }

    function close() {
      modal.hidden = true;
      if (backdrop) backdrop.hidden = true;
      opener.setAttribute('aria-expanded', 'false');
      document.removeEventListener('keydown', onKeydown);

      if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
    }

    function onKeydown(e) {
      if (e.key === 'Escape' || e.key === 'Esc') close();
    }

    opener.addEventListener('click', function () {
      if (modal.hidden) { open(); } else { close(); }
    });

    root.querySelectorAll('[data-nk-sg-close]').forEach(function (b) {
      b.addEventListener('click', close);
    });

    if (backdrop) backdrop.addEventListener('click', close);

    /* ----------------------------------------------------------------- tabs */

    var tabs = Array.prototype.slice.call(root.querySelectorAll('[data-nk-sg-tab]'));
    var panels = Array.prototype.slice.call(root.querySelectorAll('[data-nk-sg-panel]'));

    function selectTab(name) {
      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-nk-sg-tab') === name;

        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.tabIndex = active ? 0 : -1;
      });

      panels.forEach(function (panel) {
        panel.hidden = panel.getAttribute('data-nk-sg-panel') !== name;
      });
    }

    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () { selectTab(tab.getAttribute('data-nk-sg-tab')); });
    });

    /* ----------------------------------------------------------- unit toggle */

    var rows = Array.prototype.slice.call(root.querySelectorAll('[data-nk-sg-row]'));
    var unitButtons = Array.prototype.slice.call(root.querySelectorAll('[data-nk-sg-unit-btn]'));
    var unitLabels = Array.prototype.slice.call(root.querySelectorAll('[data-nk-sg-unit-label]'));
    var cmLabel = '';
    var inchLabel = '';

    unitButtons.forEach(function (b) {
      if (b.getAttribute('data-nk-sg-unit-btn') === 'cm') cmLabel = b.textContent;
      if (b.getAttribute('data-nk-sg-unit-btn') === 'inch') inchLabel = b.textContent;
    });

    // Stored value -> displayed value.
    function convert(value) {
      if (unit === baseUnit) return value;

      return unit === 'inch' ? value / CM_PER_INCH : value * CM_PER_INCH;
    }

    // Displayed value -> stored value, for the calculator inputs.
    function toBase(value) {
      if (unit === baseUnit) return value;

      return unit === 'inch' ? value * CM_PER_INCH : value / CM_PER_INCH;
    }

    function number(el, attr) {
      var raw = parseFloat(el.getAttribute(attr));

      return isNaN(raw) ? null : raw;
    }

    function renderUnit() {
      rows.forEach(function (row) {
        ['chest', 'waist', 'hips'].forEach(function (key) {
          var cell = row.querySelector('[data-nk-sg-cell="' + key + '"]');
          if (!cell) return;

          var value = number(row, 'data-nk-sg-' + key);

          cell.textContent = value === null ? '' : String(Math.round(convert(value) * 10) / 10);
        });
      });

      var label = unit === 'inch' ? inchLabel : cmLabel;

      unitLabels.forEach(function (el) { el.textContent = label; });

      unitButtons.forEach(function (b) {
        b.classList.toggle('is-active', b.getAttribute('data-nk-sg-unit-btn') === unit);
      });
    }

    unitButtons.forEach(function (b) {
      b.addEventListener('click', function () {
        unit = b.getAttribute('data-nk-sg-unit-btn') === 'inch' ? 'inch' : 'cm';
        renderUnit();
      });
    });

    if (unitButtons.length) renderUnit();

    /* ----------------------------------------------------------- calculator */

    var calcButton = root.querySelector('[data-nk-sg-calc]');
    var result = root.querySelector('[data-nk-sg-result]');

    if (calcButton && result && rows.length) {
      calcButton.addEventListener('click', function () {
        var wanted = {};
        var given = 0;

        ['chest', 'waist', 'hips'].forEach(function (key) {
          var input = root.querySelector('[data-nk-sg-input="' + key + '"]');
          if (!input) return;

          var value = parseFloat(input.value);

          if (!isNaN(value) && value > 0) {
            wanted[key] = toBase(value);
            given++;
          }
        });

        if (!given) {
          result.textContent = result.getAttribute('data-nk-sg-empty-tpl') || '';
          return;
        }

        // Best fit = smallest total absolute difference across the
        // measurements the shopper actually filled in.
        var best = null;
        var bestScore = Infinity;

        rows.forEach(function (row) {
          var score = 0;
          var matched = 0;

          Object.keys(wanted).forEach(function (key) {
            var value = number(row, 'data-nk-sg-' + key);

            if (value !== null) {
              score += Math.abs(value - wanted[key]);
              matched++;
            }
          });

          if (matched && score / matched < bestScore) {
            bestScore = score / matched;
            best = row.getAttribute('data-nk-sg-size') || '';
          }
        });

        if (best === null) {
          result.textContent = result.getAttribute('data-nk-sg-empty-tpl') || '';
          return;
        }

        var tpl = result.getAttribute('data-nk-sg-result-tpl') || '{size}';

        // textContent, never innerHTML: the size label is merchant data.
        result.textContent = tpl.replace('{size}', best);
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
