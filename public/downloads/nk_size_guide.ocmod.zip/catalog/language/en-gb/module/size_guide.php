<?php
// Text
$_['text_title']          = 'Size guide';
$_['text_tab_table']      = 'Size chart';
$_['text_tab_measure']    = 'How to measure';
$_['text_tab_calc']       = 'Find my size';
$_['text_size']           = 'Size';
$_['text_chest']          = 'Chest';
$_['text_waist']          = 'Waist';
$_['text_hips']           = 'Hips';
$_['text_measure_intro']  = 'Measure over light clothing, keeping the tape snug but not tight.';
$_['text_measure_chest']  = 'Around the fullest part of the chest, under the arms.';
$_['text_measure_waist']  = 'Around the narrowest part of the waist.';
$_['text_measure_hips']   = 'Around the fullest part of the hips.';
$_['text_calc_intro']     = 'Enter one or more measurements and we will suggest the closest size.';
$_['text_calc_result']    = 'Your recommended size: {size}';
$_['text_calc_empty']     = 'Enter at least one measurement.';
$_['text_cm']             = 'cm';
$_['text_inch']           = 'inch';
$_['text_close']          = 'Close';

// Button
$_['button_size_guide']   = 'Size guide';
$_['button_calculate']    = 'Find my size';
