<?php
// Text
$_['text_title']          = 'Beden Rehberi';
$_['text_tab_table']      = 'Beden Tablosu';
$_['text_tab_measure']    = 'Nasıl Ölçülür';
$_['text_tab_calc']       = 'Bedenimi Bul';
$_['text_size']           = 'Beden';
$_['text_chest']          = 'Göğüs';
$_['text_waist']          = 'Bel';
$_['text_hips']           = 'Kalça';
$_['text_measure_intro']  = 'Ölçüyü ince kıyafet üzerinden, mezurayı sıkmadan alın.';
$_['text_measure_chest']  = 'Göğsün en geniş yerinden, kolların altından ölçün.';
$_['text_measure_waist']  = 'Belin en ince yerinden ölçün.';
$_['text_measure_hips']   = 'Kalçanın en geniş yerinden ölçün.';
$_['text_calc_intro']     = 'Bir veya daha fazla ölçünüzü girin, size en uygun bedeni önerelim.';
$_['text_calc_result']    = 'Önerilen bedeniniz: {size}';
$_['text_calc_empty']     = 'En az bir ölçü girin.';
$_['text_cm']             = 'cm';
$_['text_inch']           = 'inç';
$_['text_close']          = 'Kapat';

// Button
$_['button_size_guide']   = 'Beden Rehberi';
$_['button_calculate']    = 'Bedenimi Bul';
