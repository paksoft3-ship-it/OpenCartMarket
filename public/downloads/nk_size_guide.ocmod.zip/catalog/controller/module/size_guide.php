<?php
namespace Opencart\Catalog\Controller\Extension\NkSizeGuide\Module;

/**
 * NovaKur Size Guide — storefront module.
 *
 * Picks the chart that matches the current product's categories, falling back to
 * the first chart marked "all categories" and then to the first chart defined.
 * Renders nothing at all when there is no chart to show, so the trigger button
 * never opens an empty popup.
 */
class SizeGuide extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_size_guide/catalog/view/assets/css/size_guide.css';
    private const JS  = 'extension/nk_size_guide/catalog/view/assets/js/size_guide.js';

    public function index(): string {
        if (!(int)$this->config->get('module_size_guide_status')) {
            return '';
        }

        $chart = $this->chart($this->productId());

        if (!$chart) {
            return '';
        }

        $this->load->language('extension/nk_size_guide/module/size_guide');

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);

        $unit = (string)$this->config->get('module_size_guide_unit');

        if (!in_array($unit, ['cm', 'inch'], true)) {
            $unit = 'cm';
        }

        $button_text = trim((string)$this->config->get('module_size_guide_button_text'));

        if ($button_text === '') {
            $button_text = $this->language->get('button_size_guide');
        }

        $data = [];

        foreach ([
            'text_title',
            'text_tab_table',
            'text_tab_measure',
            'text_tab_calc',
            'text_size',
            'text_chest',
            'text_waist',
            'text_hips',
            'text_measure_intro',
            'text_measure_chest',
            'text_measure_waist',
            'text_measure_hips',
            'text_calc_intro',
            'text_calc_result',
            'text_calc_empty',
            'text_cm',
            'text_inch',
            'text_close',
            'button_calculate'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['button_text'] = $button_text;
        $data['unit'] = $unit;
        $data['allow_unit_swap'] = (bool)$this->config->get('module_size_guide_allow_unit_swap');
        $data['show_calculator'] = (bool)$this->config->get('module_size_guide_show_calculator');
        $data['chart_title'] = $chart['title'];
        $data['rows'] = $chart['rows'];

        return $this->load->view('extension/nk_size_guide/module/size_guide_popup', $data);
    }

    private function productId(): int {
        if (!isset($this->request->get['route']) || (string)$this->request->get['route'] !== 'product/product') {
            return 0;
        }

        return isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function chart(int $product_id): ?array {
        $charts = $this->config->get('module_size_guide_charts');

        if (!is_array($charts) || !$charts) {
            return null;
        }

        $category_ids = [];

        if ($product_id > 0) {
            // 4.1: Catalog\Model\Catalog\Product::getCategories(int $product_id).
            $this->load->model('catalog/product');

            foreach ($this->model_catalog_product->getCategories($product_id) as $row) {
                $category_ids[(int)$row['category_id']] = true;
            }
        }

        $fallback = null;

        foreach ($charts as $chart) {
            $chart = $this->normalize($chart);

            if (!$chart) {
                continue;
            }

            if ($chart['category_id'] > 0 && isset($category_ids[$chart['category_id']])) {
                return $chart;
            }

            if ($fallback === null && $chart['category_id'] === 0) {
                $fallback = $chart;
            }
        }

        if ($fallback !== null) {
            return $fallback;
        }

        foreach ($charts as $chart) {
            $chart = $this->normalize($chart);

            if ($chart) {
                return $chart;
            }
        }

        return null;
    }

    /**
     * @param mixed $chart
     *
     * @return array<string, mixed>|null
     */
    private function normalize(mixed $chart): ?array {
        if (!is_array($chart) || !is_array($chart['rows'] ?? null) || !$chart['rows']) {
            return null;
        }

        $rows = [];

        foreach ($chart['rows'] as $row) {
            if (!is_array($row) || trim((string)($row['size'] ?? '')) === '') {
                continue;
            }

            $rows[] = [
                'size'  => (string)$row['size'],
                'chest' => $this->measurement($row['chest'] ?? ''),
                'waist' => $this->measurement($row['waist'] ?? ''),
                'hips'  => $this->measurement($row['hips'] ?? '')
            ];
        }

        if (!$rows) {
            return null;
        }

        return [
            'title'       => (string)($chart['title'] ?? ''),
            'category_id' => (int)($chart['category_id'] ?? 0),
            'rows'        => $rows
        ];
    }

    /**
     * Settings rows can be hand-edited in the database, so a measurement is
     * re-checked here before it reaches the table and the JS calculator.
     *
     * @param mixed $value
     */
    private function measurement(mixed $value): string {
        $value = trim((string)$value);

        if ($value === '' || !preg_match('/^\d{1,3}(\.\d{1,2})?$/', $value)) {
            return '';
        }

        return (string)(float)$value;
    }
}
