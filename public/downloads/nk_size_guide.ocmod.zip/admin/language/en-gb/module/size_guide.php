<?php
// Heading
$_['heading_title']         = 'NovaKur Size Guide';

// Text
$_['text_extension']        = 'Extensions';
$_['text_success']          = 'Success: You have modified NovaKur Size Guide settings!';
$_['text_edit']             = 'Edit NovaKur Size Guide';
$_['text_enabled']          = 'Enabled';
$_['text_disabled']         = 'Disabled';
$_['text_general']          = 'General';
$_['text_charts']           = 'Size charts';
$_['text_no_charts']        = 'No size charts yet. Add one to show the size guide on the storefront.';
$_['text_all_categories']   = '— All categories (default chart) —';
$_['text_cm']               = 'cm';
$_['text_inch']             = 'inch';

// Entry
$_['entry_status']          = 'Status';
$_['entry_button_text']     = 'Button caption';
$_['entry_unit']            = 'Measurements entered in';
$_['entry_allow_unit_swap'] = 'Shopper unit toggle';
$_['entry_show_calculator'] = 'Measurement calculator';
$_['entry_chart_title']     = 'Chart name';
$_['entry_chart_category']  = 'Category';
$_['entry_chart_rows']      = 'Rows';

// Help
$_['help_layout']           = 'This is a layout module. After enabling it, add "NovaKur Size Guide" to a layout position on the Product layout under Design > Layouts.';
$_['help_button_text']      = 'Leave empty to use the storefront language default.';
$_['help_unit']             = 'The unit the numbers below are written in. The storefront converts from this unit.';
$_['help_allow_unit_swap']  = 'Lets the shopper switch the table between cm and inch.';
$_['help_show_calculator']  = 'Adds a tab where the shopper enters their measurements and gets a recommended size.';
$_['help_chart_category']   = 'The chart is used for products in this category. Charts set to "All categories" are the fallback.';
$_['help_chart_rows']       = 'One size per line: Size, Chest, Waist, Hips — for example "S, 86, 68, 92". Measurements are optional; up to 30 rows.';

// Button
$_['button_save']           = 'Save';
$_['button_back']           = 'Back';
$_['button_chart_add']      = 'Add chart';
$_['button_remove']         = 'Remove';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify this module!';
$_['error_unit']            = 'Unit must be cm or inch!';
$_['error_chart_title']     = 'Chart name is required!';
$_['error_chart_rows']      = 'Add at least one row, e.g. "S, 86, 68, 92"!';
