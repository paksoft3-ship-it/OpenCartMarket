<?php
$_['heading_title']                  = 'NovaKur Amazon Turkey Feed';

$_['text_extension']                 = 'Extensions';
$_['text_success']                   = 'Success: You have modified Amazon Turkey feed settings!';
$_['text_edit']                      = 'Edit Amazon Turkey Feed';
$_['text_enabled']                   = 'Enabled';
$_['text_disabled']                  = 'Disabled';
$_['text_default_store']             = 'Default Store';
$_['text_cache_cleared']             = 'Feed cache has been cleared.';
$_['text_feed_url']                  = 'Export URL';
$_['text_feed_status']               = 'Export Status';
$_['text_last_generated']            = 'Last Generated';
$_['text_not_generated']             = 'Not generated yet';
$_['text_format_xml']                = 'AmazonEnvelope product XML';
$_['text_format_txt']                = 'Inventory Loader flat file (tab separated)';
$_['text_condition_new']             = 'New';
$_['text_condition_refurbished']     = 'Refurbished';
$_['text_condition_used']            = 'Used - Good';
$_['text_mfn']                       = 'Merchant fulfilled (MFN)';
$_['text_fba']                       = 'Fulfilled by Amazon (FBA)';
$_['text_how_amazon_ingests']        = 'How Amazon ingests this';

$_['entry_status']                   = 'Status';
$_['entry_store']                    = 'Store';
$_['entry_currency']                 = 'Currency';
$_['entry_language']                 = 'Language';
$_['entry_include_out_of_stock']     = 'Include Out Of Stock';
$_['entry_include_tax']              = 'Prices Include KDV';
$_['entry_format']                   = 'Export Format';
$_['entry_merchant_id']              = 'Merchant Identifier';
$_['entry_condition']                = 'Item Condition';
$_['entry_fulfillment']              = 'Fulfillment Channel';
$_['entry_asin_attribute']           = 'ASIN Attribute';
$_['entry_bullet_attribute']         = 'Bullet Point Attribute';
$_['entry_max_products']             = 'Maximum Products';
$_['entry_cache_hours']              = 'Cache Duration (Hours)';
$_['entry_excluded_categories']      = 'Excluded Categories';
$_['entry_token']                    = 'Feed Token';

$_['help_how_amazon_ingests']        = 'Amazon does not fetch a feed URL from your store. Listings reach amazon.com.tr through Seller Central flat file uploads or through the SP-API Feeds endpoints, both of which need authenticated credentials that this extension does not hold. What this extension produces is a structured export of your catalogue: download it from the URL below, then upload it in Seller Central or hand it to whoever runs your SP-API integration. Nothing is submitted to Amazon automatically.';
$_['help_feed_url']                  = 'Download the export from this URL. It contains the export token, so treat it as a secret.';
$_['help_excluded_categories']       = 'Products in the selected categories will be excluded from the export.';
$_['help_include_tax']               = 'Amazon Turkey prices are KDV inclusive. The rate comes from each product\'s OpenCart tax class.';
$_['help_max_products']              = 'Hard cap on the number of products written to the export. 0 means no limit. Products are read from the database in batches of 250 either way.';
$_['help_token']                     = 'Required. The export URL only answers when this token is supplied, otherwise the route returns 404.';
$_['help_format']                    = 'The XML form carries listing data (title, brand, description, bullet points, identifiers). The flat file form carries price and stock for the Inventory Loader. Amazon treats these as two separate uploads.';
$_['help_merchant_id']               = 'Your Seller Central merchant token, written into the AmazonEnvelope header. Letters, digits, hyphen and underscore only.';
$_['help_asin_attribute']            = 'Optional. The OpenCart attribute holding a known ASIN. When set it is exported as the standard product ID; otherwise EAN, UPC, ISBN or JAN from the product identifiers is used.';
$_['help_bullet_attribute']          = 'Optional. The OpenCart attribute holding bullet points, one per line or separated by a pipe. Up to five are exported.';

$_['button_copy']                    = 'Copy';
$_['button_clear_cache']             = 'Clear Cache';
$_['button_regenerate_token']        = 'Regenerate Token';

$_['error_permission']               = 'Warning: You do not have permission to modify Amazon Turkey feed!';
$_['error_currency']                 = 'Select a currency that exists in your store!';
$_['error_token']                    = 'The feed token must be 16 to 64 letters or digits!';
$_['error_merchant_id']              = 'The merchant identifier may only contain letters, digits, hyphen and underscore!';
