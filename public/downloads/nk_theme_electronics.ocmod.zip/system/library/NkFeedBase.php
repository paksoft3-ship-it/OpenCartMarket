<?php
namespace Opencart\System\Library;

abstract class NkFeedBase {
    protected object $registry;
    protected object $db;
    protected object $config;
    protected object $cache;
    protected object $language;
    protected string $cache_dir;

    public function __construct(object $registry) {
        $this->registry = $registry;
        $this->db = $registry->get('db');
        $this->config = $registry->get('config');
        $this->cache = $registry->get('cache');
        $this->language = $registry->get('language');
        $this->cache_dir = rtrim(DIR_CACHE, '/\\') . '/nk_feeds/';
    }

    public function getProducts(array $filters = []): array {
        $language_id = (int)$this->config->get('config_language_id');
        $store_id = (int)$this->config->get('config_store_id');

        if ($store_id < 0) {
            $store_id = 0;
        }

        $conditions = [
            'p.status = 1',
            'pd.language_id = ' . $language_id,
            'p2s.store_id = ' . $store_id
        ];

        if (array_key_exists('status', $filters)) {
            $conditions[] = 'p.status = ' . (int)$filters['status'];
        }

        if (!empty($filters['category_ids']) && is_array($filters['category_ids'])) {
            $category_ids = array_map('intval', $filters['category_ids']);
            $category_ids = array_filter($category_ids, static fn(int $category_id): bool => $category_id > 0);

            if ($category_ids) {
                $conditions[] = 'ptc.category_id IN (' . implode(',', $category_ids) . ')';
            }
        }

        if (!empty($filters['min_quantity'])) {
            $conditions[] = 'p.quantity >= ' . (int)$filters['min_quantity'];
        }

        $sql = "SELECT
                    p.product_id,
                    p.model,
                    p.sku,
                    p.upc,
                    p.ean,
                    p.jan,
                    p.isbn,
                    p.mpn,
                    p.image,
                    p.shipping,
                    p.price,
                    p.quantity,
                    p.minimum,
                    p.subtract,
                    p.stock_status_id,
                    p.weight,
                    p.weight_class_id,
                    p.tax_class_id,
                    p.date_available,
                    pd.name,
                    pd.description,
                    pd.meta_description,
                    m.manufacturer_id,
                    m.name AS manufacturer_name,
                    ss.name AS stock_status,
                    wc.unit AS weight_class,
                    ptc.category_id,
                    cd.name AS category_name
                FROM `" . DB_PREFIX . "product` p
                LEFT JOIN `" . DB_PREFIX . "product_description` pd
                    ON (pd.product_id = p.product_id)
                LEFT JOIN `" . DB_PREFIX . "product_to_store` p2s
                    ON (p2s.product_id = p.product_id)
                LEFT JOIN `" . DB_PREFIX . "product_to_category` ptc
                    ON (ptc.product_id = p.product_id)
                LEFT JOIN `" . DB_PREFIX . "category_description` cd
                    ON (cd.category_id = ptc.category_id AND cd.language_id = pd.language_id)
                LEFT JOIN `" . DB_PREFIX . "manufacturer` m
                    ON (m.manufacturer_id = p.manufacturer_id)
                LEFT JOIN `" . DB_PREFIX . "stock_status` ss
                    ON (ss.stock_status_id = p.stock_status_id AND ss.language_id = pd.language_id)
                LEFT JOIN `" . DB_PREFIX . "weight_class_description` wc
                    ON (wc.weight_class_id = p.weight_class_id AND wc.language_id = pd.language_id)
                WHERE " . implode(' AND ', $conditions) . "
                GROUP BY p.product_id
                ORDER BY p.product_id ASC";

        $query = $this->db->query($sql);
        $products = [];

        foreach ($query->rows as $row) {
            $product_id = (int)$row['product_id'];
            $special = $this->getActiveSpecialPrice($product_id);
            $additional_images = $this->getAdditionalImages($product_id);
            $category_path = '';

            if (!empty($row['category_id'])) {
                $category_path = $this->getCategoryPath((int)$row['category_id'], $language_id);
            }

            $products[] = [
                'product_id' => $product_id,
                'sku' => (string)$row['sku'],
                'ean' => (string)$row['ean'],
                'mpn' => (string)$row['mpn'],
                'model' => (string)$row['model'],
                'name' => (string)$row['name'],
                'description' => (string)$row['description'],
                'meta_description' => (string)$row['meta_description'],
                'price' => (float)$row['price'],
                'special_price' => $special['price'],
                'special_start' => $special['date_start'],
                'special_end' => $special['date_end'],
                'quantity' => (int)$row['quantity'],
                'stock_status' => (string)$row['stock_status'],
                'weight' => (float)$row['weight'],
                'weight_class' => (string)$row['weight_class'],
                'main_image' => (string)$row['image'],
                'additional_images' => $additional_images,
                'category_id' => (int)$row['category_id'],
                'category_name' => (string)$row['category_name'],
                'category_path' => $category_path,
                'manufacturer_id' => (int)$row['manufacturer_id'],
                'manufacturer_name' => (string)$row['manufacturer_name'],
                'href' => $this->getProductUrl($product_id),
                'image_url' => $this->getImageUrl((string)$row['image'])
            ];
        }

        return $products;
    }

    public function getCached(string $feed_id, int $ttl_hours): ?string {
        $cache_file = $this->getCacheFilename($feed_id);

        if (!is_file($cache_file)) {
            return null;
        }

        if ($ttl_hours > 0) {
            $ttl_seconds = $ttl_hours * 3600;

            if ((filemtime($cache_file) + $ttl_seconds) < time()) {
                return null;
            }
        }

        $content = file_get_contents($cache_file);

        return $content === false ? null : $content;
    }

    public function saveCache(string $feed_id, string $content): void {
        if (!is_dir($this->cache_dir)) {
            mkdir($this->cache_dir, 0775, true);
        }

        file_put_contents($this->getCacheFilename($feed_id), $content);
    }

    public function formatPrice(float $price, string $currency_code = ''): string {
        $currency_code = $currency_code ?: (string)$this->config->get('config_currency');

        return number_format($price, 2, '.', '') . ($currency_code ? ' ' . $currency_code : '');
    }

    public function escapeXml(string $value): string {
        return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    public function getImageUrl(string $image_path): string {
        $image_path = trim($image_path);

        if ($image_path === '') {
            $image_path = 'placeholder.png';
        }

        $image_path = ltrim($image_path, '/');

        if (!str_starts_with($image_path, 'catalog/') && !str_starts_with($image_path, 'products/')) {
            $image_path = 'catalog/' . $image_path;
        }

        return rtrim(HTTP_CATALOG, '/') . '/image/' . $image_path;
    }

    public function getProductUrl(int $product_id, string $seo_url = ''): string {
        if ($seo_url !== '') {
            if (str_starts_with($seo_url, 'http://') || str_starts_with($seo_url, 'https://')) {
                return $seo_url;
            }

            return rtrim(HTTP_CATALOG, '/') . '/' . ltrim($seo_url, '/');
        }

        return rtrim(HTTP_CATALOG, '/') . '/index.php?route=product/product&product_id=' . $product_id;
    }

    public function getAvailability(int $quantity): string {
        return $quantity > 0 ? 'in stock' : 'out of stock';
    }

    abstract public function buildFeed(): string;

    protected function getAdditionalImages(int $product_id): array {
        $query = $this->db->query(
            "SELECT image
             FROM `" . DB_PREFIX . "product_image`
             WHERE product_id = '" . $product_id . "'
             ORDER BY sort_order ASC, product_image_id ASC"
        );

        $images = [];

        foreach ($query->rows as $row) {
            if (!empty($row['image'])) {
                $images[] = $this->getImageUrl((string)$row['image']);
            }
        }

        return $images;
    }

    protected function getActiveSpecialPrice(int $product_id): array {
        $customer_group_id = (int)$this->config->get('config_customer_group_id');

        $query = $this->db->query(
            "SELECT price, date_start, date_end
             FROM `" . DB_PREFIX . "product_special`
             WHERE product_id = '" . $product_id . "'
               AND customer_group_id = '" . $customer_group_id . "'
               AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW()))
             ORDER BY priority ASC, price ASC
             LIMIT 1"
        );

        if (!$query->num_rows) {
            return [
                'price' => null,
                'date_start' => '',
                'date_end' => ''
            ];
        }

        return [
            'price' => (float)$query->row['price'],
            'date_start' => (string)$query->row['date_start'],
            'date_end' => (string)$query->row['date_end']
        ];
    }

    protected function getCategoryPath(int $category_id, int $language_id): string {
        $names = [];
        $current_category_id = $category_id;

        while ($current_category_id > 0) {
            $query = $this->db->query(
                "SELECT c.parent_id, cd.name
                 FROM `" . DB_PREFIX . "category` c
                 LEFT JOIN `" . DB_PREFIX . "category_description` cd
                    ON (cd.category_id = c.category_id AND cd.language_id = '" . $language_id . "')
                 WHERE c.category_id = '" . $current_category_id . "'
                 LIMIT 1"
            );

            if (!$query->num_rows) {
                break;
            }

            array_unshift($names, (string)$query->row['name']);
            $current_category_id = (int)$query->row['parent_id'];
        }

        return implode(' > ', $names);
    }

    protected function getCacheFilename(string $feed_id): string {
        $safe_feed_id = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $feed_id) ?: 'feed';

        return $this->cache_dir . $safe_feed_id . '.xml';
    }
}
