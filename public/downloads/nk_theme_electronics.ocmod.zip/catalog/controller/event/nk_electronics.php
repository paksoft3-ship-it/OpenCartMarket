<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeElectronics\Event;

class NkElectronics extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isElectronicsThemeActive()) {
            return;
        }

        if ($route === 'common/header') {
            $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/css/nk-electronics.css';
            $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/js/';
            $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_electronics_primary_color') ?: '#0ea5e9';
            $data['novakur_secondary_color'] = '#0f172a';
            $data['novakur_container_width'] = 1280;
            $data['novakur_base_font'] = 'Inter';
            $data['novakur_heading_font'] = 'Inter';
            $data['nk_electronics_bg_mode'] = (string)$this->config->get('theme_nk_electronics_bg_mode') ?: 'dark';
            $route = 'extension/nk_theme_electronics/common/header_electronics';
        }

        if ($route === 'common/footer') {
            $route = 'extension/nk_theme_electronics/common/footer_electronics';
        }

        if ($route === 'common/home') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/common/home_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/common/home_electronics';
            }

            $this->load->model('catalog/category');
            $categories_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 6);
            $data['categories'] = [];

            foreach ($categories_raw as $category) {
                $data['categories'][] = [
                    'name'  => $category['name'],
                    'href'  => $this->url->link('product/category', 'path=' . $category['category_id']),
                    'image' => $category['image'] ?? '',
                ];
            }

            $this->load->model('catalog/product');
            $this->load->model('tool/image');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');

            $products_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'date_added',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 8
            ]);
            $data['products'] = [];

            foreach ($products_raw as $product) {
                $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));

                $data['products'][] = [
                    'name'    => $product['name'],
                    'href'    => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                    'thumb'   => $product['image'] ? $this->model_tool_image->resize($product['image'], 300, 300) : '',
                    'price'   => $this->currency->format($price, $currency),
                    'special' => $product['special'] ? $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $currency) : false,
                ];
            }

            $best_raw = $this->model_catalog_product->getProducts([
                'sort'  => 'rating',
                'order' => 'DESC',
                'start' => 0,
                'limit' => 4
            ]);
            $data['best_sellers'] = [];

            foreach ($best_raw as $product) {
                $price = $this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax'));

                $data['best_sellers'][] = [
                    'name'    => $product['name'],
                    'href'    => $this->url->link('product/product', 'product_id=' . $product['product_id']),
                    'thumb'   => $product['image'] ? $this->model_tool_image->resize($product['image'], 300, 300) : '',
                    'price'   => $this->currency->format($price, $currency),
                    'special' => $product['special'] ? $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $currency) : false,
                ];
            }
        }

        if ($route === 'product/category') {
            $electronics_template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/product/category_electronics.twig';

            if (is_file($electronics_template)) {
                $route = 'extension/nk_theme_electronics/product/category_electronics';
            }

            // Rebuild $data['products'] as structured objects — OC4 passes rendered HTML strings
            // which our template cannot access via .thumb / .name / .href
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $path      = $this->request->get['path'] ?? '';
            $parts     = explode('_', $path);
            $cat_id    = (int)end($parts);
            $currency  = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w     = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h     = (int)($this->config->get('config_image_product_height') ?: 300);

            $raw = $this->model_catalog_product->getProducts([
                'filter_category_id'         => $cat_id,
                'filter_category_id_with_sub' => true,
                'start'                      => (int)($this->request->get['page'] ?? 1) > 1
                    ? ((int)($this->request->get['page'] - 1) * (int)$this->config->get('config_pagination'))
                    : 0,
                'limit' => (int)($this->config->get('config_pagination') ?: 20),
            ]);

            $data['products'] = [];
            foreach ($raw as $p) {
                $price = $this->tax->calculate($p['price'], $p['tax_class_id'], $this->config->get('config_tax'));
                $data['products'][] = [
                    'product_id' => $p['product_id'],
                    'name'       => $p['name'],
                    'href'       => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                    'thumb'      => $p['image']
                        ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                        : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                    'price'      => $this->currency->format($price, $currency),
                    'special'    => $p['special']
                        ? $this->currency->format($this->tax->calculate($p['special'], $p['tax_class_id'], $this->config->get('config_tax')), $currency)
                        : false,
                ];
            }
        }

        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/product/product_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/product/product_electronics';
            }
        }

        if ($route === 'checkout/cart') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/checkout/cart_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/checkout/cart_electronics';
            }
        }

        if ($route === 'checkout/checkout') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/checkout/checkout_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/checkout/checkout_electronics';
            }
        }

        if ($route === 'account/login') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/account/login_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/account/login_electronics';
            }
        }

        if ($route === 'account/register') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/account/register_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/account/register_electronics';
            }
        }

        if ($route === 'account/account') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/account/account_dashboard_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/account/account_dashboard_electronics';
            }
        }

        if ($route === 'account/order') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/account/account_order_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/account/account_order_electronics';
            }
        }

        if ($route === 'account/wishlist') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/account/wishlist_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/account/wishlist_electronics';
            }
        }

        if ($route === 'product/search') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/product/search_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/product/search_electronics';
            }

            // Rebuild $data['products'] as structured objects for search results
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $search   = $data['search'] ?? ($this->request->get['search'] ?? '');
            $currency = $this->session->data['currency'] ?? $this->config->get('config_currency');
            $img_w    = (int)($this->config->get('config_image_product_width')  ?: 300);
            $img_h    = (int)($this->config->get('config_image_product_height') ?: 300);

            if ($search) {
                $raw = $this->model_catalog_product->getProducts([
                    'filter_name'  => $search,
                    'filter_description' => true,
                    'start'        => 0,
                    'limit'        => (int)($this->config->get('config_pagination') ?: 20),
                ]);

                $data['products'] = [];
                foreach ($raw as $p) {
                    $price = $this->tax->calculate($p['price'], $p['tax_class_id'], $this->config->get('config_tax'));
                    $data['products'][] = [
                        'product_id' => $p['product_id'],
                        'name'       => $p['name'],
                        'href'       => $this->url->link('product/product', 'product_id=' . $p['product_id']),
                        'thumb'      => $p['image']
                            ? $this->model_tool_image->resize($p['image'], $img_w, $img_h)
                            : $this->model_tool_image->resize('placeholder.png', $img_w, $img_h),
                        'price'      => $this->currency->format($price, $currency),
                        'special'    => $p['special']
                            ? $this->currency->format($this->tax->calculate($p['special'], $p['tax_class_id'], $this->config->get('config_tax')), $currency)
                            : false,
                    ];
                }
            }
        }

        if ($route === 'error/not_found') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/error/not_found_electronics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/error/not_found_electronics';
            }
        }
    }

    public function viewAfter(string &$route, array &$data, string &$output): void {
        if (!$this->isElectronicsThemeActive() || $route !== 'common/header' || !$output) {
            return;
        }

        $css = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">'
             . '<link rel="stylesheet" href="' . rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/css/nk-electronics.css">';
        $output = str_replace('</head>', $css . '</head>', $output);
    }

    private function isElectronicsThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');

        return in_array($current_theme, ['nk_electronics', 'novakur_electronics'], true) && (bool)$this->config->get('theme_nk_electronics_status');
    }
}
