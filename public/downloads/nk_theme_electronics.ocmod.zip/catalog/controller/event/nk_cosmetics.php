<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeElectronics\Event;

class NkCosmetics extends \Opencart\System\Engine\Controller {
    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isCosmeticsThemeActive()) {
            return;
        }

        if ($route === 'common/header') {
            $data['novakur_main_css'] = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/css/nk-cosmetics.css';
            $data['nk_js_base'] = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/js/';
            $data['novakur_primary_color'] = (string)$this->config->get('theme_nk_cosmetics_primary_color') ?: '#c4837a';
            $data['novakur_secondary_color'] = '#e8c4bf';
            $data['novakur_container_width'] = 1200;
            $data['novakur_base_font'] = 'Nunito Sans';
            $data['novakur_heading_font'] = 'Cormorant Garamond';
            $route = 'extension/nk_theme_electronics/common/header_cosmetics';
        }

        if ($route === 'common/footer') {
            $route = 'extension/nk_theme_electronics/common/footer_cosmetics';
        }

        if ($route === 'product/category') {
            $cosmetics_template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/product/category_cosmetics.twig';

            if (is_file($cosmetics_template)) {
                $route = 'extension/nk_theme_electronics/product/category_cosmetics';
            }
        }

        if ($route === 'product/product') {
            $template = DIR_EXTENSION . 'nk_theme_electronics/catalog/view/template/product/product_cosmetics.twig';

            if (is_file($template)) {
                $route = 'extension/nk_theme_electronics/product/product_cosmetics';
            }
        }
    }

    public function viewAfter(string &$route, array &$data, string &$output): void {
        if (!$this->isCosmeticsThemeActive() || $route !== 'common/header' || !$output) {
            return;
        }

        $css = '<link rel="preconnect" href="https://fonts.googleapis.com">'
             . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
             . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Nunito+Sans:wght@300;400;600&display=swap">'
             . '<link rel="stylesheet" href="' . rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_electronics/catalog/view/assets/dist/css/nk-cosmetics.css">';
        $output = str_replace('</head>', $css . '</head>', $output);
    }

    private function isCosmeticsThemeActive(): bool {
        $current_theme = (string)$this->config->get('config_theme');

        return in_array($current_theme, ['nk_cosmetics', 'novakur_cosmetics'], true) && (bool)$this->config->get('theme_nk_cosmetics_status');
    }
}
