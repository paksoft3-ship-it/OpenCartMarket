<?php
namespace Opencart\Catalog\Model\Extension\NkThemeElectronics\Payment;

class Iyzico extends \Opencart\System\Engine\Model {

    public function getMethods(array $address = []): array {
        $this->load->language('extension/nk_theme_electronics/payment/iyzico');

        if ($this->cart->hasSubscription()) {
            $status = false;
        } elseif (!$this->config->get('payment_iyzico_api_key') || !$this->config->get('payment_iyzico_secret_key')) {
            $status = false;
        } elseif (!$this->config->get('config_checkout_payment_address')) {
            $status = true;
        } else {
            $status = true;
        }

        $method_data = [];

        if ($status) {
            $method_data = [
                'code'       => 'iyzico',
                'name'       => $this->language->get('heading_title'),
                'option'     => [
                    'iyzico' => [
                        'code' => 'iyzico.iyzico',
                        'name' => $this->language->get('heading_title'),
                    ]
                ],
                'sort_order' => $this->config->get('payment_iyzico_sort_order'),
            ];
        }

        return $method_data;
    }
}
