<?php
$_['heading_title'] = 'iyzico — Kredi/Banka Kartı';
$_['text_title']    = 'Kredi/Banka Kartıyla Öde (iyzico)';
