<?php
$_['heading_title'] = 'iyzico — Credit/Debit Card';
$_['text_title']    = 'Pay by Credit/Debit Card (iyzico)';
