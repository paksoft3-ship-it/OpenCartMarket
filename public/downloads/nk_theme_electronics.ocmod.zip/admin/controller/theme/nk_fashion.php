<?php
namespace Opencart\Admin\Controller\Extension\NkThemeElectronics\Theme;

class NkFashion extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_theme_electronics/theme/nk_fashion';
    private string $setting_code = 'theme_nk_fashion';
    private string $event_code = 'nk_fashion';
    private array $error = [];

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        foreach ([
            'theme_nk_fashion_primary_color',
            'theme_nk_fashion_accent_color'
        ] as $key) {
            if (!$this->isValidHexColor((string)($this->request->post[$key] ?? ''))) {
                $json['error'][$key] = $this->language->get('error_color');
            }
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->setting_code, $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code' => $this->event_code,
            'description' => 'NovaKur Fashion theme hook',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/nk_theme_electronics/event/nk_fashion.view',
            'status' => 1,
            'sort_order' => 1
        ]);

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->event_code);

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->setting_code);
    }

    private function buildFormData(): array {
        $this->load->model('setting/setting');
        $this->load->model('tool/image');

        $settings = $this->model_setting_setting->getSetting($this->setting_code);

        $data = [];

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'text_save',
            'text_back',
            'entry_status',
            'entry_demo_mode',
            'entry_primary_color',
            'entry_accent_color',
            'entry_heading_font',
            'entry_card_hover_image_swap',
            'entry_show_lookbook',
            'entry_show_collection_banner',
            'entry_container_width',
            'help_demo_mode',
            'help_container_width',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $defaults = [
            'theme_nk_fashion_status' => '1',
            'theme_nk_fashion_demo_mode' => '1',
            'theme_nk_fashion_primary_color' => '#18181b',
            'theme_nk_fashion_accent_color' => '#c9a96e',
            'theme_nk_fashion_heading_font' => 'Playfair Display',
            'theme_nk_fashion_card_hover_image_swap' => '1',
            'theme_nk_fashion_show_lookbook' => '1',
            'theme_nk_fashion_show_collection_banner' => '1',
            'theme_nk_fashion_container_width' => '1320'
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['config_theme_nk_fashion_demo_mode'] = $data['theme_nk_fashion_demo_mode'];

        $data['font_options'] = [
            'Playfair Display',
            'Cormorant Garamond',
            'Didact Gothic'
        ];

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
            ]
        ];

        $data['save'] = $this->url->link($this->route . '|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }

    private function isValidHexColor(string $color): bool {
        return (bool)preg_match('/^#(?:[0-9a-fA-F]{3}){1,2}$/', trim($color));
    }
}
