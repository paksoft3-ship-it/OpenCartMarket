<?php
namespace Opencart\Admin\Controller\Extension\NkThemeElectronics\Payment;

class Iyzico extends \Opencart\System\Engine\Controller {

    public function index(): void {
        $this->load->language('extension/nk_theme_electronics/payment/iyzico');
        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token']),
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment'),
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/nk_theme_electronics/payment/iyzico', 'user_token=' . $this->session->data['user_token']),
            ],
        ];

        $data['save'] = $this->url->link('extension/nk_theme_electronics/payment/iyzico.save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        $data['payment_iyzico_api_key']        = $this->config->get('payment_iyzico_api_key');
        $data['payment_iyzico_secret_key']     = $this->config->get('payment_iyzico_secret_key');
        $data['payment_iyzico_sandbox']        = $this->config->get('payment_iyzico_sandbox') ?? '1';
        $data['payment_iyzico_order_status_id'] = $this->config->get('payment_iyzico_order_status_id');
        $data['payment_iyzico_status']         = $this->config->get('payment_iyzico_status');
        $data['payment_iyzico_sort_order']     = $this->config->get('payment_iyzico_sort_order') ?? '1';

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_theme_electronics/payment/iyzico', $data));
    }

    public function save(): void {
        $this->load->language('extension/nk_theme_electronics/payment/iyzico');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/nk_theme_electronics/payment/iyzico')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        if (empty($this->request->post['payment_iyzico_api_key'])) {
            $json['error']['api_key'] = $this->language->get('error_api_key');
        }

        if (empty($this->request->post['payment_iyzico_secret_key'])) {
            $json['error']['secret_key'] = $this->language->get('error_secret_key');
        }

        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_iyzico', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('payment_iyzico', [
            'payment_iyzico_status'          => '0',
            'payment_iyzico_sandbox'         => '1',
            'payment_iyzico_sort_order'      => '1',
            'payment_iyzico_order_status_id' => '2',
            'payment_iyzico_api_key'         => '',
            'payment_iyzico_secret_key'      => '',
        ]);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('payment_iyzico');
    }
}
