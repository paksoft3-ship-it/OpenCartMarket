<?php
$_['heading_title'] = 'NovaKur Cosmetics Theme';
$_['text_edit'] = 'Beauty theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Cosmetics theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_show_before_after'] = 'Show Before / After';
$_['entry_show_shades'] = 'Show Shade Selector';
$_['entry_show_ingredients'] = 'Show Ingredient Accordion';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
