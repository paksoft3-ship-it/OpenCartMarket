<?php
$_['heading_title'] = 'NovaKur Furniture Theme';
$_['text_edit'] = 'Warm furniture theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Furniture theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_spacing_section'] = 'Section Spacing';
$_['entry_show_dimensions'] = 'Show Dimensions Blocks';
$_['entry_show_material_swatches'] = 'Show Material Swatches';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
