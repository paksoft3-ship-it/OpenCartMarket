<?php
$_['heading_title'] = 'NovaKur Electronics Theme';
$_['text_edit'] = 'Technical electronics theme settings';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_home'] = 'Home';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Electronics theme settings saved successfully.';
$_['entry_status'] = 'Status';
$_['entry_primary_color'] = 'Primary Color';
$_['entry_bg_mode'] = 'Background Mode';
$_['entry_show_spec_table'] = 'Show Spec Table';
$_['entry_comparison_enabled'] = 'Enable Comparison UI';
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';
$_['error_permission'] = 'Warning: You do not have permission to modify this theme.';
$_['error_color'] = 'Enter a valid hex color value.';
