<?php
$_['heading_title']                    = 'iyzico Credit/Debit Card';
$_['text_extension']                   = 'Extensions';
$_['text_success']                     = 'Success: iyzico settings have been saved.';
$_['text_edit']                        = 'Edit iyzico Settings';
$_['entry_api_key']                    = 'API Key';
$_['entry_secret_key']                 = 'Secret Key';
$_['entry_sandbox']                    = 'Sandbox (Test Mode)';
$_['entry_order_status']               = 'Order Status (Success)';
$_['entry_status']                     = 'Status';
$_['entry_sort_order']                 = 'Sort Order';
$_['help_sandbox']                     = 'Uses sandbox-api.iyzipay.com for test payments. Disable before going live.';
$_['error_permission']                 = 'Warning: You do not have permission to modify this module!';
$_['error_api_key']                    = 'API Key is required!';
$_['error_secret_key']                 = 'Secret Key is required!';
