<?php
$_['heading_title']                    = 'iyzico Kredi/Banka Kartı';
$_['text_extension']                   = 'Eklentiler';
$_['text_success']                     = 'Başarılı: iyzico ayarları güncellendi.';
$_['text_edit']                        = 'iyzico Ayarlarını Düzenle';
$_['entry_api_key']                    = 'API Anahtarı';
$_['entry_secret_key']                 = 'Gizli Anahtar';
$_['entry_sandbox']                    = 'Test Modu (Sandbox)';
$_['entry_order_status']               = 'Başarılı Sipariş Durumu';
$_['entry_status']                     = 'Durum';
$_['entry_sort_order']                 = 'Sıralama';
$_['help_sandbox']                     = 'Test ödemeleri için sandbox.api.iyzipay.com kullanılır. Canlıya geçmeden önce kapatın.';
$_['error_permission']                 = 'Uyarı: Bu modülü düzenleme izniniz yok!';
$_['error_api_key']                    = 'API Anahtarı zorunludur!';
$_['error_secret_key']                 = 'Gizli Anahtar zorunludur!';
