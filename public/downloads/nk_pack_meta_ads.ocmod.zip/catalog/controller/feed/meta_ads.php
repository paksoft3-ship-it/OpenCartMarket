<?php
namespace Opencart\Catalog\Controller\Extension\NkPackMetaAds\Feed;

/**
 * NovaKur Meta Pixel + CAPI Pack — Meta (Facebook/Instagram) catalog feed.
 *
 * index.php?route=extension/nk_pack_meta_ads/feed/meta_ads&token=xxxx
 *
 * Emits the RSS 2.0 + Google namespace format that Meta Commerce Manager accepts:
 * g:id, g:title, g:description, g:availability, g:condition, g:price, g:link,
 * g:image_link, g:brand (plus sale_price / mpn / product_type when available).
 *
 * g:id is generated with the same rule as the pixel's content_ids so browser
 * events, server events and the catalog all reference the same product key.
 */
class MetaAds extends \Opencart\System\Engine\Controller {
    public function index(): void {
        if (!(int)$this->config->get('module_meta_ads_status') || !(int)$this->config->get('module_meta_ads_feed_status')) {
            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');
            $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
            $this->response->setOutput('Feed disabled');

            return;
        }

        $token    = (string)$this->config->get('module_meta_ads_feed_token');
        $supplied = isset($this->request->get['token']) ? (string)$this->request->get['token'] : '';

        if ($token === '' || !hash_equals($token, $supplied)) {
            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 403 Forbidden');
            $this->response->addHeader('Content-Type: text/plain; charset=utf-8');
            $this->response->setOutput('Forbidden');

            return;
        }

        $cache_hours = (int)$this->config->get('module_meta_ads_feed_cache_hours');

        if (!in_array($cache_hours, [0, 1, 6, 12, 24], true)) {
            $cache_hours = 6;
        }

        $cache_file = DIR_CACHE . 'nk_meta_ads_feed.xml';

        if ($cache_hours > 0 && is_file($cache_file) && (time() - filemtime($cache_file)) < ($cache_hours * 3600)) {
            $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
            $this->response->setOutput((string)file_get_contents($cache_file));

            return;
        }

        $output = $this->build();

        if ($cache_hours > 0) {
            @file_put_contents($cache_file, $output);
        }

        $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
        $this->response->setOutput($output);
    }

    protected function build(): string {
        $language_id = (int)$this->config->get('module_meta_ads_feed_language_id');

        if (!$language_id) {
            $language_id = (int)$this->config->get('config_language_id');
        }

        $currency_code = (string)$this->config->get('module_meta_ads_feed_currency_code');

        if ($currency_code === '' || !$this->currency->has($currency_code)) {
            $currency_code = (string)$this->config->get('config_currency');
        }

        $condition = (string)$this->config->get('module_meta_ads_feed_condition');

        if (!in_array($condition, ['new', 'refurbished', 'used'], true)) {
            $condition = 'new';
        }

        $brand_default = trim((string)$this->config->get('module_meta_ads_feed_brand_default'));
        $store_name    = (string)$this->config->get('config_name');
        $store_url     = rtrim((string)$this->config->get('config_url'), '/') . '/';
        $apply_tax     = (bool)(int)$this->config->get('module_meta_ads_value_tax');
        $id_type       = (string)$this->config->get('module_meta_ads_content_id_type');

        $this->load->model('tool/image');

        $sql = "SELECT `p`.`product_id`, `p`.`model`, `p`.`sku`, `p`.`mpn`, `p`.`ean`, `p`.`upc`, `p`.`price`, `p`.`quantity`, `p`.`image`, `p`.`tax_class_id`, `p`.`manufacturer_id`, `p`.`stock_status_id`, `pd`.`name`, `pd`.`description`,
            (SELECT `md`.`name` FROM `" . DB_PREFIX . "manufacturer` `md` WHERE `md`.`manufacturer_id` = `p`.`manufacturer_id` LIMIT 1) AS `manufacturer`,
            (SELECT (CASE WHEN `ps`.`type` = 'P' THEN (`p`.`price` - (`p`.`price` * (`ps`.`price` / 100))) WHEN `ps`.`type` = 'S' THEN (`p`.`price` - `ps`.`price`) ELSE `ps`.`price` END) FROM `" . DB_PREFIX . "product_discount` `ps` WHERE `ps`.`product_id` = `p`.`product_id` AND `ps`.`customer_group_id` = '" . (int)$this->config->get('config_customer_group_id') . "' AND `ps`.`quantity` = '1' AND `ps`.`special` = '1' AND ((`ps`.`date_start` = '0000-00-00' OR `ps`.`date_start` < NOW()) AND (`ps`.`date_end` = '0000-00-00' OR `ps`.`date_end` > NOW())) ORDER BY `ps`.`priority` ASC, `ps`.`price` ASC LIMIT 1) AS `special`
            FROM `" . DB_PREFIX . "product_to_store` `p2s`
            LEFT JOIN `" . DB_PREFIX . "product` `p` ON (`p`.`product_id` = `p2s`.`product_id`)
            LEFT JOIN `" . DB_PREFIX . "product_description` `pd` ON (`p`.`product_id` = `pd`.`product_id` AND `pd`.`language_id` = '" . (int)$language_id . "')
            WHERE `p2s`.`store_id` = '" . (int)$this->config->get('config_store_id') . "'
            AND `p`.`status` = '1'
            AND `p`.`date_available` <= NOW()
            AND `p`.`master_id` = '0'
            GROUP BY `p`.`product_id`
            ORDER BY `p`.`product_id` ASC";

        $products = $this->db->query($sql)->rows;

        // OpenCart 4.1 also stores identifiers (sku/mpn/ean/upc/gtin) in the
        // product_code table — preload them as a fallback for the legacy columns.
        $codes = $this->loadProductCodes();

        $xml   = [];
        $xml[] = '<?xml version="1.0" encoding="UTF-8"?>';
        $xml[] = '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">';
        $xml[] = '<channel>';
        $xml[] = '<title>' . $this->esc($store_name) . '</title>';
        $xml[] = '<link>' . $this->esc($store_url) . '</link>';
        $xml[] = '<description>' . $this->esc($store_name . ' — Meta product catalog feed') . '</description>';

        foreach ($products as $product) {
            // Meta rejects markup in titles, so decode entities then flatten any HTML.
            $name = trim(strip_tags(html_entity_decode((string)$product['name'], ENT_QUOTES, 'UTF-8')));

            if ($name === '') {
                continue;
            }

            $description = trim(strip_tags(html_entity_decode((string)$product['description'], ENT_QUOTES, 'UTF-8')));
            $description = preg_replace('/\s+/u', ' ', $description);

            if ($description === '') {
                $description = $name;
            }

            $base_price = (float)$product['price'];
            $sale_price = !empty($product['special']) ? (float)$product['special'] : null;

            if ($apply_tax) {
                $base_price = (float)$this->tax->calculate($base_price, (int)$product['tax_class_id'], (bool)$this->config->get('config_tax'));

                if ($sale_price !== null) {
                    $sale_price = (float)$this->tax->calculate($sale_price, (int)$product['tax_class_id'], (bool)$this->config->get('config_tax'));
                }
            }

            $base_price = (float)$this->currency->format($base_price, $currency_code, 0, false);

            if ($sale_price !== null) {
                $sale_price = (float)$this->currency->format($sale_price, $currency_code, 0, false);
            }

            $image_link = '';

            if (!empty($product['image'])) {
                $image_link = $this->model_tool_image->resize((string)$product['image'], 800, 800);
            }

            if ($image_link === '') {
                // Meta rejects items without an image_link, so skip them rather than ship a broken row.
                continue;
            }

            $brand = trim((string)$product['manufacturer']);

            if ($brand === '') {
                $brand = $brand_default !== '' ? $brand_default : $store_name;
            }

            $product_codes = $codes[(int)$product['product_id']] ?? [];

            $sku = trim((string)$product['sku']) ?: (string)($product_codes['sku'] ?? '');

            $item_id = $this->contentId($id_type, (int)$product['product_id'], (string)$product['model'], $sku);

            $xml[] = '<item>';
            $xml[] = '<g:id>' . $this->esc($item_id) . '</g:id>';
            $xml[] = '<g:title>' . $this->cdata(mb_substr($name, 0, 200)) . '</g:title>';
            $xml[] = '<g:description>' . $this->cdata(mb_substr($description, 0, 5000)) . '</g:description>';
            $xml[] = '<g:availability>' . ((int)$product['quantity'] > 0 ? 'in stock' : 'out of stock') . '</g:availability>';
            $xml[] = '<g:condition>' . $condition . '</g:condition>';
            $xml[] = '<g:price>' . number_format($base_price, 2, '.', '') . ' ' . $this->esc($currency_code) . '</g:price>';

            if ($sale_price !== null && $sale_price > 0 && $sale_price < $base_price) {
                $xml[] = '<g:sale_price>' . number_format($sale_price, 2, '.', '') . ' ' . $this->esc($currency_code) . '</g:sale_price>';
            }

            $xml[] = '<g:link>' . $this->esc($this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$product['product_id'], true)) . '</g:link>';
            $xml[] = '<g:image_link>' . $this->esc($image_link) . '</g:image_link>';
            $xml[] = '<g:brand>' . $this->cdata(mb_substr($brand, 0, 100)) . '</g:brand>';

            $mpn = trim((string)$product['mpn']) ?: (string)($product_codes['mpn'] ?? '') ?: trim((string)$product['model']);

            if ($mpn !== '') {
                $xml[] = '<g:mpn>' . $this->esc($mpn) . '</g:mpn>';
            }

            $gtin = trim((string)$product['ean'])
                ?: trim((string)$product['upc'])
                ?: (string)($product_codes['ean'] ?? '')
                ?: (string)($product_codes['upc'] ?? '')
                ?: (string)($product_codes['gtin'] ?? '');

            if ($gtin !== '') {
                $xml[] = '<g:gtin>' . $this->esc($gtin) . '</g:gtin>';
            }

            $category_path = $this->categoryPath((int)$product['product_id'], $language_id);

            if ($category_path !== '') {
                $xml[] = '<g:product_type>' . $this->cdata(mb_substr($category_path, 0, 750)) . '</g:product_type>';
            }

            foreach ($this->additionalImages((int)$product['product_id']) as $extra_image) {
                $xml[] = '<g:additional_image_link>' . $this->esc($extra_image) . '</g:additional_image_link>';
            }

            $xml[] = '</item>';
        }

        $xml[] = '</channel>';
        $xml[] = '</rss>';

        return implode("\n", $xml);
    }

    /**
     * product_id => [code => value]
     *
     * @return array<int, array<string, string>>
     */
    protected function loadProductCodes(): array {
        $map = [];

        $rows = $this->db->query("SELECT `product_id`, `code`, `value` FROM `" . DB_PREFIX . "product_code` WHERE `value` <> ''")->rows;

        foreach ($rows as $row) {
            $map[(int)$row['product_id']][strtolower((string)$row['code'])] = trim((string)$row['value']);
        }

        return $map;
    }

    /**
     * @return array<int, string>
     */
    protected function additionalImages(int $product_id): array {
        $images = [];

        $rows = $this->db->query("SELECT `image` FROM `" . DB_PREFIX . "product_image` WHERE `product_id` = '" . (int)$product_id . "' ORDER BY `sort_order` ASC LIMIT 10")->rows;

        foreach ($rows as $row) {
            if (empty($row['image'])) {
                continue;
            }

            $resized = $this->model_tool_image->resize((string)$row['image'], 800, 800);

            if ($resized !== '') {
                $images[] = $resized;
            }
        }

        return $images;
    }

    protected function categoryPath(int $product_id, int $language_id): string {
        $row = $this->db->query("SELECT `p2c`.`category_id` FROM `" . DB_PREFIX . "product_to_category` `p2c` WHERE `p2c`.`product_id` = '" . (int)$product_id . "' LIMIT 1")->row;

        if (!$row) {
            return '';
        }

        $names = [];
        $path  = $this->db->query("SELECT `cp`.`path_id` FROM `" . DB_PREFIX . "category_path` `cp` WHERE `cp`.`category_id` = '" . (int)$row['category_id'] . "' ORDER BY `cp`.`level` ASC")->rows;

        foreach ($path as $part) {
            $name_row = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$part['path_id'] . "' AND `language_id` = '" . (int)$language_id . "' LIMIT 1")->row;

            if ($name_row) {
                $names[] = trim(html_entity_decode((string)$name_row['name'], ENT_QUOTES, 'UTF-8'));
            }
        }

        return implode(' > ', array_filter($names));
    }

    protected function contentId(string $id_type, int $product_id, string $model, string $sku): string {
        switch ($id_type) {
            case 'model':
                return $model !== '' ? $model : (string)$product_id;
            case 'sku':
                return $sku !== '' ? $sku : (string)$product_id;
            default:
                return (string)$product_id;
        }
    }

    protected function esc(string $value): string {
        return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    protected function cdata(string $value): string {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $value) . ']]>';
    }
}
