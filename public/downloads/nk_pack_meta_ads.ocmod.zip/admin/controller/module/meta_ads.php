<?php
namespace Opencart\Admin\Controller\Extension\NkPackMetaAds\Module;

class MetaAds extends \Opencart\System\Engine\Controller {
    /**
     * Setting key => default. Every key here must exist in the twig form.
     *
     * @var array<string, mixed>
     */
    protected array $defaults = [
        'module_meta_ads_status'                 => '0',
        'module_meta_ads_pixel_id'               => '',
        'module_meta_ads_access_token'           => '',
        'module_meta_ads_test_event_code'        => '',
        'module_meta_ads_api_version'            => 'v21.0',
        'module_meta_ads_capi_status'            => '0',
        'module_meta_ads_capi_mode'              => 'instant',
        'module_meta_ads_capi_user_data'         => '1',
        'module_meta_ads_content_id_type'        => 'product_id',
        'module_meta_ads_value_tax'              => '1',
        'module_meta_ads_debug'                  => '0',
        'module_meta_ads_event_pageview'         => '1',
        'module_meta_ads_event_viewcontent'      => '1',
        'module_meta_ads_event_addtocart'        => '1',
        'module_meta_ads_event_initiatecheckout' => '1',
        'module_meta_ads_event_purchase'         => '1',
        'module_meta_ads_feed_status'            => '0',
        'module_meta_ads_feed_token'             => '',
        'module_meta_ads_feed_language_id'       => '',
        'module_meta_ads_feed_currency_code'     => '',
        'module_meta_ads_feed_condition'         => 'new',
        'module_meta_ads_feed_brand_default'     => '',
        'module_meta_ads_feed_cache_hours'       => '6',
        'module_meta_ads_cron_token'             => ''
    ];

    /* ------------------------------------------------------------------ */
    /* Form                                                                */
    /* ------------------------------------------------------------------ */

    public function index(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');

        $settings = $this->model_setting_setting->getSetting('module_meta_ads', $store_id);

        $data = [];

        foreach ($this->defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key]) && $settings[$key] !== '') {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        if ($data['module_meta_ads_feed_language_id'] === '') {
            $data['module_meta_ads_feed_language_id'] = (string)$this->config->get('config_language_id');
        }

        if ($data['module_meta_ads_feed_currency_code'] === '') {
            $data['module_meta_ads_feed_currency_code'] = (string)$this->config->get('config_currency');
        }

        if ($data['module_meta_ads_feed_token'] === '') {
            $data['module_meta_ads_feed_token'] = $this->makeToken();
        }

        if ($data['module_meta_ads_cron_token'] === '') {
            $data['module_meta_ads_cron_token'] = $this->makeToken();
        }

        // Language strings
        foreach ($this->languageKeys() as $key) {
            $data[$key] = $this->language->get($key);
        }

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        $this->load->model('localisation/currency');
        $data['currencies'] = array_values($this->model_localisation_currency->getCurrencies());

        $catalog_url = $this->catalogUrl($store_id);

        $data['feed_url'] = $catalog_url . 'index.php?route=extension/nk_pack_meta_ads/feed/meta_ads&token=' . rawurlencode((string)$data['module_meta_ads_feed_token']);
        $data['cron_url'] = $catalog_url . 'index.php?route=extension/nk_pack_meta_ads/module/meta_ads.send&token=' . rawurlencode((string)$data['module_meta_ads_cron_token']);

        // Server event queue log
        $log     = [];
        $counts  = ['pending' => 0, 'sent' => 0, 'failed' => 0];
        $statuses = [
            0 => $this->language->get('text_status_pending'),
            1 => $this->language->get('text_status_sent'),
            2 => $this->language->get('text_status_failed')
        ];

        if ($this->tableExists()) {
            $capi   = $this->capi();
            $counts = $capi->getCounts();

            foreach ($capi->getLog(0, 20) as $row) {
                $log[] = [
                    'event_name' => $row['event_name'],
                    'event_id'   => $row['event_id'],
                    'reference'  => $row['reference'],
                    'status'     => $statuses[(int)$row['status']] ?? (string)$row['status'],
                    'status_id'  => (int)$row['status'],
                    'attempts'   => (int)$row['attempts'],
                    'response'   => mb_substr((string)$row['response'], 0, 300),
                    'date_added' => $row['date_added'],
                    'date_sent'  => $row['date_sent'] ?: '-'
                ];
            }
        }

        $data['log']    = $log;
        $data['counts'] = $counts;

        $data['curl_available'] = function_exists('curl_init');

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nk_pack_meta_ads/module/meta_ads', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save']        = $this->url->link('extension/nk_pack_meta_ads/module/meta_ads.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['test']        = $this->url->link('extension/nk_pack_meta_ads/module/meta_ads.test', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['flush']       = $this->url->link('extension/nk_pack_meta_ads/module/meta_ads.flush', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['clear_log']   = $this->url->link('extension/nk_pack_meta_ads/module/meta_ads.clearLog', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['clear_cache'] = $this->url->link('extension/nk_pack_meta_ads/module/meta_ads.clearCache', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back']        = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $cache_file = DIR_CACHE . 'nk_meta_ads_feed.xml';

        $data['feed_generated'] = is_file($cache_file) ? date('Y-m-d H:i:s', (int)filemtime($cache_file)) : $this->language->get('text_not_generated');

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nk_pack_meta_ads/module/meta_ads', $data));
    }

    /* ------------------------------------------------------------------ */
    /* Save                                                                */
    /* ------------------------------------------------------------------ */

    public function save(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/nk_pack_meta_ads/module/meta_ads')) {
            $json['error'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;

        $pixel_id = isset($post['module_meta_ads_pixel_id']) ? preg_replace('/[^0-9]/', '', (string)$post['module_meta_ads_pixel_id']) : '';

        if (!isset($json['error'])) {
            // A pixel id is only required once the module is switched on.
            if (!empty($post['module_meta_ads_status']) && $pixel_id === '') {
                $json['error_pixel_id'] = $this->language->get('error_pixel_id');
            }

            if (!empty($post['module_meta_ads_capi_status']) && trim((string)($post['module_meta_ads_access_token'] ?? '')) === '') {
                $json['error_access_token'] = $this->language->get('error_access_token');
            }

            $api_version = trim((string)($post['module_meta_ads_api_version'] ?? ''));

            if ($api_version !== '' && !preg_match('/^v[0-9]+\.[0-9]+$/', $api_version)) {
                $json['error_api_version'] = $this->language->get('error_api_version');
            }
        }

        if (!isset($json['error']) && !isset($json['error_pixel_id']) && !isset($json['error_access_token']) && !isset($json['error_api_version'])) {
            $save = [];

            $save['module_meta_ads_status']          = !empty($post['module_meta_ads_status']) ? '1' : '0';
            $save['module_meta_ads_pixel_id']        = $pixel_id;
            $save['module_meta_ads_access_token']    = trim((string)($post['module_meta_ads_access_token'] ?? ''));
            $save['module_meta_ads_test_event_code'] = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($post['module_meta_ads_test_event_code'] ?? ''));
            $save['module_meta_ads_api_version']     = preg_match('/^v[0-9]+\.[0-9]+$/', (string)($post['module_meta_ads_api_version'] ?? '')) ? (string)$post['module_meta_ads_api_version'] : 'v21.0';
            $save['module_meta_ads_capi_status']     = !empty($post['module_meta_ads_capi_status']) ? '1' : '0';
            $save['module_meta_ads_capi_mode']       = ((string)($post['module_meta_ads_capi_mode'] ?? '') === 'queue') ? 'queue' : 'instant';
            $save['module_meta_ads_capi_user_data']  = !empty($post['module_meta_ads_capi_user_data']) ? '1' : '0';
            $save['module_meta_ads_value_tax']       = !empty($post['module_meta_ads_value_tax']) ? '1' : '0';
            $save['module_meta_ads_debug']           = !empty($post['module_meta_ads_debug']) ? '1' : '0';

            $id_type = (string)($post['module_meta_ads_content_id_type'] ?? 'product_id');
            $save['module_meta_ads_content_id_type'] = in_array($id_type, ['product_id', 'model', 'sku'], true) ? $id_type : 'product_id';

            foreach (['pageview', 'viewcontent', 'addtocart', 'initiatecheckout', 'purchase'] as $event) {
                $save['module_meta_ads_event_' . $event] = !empty($post['module_meta_ads_event_' . $event]) ? '1' : '0';
            }

            $save['module_meta_ads_feed_status'] = !empty($post['module_meta_ads_feed_status']) ? '1' : '0';

            $feed_token = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($post['module_meta_ads_feed_token'] ?? ''));
            $save['module_meta_ads_feed_token'] = strlen($feed_token) >= 16 ? $feed_token : $this->makeToken();

            $cron_token = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($post['module_meta_ads_cron_token'] ?? ''));
            $save['module_meta_ads_cron_token'] = strlen($cron_token) >= 16 ? $cron_token : $this->makeToken();

            $save['module_meta_ads_feed_language_id'] = (string)(int)($post['module_meta_ads_feed_language_id'] ?? $this->config->get('config_language_id'));

            $this->load->model('localisation/currency');

            $currencies    = $this->model_localisation_currency->getCurrencies();
            $currency_code = (string)($post['module_meta_ads_feed_currency_code'] ?? '');
            $save['module_meta_ads_feed_currency_code'] = isset($currencies[$currency_code]) ? $currency_code : (string)$this->config->get('config_currency');

            $condition = (string)($post['module_meta_ads_feed_condition'] ?? 'new');
            $save['module_meta_ads_feed_condition'] = in_array($condition, ['new', 'refurbished', 'used'], true) ? $condition : 'new';

            $save['module_meta_ads_feed_brand_default'] = mb_substr(trim(strip_tags((string)($post['module_meta_ads_feed_brand_default'] ?? ''))), 0, 100);

            $cache_hours = (string)($post['module_meta_ads_feed_cache_hours'] ?? '6');
            $save['module_meta_ads_feed_cache_hours'] = in_array($cache_hours, ['0', '1', '6', '12', '24'], true) ? $cache_hours : '6';

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_meta_ads', $save, $store_id);

            // Settings changed -> the cached feed is stale.
            $this->deleteFeedCache();

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Conversions API tools                                               */
    /* ------------------------------------------------------------------ */

    /**
     * Send a single TestEvent straight to Meta so the merchant can confirm the
     * access token works without waiting for a real order.
     */
    public function test(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/nk_pack_meta_ads/module/meta_ads')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            $capi = $this->capi();

            if ($capi->getPixelId() === '' || $capi->getAccessToken() === '') {
                $json['error'] = $this->language->get('error_test_config');
            } elseif (!function_exists('curl_init')) {
                $json['error'] = $this->language->get('error_curl');
            } else {
                $event_id = $capi->makeEventId('PageView');

                $event = $capi->buildEvent(
                    'PageView',
                    $event_id,
                    [],
                    ['client_user_agent' => 'NovaKur-MetaAds/1.0 (connection test)'],
                    (string)$this->config->get('config_url')
                );

                $result = $capi->post([$event]);

                if ($result['ok']) {
                    $json['success'] = sprintf($this->language->get('text_test_success'), $event_id);
                } else {
                    $json['error'] = $this->language->get('text_test_failed') . ' ' . $result['body'];
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Send everything currently pending in the queue.
     */
    public function flush(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/nk_pack_meta_ads/module/meta_ads')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            if (!$this->tableExists()) {
                $json['error'] = $this->language->get('error_no_table');
            } else {
                $capi = $this->capi();

                if (!$capi->isEnabled()) {
                    $json['error'] = $this->language->get('error_capi_disabled');
                } else {
                    $report = $capi->flush(100);

                    $json['success'] = sprintf($this->language->get('text_flush_result'), $report['sent'], $report['failed']) . ' ' . $report['message'];
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function clearLog(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/nk_pack_meta_ads/module/meta_ads')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            if ($this->tableExists()) {
                $this->capi()->clearLog();
            }

            $json['success'] = $this->language->get('text_log_cleared');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function clearCache(): void {
        $this->load->language('extension/nk_pack_meta_ads/module/meta_ads');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/nk_pack_meta_ads/module/meta_ads')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            $this->deleteFeedCache();

            $json['success'] = $this->language->get('text_cache_cleared');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /* ------------------------------------------------------------------ */
    /* Install / uninstall                                                 */
    /* ------------------------------------------------------------------ */

    public function install(): void {
        $this->load->model('setting/setting');

        $defaults = $this->defaults;

        $defaults['module_meta_ads_feed_language_id']   = (string)$this->config->get('config_language_id');
        $defaults['module_meta_ads_feed_currency_code'] = (string)$this->config->get('config_currency');
        $defaults['module_meta_ads_feed_token']         = $this->makeToken();
        $defaults['module_meta_ads_cron_token']         = $this->makeToken();

        $this->model_setting_setting->editSetting('module_meta_ads', $defaults);

        // Server event queue
        $this->capi()->createTable();

        // Storefront event hooks
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('novakur_meta_ads');
        $this->model_setting_event->deleteEventByCode('novakur_meta_ads_purchase');

        $this->model_setting_event->addEvent([
            'code'        => 'novakur_meta_ads',
            'description' => 'NovaKur Meta Pixel — injects the pixel base code and page events.',
            'trigger'     => 'catalog/view/common/header/after',
            'action'      => 'extension/nk_pack_meta_ads/event/meta_ads.header',
            'status'      => 1,
            'sort_order'  => 1
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'novakur_meta_ads_purchase',
            'description' => 'NovaKur Meta Pixel — captures the order on checkout success for the Purchase event.',
            'trigger'     => 'catalog/controller/checkout/success/before',
            'action'      => 'extension/nk_pack_meta_ads/event/meta_ads.orderSuccess',
            'status'      => 1,
            'sort_order'  => 1
        ]);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('novakur_meta_ads');
        $this->model_setting_event->deleteEventByCode('novakur_meta_ads_purchase');

        $this->capi()->dropTable();

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_meta_ads');

        $this->deleteFeedCache();
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                             */
    /* ------------------------------------------------------------------ */

    protected function capi(): \Opencart\System\Library\Extension\NkPackMetaAds\MetaAds {
        return new \Opencart\System\Library\Extension\NkPackMetaAds\MetaAds($this->registry);
    }

    protected function tableExists(): bool {
        $table = DB_PREFIX . 'nk_meta_ads_event';

        return (bool)$this->db->query("SHOW TABLES LIKE '" . $this->db->escape($table) . "'")->num_rows;
    }

    protected function makeToken(): string {
        try {
            return bin2hex(random_bytes(16));
        } catch (\Exception $e) {
            return md5(uniqid('nk_meta_ads', true));
        }
    }

    protected function deleteFeedCache(): void {
        $cache_file = DIR_CACHE . 'nk_meta_ads_feed.xml';

        if (is_file($cache_file)) {
            @unlink($cache_file);
        }
    }

    protected function catalogUrl(int $store_id): string {
        if ($store_id) {
            $this->load->model('setting/store');

            $store_info = $this->model_setting_store->getStore($store_id);

            if ($store_info && !empty($store_info['url'])) {
                return rtrim(html_entity_decode((string)$store_info['url'], ENT_QUOTES, 'UTF-8'), '/') . '/';
            }
        }

        return rtrim(html_entity_decode((string)$this->config->get('config_url'), ENT_QUOTES, 'UTF-8'), '/') . '/';
    }

    /**
     * @return array<int, string>
     */
    protected function languageKeys(): array {
        return [
            'heading_title', 'text_edit', 'text_enabled', 'text_disabled', 'text_yes', 'text_no',
            'text_tab_general', 'text_tab_events', 'text_tab_feed', 'text_tab_log', 'text_tab_guide',
            'text_instant', 'text_queue', 'text_not_generated', 'text_none',
            'text_status_pending', 'text_status_sent', 'text_status_failed',
            'text_guide_intro', 'text_guide_step1', 'text_guide_step2', 'text_guide_step3',
            'text_guide_step4', 'text_guide_step5', 'text_guide_step6', 'text_guide_limits',
            'text_events_intro', 'text_capi_intro', 'text_feed_intro',
            'entry_status', 'entry_pixel_id', 'entry_access_token', 'entry_test_event_code',
            'entry_api_version', 'entry_capi_status', 'entry_capi_mode', 'entry_capi_user_data',
            'entry_content_id_type', 'entry_value_tax', 'entry_debug',
            'entry_event_pageview', 'entry_event_viewcontent', 'entry_event_addtocart',
            'entry_event_initiatecheckout', 'entry_event_purchase',
            'entry_feed_status', 'entry_feed_token', 'entry_feed_url', 'entry_feed_language',
            'entry_feed_currency', 'entry_feed_condition', 'entry_feed_brand_default',
            'entry_feed_cache_hours', 'entry_cron_url',
            'help_pixel_id', 'help_access_token', 'help_test_event_code', 'help_api_version',
            'help_capi_status', 'help_capi_mode', 'help_capi_user_data', 'help_content_id_type',
            'help_value_tax', 'help_debug', 'help_feed_url', 'help_cron_url', 'help_feed_cache_hours',
            'help_feed_brand_default', 'help_addtocart',
            'column_event', 'column_event_id', 'column_reference', 'column_status',
            'column_attempts', 'column_response', 'column_date_added', 'column_date_sent',
            'button_save', 'button_back', 'button_copy', 'button_test', 'button_flush',
            'button_clear_log', 'button_clear_cache', 'button_regenerate',
            'text_pending', 'text_sent', 'text_failed', 'text_curl_missing', 'text_last_generated'
        ];
    }
}
