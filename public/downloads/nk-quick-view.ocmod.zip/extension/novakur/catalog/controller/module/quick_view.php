<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Module;

class QuickView extends \Opencart\System\Engine\Controller {
    /**
     * Animations shipped in quick_view.css.
     *
     * @var array<int, string>
     */
    private array $animations = ['fade', 'zoom', 'slide'];

    public function index(): string {
        if (!(int)$this->config->get('module_quick_view_status')) {
            return '';
        }

        $this->load->language('extension/novakur/module/quick_view');

        $this->document->addStyle('extension/novakur/catalog/view/assets/css/quick_view.css');
        $this->document->addScript('extension/novakur/catalog/view/assets/js/quick_view.js');

        $animation = (string)$this->config->get('module_quick_view_animation');

        if (!in_array($animation, $this->animations, true)) {
            $animation = 'fade';
        }

        $language = (string)$this->config->get('config_language');

        return $this->load->view('extension/novakur/module/quick_view_modal', [
            'animation'      => $animation,
            'show_reviews'   => (bool)$this->config->get('module_quick_view_show_reviews') && (bool)$this->config->get('config_review_status'),
            // true = leave "&" un-escaped; the template escapes these once, as
            // attribute values, on the way out.
            'product_url'    => $this->url->link('extension/novakur/module/quick_view.getProduct', 'language=' . $language, true),
            'cart_add_url'   => $this->url->link('checkout/cart.add', 'language=' . $language, true),
            'cart_info_url'  => $this->url->link('common/cart.info', 'language=' . $language, true),
            'text_quick_view' => $this->language->get('text_quick_view'),
            'text_close'      => $this->language->get('text_close'),
            'text_add_cart'   => $this->language->get('text_add_cart'),
            'text_options'    => $this->language->get('text_options'),
            'text_details'    => $this->language->get('text_details'),
            'text_loading'    => $this->language->get('text_loading'),
            'text_error'      => $this->language->get('text_error')
        ]);
    }

    public function getProduct(): void {
        $this->load->language('extension/novakur/module/quick_view');

        $json = [];

        if (!(int)$this->config->get('module_quick_view_status')) {
            $json['error'] = $this->language->get('text_error');

            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));

            return;
        }

        $product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;

        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $product = $this->model_catalog_product->getProduct($product_id);

        if (!$product) {
            $json['error'] = $this->language->get('text_error');

            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));

            return;
        }

        $images = [];

        if (!empty($product['image'])) {
            $images[] = [
                'thumb' => $this->model_tool_image->resize($product['image'], 120, 120),
                'popup' => $this->model_tool_image->resize($product['image'], 800, 800)
            ];
        }

        foreach ($this->model_catalog_product->getImages($product_id) as $image) {
            if (empty($image['image'])) {
                continue;
            }

            $images[] = [
                'thumb' => $this->model_tool_image->resize($image['image'], 120, 120),
                'popup' => $this->model_tool_image->resize($image['image'], 800, 800)
            ];
        }

        // Same rules the core product controllers use: prices are tax-adjusted
        // and hidden from guests when config_customer_price is on.
        if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
            $price = $this->currency->format($this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);

            if ((float)$product['special']) {
                $special = $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
            } else {
                $special = '';
            }
        } else {
            $price = '';
            $special = '';
        }

        // A product with required options cannot be added straight from the
        // modal - the shopper is sent to the full product page instead.
        $has_options = false;

        foreach ($this->model_catalog_product->getOptions($product_id) as $option) {
            if ($option['required']) {
                $has_options = true;

                break;
            }
        }

        $json = [
            'product_id'  => $product_id,
            'name'        => html_entity_decode((string)$product['name'], ENT_QUOTES, 'UTF-8'),
            'price'       => $price,
            'special'     => $special,
            'description' => mb_substr(trim(strip_tags(html_entity_decode((string)$product['description'], ENT_QUOTES, 'UTF-8'))), 0, 1200),
            'images'      => $images,
            'stock'       => (int)$product['quantity'] > 0,
            'minimum'     => max(1, (int)$product['minimum']),
            'rating'      => (int)$product['rating'],
            'has_options' => $has_options,
            'href'        => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id)
        ];

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}
