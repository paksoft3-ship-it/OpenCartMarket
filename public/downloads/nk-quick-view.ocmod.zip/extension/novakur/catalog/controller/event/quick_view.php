<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class QuickView extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/novakur/catalog/view/assets/css/quick_view.css';
    private const JS  = 'extension/novakur/catalog/view/assets/js/quick_view.js';

    /**
     * catalog/controller/common/header/before
     *
     * The assets have to be queued before common/header renders, otherwise the
     * <link>/<script> loops in header.twig have already been written out.
     *
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * catalog/view/common/footer/after
     *
     * @param string               $route
     * @param array<string, mixed> $args
     * @param mixed                $output
     *
     * @return void
     */
    public function modal(string &$route, array &$args, mixed &$output): void {
        if (!$this->enabled() || !is_string($output) || $output === '') {
            return;
        }

        // The module can also be dropped into a layout position; never emit a
        // second copy of the modal (duplicate element id).
        if (str_contains($output, 'id="nk-qv-modal"')) {
            return;
        }

        $html = $this->load->controller('extension/novakur/module/quick_view');

        if (!is_string($html) || $html === '') {
            return;
        }

        $position = strripos($output, '</body>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_quick_view_status');
    }
}
