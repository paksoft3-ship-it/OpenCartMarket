<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

class QuickView extends \Opencart\System\Engine\Controller {
    /**
     * Animations offered by quick_view.css.
     *
     * @var array<int, string>
     */
    private array $animations = ['fade', 'zoom', 'slide'];

    /**
     * Setting key => default value. Also drives index() and save().
     *
     * @var array<string, string>
     */
    private array $defaults = [
        'module_quick_view_status'       => '0',
        'module_quick_view_animation'    => 'fade',
        'module_quick_view_show_reviews' => '1'
    ];

    /**
     * Events registered on install, removed on uninstall.
     *
     * The assets have to be registered before common/header runs, otherwise the
     * <link>/<script> tags are already rendered by the time we get the output.
     *
     * @var array<int, array<string, string>>
     */
    private array $events = [
        [
            'code'        => 'novakur_quick_view_assets',
            'description' => 'NovaKur Quick View: registers the storefront CSS/JS.',
            'trigger'     => 'catalog/controller/common/header/before',
            'action'      => 'extension/novakur/event/quick_view.assets'
        ],
        [
            'code'        => 'novakur_quick_view_modal',
            'description' => 'NovaKur Quick View: injects the modal markup before </body>.',
            'trigger'     => 'catalog/view/common/footer/after',
            'action'      => 'extension/novakur/event/quick_view.modal'
        ]
    ];

    public function index(): void {
        $this->load->language('extension/novakur/module/quick_view');
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting('module_quick_view', $store_id);

        $data = [];

        foreach ($this->defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = $settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        $data['animations'] = [];

        foreach ($this->animations as $animation) {
            $data['animations'][] = [
                'value' => $animation,
                'text'  => $this->language->get('text_animation_' . $animation)
            ];
        }

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'entry_status',
            'entry_animation',
            'entry_show_reviews',
            'help_status',
            'help_animation',
            'help_show_reviews',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/novakur/module/quick_view', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/novakur/module/quick_view.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/module/quick_view', $data));
    }

    public function save(): void {
        $this->load->language('extension/novakur/module/quick_view');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/novakur/module/quick_view')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;

        $animation = isset($post['module_quick_view_animation']) ? (string)$post['module_quick_view_animation'] : '';

        if (!in_array($animation, $this->animations, true)) {
            $json['error']['animation'] = $this->language->get('error_animation');
        }

        if (!isset($json['error'])) {
            $save = [
                'module_quick_view_status'       => !empty($post['module_quick_view_status']) ? '1' : '0',
                'module_quick_view_animation'    => $animation,
                'module_quick_view_show_reviews' => !empty($post['module_quick_view_show_reviews']) ? '1' : '0'
            ];

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_quick_view', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_quick_view', $this->defaults);

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);

            $this->model_setting_event->addEvent([
                'code'        => $event['code'],
                'description' => $event['description'],
                'trigger'     => $event['trigger'],
                'action'      => $event['action'],
                'status'      => 1,
                'sort_order'  => 1
            ]);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_quick_view');

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }
    }
}
