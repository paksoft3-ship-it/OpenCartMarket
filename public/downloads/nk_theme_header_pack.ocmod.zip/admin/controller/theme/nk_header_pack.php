<?php
namespace Opencart\Admin\Controller\Extension\NkThemeHeaderPack\Theme;

class NkHeaderPack extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_theme_header_pack/theme/nk_header_pack';
    private string $setting_code = 'theme_nk_header_pack';
    private string $event_code = 'nk_header_pack';

    private array $header_layouts = ['classic', 'centered', 'minimal', 'mega', 'utility'];
    private array $footer_layouts = ['columns', 'minimal', 'newsletter'];

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);
        $json = [];

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $post['theme_nk_header_pack_status'] = (int)($post['theme_nk_header_pack_status'] ?? 0);
        $post['theme_nk_header_pack_header_layout'] = trim((string)($post['theme_nk_header_pack_header_layout'] ?? ''));
        $post['theme_nk_header_pack_footer_layout'] = trim((string)($post['theme_nk_header_pack_footer_layout'] ?? ''));
        $post['theme_nk_header_pack_sticky_header'] = (int)!empty($post['theme_nk_header_pack_sticky_header']);
        $post['theme_nk_header_pack_show_topbar'] = (int)!empty($post['theme_nk_header_pack_show_topbar']);

        if (!in_array($post['theme_nk_header_pack_header_layout'], $this->header_layouts, true)) {
            $json['error']['theme_nk_header_pack_header_layout'] = $this->language->get('error_header_layout');
        }

        if (!in_array($post['theme_nk_header_pack_footer_layout'], $this->footer_layouts, true)) {
            $json['error']['theme_nk_header_pack_footer_layout'] = $this->language->get('error_footer_layout');
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->setting_code, $post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code' => $this->event_code,
            'description' => 'NovaKur Premium Header & Footer Pack hook',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/nk_theme_header_pack/event/nk_header_pack.view',
            'status' => 1,
            'sort_order' => 2
        ]);

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->event_code);

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->setting_code);
    }

    private function buildFormData(): array {
        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->setting_code);
        $data = [];

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'text_header_classic',
            'text_header_centered',
            'text_header_minimal',
            'text_header_mega',
            'text_header_utility',
            'text_footer_columns',
            'text_footer_minimal',
            'text_footer_newsletter',
            'entry_status',
            'entry_header_layout',
            'entry_footer_layout',
            'entry_sticky_header',
            'entry_show_topbar',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $defaults = [
            'theme_nk_header_pack_status' => '1',
            'theme_nk_header_pack_header_layout' => 'classic',
            'theme_nk_header_pack_footer_layout' => 'columns',
            'theme_nk_header_pack_sticky_header' => '1',
            'theme_nk_header_pack_show_topbar' => '1'
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['header_layouts'] = $this->header_layouts;
        $data['footer_layouts'] = $this->footer_layouts;

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
            ]
        ];

        $data['save'] = $this->url->link($this->route . '|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }
}
