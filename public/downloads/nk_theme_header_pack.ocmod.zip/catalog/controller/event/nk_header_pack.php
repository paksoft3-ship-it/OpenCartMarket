<?php
namespace Opencart\Catalog\Controller\Extension\NkThemeHeaderPack\Event;

class NkHeaderPack extends \Opencart\System\Engine\Controller {

    private array $header_layouts = ['classic', 'centered', 'minimal', 'mega', 'utility'];
    private array $footer_layouts = ['columns', 'minimal', 'newsletter'];

    public function view(string &$route, array &$data, string &$code): void {
        if (!$this->isPackActive()) {
            return;
        }

        // ---- Header ----
        if ($route === 'common/header') {
            $layout = $this->headerLayout();
            $template = DIR_EXTENSION . 'nk_theme_header_pack/catalog/view/template/common/header_pack_' . $layout . '.twig';
            if (is_file($template)) {
                $this->injectPackAssets($data);
                $data['cart_quantity'] = $this->cart->countProducts();
                $data['categories']    = $this->topCategories();

                $route = 'extension/nk_theme_header_pack/common/header_pack_' . $layout;
            }
        }

        // ---- Footer ----
        if ($route === 'common/footer') {
            $layout = $this->footerLayout();
            $template = DIR_EXTENSION . 'nk_theme_header_pack/catalog/view/template/common/footer_pack_' . $layout . '.twig';
            if (is_file($template)) {
                $this->injectPackAssets($data);
                $data['categories'] = $this->topCategories();

                $route = 'extension/nk_theme_header_pack/common/footer_pack_' . $layout;
            }
        }
    }

    private function injectPackAssets(array &$data): void {
        $data['nk_hp_css']         = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_header_pack/catalog/view/assets/dist/css/nk-header-pack.css';
        $data['nk_hp_js']          = rtrim(HTTP_SERVER, '/') . '/extension/nk_theme_header_pack/catalog/view/assets/dist/js/nk-header-pack.js';
        $data['nk_hp_layout']      = $this->headerLayout();
        $data['nk_hp_footer']      = $this->footerLayout();
        $data['nk_hp_sticky']      = (int)$this->config->get('theme_nk_header_pack_sticky_header');
        $data['nk_hp_show_topbar'] = (int)$this->config->get('theme_nk_header_pack_show_topbar');
    }

    private function topCategories(): array {
        $this->load->model('catalog/category');
        $cats_raw = array_slice($this->model_catalog_category->getCategories(0), 0, 8);
        $categories = [];
        foreach ($cats_raw as $cat) {
            $categories[] = [
                'name'  => $cat['name'],
                'href'  => $this->url->link('product/category', 'path=' . $cat['category_id']),
                'image' => $cat['image'] ?? '',
            ];
        }
        return $categories;
    }

    private function headerLayout(): string {
        $layout = (string)$this->config->get('theme_nk_header_pack_header_layout');
        return in_array($layout, $this->header_layouts, true) ? $layout : 'classic';
    }

    private function footerLayout(): string {
        $layout = (string)$this->config->get('theme_nk_header_pack_footer_layout');
        return in_array($layout, $this->footer_layouts, true) ? $layout : 'columns';
    }

    private function isPackActive(): bool {
        return (bool)$this->config->get('theme_nk_header_pack_status');
    }
}
