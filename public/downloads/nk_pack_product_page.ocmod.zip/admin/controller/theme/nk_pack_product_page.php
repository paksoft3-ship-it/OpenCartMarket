<?php
namespace Opencart\Admin\Controller\Extension\NkPackProductPage\Theme;

class NkPackProductPage extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_pack_product_page/theme/nk_pack_product_page';
    private string $setting_code = 'theme_nk_pack_product_page';
    private string $event_code = 'nk_pack_product_page';

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));
        $this->response->setOutput($this->load->view($this->route, $this->buildFormData()));
    }

    public function save(): void {
        $this->load->language($this->route);
        $json = [];

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $post['theme_nk_pack_product_page_status'] = (int)($post['theme_nk_pack_product_page_status'] ?? 0);
        $post['theme_nk_pack_product_page_show_badges'] = (int)!empty($post['theme_nk_pack_product_page_show_badges']);
        $post['theme_nk_pack_product_page_show_trust_row'] = (int)!empty($post['theme_nk_pack_product_page_show_trust_row']);
        $post['theme_nk_pack_product_page_show_tabs'] = (int)!empty($post['theme_nk_pack_product_page_show_tabs']);
        $post['theme_nk_pack_product_page_show_sticky_cta'] = (int)!empty($post['theme_nk_pack_product_page_show_sticky_cta']);
        $post['theme_nk_pack_product_page_show_recently_viewed'] = (int)!empty($post['theme_nk_pack_product_page_show_recently_viewed']);
        $post['theme_nk_pack_product_page_re_route_template'] = (int)!empty($post['theme_nk_pack_product_page_re_route_template']);
        $post['theme_nk_pack_product_page_low_stock_threshold'] = trim((string)($post['theme_nk_pack_product_page_low_stock_threshold'] ?? '5'));

        if (!$this->isValidThreshold($post['theme_nk_pack_product_page_low_stock_threshold'])) {
            $json['error']['theme_nk_pack_product_page_low_stock_threshold'] = $this->language->get('error_threshold');
        } else {
            $post['theme_nk_pack_product_page_low_stock_threshold'] = (int)$post['theme_nk_pack_product_page_low_stock_threshold'];
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->setting_code, $post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code' => $this->event_code,
            'description' => 'NovaKur Product Page Conversion Pack hook',
            'trigger' => 'catalog/view/*/before',
            'action' => 'extension/nk_pack_product_page/event/nk_pack_product_page.view',
            'status' => 1,
            'sort_order' => 2
        ]);

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->event_code);

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->setting_code);
    }

    private function buildFormData(): array {
        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->setting_code);
        $data = [];

        foreach ([
            'heading_title',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_home',
            'text_extension',
            'entry_status',
            'entry_show_badges',
            'entry_show_trust_row',
            'entry_show_tabs',
            'entry_show_sticky_cta',
            'entry_show_recently_viewed',
            'entry_re_route_template',
            'entry_low_stock_threshold',
            'help_re_route_template',
            'help_low_stock_threshold',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        $defaults = [
            'theme_nk_pack_product_page_status' => '1',
            'theme_nk_pack_product_page_show_badges' => '1',
            'theme_nk_pack_product_page_show_trust_row' => '1',
            'theme_nk_pack_product_page_show_tabs' => '1',
            'theme_nk_pack_product_page_show_sticky_cta' => '1',
            'theme_nk_pack_product_page_show_recently_viewed' => '1',
            'theme_nk_pack_product_page_re_route_template' => '0',
            'theme_nk_pack_product_page_low_stock_threshold' => '5'
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'])
            ]
        ];

        $data['save'] = $this->url->link($this->route . '|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        return $data;
    }

    private function isValidThreshold(string $value): bool {
        if (!preg_match('/^\d{1,2}$/', $value)) {
            return false;
        }

        $threshold = (int)$value;

        return $threshold >= 0 && $threshold <= 99;
    }
}
