<?php
// Heading
$_['heading_title']        = 'NovaKur AJAX Live Search';

// Text
$_['text_extension']       = 'Extensions';
$_['text_success']         = 'Success: You have modified NovaKur AJAX Live Search settings!';
$_['text_edit']            = 'Edit NovaKur AJAX Live Search';
$_['text_enabled']         = 'Enabled';
$_['text_disabled']        = 'Disabled';
$_['text_general']         = 'General';
$_['text_behaviour']       = 'Typing behaviour';
$_['text_result_layout']   = 'Result layout';

// Entry
$_['entry_status']         = 'Status';
$_['entry_limit']          = 'Results shown';
$_['entry_min_chars']      = 'Minimum characters';
$_['entry_debounce']       = 'Debounce (ms)';
$_['entry_show_image']     = 'Product image';
$_['entry_show_price']     = 'Price';
$_['entry_show_category']  = 'Category line';
$_['entry_highlight']      = 'Highlight match';
$_['entry_description']    = 'Search descriptions';
$_['entry_selector']       = 'Search input selector';

// Help
$_['help_limit']           = 'How many products the dropdown lists. Between 1 and 10 — the storefront endpoint caps this at 10 regardless.';
$_['help_min_chars']       = 'The shopper must type at least this many characters before a request is made. Between 1 and 5.';
$_['help_debounce']        = 'Milliseconds of silence after the last keystroke before the request fires. Between 50 and 2000.';
$_['help_show_image']      = 'Show a thumbnail next to each result.';
$_['help_show_price']      = 'Show the price, tax-adjusted and in the active currency. Specials are shown with the old price struck through.';
$_['help_show_category']   = 'Show the product\'s category underneath its name.';
$_['help_highlight']       = 'Wrap the typed term in the result name so it stands out.';
$_['help_description']     = 'Also match against product descriptions. Broader results, heavier query.';
$_['help_selector']        = 'Leave blank to use the stock OpenCart header search field. Set a CSS selector (for example: header form input[name="search"]) if your theme renders its own search box.';

// Button
$_['button_save']          = 'Save';
$_['button_back']          = 'Back';

// Error
$_['error_permission']     = 'Warning: You do not have permission to modify this module!';
$_['error_limit']          = 'Results shown must be between 1 and 10!';
$_['error_min_chars']      = 'Minimum characters must be between 1 and 5!';
$_['error_debounce']       = 'Debounce must be between 50 and 2000 milliseconds!';
$_['error_selector']       = 'Selector may only contain CSS selector characters and must be under 200 characters!';
