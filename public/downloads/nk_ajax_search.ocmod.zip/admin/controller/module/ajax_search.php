<?php
namespace Opencart\Admin\Controller\Extension\NkAjaxSearch\Module;

/**
 * NovaKur AJAX Live Search
 *
 * Settings namespace: module_ajax_search_*
 * Route:              extension/nk_ajax_search/module/ajax_search
 * Event codes:        nk_ajax_search_assets / nk_ajax_search_render
 */
class AjaxSearch extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_ajax_search/module/ajax_search';
    private string $prefix = 'module_ajax_search';

    /**
     * Every key must start with $prefix or editSetting() silently drops it.
     *
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_ajax_search_status'        => '0',
            'module_ajax_search_limit'         => '6',
            'module_ajax_search_min_chars'     => '3',
            'module_ajax_search_debounce'      => '250',
            'module_ajax_search_show_image'    => '1',
            'module_ajax_search_show_price'    => '1',
            'module_ajax_search_show_category' => '1',
            'module_ajax_search_highlight'     => '1',
            'module_ajax_search_description'   => '0',
            'module_ajax_search_selector'      => ''
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function events(): array {
        return [
            [
                'code'        => 'nk_ajax_search_assets',
                'description' => 'NovaKur AJAX Live Search: stylesheet + script injection',
                'trigger'     => 'catalog/controller/common/header/before',
                'action'      => 'extension/nk_ajax_search/event/ajax_search.assets',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_ajax_search_render',
                'description' => 'NovaKur AJAX Live Search: dropdown wrapper around the header search form',
                'trigger'     => 'catalog/view/common/search/after',
                'action'      => 'extension/nk_ajax_search/event/ajax_search.wrap',
                'status'      => 1,
                'sort_order'  => 1
            ],
            [
                'code'        => 'nk_ajax_search_fallback',
                'description' => 'NovaKur AJAX Live Search: dropdown host for themes without a common/search partial',
                'trigger'     => 'catalog/view/common/footer/after',
                'action'      => 'extension/nk_ajax_search/event/ajax_search.fallback',
                'status'      => 1,
                'sort_order'  => 1
            ]
        ];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'text_general',
            'text_behaviour',
            'text_result_layout',
            'entry_status',
            'entry_limit',
            'entry_min_chars',
            'entry_debounce',
            'entry_show_image',
            'entry_show_price',
            'entry_show_category',
            'entry_highlight',
            'entry_description',
            'entry_selector',
            'help_limit',
            'help_min_chars',
            'help_debounce',
            'help_show_image',
            'help_show_price',
            'help_show_category',
            'help_highlight',
            'help_description',
            'help_selector',
            'button_save',
            'button_back',
            'error_permission',
            'error_limit',
            'error_min_chars',
            'error_debounce',
            'error_selector'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        // --- Toggles ---------------------------------------------------------
        foreach (['status', 'show_image', 'show_price', 'show_category', 'highlight', 'description'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // --- Numeric ranges --------------------------------------------------
        // limit is hard-capped at 10 again in the catalog endpoint; this is only
        // the merchant-facing bound.
        foreach (['limit' => [1, 10], 'min_chars' => [1, 5], 'debounce' => [50, 2000]] as $key => $range) {
            $value = trim((string)($post[$this->prefix . '_' . $key] ?? ''));

            if (!$this->inRange($value, $range[0], $range[1])) {
                $json['error'][$this->prefix . '_' . $key] = $this->language->get('error_' . $key);
            } else {
                $save[$this->prefix . '_' . $key] = (string)(int)$value;
            }
        }

        // --- Selector override -----------------------------------------------
        // Restricted to the characters a CSS selector actually needs so a stored
        // value can never carry markup into the storefront data attribute.
        $selector = trim((string)($post[$this->prefix . '_selector'] ?? ''));

        if ($selector !== '' && !preg_match('/^[A-Za-z0-9\s,.#_\-\[\]="\':()>+~*^$|]{1,200}$/', $selector)) {
            $json['error'][$this->prefix . '_selector'] = $this->language->get('error_selector');
        } else {
            $save[$this->prefix . '_selector'] = $selector;
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ($this->events() as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }

        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }

    private function inRange(string $value, int $min, int $max): bool {
        if (!preg_match('/^\d{1,5}$/', $value)) {
            return false;
        }

        $number = (int)$value;

        return $number >= $min && $number <= $max;
    }
}
