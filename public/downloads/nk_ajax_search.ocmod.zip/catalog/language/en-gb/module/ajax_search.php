<?php
// Text
$_['text_no_results'] = 'No products matched';
$_['text_searching']  = 'Searching...';
$_['text_view_all']   = 'View all %s results';
$_['text_error']      = 'Search is unavailable right now';
$_['text_results']    = 'Search suggestions';
