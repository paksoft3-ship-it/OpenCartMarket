/**
 * NovaKur AJAX Live Search
 *
 * Binds to the stock OpenCart 4.1 header search input — catalog/view/template/
 * common/search.twig renders `<input type="text" name="search">` inside a
 * `<form class="input-group">` — and falls back to an admin-configured CSS
 * selector for themes that roll their own search box.
 *
 * Nothing here is required for search to work: the form is left untouched and
 * still submits normally, so a JS failure (or JS off entirely) degrades to the
 * ordinary product/search page.
 */
(function () {
  'use strict';

  var HOST_ID = 'nk-as';

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Wraps every occurrence of `term` in the already-escaped `name`. Both sides
   * are escaped first, so the <mark> tags are the only markup that survives.
   */
  function highlight(name, term) {
    var safe = escapeHtml(name);

    if (!term) {
      return safe;
    }

    var words = term.split(/\s+/).filter(function (word) { return word.length > 0; });

    if (!words.length) {
      return safe;
    }

    var pattern = words.map(function (word) { return escapeRegExp(escapeHtml(word)); }).join('|');

    try {
      return safe.replace(new RegExp('(' + pattern + ')', 'gi'), '<mark class="nk-as__mark">$1</mark>');
    } catch (e) {
      return safe;
    }
  }

  function clamp(value, min, max, fallback) {
    var number = parseInt(value, 10);

    if (isNaN(number)) {
      return fallback;
    }

    return Math.min(max, Math.max(min, number));
  }

  function init() {
    var host = document.getElementById(HOST_ID);

    if (!host) {
      return;
    }

    var cfg = {
      resultsUrl: host.getAttribute('data-results-url') || '',
      searchUrl: host.getAttribute('data-search-url') || '',
      limit: clamp(host.getAttribute('data-limit'), 1, 10, 6),
      minChars: clamp(host.getAttribute('data-min-chars'), 1, 5, 3),
      debounce: clamp(host.getAttribute('data-debounce'), 50, 2000, 250),
      highlight: host.getAttribute('data-highlight') === '1',
      selector: host.getAttribute('data-selector') || ''
    };

    var text = {
      noResults: host.getAttribute('data-text-no-results') || 'No products matched',
      searching: host.getAttribute('data-text-searching') || 'Searching...',
      viewAll: host.getAttribute('data-text-view-all') || 'View all %s results',
      error: host.getAttribute('data-text-error') || 'Search is unavailable right now',
      results: host.getAttribute('data-text-results') || 'Search suggestions'
    };

    if (!cfg.resultsUrl) {
      return;
    }

    var input = findInput(cfg.selector);

    if (!input) {
      return;
    }

    build(input, host, cfg, text);
  }

  /**
   * Admin selector first, then the stock 4.1 header field, then progressively
   * looser guesses for third-party themes.
   */
  function findInput(selector) {
    var candidates = [];

    if (selector) {
      candidates.push(selector);
    }

    candidates.push(
      'header input[name="search"]',
      '#search input[name="search"]',
      'form input[name="search"]',
      'input[name="search"]'
    );

    for (var i = 0; i < candidates.length; i++) {
      var found;

      try {
        found = document.querySelector(candidates[i]);
      } catch (e) {
        // A hand-edited selector setting that isn't valid CSS just gets skipped.
        found = null;
      }

      // Skip the search page's own filter inputs of type hidden/checkbox.
      if (found && found.tagName === 'INPUT' && (found.type === 'text' || found.type === 'search')) {
        return found;
      }
    }

    return null;
  }

  function build(input, host, cfg, text) {
    // The panel lives on <body> and is positioned from the input's bounding box
    // rather than injected next to it. The stock 4.1 search box is a Bootstrap
    // `.input-group` whose flex layout depends on the input being a direct
    // child, so re-parenting it would break the theme's own markup.
    var panel = document.createElement('div');
    panel.className = 'nk-as__panel';
    panel.id = 'nk-as-panel';
    panel.setAttribute('role', 'listbox');
    panel.setAttribute('aria-label', text.results);
    panel.hidden = true;
    document.body.appendChild(panel);

    var live = document.createElement('div');
    live.className = 'nk-as__live';
    live.setAttribute('aria-live', 'polite');
    live.setAttribute('role', 'status');
    document.body.appendChild(live);

    input.setAttribute('autocomplete', 'off');
    input.setAttribute('role', 'combobox');
    input.setAttribute('aria-expanded', 'false');
    input.setAttribute('aria-controls', panel.id);
    input.setAttribute('aria-autocomplete', 'list');

    host.hidden = true;

    var timer = null;
    var controller = null;
    var items = [];
    var active = -1;
    var lastTerm = '';
    var open = false;

    function closePanel() {
      open = false;
      panel.hidden = true;
      panel.innerHTML = '';
      items = [];
      active = -1;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
    }

    function place() {
      var box = input.getBoundingClientRect();
      var left = box.left + (window.pageXOffset || document.documentElement.scrollLeft || 0);
      var top = box.bottom + (window.pageYOffset || document.documentElement.scrollTop || 0);

      panel.style.left = Math.max(4, Math.round(left)) + 'px';
      panel.style.top = Math.round(top + 4) + 'px';
      panel.style.width = Math.round(Math.max(box.width, 240)) + 'px';
    }

    function openPanel() {
      open = true;
      panel.hidden = false;
      place();
      input.setAttribute('aria-expanded', 'true');
    }

    function setActive(index) {
      if (!items.length) {
        return;
      }

      if (active >= 0 && items[active]) {
        items[active].classList.remove('is-active');
        items[active].setAttribute('aria-selected', 'false');
      }

      // Wrap around at both ends.
      active = (index + items.length) % items.length;

      items[active].classList.add('is-active');
      items[active].setAttribute('aria-selected', 'true');
      input.setAttribute('aria-activedescendant', items[active].id);

      if (items[active].scrollIntoView) {
        items[active].scrollIntoView({ block: 'nearest' });
      }
    }

    function message(body) {
      panel.innerHTML = '<div class="nk-as__message">' + escapeHtml(body) + '</div>';
      items = [];
      active = -1;
      openPanel();
    }

    function render(data, term) {
      var products = (data && data.products) || [];

      if (!products.length) {
        message(text.noResults);
        live.textContent = text.noResults;

        return;
      }

      var html = '<ul class="nk-as__list">';

      for (var i = 0; i < products.length; i++) {
        var product = products[i];
        var price = product.price || {};
        var priceHtml = '';

        if (price.special) {
          priceHtml = '<span class="nk-as__price"><s class="nk-as__was">' + escapeHtml(price.price) + '</s> <span class="nk-as__now">' + escapeHtml(price.special) + '</span></span>';
        } else if (price.price) {
          priceHtml = '<span class="nk-as__price">' + escapeHtml(price.price) + '</span>';
        }

        html += '<li class="nk-as__item" id="nk-as-item-' + i + '" role="option" aria-selected="false">'
          + '<a class="nk-as__link" href="' + escapeHtml(product.href) + '">'
          + (product.thumb ? '<img class="nk-as__thumb" src="' + escapeHtml(product.thumb) + '" alt="" loading="lazy"/>' : '')
          + '<span class="nk-as__body">'
          + '<span class="nk-as__name">' + (cfg.highlight ? highlight(product.name, term) : escapeHtml(product.name)) + '</span>'
          + (product.category ? '<span class="nk-as__cat">' + escapeHtml(product.category) + '</span>' : '')
          + '</span>'
          + priceHtml
          + '</a></li>';
      }

      html += '</ul>';

      var total = parseInt(data.total, 10) || products.length;

      if (total > products.length && data.href) {
        html += '<a class="nk-as__all" href="' + escapeHtml(data.href) + '">' + escapeHtml(text.viewAll.replace('%s', String(total))) + '</a>';
      }

      panel.innerHTML = html;
      items = Array.prototype.slice.call(panel.querySelectorAll('.nk-as__item'));
      active = -1;
      openPanel();

      live.textContent = String(products.length);
    }

    function request(term) {
      if (controller && controller.abort) {
        controller.abort();
      }

      var signal;

      if (typeof window.AbortController === 'function') {
        controller = new window.AbortController();
        signal = controller.signal;
      } else {
        controller = null;
      }

      var url = cfg.resultsUrl + (cfg.resultsUrl.indexOf('?') === -1 ? '?' : '&') + 'search=' + encodeURIComponent(term);

      message(text.searching);

      fetch(url, {
        signal: signal,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
        .then(function (response) { return response.json(); })
        .then(function (data) {
          // A slow response for a term the shopper has already typed past is
          // discarded rather than flashed on screen.
          if (term !== lastTerm) {
            return;
          }

          render(data, term);
        })
        .catch(function (e) {
          if (e && e.name === 'AbortError') {
            return;
          }

          if (term === lastTerm) {
            message(text.error);
          }
        });
    }

    function schedule() {
      var term = input.value.trim();

      lastTerm = term;

      if (timer) {
        window.clearTimeout(timer);
      }

      if (term.length < cfg.minChars) {
        if (controller && controller.abort) {
          controller.abort();
        }

        closePanel();

        return;
      }

      timer = window.setTimeout(function () { request(term); }, cfg.debounce);
    }

    input.addEventListener('input', schedule);

    input.addEventListener('focus', function () {
      if (!open && input.value.trim().length >= cfg.minChars) {
        schedule();
      }
    });

    input.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' || event.key === 'Esc') {
        if (open) {
          // Only swallow the key when there is actually a panel to close, so
          // Escape keeps its normal meaning otherwise.
          event.preventDefault();
          closePanel();
        }

        return;
      }

      if (!open || !items.length) {
        return;
      }

      if (event.key === 'ArrowDown' || event.key === 'Down') {
        event.preventDefault();
        setActive(active + 1);
      } else if (event.key === 'ArrowUp' || event.key === 'Up') {
        event.preventDefault();
        setActive(active - 1);
      } else if (event.key === 'Enter') {
        if (active >= 0 && items[active]) {
          var link = items[active].querySelector('a');

          if (link) {
            // Only intercept Enter when a suggestion is highlighted; a plain
            // Enter still submits the form to the full search page.
            event.preventDefault();
            window.location.href = link.href;
          }
        }
      } else if (event.key === 'Tab') {
        closePanel();
      }
    });

    // Pointer highlight keeps the keyboard and mouse cursors in sync.
    panel.addEventListener('mousemove', function (event) {
      var item = event.target.closest ? event.target.closest('.nk-as__item') : null;

      if (item) {
        var index = items.indexOf(item);

        if (index !== -1 && index !== active) {
          setActive(index);
        }
      }
    });

    document.addEventListener('click', function (event) {
      if (open && event.target !== input && !panel.contains(event.target)) {
        closePanel();
      }
    });

    // The panel is body-anchored, so it has to follow the input when the page
    // moves underneath it (including under a sticky header).
    window.addEventListener('resize', function () {
      if (open) {
        place();
      }
    });

    window.addEventListener('scroll', function () {
      if (open) {
        place();
      }
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}());
