<?php
namespace Opencart\Catalog\Controller\Extension\NkAjaxSearch\Module;

/**
 * NovaKur AJAX Live Search — storefront module + JSON endpoint.
 *
 * index()   renders the dropdown host markup (config carrier for the JS).
 * results() the JSON endpoint the JS polls as the shopper types.
 *
 * The endpoint reuses the core catalog product model, so a live result set is
 * always a prefix of what product/search would return for the same term.
 */
class AjaxSearch extends \Opencart\System\Engine\Controller {
    /**
     * Hard ceiling. The admin form already bounds the setting, but a hand-edited
     * `oc_setting` row must not be able to turn a keystroke into a 500-row query.
     */
    private const MAX_LIMIT = 10;

    /**
     * Longest term accepted. Anything past this is truncated before it reaches
     * the model — long strings only ever produce LIKE '%...%' misses.
     */
    private const MAX_TERM = 128;

    /**
     * Requests tolerated per second, per session, before the endpoint starts
     * answering with an empty (but valid) result set.
     */
    private const RATE_PER_SECOND = 15;

    /**
     * Resolved category names, keyed by category_id, for the life of one
     * request. Ten results share at most ten lookups.
     *
     * @var array<int, string>
     */
    private array $category_names = [];

    /**
     * @return string
     */
    public function index(): string {
        if (!$this->enabled()) {
            return '';
        }

        $this->load->language('extension/nk_ajax_search/module/ajax_search');

        $language = (string)$this->config->get('config_language');

        return $this->load->view('extension/nk_ajax_search/module/ajax_search', [
            'results_url'     => $this->url->link('extension/nk_ajax_search/module/ajax_search.results', 'language=' . $language, true),
            'search_url'      => $this->url->link('product/search', 'language=' . $language, true),
            'limit'           => $this->limit(),
            'min_chars'       => $this->number('module_ajax_search_min_chars', 3, 1, 5),
            'debounce'        => $this->number('module_ajax_search_debounce', 250, 50, 2000),
            'highlight'       => (bool)(int)$this->config->get('module_ajax_search_highlight'),
            'selector'        => $this->selector(),
            'text_no_results' => $this->language->get('text_no_results'),
            'text_searching'  => $this->language->get('text_searching'),
            'text_view_all'   => $this->language->get('text_view_all'),
            'text_error'      => $this->language->get('text_error'),
            'text_results'    => $this->language->get('text_results')
        ]);
    }

    /**
     * @return void
     */
    public function results(): void {
        $this->response->addHeader('Content-Type: application/json');
        // A search suggestion feed has nothing to offer a crawler, and every one
        // of these URLs is a unique thin page if indexed.
        $this->response->addHeader('X-Robots-Tag: noindex');

        if (!$this->enabled() || $this->throttled()) {
            $this->response->setOutput(json_encode(['products' => [], 'total' => 0, 'href' => '']));

            return;
        }

        $search = isset($this->request->get['search']) ? (string)$this->request->get['search'] : '';
        $search = trim((string)preg_replace('/\s+/u', ' ', $search));

        if (oc_strlen($search) > self::MAX_TERM) {
            $search = oc_substr($search, 0, self::MAX_TERM);
        }

        if ($search === '' || oc_strlen($search) < $this->number('module_ajax_search_min_chars', 3, 1, 5)) {
            $this->response->setOutput(json_encode(['products' => [], 'total' => 0, 'href' => '']));

            return;
        }

        $limit = $this->limit();
        $language = (string)$this->config->get('config_language');

        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        // Same filter shape product/search builds, so the dropdown and the full
        // results page agree. `filter_search` is the 4.1 key (4.0 used
        // filter_name); the model escapes every word it splits out.
        $filter_data = [
            'filter_search'      => $search,
            'filter_description' => (int)(bool)$this->config->get('module_ajax_search_description'),
            'filter_tag'         => $search,
            'start'              => 0,
            'limit'              => $limit
        ];

        $results = $this->model_catalog_product->getProducts($filter_data);

        $show_image = (bool)(int)$this->config->get('module_ajax_search_show_image');
        $show_price = (bool)(int)$this->config->get('module_ajax_search_show_price');
        $show_category = (bool)(int)$this->config->get('module_ajax_search_show_category');

        $width = (int)$this->config->get('config_image_cart_width') ?: 47;
        $height = (int)$this->config->get('config_image_cart_height') ?: 47;

        $products = [];

        foreach ($results as $result) {
            $products[] = [
                'product_id' => (int)$result['product_id'],
                'name'       => html_entity_decode((string)$result['name'], ENT_QUOTES, 'UTF-8'),
                'thumb'      => $show_image ? $this->thumb($result, $width, $height) : '',
                'price'      => $show_price ? $this->price($result) : ['price' => '', 'special' => ''],
                'category'   => $show_category ? $this->categoryName((int)$result['product_id']) : '',
                'href'       => $this->url->link('product/product', 'language=' . $language . '&product_id=' . (int)$result['product_id'])
            ];
        }

        // getTotalProducts() is a second full scan; only worth it when the page
        // is actually going to show a "view all N" line, i.e. when the dropdown
        // filled up.
        if (count($products) >= $limit) {
            $total = $this->model_catalog_product->getTotalProducts($filter_data);
        } else {
            $total = count($products);
        }

        $this->response->setOutput(json_encode([
            'products' => $products,
            'total'    => (int)$total,
            'href'     => $this->url->link('product/search', 'language=' . $language . '&search=' . urlencode(html_entity_decode($search, ENT_QUOTES, 'UTF-8')))
        ]));
    }

    /**
     * @param array<string, mixed> $result
     * @param int                  $width
     * @param int                  $height
     *
     * @return string
     */
    private function thumb(array $result, int $width, int $height): string {
        $image = !empty($result['image']) ? (string)$result['image'] : 'placeholder.png';

        return (string)$this->model_tool_image->resize($image, $width, $height);
    }

    /**
     * Core rule: prices are tax-adjusted, and hidden entirely from guests when
     * config_customer_price is on.
     *
     * @param array<string, mixed> $result
     *
     * @return array<string, string>
     */
    private function price(array $result): array {
        if (!$this->customer->isLogged() && $this->config->get('config_customer_price')) {
            return ['price' => '', 'special' => ''];
        }

        $tax_class_id = (int)($result['tax_class_id'] ?? 0);
        $currency = (string)($this->session->data['currency'] ?? $this->config->get('config_currency'));

        $price = $this->currency->format(
            $this->tax->calculate((float)$result['price'], $tax_class_id, $this->config->get('config_tax')),
            $currency
        );

        // `special` comes back NULL when no product_discount row with special=1
        // is live for this customer group.
        if (isset($result['special']) && $result['special'] !== null && (float)$result['special'] > 0) {
            $special = $this->currency->format(
                $this->tax->calculate((float)$result['special'], $tax_class_id, $this->config->get('config_tax')),
                $currency
            );
        } else {
            $special = '';
        }

        return ['price' => $price, 'special' => $special];
    }

    /**
     * First store-visible, enabled category the product sits in. Empty string
     * when the product is uncategorised — the JS just omits the line.
     *
     * @param int $product_id
     *
     * @return string
     */
    private function categoryName(int $product_id): string {
        $this->load->model('catalog/category');

        foreach ($this->model_catalog_product->getCategories($product_id) as $row) {
            $category_id = (int)$row['category_id'];

            if (!array_key_exists($category_id, $this->category_names)) {
                $category = $this->model_catalog_category->getCategory($category_id);

                $this->category_names[$category_id] = $category ? html_entity_decode((string)$category['name'], ENT_QUOTES, 'UTF-8') : '';
            }

            if ($this->category_names[$category_id] !== '') {
                return $this->category_names[$category_id];
            }
        }

        return '';
    }

    /**
     * Cheap per-session token bucket. Fails open: any surprise in the session
     * store means the request is served normally.
     *
     * @return bool
     */
    private function throttled(): bool {
        $now = microtime(true);

        $bucket = $this->session->data['nk_ajax_search_rate'] ?? null;

        if (!is_array($bucket) || !isset($bucket['t'], $bucket['n']) || ($now - (float)$bucket['t']) > 1.0) {
            $bucket = ['t' => $now, 'n' => 0];
        }

        $bucket['n'] = (int)$bucket['n'] + 1;

        $this->session->data['nk_ajax_search_rate'] = $bucket;

        return $bucket['n'] > self::RATE_PER_SECOND;
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_ajax_search_status');
    }

    /**
     * @return int
     */
    private function limit(): int {
        return $this->number('module_ajax_search_limit', 6, 1, self::MAX_LIMIT);
    }

    /**
     * @return string
     */
    private function selector(): string {
        $selector = trim((string)$this->config->get('module_ajax_search_selector'));

        if ($selector === '' || !preg_match('/^[A-Za-z0-9\s,.#_\-\[\]="\':()>+~*^$|]{1,200}$/', $selector)) {
            return '';
        }

        return $selector;
    }

    /**
     * @param string $key
     * @param int    $fallback
     * @param int    $min
     * @param int    $max
     *
     * @return int
     */
    private function number(string $key, int $fallback, int $min, int $max): int {
        $value = $this->config->get($key);

        if ($value === null || $value === '' || !is_numeric($value)) {
            return $fallback;
        }

        $number = (int)$value;

        return ($number >= $min && $number <= $max) ? $number : $fallback;
    }
}
