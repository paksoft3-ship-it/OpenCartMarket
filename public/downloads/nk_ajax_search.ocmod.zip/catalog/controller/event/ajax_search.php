<?php
namespace Opencart\Catalog\Controller\Extension\NkAjaxSearch\Event;

/**
 * NovaKur AJAX Live Search — storefront hooks.
 *
 * assets()   catalog/controller/common/header/before → queue CSS/JS
 * wrap()     catalog/view/common/search/after        → append the dropdown host
 *                                                      directly after the stock
 *                                                      header search form
 * fallback() catalog/view/common/footer/after        → last-resort host for
 *                                                      themes that never render
 *                                                      the common/search partial
 *
 * Every hook fails open: on unexpected input the storefront output is returned
 * untouched.
 */
class AjaxSearch extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_ajax_search/catalog/view/assets/css/ajax_search.css';
    private const JS  = 'extension/nk_ajax_search/catalog/view/assets/js/ajax_search.js';

    /**
     * The host element carries an id, so it may only ever be emitted once even
     * if a theme renders the search partial in both the header and a mobile
     * drawer.
     */
    private static bool $rendered = false;

    /**
     * @param string               $route
     * @param array<string, mixed> $args
     *
     * @return void
     */
    public function assets(string &$route, array &$args): void {
        if (!$this->enabled()) {
            return;
        }

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function wrap(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || self::$rendered || !is_string($output) || $output === '') {
            return;
        }

        $html = $this->host();

        if ($html === '') {
            return;
        }

        self::$rendered = true;

        // The dropdown is absolutely positioned against a relative wrapper the
        // JS creates around the input, so it only needs to be adjacent in the
        // DOM — no restructuring of the theme's own markup.
        $output .= $html;
    }

    /**
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function fallback(string &$route, array &$data, mixed &$output): void {
        if (!$this->enabled() || self::$rendered || !is_string($output) || $output === '') {
            return;
        }

        // wrap() already ran on this page if the theme uses common/search; this
        // only fires for themes with a bespoke search box.
        if (str_contains($output, 'id="nk-as"')) {
            return;
        }

        $html = $this->host();

        if ($html === '') {
            return;
        }

        self::$rendered = true;

        $position = strripos($output, '</body>');

        if ($position !== false) {
            $output = substr($output, 0, $position) . $html . substr($output, $position);
        } else {
            $output .= $html;
        }
    }

    /**
     * @return string
     */
    private function host(): string {
        $html = $this->load->controller('extension/nk_ajax_search/module/ajax_search');

        return is_string($html) ? $html : '';
    }

    /**
     * @return bool
     */
    private function enabled(): bool {
        return (bool)(int)$this->config->get('module_ajax_search_status');
    }
}
