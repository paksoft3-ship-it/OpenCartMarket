<?php
namespace Opencart\Catalog\Controller\Extension\NkRecentlyViewed\Module;

/**
 * NovaKur Recently Viewed — storefront module.
 *
 * index() renders an empty shell into the layout position. The browsing history
 * lives in localStorage, so the shell carries everything the script needs
 * (endpoint, limit, current product id) as data attributes and the script then
 * asks items() to render the cards.
 *
 * items() is a public storefront route by design: it only ever exposes products
 * that are already enabled, in-store and available — exactly what a category
 * page shows — and it honours config_customer_price for prices.
 */
class RecentlyViewed extends \Opencart\System\Engine\Controller {
    private const CSS = 'extension/nk_recently_viewed/catalog/view/assets/css/recently_viewed.css';
    private const JS  = 'extension/nk_recently_viewed/catalog/view/assets/js/recently_viewed.js';

    /**
     * Hard ceiling on ids accepted from the query string, independent of the
     * configured limit, so the route can never be turned into a bulk product
     * dump by hand-crafting a URL.
     */
    private const MAX_IDS = 24;

    public function index(): string {
        if (!(int)$this->config->get('module_recently_viewed_status')) {
            return '';
        }

        $this->load->language('extension/nk_recently_viewed/module/recently_viewed');

        $this->document->addStyle(self::CSS);
        $this->document->addScript(self::JS);

        $title = trim((string)$this->config->get('module_recently_viewed_title'));

        if ($title === '') {
            $title = $this->language->get('heading_title');
        }

        // On a product page the product being looked at is excluded from its own
        // "recently viewed" strip, and it is what the script records.
        $product_id = 0;

        if (isset($this->request->get['route']) && (string)$this->request->get['route'] === 'product/product' && isset($this->request->get['product_id'])) {
            $product_id = (int)$this->request->get['product_id'];
        }

        return $this->load->view('extension/nk_recently_viewed/module/recently_viewed', [
            'title'      => $title,
            'limit'      => $this->limit(),
            'product_id' => $product_id,
            'items_url'  => $this->url->link('extension/nk_recently_viewed/module/recently_viewed.items', 'language=' . $this->config->get('config_language'))
        ]);
    }

    /**
     * Renders the cards for the ids the browser remembered. Called over AJAX.
     */
    public function items(): void {
        $this->response->addHeader('Content-Type: text/html; charset=utf-8');

        if (!(int)$this->config->get('module_recently_viewed_status')) {
            $this->response->setOutput('');

            return;
        }

        $this->load->language('extension/nk_recently_viewed/module/recently_viewed');

        $ids = [];

        if (isset($this->request->get['ids'])) {
            foreach (explode(',', (string)$this->request->get['ids']) as $id) {
                $id = (int)trim($id);

                if ($id > 0 && !in_array($id, $ids, true)) {
                    $ids[] = $id;
                }

                if (count($ids) >= self::MAX_IDS) {
                    break;
                }
            }
        }

        $exclude = isset($this->request->get['exclude']) ? (int)$this->request->get['exclude'] : 0;

        if ($exclude > 0) {
            $ids = array_values(array_diff($ids, [$exclude]));
        }

        $ids = array_slice($ids, 0, $this->limit());

        $products = [];

        if ($ids) {
            $this->load->model('catalog/product');
            $this->load->model('tool/image');

            $width = (int)$this->config->get('config_image_product_width') ?: 228;
            $height = (int)$this->config->get('config_image_product_height') ?: 228;

            $show_price = (bool)$this->config->get('module_recently_viewed_show_price');
            $price_allowed = $this->customer->isLogged() || !$this->config->get('config_customer_price');

            foreach ($ids as $product_id) {
                // 4.1: getProduct(int $product_id) — an array argument is a TypeError.
                $product_info = $this->model_catalog_product->getProduct($product_id);

                if (!$product_info) {
                    continue;
                }

                $price = '';
                $special = '';

                if ($show_price && $price_allowed) {
                    $price = $this->currency->format($this->tax->calculate((float)$product_info['price'], (int)$product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);

                    // 4.1 has no `product_special` table: getProduct() derives
                    // `special` from oc_product_discount rows with special = 1.
                    if ((float)$product_info['special']) {
                        $special = $this->currency->format($this->tax->calculate((float)$product_info['special'], (int)$product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
                    }
                }

                $products[] = [
                    'product_id' => (int)$product_info['product_id'],
                    'name'       => (string)$product_info['name'],
                    'href'       => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . (int)$product_info['product_id']),
                    'thumb'      => $this->model_tool_image->resize($product_info['image'] ? html_entity_decode((string)$product_info['image'], ENT_QUOTES, 'UTF-8') : 'placeholder.png', $width, $height),
                    'price'      => $price,
                    'special'    => $special
                ];
            }
        }

        $this->response->setOutput($this->load->view('extension/nk_recently_viewed/module/recently_viewed_items', ['products' => $products]));
    }

    private function limit(): int {
        $limit = (int)$this->config->get('module_recently_viewed_limit');

        return in_array($limit, [4, 6, 8, 12], true) ? $limit : 6;
    }
}
