<?php
namespace Opencart\Admin\Controller\Extension\NkRecentlyViewed\Module;

/**
 * NovaKur Recently Viewed
 *
 * Settings namespace: module_recently_viewed_*
 * Route:              extension/nk_recently_viewed/module/recently_viewed
 *
 * A layout module (Design > Layouts > add "NovaKur Recently Viewed"), so there
 * are no storefront events to register.
 */
class RecentlyViewed extends \Opencart\System\Engine\Controller {
    private string $route = 'extension/nk_recently_viewed/module/recently_viewed';
    private string $prefix = 'module_recently_viewed';

    /**
     * @return array<string, string>
     */
    private function defaults(): array {
        return [
            'module_recently_viewed_status'     => '0',
            'module_recently_viewed_title'      => '',
            'module_recently_viewed_limit'      => '6',
            'module_recently_viewed_show_price' => '1'
        ];
    }

    /**
     * @return array<int, int>
     */
    private function limits(): array {
        return [4, 6, 8, 12];
    }

    public function index(): void {
        $this->load->language($this->route);
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->prefix, $store_id);

        $data = [];

        foreach ([
            'heading_title',
            'text_home',
            'text_extension',
            'text_edit',
            'text_enabled',
            'text_disabled',
            'entry_status',
            'entry_title',
            'entry_limit',
            'entry_show_price',
            'help_title',
            'help_limit',
            'help_show_price',
            'help_layout',
            'button_save',
            'button_back'
        ] as $key) {
            $data[$key] = $this->language->get($key);
        }

        foreach ($this->defaults() as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } else {
                $data[$key] = $settings[$key] ?? $default;
            }
        }

        $data['limits'] = $this->limits();

        $data['breadcrumbs'] = [
            [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
            ],
            [
                'text' => $this->language->get('text_extension'),
                'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
            ],
            [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link($this->route, 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
            ]
        ];

        $data['save'] = $this->url->link($this->route . '.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->route, $data));
    }

    public function save(): void {
        $this->load->language($this->route);

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', $this->route)) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        $post = $this->request->post;
        $save = [];

        foreach (['status', 'show_price'] as $key) {
            $save[$this->prefix . '_' . $key] = (string)(int)!empty($post[$this->prefix . '_' . $key]);
        }

        // Heading is rendered escaped, but tags and control characters have no
        // business in a heading either way.
        $title = trim(strip_tags((string)($post[$this->prefix . '_title'] ?? '')));
        $title = preg_replace('/\s+/u', ' ', $title) ?? '';

        if (oc_strlen($title) > 64) {
            $json['error'][$this->prefix . '_title'] = $this->language->get('error_title');
        } else {
            $save[$this->prefix . '_title'] = $title;
        }

        $limit = (int)($post[$this->prefix . '_limit'] ?? 6);

        if (!in_array($limit, $this->limits(), true)) {
            $json['error'][$this->prefix . '_limit'] = $this->language->get('error_limit');
        } else {
            $save[$this->prefix . '_limit'] = (string)$limit;
        }

        if (!isset($json['error'])) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting($this->prefix, $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting($this->prefix, $this->defaults());

        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->route);
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->route);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting($this->prefix);
    }
}
