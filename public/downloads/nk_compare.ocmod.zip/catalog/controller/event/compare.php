<?php
namespace Opencart\Catalog\Controller\Extension\NkCompare\Event;

/**
 * NovaKur Compare Products - storefront event hooks.
 *
 * Registered by the admin controller's install():
 *   catalog/controller/common/header/before -> header()  queue the css/js in <head>
 *   catalog/view/common/footer/after        -> footer()  inject the floating bar + config
 *   catalog/view/product/thumb/after        -> thumb()   add a compare button to product cards
 */
class Compare extends \Opencart\System\Engine\Controller {
	/**
	 * @param string            $route
	 * @param array<int, mixed> $args
	 *
	 * @return void
	 */
	public function header(string &$route, array &$args): void {
		if (!(int)$this->config->get('module_compare_status')) {
			return;
		}

		$this->document->addStyle('extension/nk_compare/catalog/view/assets/css/compare.css');
		$this->document->addScript('extension/nk_compare/catalog/view/assets/js/compare.js');
	}

	/**
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function footer(string &$route, array &$data, &$output): void {
		if (!(int)$this->config->get('module_compare_status') || !is_string($output)) {
			return;
		}

		if (str_contains($output, 'id="nk-compare-bar"')) {
			return;
		}

		$bar = $this->load->controller('extension/nk_compare/module/compare.bar');

		if (!is_string($bar) || $bar === '') {
			return;
		}

		$config = [
			'add'    => $this->url->link('extension/nk_compare/module/compare.add', 'language=' . $this->config->get('config_language')),
			'remove' => $this->url->link('extension/nk_compare/module/compare.remove', 'language=' . $this->config->get('config_language')),
			'clear'  => $this->url->link('extension/nk_compare/module/compare.clear', 'language=' . $this->config->get('config_language')),
			'sync'   => $this->url->link('extension/nk_compare/module/compare.sync', 'language=' . $this->config->get('config_language')),
			'limit'  => max(2, min(4, (int)$this->config->get('module_compare_limit') ?: 4))
		];

		$html = '<script type="text/javascript">var nk_compare = ' . json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';</script>' . "\n" . $bar;

		if (str_contains($output, '</body>')) {
			$output = str_replace('</body>', $html . '</body>', $output);
		} else {
			$output .= $html;
		}
	}

	/**
	 * Add the compare button to every product card the theme renders.
	 *
	 * @param string               $route
	 * @param array<string, mixed> $data
	 * @param mixed                $output
	 *
	 * @return void
	 */
	public function thumb(string &$route, array &$data, &$output): void {
		if (!(int)$this->config->get('module_compare_status') || !is_string($output) || empty($data['product_id'])) {
			return;
		}

		if (str_contains($output, 'data-compare-add')) {
			return;
		}

		$this->load->language('extension/nk_compare/module/compare');

		$button = '<button type="button" class="nk-compare-add" data-compare-add="' . (int)$data['product_id'] . '" title="' . htmlspecialchars($this->language->get('button_compare'), ENT_QUOTES, 'UTF-8') . '"><i class="fa-solid fa-arrow-right-arrow-left"></i></button>';

		// Default OC4 theme (and most derivatives) group the card buttons in <div class="button">.
		if (str_contains($output, '<div class="button">')) {
			$output = preg_replace('#<div class="button">#', '<div class="button">' . $button, $output, 1) ?? $output;

			return;
		}

		// Unknown markup: append rather than lose the button entirely.
		$output .= '<div class="nk-compare-add-wrap">' . $button . '</div>';
	}
}
