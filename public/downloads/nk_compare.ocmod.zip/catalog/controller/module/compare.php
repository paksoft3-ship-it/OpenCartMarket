<?php
namespace Opencart\Catalog\Controller\Extension\NkCompare\Module;

/**
 * NovaKur Compare Products - storefront endpoints.
 *
 *   extension/nk_compare/module/compare.page    full side by side comparison page
 *   extension/nk_compare/module/compare.bar     floating bar markup (used by the footer event)
 *   extension/nk_compare/module/compare.add     POST product_id
 *   extension/nk_compare/module/compare.remove  POST product_id
 *   extension/nk_compare/module/compare.clear   POST
 *   extension/nk_compare/module/compare.sync    POST product_id[] - restore a localStorage list
 *
 * The floating bar and the compare buttons on product cards are injected by
 * extension/nk_compare/event/compare.*, which the admin controller registers on install.
 */
class Compare extends \Opencart\System\Engine\Controller {
	/**
	 * Hard ceiling regardless of what the merchant configures - the table has to stay readable.
	 */
	private const MAX_PRODUCTS = 4;

	/**
	 * Layout placeholder. The bar is injected sitewide by the footer event.
	 *
	 * @return string
	 */
	public function index(): string {
		return '';
	}

	/**
	 * Floating selection bar.
	 *
	 * @return string
	 */
	public function bar(): string {
		if (!(int)$this->config->get('module_compare_status')) {
			return '';
		}

		$this->load->language('extension/nk_compare/module/compare');

		$data = $this->language->all();

		$data['products'] = [];

		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		foreach ($this->getList() as $product_id) {
			$product_info = $this->model_catalog_product->getProduct($product_id);

			if (!$product_info) {
				continue;
			}

			$data['products'][] = [
				'product_id' => $product_id,
				'name'       => (string)$product_info['name'],
				'thumb'      => $this->thumb($product_info['image'], 50, 50),
				'href'       => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id)
			];
		}

		$data['limit'] = $this->getLimit();
		$data['compare'] = $this->url->link('extension/nk_compare/module/compare.page', 'language=' . $this->config->get('config_language'));

		return $this->load->view('extension/nk_compare/module/compare_bar', $data);
	}

	/**
	 * Full comparison page.
	 *
	 * @return void
	 */
	public function page(): void {
		$this->load->language('extension/nk_compare/module/compare');

		if (!(int)$this->config->get('module_compare_status')) {
			$this->response->redirect($this->url->link('common/home', 'language=' . $this->config->get('config_language')));

			return;
		}

		$this->document->setTitle($this->language->get('heading_title'));

		$data = $this->language->all();

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', 'language=' . $this->config->get('config_language'))
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/nk_compare/module/compare.page', 'language=' . $this->config->get('config_language'))
		];

		$data = array_merge($data, $this->getTable());

		$data['clear'] = $this->url->link('extension/nk_compare/module/compare.clear', 'language=' . $this->config->get('config_language'));
		$data['continue'] = $this->url->link('common/home', 'language=' . $this->config->get('config_language'));

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('extension/nk_compare/module/compare_table', $data));
	}

	/**
	 * Add a product to the comparison list.
	 *
	 * @return void
	 */
	public function add(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$json = [];

		if (!(int)$this->config->get('module_compare_status')) {
			$json['error'] = 'disabled';
		}

		$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

		if (!isset($json['error']) && $product_id < 1) {
			$json['error'] = $this->language->get('error_product');
		}

		if (!isset($json['error'])) {
			$this->load->model('catalog/product');

			// Only real, enabled, in-store products may enter the list - otherwise the
			// session fills up with ids that resolve to nothing on the compare page.
			if (!$this->model_catalog_product->getProduct($product_id)) {
				$json['error'] = $this->language->get('error_product');
			}
		}

		if (!isset($json['error'])) {
			$list = $this->getList();

			if (!in_array($product_id, $list, true)) {
				if (count($list) >= $this->getLimit()) {
					// Oldest out, newest in - silently dropping the click is worse.
					array_shift($list);
				}

				$list[] = $product_id;
			}

			$this->setList($list);

			$json['success'] = $this->language->get('text_success');
		}

		$this->respond($json);
	}

	/**
	 * @return void
	 */
	public function remove(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$json = [];

		if (!(int)$this->config->get('module_compare_status')) {
			$json['error'] = 'disabled';
		}

		if (!isset($json['error'])) {
			$product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;

			$this->setList(array_filter($this->getList(), static fn(int $id): bool => $id !== $product_id));

			$json['success'] = $this->language->get('text_remove');
		}

		$this->respond($json);
	}

	/**
	 * @return void
	 */
	public function clear(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$this->setList([]);

		$this->respond(['success' => $this->language->get('text_remove')]);
	}

	/**
	 * Rebuild the session list from the browser's localStorage copy.
	 *
	 * Sessions expire long before localStorage does; this is what keeps the selection
	 * alive across visits.
	 *
	 * @return void
	 */
	public function sync(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$json = [];

		if (!(int)$this->config->get('module_compare_status')) {
			$json['error'] = 'disabled';
		}

		if (!isset($json['error'])) {
			$posted = isset($this->request->post['product_id']) ? (array)$this->request->post['product_id'] : [];

			$this->load->model('catalog/product');

			$list = [];

			// Cap the loop before validating: an unauthenticated endpoint must not be
			// turned into an unbounded run of product lookups.
			foreach (array_slice($posted, 0, self::MAX_PRODUCTS) as $value) {
				$product_id = (int)$value;

				if ($product_id > 0 && !in_array($product_id, $list, true) && $this->model_catalog_product->getProduct($product_id)) {
					$list[] = $product_id;
				}
			}

			$this->setList($list);

			$json['success'] = 1;
		}

		$this->respond($json);
	}

	/**
	 * Comparison table data, shared by the page and (potentially) any embed.
	 *
	 * @return array<string, mixed>
	 */
	private function getTable(): array {
		$this->load->model('catalog/product');
		$this->load->model('catalog/manufacturer');
		$this->load->model('localisation/stock_status');
		$this->load->model('tool/image');

		$show_attributes = (bool)$this->config->get('module_compare_show_attributes');

		$price_status = $this->customer->isLogged() || !$this->config->get('config_customer_price');

		$products = [];
		$attribute_labels = [];
		$attribute_values = [];

		foreach ($this->getList() as $product_id) {
			$product_info = $this->model_catalog_product->getProduct($product_id);

			if (!$product_info) {
				continue;
			}

			$manufacturer = '';

			// getProduct() only returns manufacturer_id - the name lives in its own table.
			if ($product_info['manufacturer_id']) {
				$manufacturer_info = $this->model_catalog_manufacturer->getManufacturer((int)$product_info['manufacturer_id']);

				if ($manufacturer_info) {
					$manufacturer = (string)$manufacturer_info['name'];
				}
			}

			if ($price_status) {
				$price = $this->currency->format($this->tax->calculate((float)$product_info['price'], (int)$product_info['tax_class_id'], (bool)$this->config->get('config_tax')), $this->session->data['currency']);
			} else {
				$price = '';
			}

			$products[] = [
				'product_id'   => $product_id,
				'name'         => (string)$product_info['name'],
				'thumb'        => $this->thumb($product_info['image'], (int)$this->config->get('config_image_compare_width'), (int)$this->config->get('config_image_compare_height')),
				'href'         => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product_id),
				'price'        => $price,
				'model'        => (string)$product_info['model'],
				'manufacturer' => $manufacturer,
				'stock'        => $this->stockText($product_info),
				'rating'       => sprintf($this->language->get('text_rating'), (int)$product_info['rating'])
			];

			if ($show_attributes) {
				$index = count($products) - 1;

				foreach ($this->model_catalog_product->getAttributes($product_id) as $attribute_group) {
					foreach ($attribute_group['attribute'] as $attribute) {
						$key = (int)$attribute['attribute_id'];

						$attribute_labels[$key] = (string)$attribute['name'];
						$attribute_values[$key][$index] = (string)$attribute['text'];
					}
				}
			}
		}

		$count = count($products);

		$rows = [];

		$fields = [
			'price'        => $this->language->get('text_price'),
			'model'        => $this->language->get('text_model'),
			'manufacturer' => $this->language->get('text_manufacturer'),
			'stock'        => $this->language->get('text_stock'),
			'rating'       => $this->language->get('text_rating_label')
		];

		foreach ($fields as $field => $label) {
			if ($field === 'price' && !$price_status) {
				continue;
			}

			$rows[] = $this->buildRow($label, array_map(static fn(array $product): string => (string)$product[$field], $products));
		}

		foreach ($attribute_labels as $key => $label) {
			$values = [];

			for ($index = 0; $index < $count; $index++) {
				$values[] = $attribute_values[$key][$index] ?? '';
			}

			$rows[] = $this->buildRow($label, $values);
		}

		// "Highlight differences only" hides every row where all products agree.
		if ((bool)$this->config->get('module_compare_diff_only') && $count > 1) {
			$rows = array_values(array_filter($rows, static fn(array $row): bool => $row['different']));
		}

		return [
			'products'        => $products,
			'comparison_rows' => $rows,
			'highlight'       => (bool)$this->config->get('module_compare_highlight'),
			'remove'          => $this->url->link('extension/nk_compare/module/compare.remove', 'language=' . $this->config->get('config_language'))
		];
	}

	/**
	 * @param string            $label
	 * @param array<int, string> $values
	 *
	 * @return array<string, mixed>
	 */
	private function buildRow(string $label, array $values): array {
		return [
			'label'     => $label,
			'values'    => $values,
			'different' => count(array_unique($values)) > 1
		];
	}

	/**
	 * Stock wording, following the store's own stock display settings.
	 *
	 * @param array<string, mixed> $product_info
	 *
	 * @return string
	 */
	private function stockText(array $product_info): string {
		if ((int)$product_info['quantity'] <= 0) {
			$stock_status_id = (int)$product_info['stock_status_id'];
		} elseif (!$this->config->get('config_stock_display')) {
			$stock_status_id = (int)$this->config->get('config_stock_status_id');
		} else {
			return (string)$product_info['quantity'];
		}

		$stock_status_info = $this->model_localisation_stock_status->getStockStatus($stock_status_id);

		if ($stock_status_info) {
			return (string)$stock_status_info['name'];
		}

		return (int)$product_info['quantity'] > 0 ? $this->language->get('text_in_stock') : $this->language->get('text_out_of_stock');
	}

	/**
	 * @param mixed $image
	 * @param int   $width
	 * @param int   $height
	 *
	 * @return string
	 */
	private function thumb($image, int $width, int $height): string {
		if (!$width || !$height) {
			$width = 160;
			$height = 160;
		}

		if ($image && is_file(DIR_IMAGE . html_entity_decode((string)$image, ENT_QUOTES, 'UTF-8'))) {
			return $this->model_tool_image->resize((string)$image, $width, $height);
		}

		return $this->model_tool_image->resize('placeholder.png', $width, $height);
	}

	/**
	 * The comparison list, always a clean list of positive ints within the limit.
	 *
	 * @return array<int, int>
	 */
	private function getList(): array {
		$list = $this->session->data['novakur_compare'] ?? [];

		if (!is_array($list)) {
			return [];
		}

		$clean = [];

		foreach ($list as $value) {
			$product_id = (int)$value;

			if ($product_id > 0 && !in_array($product_id, $clean, true)) {
				$clean[] = $product_id;
			}
		}

		return array_slice($clean, 0, $this->getLimit());
	}

	/**
	 * @param array<int, int> $list
	 *
	 * @return void
	 */
	private function setList(array $list): void {
		$this->session->data['novakur_compare'] = array_slice(array_values($list), 0, $this->getLimit());
	}

	/**
	 * @return int
	 */
	private function getLimit(): int {
		$limit = (int)$this->config->get('module_compare_limit');

		if ($limit < 2) {
			$limit = self::MAX_PRODUCTS;
		}

		return min($limit, self::MAX_PRODUCTS);
	}

	/**
	 * Every mutating endpoint answers with the refreshed bar so the page never
	 * has to guess what the server did.
	 *
	 * @param array<string, mixed> $json
	 *
	 * @return void
	 */
	private function respond(array $json): void {
		if (!isset($json['error'])) {
			$json['items'] = $this->getList();
			$json['html'] = $this->bar();
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}
}
