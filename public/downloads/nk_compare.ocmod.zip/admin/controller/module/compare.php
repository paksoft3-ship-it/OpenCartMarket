<?php
namespace Opencart\Admin\Controller\Extension\NkCompare\Module;

/**
 * NovaKur Compare Products - admin settings.
 */
class Compare extends \Opencart\System\Engine\Controller {
	/**
	 * Storefront events registered on install / removed on uninstall.
	 *
	 * Without these there is no compare button on the product cards and no floating bar,
	 * which is the whole storefront surface of the module.
	 *
	 * @var array<int, array<string, string>>
	 */
	private array $events = [
		[
			'code'        => 'nk_compare_header',
			'description' => 'NovaKur Compare: queue the comparison stylesheet and script in the page head.',
			'trigger'     => 'catalog/controller/common/header/before',
			'action'      => 'extension/nk_compare/event/compare.header'
		],
		[
			'code'        => 'nk_compare_footer',
			'description' => 'NovaKur Compare: inject the floating comparison bar into every page.',
			'trigger'     => 'catalog/view/common/footer/after',
			'action'      => 'extension/nk_compare/event/compare.footer'
		],
		[
			'code'        => 'nk_compare_thumb',
			'description' => 'NovaKur Compare: add the compare button to product cards.',
			'trigger'     => 'catalog/view/product/thumb/after',
			'action'      => 'extension/nk_compare/event/compare.thumb'
		]
	];

	/**
	 * @return array<string, string>
	 */
	private function defaults(): array {
		return [
			'module_compare_status'          => '0',
			'module_compare_limit'           => '4',
			'module_compare_highlight'       => '1',
			'module_compare_diff_only'       => '0',
			'module_compare_show_attributes' => '1'
		];
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$this->document->setTitle($this->language->get('heading_title'));

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		$this->load->model('setting/setting');

		$settings = $this->model_setting_setting->getSetting('module_compare', $store_id);

		foreach ($this->defaults() as $key => $default) {
			if (isset($this->request->post[$key])) {
				$data[$key] = $this->request->post[$key];
			} elseif (isset($settings[$key])) {
				$data[$key] = $settings[$key];
			} else {
				$data[$key] = $default;
			}
		}

		foreach ($this->language->all() as $key => $value) {
			$data[$key] = $value;
		}

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/nk_compare/module/compare', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
		];

		$data['save'] = $this->url->link('extension/nk_compare/module/compare.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/nk_compare/module/compare', $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/nk_compare/module/compare');

		$json = [];

		$store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

		if (!$this->user->hasPermission('modify', 'extension/nk_compare/module/compare')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		$post = $this->request->post;

		$limit = isset($post['module_compare_limit']) ? (int)$post['module_compare_limit'] : 4;

		// The table is laid out for at most four columns.
		if ($limit < 2 || $limit > 4) {
			$json['error']['limit'] = $this->language->get('error_limit');
		}

		if (!$json) {
			$save = [
				'module_compare_status'          => !empty($post['module_compare_status']) ? '1' : '0',
				'module_compare_limit'           => (string)$limit,
				'module_compare_highlight'       => !empty($post['module_compare_highlight']) ? '1' : '0',
				'module_compare_diff_only'       => !empty($post['module_compare_diff_only']) ? '1' : '0',
				'module_compare_show_attributes' => !empty($post['module_compare_show_attributes']) ? '1' : '0'
			];

			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_compare', $save, $store_id);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)json_encode($json));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->load->model('setting/setting');

		$this->model_setting_setting->editSetting('module_compare', $this->defaults());

		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);

			$this->model_setting_event->addEvent([
				'code'        => $event['code'],
				'description' => $event['description'],
				'trigger'     => $event['trigger'],
				'action'      => $event['action'],
				'status'      => 1,
				'sort_order'  => 1
			]);
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->load->model('setting/event');

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['code']);
		}

		$this->load->model('setting/setting');

		$this->model_setting_setting->deleteSetting('module_compare');
	}
}
