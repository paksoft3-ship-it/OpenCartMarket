<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Module;

class OnepageCheckout extends \Opencart\System\Engine\Controller {
    /**
     * Event rows this module owns. Registered on install, removed on uninstall.
     *
     * @var array<int, array<string, mixed>>
     */
    private array $events = [
        [
            'code'        => 'novakur_onepage_checkout',
            'description' => 'NovaKur One-Page Checkout: loads the one-page checkout assets.',
            'trigger'     => 'catalog/controller/checkout/checkout/before',
            'action'      => 'extension/novakur/event/onepage_checkout.before',
            'status'      => 1,
            'sort_order'  => 1
        ],
        [
            'code'        => 'novakur_onepage_checkout_view',
            'description' => 'NovaKur One-Page Checkout: swaps the checkout template for the one-page accordion.',
            'trigger'     => 'catalog/view/checkout/checkout/before',
            'action'      => 'extension/novakur/event/onepage_checkout.view',
            'status'      => 1,
            'sort_order'  => 1
        ]
    ];

    public function index(): void {
        $this->load->language('extension/novakur/module/onepage_checkout');
        $this->document->setTitle($this->language->get('heading_title'));

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting('module_onepage_checkout', $store_id);

        $defaults = [
            'module_onepage_checkout_status'           => '0',
            'module_onepage_checkout_guest_highlight'  => '1',
            'module_onepage_checkout_show_comments'    => '1'
        ];

        foreach ($defaults as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = (string)(int)$this->request->post[$key];
            } elseif (isset($settings[$key])) {
                $data[$key] = (string)(int)$settings[$key];
            } else {
                $data[$key] = $default;
            }
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_section_order'] = $this->language->get('text_section_order');
        $data['text_payment_note'] = $this->language->get('text_payment_note');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_guest_highlight'] = $this->language->get('entry_guest_highlight');
        $data['entry_show_comments'] = $this->language->get('entry_show_comments');
        $data['entry_sections'] = $this->language->get('entry_sections');
        $data['help_guest_highlight'] = $this->language->get('help_guest_highlight');
        $data['help_show_comments'] = $this->language->get('help_show_comments');
        $data['help_sections'] = $this->language->get('help_sections');

        $data['sections'] = [
            $this->language->get('text_section_cart'),
            $this->language->get('text_section_customer'),
            $this->language->get('text_section_shipping_address'),
            $this->language->get('text_section_shipping_method'),
            $this->language->get('text_section_payment_method'),
            $this->language->get('text_section_confirm')
        ];

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/novakur/module/onepage_checkout', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id)
        ];

        $data['save'] = $this->url->link('extension/novakur/module/onepage_checkout.save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $store_id);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur/module/onepage_checkout', $data));
    }

    public function save(): void {
        $this->load->language('extension/novakur/module/onepage_checkout');

        $json = [];

        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : 0;

        if (!$this->user->hasPermission('modify', 'extension/novakur/module/onepage_checkout')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!isset($json['error'])) {
            // Only the keys below are ever persisted, and each is normalised to '0' or '1'.
            $save = [];

            foreach (['module_onepage_checkout_status', 'module_onepage_checkout_guest_highlight', 'module_onepage_checkout_show_comments'] as $key) {
                $save[$key] = isset($this->request->post[$key]) ? (string)(int)(bool)$this->request->post[$key] : '0';
            }

            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_onepage_checkout', $save, $store_id);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $this->model_setting_setting->editSetting('module_onepage_checkout', [
            'module_onepage_checkout_status'          => '0',
            'module_onepage_checkout_guest_highlight' => '1',
            'module_onepage_checkout_show_comments'   => '1'
        ]);

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('module_onepage_checkout');

        $this->load->model('setting/event');

        foreach ($this->events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
        }
    }
}
