<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Module;

/**
 * NovaKur One-Page Checkout — cart summary partial.
 *
 * Rendered inline by the checkout event on first paint, and re-fetched over AJAX by
 * onepage_checkout.js whenever a checkout step changes the order totals.
 */
class OnepageCheckout extends \Opencart\System\Engine\Controller {
    /**
     * @return string
     */
    public function index(): string {
        if (!$this->config->get('module_onepage_checkout_status')) {
            return '';
        }

        $this->load->language('extension/novakur/checkout/onepage');

        $language = (string)$this->config->get('config_language');

        $data['nk_cart_url'] = $this->url->link('checkout/cart', 'language=' . $language);

        foreach (['nk_text_items', 'nk_text_edit_cart', 'nk_text_empty', 'nk_text_model'] as $key) {
            $data[$key] = $this->language->get($key);
        }

        // Products
        $this->load->model('checkout/cart');
        $this->load->model('tool/image');

        $data['nk_products'] = [];
        $data['nk_quantity'] = 0;

        foreach ($this->model_checkout_cart->getProducts() as $product) {
            $option_data = [];

            foreach ($product['option'] as $option) {
                $value = (string)$option['value'];

                $option_data[] = [
                    'name'  => html_entity_decode((string)$option['name'], ENT_QUOTES, 'UTF-8'),
                    'value' => html_entity_decode(oc_strlen($value) > 24 ? oc_substr($value, 0, 24) . '..' : $value, ENT_QUOTES, 'UTF-8')
                ];
            }

            $data['nk_quantity'] += (int)$product['quantity'];

            $data['nk_products'][] = [
                'name'       => html_entity_decode((string)$product['name'], ENT_QUOTES, 'UTF-8'),
                'model'      => html_entity_decode((string)$product['model'], ENT_QUOTES, 'UTF-8'),
                'quantity'   => (int)$product['quantity'],
                'option'     => $option_data,
                'thumb'      => $this->model_tool_image->resize((string)$product['image'], (int)$this->config->get('config_image_cart_width'), (int)$this->config->get('config_image_cart_height')),
                'total_text' => $product['total_text'],
                'href'       => $this->url->link('product/product', 'language=' . $language . '&product_id=' . (int)$product['product_id'])
            ];
        }

        // Totals. Only shown to shoppers allowed to see prices, mirroring checkout/confirm.
        $data['nk_totals'] = [];

        if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
            $totals = [];
            $taxes = $this->cart->getTaxes();
            $total = 0;

            // getTotals() takes its arguments by reference, so it is invoked through the
            // model proxy as a callable the same way checkout/confirm does it.
            ($this->model_checkout_cart->getTotals)($totals, $taxes, $total);

            foreach ($totals as $result) {
                $data['nk_totals'][] = [
                    'title' => html_entity_decode((string)$result['title'], ENT_QUOTES, 'UTF-8'),
                    'text'  => $this->currency->format((float)$result['value'], $this->session->data['currency'])
                ];
            }
        }

        return $this->load->view('extension/novakur/checkout/onepage_summary', $data);
    }

    /**
     * AJAX endpoint: index.php?route=extension/novakur/module/onepage_checkout.summary
     *
     * @return void
     */
    public function summary(): void {
        $this->response->setOutput($this->index());
    }
}
