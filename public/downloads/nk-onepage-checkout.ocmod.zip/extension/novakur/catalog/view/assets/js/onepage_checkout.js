/**
 * NovaKur One-Page Checkout
 *
 * Drives the accordion only. Every checkout request is still fired by OpenCart's own
 * inline section scripts against OpenCart's own endpoints; this file just listens to the
 * results so it can tick a step off and slide the next one open.
 */
(function () {
  'use strict';

  var $ = window.jQuery;

  if (!$) {
    return;
  }

  var OWN_ROUTE = 'extension/novakur/module/onepage_checkout';

  $(function () {
    var $root = $('#checkout-checkout.nk-opc');

    if (!$root.length) {
      return;
    }

    var summaryUrl = String($root.attr('data-nk-summary-url') || '');
    var guestHighlight = String($root.attr('data-nk-guest-highlight') || '0') === '1';
    var showComments = String($root.attr('data-nk-show-comments') || '1') === '1';
    var guestBadge = String($root.attr('data-nk-guest-badge') || '');

    var $steps = $root.find('.nk-opc-step');

    if (!$steps.length) {
      return;
    }

    function escapeHtml(value) {
      return String(value).replace(/[&<>"']/g, function (chr) {
        return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[chr];
      });
    }

    function step(name) {
      return $steps.filter('[data-nk-step="' + name + '"]');
    }

    function isDone($step) {
      return $step.attr('data-nk-done') === '1';
    }

    function markDone(name) {
      step(name).attr('data-nk-done', '1').addClass('is-done');
    }

    function markUndone(name) {
      step(name).attr('data-nk-done', '0').removeClass('is-done');
    }

    function open($step, scroll) {
      if (!$step || !$step.length) {
        return;
      }

      $steps.removeClass('is-open').children('.nk-opc-heading').children('.nk-opc-toggle').attr('aria-expanded', 'false');
      $step.addClass('is-open').children('.nk-opc-heading').children('.nk-opc-toggle').attr('aria-expanded', 'true');

      if (scroll) {
        var top = $step.offset().top - 20;

        if (Math.abs(top - $(window).scrollTop()) > 40) {
          $('html, body').animate({scrollTop: top}, 250);
        }
      }
    }

    // Opens the first step that has not been completed yet, starting the search after
    // the step that was just finished. Falls back to the confirm step.
    function openNext(afterName, scroll) {
      var startIndex = 0;

      if (afterName) {
        var $from = step(afterName);

        if ($from.length) {
          startIndex = $steps.index($from) + 1;
        }
      }

      for (var i = startIndex; i < $steps.length; i++) {
        var $candidate = $steps.eq(i);

        if (!isDone($candidate)) {
          open($candidate, scroll);
          return;
        }
      }

      open(step('confirm'), scroll);
    }

    function refreshSummary() {
      var $summary = $('#nk-opc-summary');

      if (!$summary.length || !summaryUrl) {
        return;
      }

      $summary.children().addClass('is-loading');

      $.ajax({
        url: summaryUrl,
        dataType: 'html',
        success: function (html) {
          $summary.html(html);
        },
        error: function () {
          $summary.children().removeClass('is-loading');
        }
      });
    }

    /* --- Accordion interaction ------------------------------------------------ */

    $root.on('click', '.nk-opc-toggle', function () {
      var $step = $(this).closest('.nk-opc-step');

      if ($step.hasClass('is-open')) {
        $step.removeClass('is-open');
        $(this).attr('aria-expanded', 'false');
      } else {
        open($step, false);
      }
    });

    /* --- Admin toggles -------------------------------------------------------- */

    if (!showComments) {
      // The stock payment_method template wraps the textarea in a .mb-2 block.
      $('#input-comment').closest('.mb-2').hide();
    }

    if (guestHighlight) {
      var $guest = $('#input-guest');

      if ($guest.length && !$guest.prop('disabled')) {
        $guest.prop('checked', true).trigger('click');

        var $label = $('label[for="input-guest"]');

        if (guestBadge && $label.length && !$label.find('.nk-opc-guest-highlight').length) {
          $label.append(' <span class="nk-opc-guest-highlight">' + escapeHtml(guestBadge) + '</span>');
        }
      }
    }

    /* --- Follow OpenCart's own checkout traffic ------------------------------- */

    function routeOf(url) {
      var match = /[?&]route=([^&#]+)/.exec(String(url || ''));

      return match ? decodeURIComponent(match[1]) : '';
    }

    function jsonOf(xhr) {
      if (xhr && typeof xhr.responseJSON === 'object' && xhr.responseJSON !== null) {
        return xhr.responseJSON;
      }

      try {
        return JSON.parse(xhr.responseText);
      } catch (e) {
        return null;
      }
    }

    $(document).ajaxSuccess(function (event, xhr, settings) {
      var route = routeOf(settings ? settings.url : '');

      if (!route || route.indexOf(OWN_ROUTE) === 0) {
        return;
      }

      var json = jsonOf(xhr);

      if (!json || !json.success) {
        return;
      }

      switch (route) {
        case 'checkout/register.save':
          markDone('customer');
          // Saving customer details invalidates any previously chosen methods.
          markUndone('shipping_method');
          markUndone('payment_method');
          refreshSummary();
          openNext('customer', true);
          break;

        case 'checkout/payment_address.save':
        case 'checkout/payment_address.address':
          markDone('payment_address');
          markUndone('shipping_method');
          markUndone('payment_method');
          refreshSummary();
          openNext('payment_address', true);
          break;

        case 'checkout/shipping_address.save':
        case 'checkout/shipping_address.address':
          markDone('shipping_address');
          markUndone('shipping_method');
          markUndone('payment_method');
          refreshSummary();
          openNext('shipping_address', true);
          break;

        case 'checkout/shipping_method.save':
          markDone('shipping_method');
          markUndone('payment_method');
          refreshSummary();
          openNext('shipping_method', true);
          break;

        case 'checkout/payment_method.save':
          markDone('payment_method');
          refreshSummary();
          openNext('payment_method', true);
          break;

        default:
          break;
      }
    });

    /* --- Initial state -------------------------------------------------------- */

    openNext(null, false);
  });
})();
