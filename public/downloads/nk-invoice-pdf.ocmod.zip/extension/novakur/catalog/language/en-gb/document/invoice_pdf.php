<?php
// Text
$_['text_invoice']          = 'Invoice';
$_['text_packing_slip']     = 'Packing Slip';
$_['text_invoice_no']       = 'Invoice No.';
$_['text_invoice_date']     = 'Invoice Date';
$_['text_order_id']         = 'Order ID';
$_['text_order_date']       = 'Order Date';
$_['text_order_status']     = 'Order Status';
$_['text_bill_to']          = 'Bill To';
$_['text_ship_to']          = 'Ship To';
$_['text_payment_method']   = 'Payment Method';
$_['text_shipping_method']  = 'Shipping Method';
$_['text_email']            = 'E-Mail';
$_['text_telephone']        = 'Telephone';
$_['text_comment']          = 'Order Comment';
$_['text_tax_breakdown']    = 'VAT / Tax Breakdown';
$_['text_net_total']        = 'Total (net)';
$_['text_tax_total']        = 'Total tax';
$_['text_gross_total']      = 'Total (gross)';
$_['text_total']            = 'Total';
$_['text_print']            = 'Print';
$_['text_no_orders']        = 'No printable order was found.';

// Column
$_['column_product']        = 'Product';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Qty';
$_['column_unit_net']       = 'Unit price (net)';
$_['column_tax_rate']       = 'Tax %';
$_['column_tax_amount']     = 'Tax';
$_['column_line_net']       = 'Line total (net)';
$_['column_line_gross']     = 'Line total (gross)';
$_['column_taxable_net']    = 'Taxable amount (net)';
$_['column_tax']            = 'Tax amount';

// Button
$_['button_print_invoice']  = 'Print invoice';
