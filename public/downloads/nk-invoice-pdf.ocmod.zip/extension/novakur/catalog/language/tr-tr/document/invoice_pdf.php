<?php
// Text
$_['text_invoice']          = 'Fatura';
$_['text_packing_slip']     = 'İrsaliye';
$_['text_invoice_no']       = 'Fatura No';
$_['text_invoice_date']     = 'Fatura Tarihi';
$_['text_order_id']         = 'Sipariş No';
$_['text_order_date']       = 'Sipariş Tarihi';
$_['text_order_status']     = 'Sipariş Durumu';
$_['text_bill_to']          = 'Fatura Adresi';
$_['text_ship_to']          = 'Teslimat Adresi';
$_['text_payment_method']   = 'Ödeme Yöntemi';
$_['text_shipping_method']  = 'Kargo Yöntemi';
$_['text_email']            = 'E-Posta';
$_['text_telephone']        = 'Telefon';
$_['text_comment']          = 'Sipariş Notu';
$_['text_tax_breakdown']    = 'KDV / Vergi Dökümü';
$_['text_net_total']        = 'Toplam (matrah)';
$_['text_tax_total']        = 'Toplam vergi';
$_['text_gross_total']      = 'Genel toplam';
$_['text_total']            = 'Toplam';
$_['text_print']            = 'Yazdır';
$_['text_no_orders']        = 'Yazdırılabilir sipariş bulunamadı.';

// Column
$_['column_product']        = 'Ürün';
$_['column_model']          = 'Model';
$_['column_quantity']       = 'Adet';
$_['column_unit_net']       = 'Birim fiyat (matrah)';
$_['column_tax_rate']       = 'KDV %';
$_['column_tax_amount']     = 'Vergi';
$_['column_line_net']       = 'Satır toplamı (matrah)';
$_['column_line_gross']     = 'Satır toplamı (KDV dahil)';
$_['column_taxable_net']    = 'Matrah';
$_['column_tax']            = 'Vergi tutarı';

// Button
$_['button_print_invoice']  = 'Faturayı yazdır';
