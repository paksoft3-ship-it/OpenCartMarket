<?php
namespace Opencart\Catalog\Model\Extension\Novakur\Invoice;

class InvoicePdf extends \Opencart\System\Engine\Model {
    /**
     * @param int $order_id
     *
     * @return array<string, mixed>
     */
    public function getInvoice(int $order_id): array {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "nk_invoice_pdf` WHERE `order_id` = '" . (int)$order_id . "' LIMIT 1");

        return $query->row ? $query->row : [];
    }

    /**
     * @param string $prefix
     *
     * @return int
     */
    public function getMaxNumber(string $prefix): int {
        $query = $this->db->query("SELECT MAX(`invoice_number`) AS `invoice_number` FROM `" . DB_PREFIX . "nk_invoice_pdf` WHERE `invoice_prefix` = '" . $this->db->escape($prefix) . "'");

        return (int)($query->row['invoice_number'] ?? 0);
    }

    /**
     * Issue (or return the already issued) invoice number for an order.
     *
     * @param int    $order_id
     * @param string $prefix
     * @param int    $start
     *
     * @return array<string, mixed>
     */
    public function addInvoice(int $order_id, string $prefix, int $start): array {
        // Defensive: the table is created by the admin installer, but a half-installed
        // store must not fatal on the storefront.
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "nk_invoice_pdf` (
            `invoice_pdf_id` int(11) NOT NULL AUTO_INCREMENT,
            `order_id` int(11) NOT NULL DEFAULT '0',
            `invoice_prefix` varchar(32) NOT NULL DEFAULT '',
            `invoice_number` int(11) NOT NULL DEFAULT '0',
            `date_added` datetime NOT NULL,
            PRIMARY KEY (`invoice_pdf_id`),
            UNIQUE KEY `order_id` (`order_id`),
            KEY `invoice_prefix` (`invoice_prefix`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $invoice_info = $this->getInvoice($order_id);

        if ($invoice_info) {
            return $invoice_info;
        }

        if ($start < 1) {
            $start = 1;
        }

        $max = $this->getMaxNumber($prefix);

        $number = ($max + 1 > $start) ? $max + 1 : $start;

        $this->db->query("INSERT INTO `" . DB_PREFIX . "nk_invoice_pdf` SET `order_id` = '" . (int)$order_id . "', `invoice_prefix` = '" . $this->db->escape($prefix) . "', `invoice_number` = '" . (int)$number . "', `date_added` = NOW() ON DUPLICATE KEY UPDATE `order_id` = `order_id`");

        return $this->getInvoice($order_id);
    }
}
