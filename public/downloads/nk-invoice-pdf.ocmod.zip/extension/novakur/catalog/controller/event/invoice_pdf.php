<?php
namespace Opencart\Catalog\Controller\Extension\Novakur\Event;

class InvoicePdf extends \Opencart\System\Engine\Controller {
    /**
     * Injects a "Print invoice" button into the customer's account order page.
     *
     * Trigger: catalog/view/account/order_info/after
     *
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function orderInfo(string &$route, array &$data, mixed &$output): void {
        if (!$this->config->get('module_invoice_pdf_status')) {
            return;
        }

        if (!is_string($output) || $output === '') {
            return;
        }

        if (!isset($this->session->data['customer_token'])) {
            return;
        }

        $order_id = isset($data['order_id']) ? (int)$data['order_id'] : 0;

        if (!$order_id) {
            return;
        }

        $this->load->language('extension/novakur/document/invoice_pdf', '', 'en-gb');
        $this->load->language('extension/novakur/document/invoice_pdf');

        $link = $this->url->link('extension/novakur/document/invoice_pdf.invoice', 'language=' . $this->config->get('config_language') . '&customer_token=' . $this->session->data['customer_token'] . '&order_id=' . $order_id);

        $button = '<div class="text-end mt-3 nk-invoice-pdf-print"><a href="' . $link . '" target="_blank" rel="noopener" class="btn btn-outline-secondary"><i class="fa-solid fa-file-invoice"></i> ' . htmlspecialchars($this->language->get('button_print_invoice'), ENT_QUOTES, 'UTF-8') . '</a></div>';

        $anchor = '<div class="text-end mt-3">';

        $position = strpos($output, $anchor);

        if ($position !== false) {
            $output = substr_replace($output, $button . $anchor, $position, strlen($anchor));
        } else {
            $output = str_replace('</body>', $button . '</body>', $output);
        }
    }
}
