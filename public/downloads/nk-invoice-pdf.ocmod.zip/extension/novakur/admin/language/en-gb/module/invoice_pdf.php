<?php
// Heading
$_['heading_title']            = 'NovaKur Invoice + Packing Slip';

// Text
$_['text_home']                = 'Home';
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified NovaKur Invoice + Packing Slip settings!';
$_['text_edit']                = 'Edit NovaKur Invoice + Packing Slip';
$_['text_enabled']             = 'Enabled';
$_['text_disabled']            = 'Disabled';
$_['text_general']             = 'General';
$_['text_branding']            = 'Branding';
$_['text_numbering']           = 'Invoice numbering';
$_['text_how_it_works']        = 'How printing works';
$_['text_pdf_notice']          = 'OpenCart 4 ships no PDF library (no dompdf/TCPDF/mPDF in system/storage/vendor), and this extension adds no Composer dependencies. Invoices and packing slips are therefore rendered as pixel-clean printable HTML documents with a dedicated A4 print stylesheet. Opening one automatically triggers the browser print dialog, where "Save as PDF" produces the PDF file. Append &amp;preview=1 to the document URL to open it without the print dialog.';
$_['text_where_buttons']       = 'Once enabled, a green invoice button (and, if switched on, a packing slip button) appears in the top-right button bar of Sales &gt; Orders &gt; View. Customers get a "Print invoice" button at the bottom of their own order page under My Account &gt; Order History.';

// Document
$_['text_invoice']             = 'Invoice';
$_['text_packing_slip']        = 'Packing Slip';
$_['text_invoice_no']          = 'Invoice No.';
$_['text_invoice_date']        = 'Invoice Date';
$_['text_order_id']            = 'Order ID';
$_['text_order_date']          = 'Order Date';
$_['text_order_status']        = 'Order Status';
$_['text_bill_to']             = 'Bill To';
$_['text_ship_to']             = 'Ship To';
$_['text_payment_method']      = 'Payment Method';
$_['text_shipping_method']     = 'Shipping Method';
$_['text_email']               = 'E-Mail';
$_['text_telephone']           = 'Telephone';
$_['text_comment']             = 'Order Comment';
$_['text_tax_breakdown']       = 'VAT / Tax Breakdown';
$_['text_net_total']           = 'Total (net)';
$_['text_tax_total']           = 'Total tax';
$_['text_gross_total']         = 'Total (gross)';
$_['text_total']               = 'Total';
$_['text_print']               = 'Print';
$_['text_no_orders']           = 'No printable order was found.';

// Column
$_['column_product']           = 'Product';
$_['column_model']             = 'Model';
$_['column_quantity']          = 'Qty';
$_['column_unit_net']          = 'Unit price (net)';
$_['column_tax_rate']          = 'Tax %';
$_['column_tax_amount']        = 'Tax';
$_['column_line_net']          = 'Line total (net)';
$_['column_line_gross']        = 'Line total (gross)';
$_['column_taxable_net']       = 'Taxable amount (net)';
$_['column_tax']               = 'Tax amount';

// Entry
$_['entry_status']             = 'Status';
$_['entry_logo']               = 'Invoice logo';
$_['entry_company']            = 'Company address block';
$_['entry_prefix']             = 'Invoice number prefix';
$_['entry_next_number']        = 'Next invoice number';
$_['entry_footer']             = 'Footer note';
$_['entry_show_packing_slip']  = 'Packing slip';

// Help
$_['help_logo']                = 'Shown at the top of every invoice and packing slip. Leave empty to fall back to the store logo from System &gt; Settings.';
$_['help_company']             = 'Your legal company block: registered name, address, tax/VAT number, trade registry number. One item per line — line breaks are preserved on the document.';
$_['help_prefix']              = 'Prepended to the sequence number, e.g. "INV-2026-". Letters, digits, - _ . / only, max 32 characters. Each prefix keeps its own counter.';
$_['help_next_number']         = 'The starting point of the sequence. A number is issued the first time an invoice is generated for an order and is then permanent for that order. Numbers already issued are never reused, so raising this value skips ahead but lowering it has no effect.';
$_['help_next_number_live']    = 'The next invoice will be issued as: %s';
$_['help_footer']              = 'Free text printed at the bottom of every document — payment terms, IBAN, thank-you note.';
$_['help_show_packing_slip']   = 'Adds a second button that prints the same document with every price, tax and total removed — for the warehouse.';

// Button
$_['button_print_invoice']     = 'Print invoice';
$_['button_print_packing_slip'] = 'Print packing slip';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify NovaKur Invoice + Packing Slip!';
$_['error_prefix']             = 'Prefix must be 32 characters or fewer and may only contain letters, digits and - _ . /';
$_['error_next_number']        = 'Next invoice number must be a whole number between 1 and 999999999!';
$_['error_logo']               = 'The selected logo could not be found in the image directory!';
