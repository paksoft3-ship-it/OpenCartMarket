<?php
// Heading
$_['heading_title']            = 'NovaKur Fatura + İrsaliye';

// Text
$_['text_home']                = 'Anasayfa';
$_['text_extension']           = 'Eklentiler';
$_['text_success']             = 'Başarılı: NovaKur Fatura + İrsaliye ayarlarını değiştirdiniz!';
$_['text_edit']                = 'NovaKur Fatura + İrsaliye Düzenle';
$_['text_enabled']             = 'Etkin';
$_['text_disabled']            = 'Devre Dışı';
$_['text_general']             = 'Genel';
$_['text_branding']            = 'Marka';
$_['text_numbering']           = 'Fatura numaralandırma';
$_['text_how_it_works']        = 'Yazdırma nasıl çalışır';
$_['text_pdf_notice']          = 'OpenCart 4 hiçbir PDF kütüphanesi ile gelmez (system/storage/vendor içinde dompdf/TCPDF/mPDF yoktur) ve bu eklenti hiçbir Composer bağımlılığı eklemez. Bu nedenle faturalar ve irsaliyeler, A4 için hazırlanmış özel bir yazdırma stiliyle kusursuz yazdırılabilir HTML belgeleri olarak oluşturulur. Belge açıldığında tarayıcının yazdırma penceresi otomatik olarak açılır; oradaki "PDF olarak kaydet" seçeneği PDF dosyasını üretir. Yazdırma penceresi olmadan açmak için belge adresinin sonuna &amp;preview=1 ekleyin.';
$_['text_where_buttons']       = 'Etkinleştirildiğinde, Satış &gt; Siparişler &gt; Görüntüle sayfasının sağ üst düğme çubuğunda yeşil bir fatura düğmesi (açıksa bir de irsaliye düğmesi) görünür. Müşteriler ise Hesabım &gt; Sipariş Geçmişi altındaki kendi sipariş sayfalarının altında "Faturayı yazdır" düğmesini görür.';

// Document
$_['text_invoice']             = 'Fatura';
$_['text_packing_slip']        = 'İrsaliye';
$_['text_invoice_no']          = 'Fatura No';
$_['text_invoice_date']        = 'Fatura Tarihi';
$_['text_order_id']            = 'Sipariş No';
$_['text_order_date']          = 'Sipariş Tarihi';
$_['text_order_status']        = 'Sipariş Durumu';
$_['text_bill_to']             = 'Fatura Adresi';
$_['text_ship_to']             = 'Teslimat Adresi';
$_['text_payment_method']      = 'Ödeme Yöntemi';
$_['text_shipping_method']     = 'Kargo Yöntemi';
$_['text_email']               = 'E-Posta';
$_['text_telephone']           = 'Telefon';
$_['text_comment']             = 'Sipariş Notu';
$_['text_tax_breakdown']       = 'KDV / Vergi Dökümü';
$_['text_net_total']           = 'Toplam (matrah)';
$_['text_tax_total']           = 'Toplam vergi';
$_['text_gross_total']         = 'Genel toplam';
$_['text_total']               = 'Toplam';
$_['text_print']               = 'Yazdır';
$_['text_no_orders']           = 'Yazdırılabilir sipariş bulunamadı.';

// Column
$_['column_product']           = 'Ürün';
$_['column_model']             = 'Model';
$_['column_quantity']          = 'Adet';
$_['column_unit_net']          = 'Birim fiyat (matrah)';
$_['column_tax_rate']          = 'KDV %';
$_['column_tax_amount']        = 'Vergi';
$_['column_line_net']          = 'Satır toplamı (matrah)';
$_['column_line_gross']        = 'Satır toplamı (KDV dahil)';
$_['column_taxable_net']       = 'Matrah';
$_['column_tax']               = 'Vergi tutarı';

// Entry
$_['entry_status']             = 'Durum';
$_['entry_logo']               = 'Fatura logosu';
$_['entry_company']            = 'Firma adres bloğu';
$_['entry_prefix']             = 'Fatura numarası ön eki';
$_['entry_next_number']        = 'Sonraki fatura numarası';
$_['entry_footer']             = 'Alt bilgi notu';
$_['entry_show_packing_slip']  = 'İrsaliye';

// Help
$_['help_logo']                = 'Her fatura ve irsaliyenin üst kısmında gösterilir. Boş bırakılırsa Sistem &gt; Ayarlar bölümündeki mağaza logosu kullanılır.';
$_['help_company']             = 'Yasal firma bilgileriniz: unvan, adres, vergi dairesi ve vergi numarası, ticaret sicil numarası. Her satıra bir bilgi yazın — satır sonları belgede korunur.';
$_['help_prefix']              = 'Sıra numarasının önüne eklenir, örn. "FTR-2026-". Yalnızca harf, rakam ve - _ . / karakterleri, en fazla 32 karakter. Her ön ek kendi sayacını tutar.';
$_['help_next_number']         = 'Serinin başlangıç noktasıdır. Numara, bir sipariş için fatura ilk kez oluşturulduğunda verilir ve o sipariş için kalıcı olur. Verilmiş numaralar asla tekrar kullanılmaz; bu nedenle değeri yükseltmek ileri atlar, düşürmek ise etkisizdir.';
$_['help_next_number_live']    = 'Verilecek ilk fatura numarası: %s';
$_['help_footer']              = 'Her belgenin altına basılan serbest metin — ödeme koşulları, IBAN, teşekkür notu.';
$_['help_show_packing_slip']   = 'Aynı belgeyi tüm fiyat, vergi ve toplamlar kaldırılmış hâlde yazdıran ikinci bir düğme ekler — depo için.';

// Button
$_['button_print_invoice']     = 'Faturayı yazdır';
$_['button_print_packing_slip'] = 'İrsaliyeyi yazdır';

// Error
$_['error_permission']         = 'Uyarı: NovaKur Fatura + İrsaliye ayarlarını değiştirme yetkiniz yok!';
$_['error_prefix']             = 'Ön ek en fazla 32 karakter olmalı ve yalnızca harf, rakam ve - _ . / içerebilir!';
$_['error_next_number']        = 'Sonraki fatura numarası 1 ile 999999999 arasında bir tam sayı olmalıdır!';
$_['error_logo']               = 'Seçilen logo görsel dizininde bulunamadı!';
