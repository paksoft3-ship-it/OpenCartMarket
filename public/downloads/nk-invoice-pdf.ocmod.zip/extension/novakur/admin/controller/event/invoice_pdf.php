<?php
namespace Opencart\Admin\Controller\Extension\Novakur\Event;

class InvoicePdf extends \Opencart\System\Engine\Controller {
    /**
     * Injects "Print invoice" / "Print packing slip" buttons into the admin order view.
     *
     * Trigger: admin/view/sale/order_info/after
     *
     * @param string               $route
     * @param array<string, mixed> $data
     * @param mixed                $output
     *
     * @return void
     */
    public function orderInfo(string &$route, array &$data, mixed &$output): void {
        if (!$this->config->get('module_invoice_pdf_status')) {
            return;
        }

        if (!is_string($output) || $output === '') {
            return;
        }

        if (!isset($this->session->data['user_token'])) {
            return;
        }

        $order_id = isset($data['order_id']) ? (int)$data['order_id'] : 0;

        if (!$order_id) {
            return;
        }

        $this->load->language('extension/novakur/module/invoice_pdf', '', 'en-gb');
        $this->load->language('extension/novakur/module/invoice_pdf');

        $query = 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $order_id;

        $buttons = '<a href="' . $this->url->link('extension/novakur/module/invoice_pdf.invoice', $query) . '" target="_blank" data-bs-toggle="tooltip" title="' . htmlspecialchars($this->language->get('button_print_invoice'), ENT_QUOTES, 'UTF-8') . '" class="btn btn-success"><i class="fa-solid fa-file-invoice"></i></a> ';

        if ($this->config->get('module_invoice_pdf_show_packing_slip')) {
            $buttons .= '<a href="' . $this->url->link('extension/novakur/module/invoice_pdf.packingSlip', $query) . '" target="_blank" data-bs-toggle="tooltip" title="' . htmlspecialchars($this->language->get('button_print_packing_slip'), ENT_QUOTES, 'UTF-8') . '" class="btn btn-secondary"><i class="fa-solid fa-box-open"></i></a> ';
        }

        $anchor = '<div class="float-end">';

        $position = strpos($output, $anchor);

        if ($position !== false) {
            $output = substr_replace($output, $anchor . $buttons, $position, strlen($anchor));
        }
    }
}
